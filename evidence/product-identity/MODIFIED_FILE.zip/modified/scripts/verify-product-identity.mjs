import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import assert from 'node:assert/strict';import {randomUUID,createHash} from 'node:crypto';import {spawn} from 'node:child_process';import {stringify,parse} from 'yaml';import {chromium} from '../desktop/node_modules/playwright/index.mjs';
const root=process.cwd(),e=path.join(root,'evidence/product-identity');fs.mkdirSync(e,{recursive:true});
const temporary=path.join(root,'runtime','custom-model-fixture-'+randomUUID()),home=path.join(temporary,'home'),profile=path.join(home,'profiles/web');fs.mkdirSync(path.join(profile,'node_modules/@naumi'),{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
for(const[name,folder]of [['dsh-enterprise','naumi-enterprise'],['dsh-ui-layout','naumi-ui-layout'],['dsh-sidebar-browser','naumi-sidebar-browser']])fs.symlinkSync(path.join(root,'plugins',folder),path.join(profile,'node_modules/@naumi',name),'junction');
fs.symlinkSync(path.join(root,'node_modules/@deepseek-ai'),path.join(profile,'node_modules/@deepseek-ai'),'junction');
fs.writeFileSync(path.join(profile,'package.json'),JSON.stringify({name:'naumi-custom-fixture',private:true,dsh:{profile:{bundles:['@deepseek-ai/dsh-base','@deepseek-ai/dsh-web-app','@deepseek-ai/dsh-experimental-agent-team-profile','@naumi/dsh-enterprise']}}}));
fs.writeFileSync(path.join(home,'cordis.patch.yml'),stringify([{id:'ui-theme',config:{preference:'light'}},{id:'session-log-deepseek',disabled:true}]));
const upstreamRequests=[];let holdResponse=false;const pendingResponses=[];
const upstream=http.createServer(async(req,res)=>{let body='';for await(const b of req)body+=b;upstreamRequests.push({path:req.url,authorization:req.headers.authorization,body:body?JSON.parse(body):null});
 if(req.url==='/v1/chat/completions'){res.writeHead(200,{'Content-Type':'text/event-stream'});const finish=()=>res.end('data: '+JSON.stringify({id:'fixture-chat',object:'chat.completion.chunk',created:1,model:'fixture-model',choices:[{index:0,delta:{role:'assistant',content:'OK'},finish_reason:null}]})+'\n\ndata: '+JSON.stringify({id:'fixture-chat',object:'chat.completion.chunk',created:1,model:'fixture-model',choices:[{index:0,delta:{},finish_reason:'stop'}],usage:{prompt_tokens:1,completion_tokens:1,total_tokens:2}})+'\n\ndata: [DONE]\n\n');if(holdResponse){pendingResponses.push(finish);res.flushHeaders();}else finish();return;}
 res.writeHead(404).end();
});await new Promise(r=>upstream.listen(0,'127.0.0.1',r));const apiURL='http://127.0.0.1:'+upstream.address().port+'/v1';
const originalProfile={displayName:'原有分组',api:'openai-completions',baseURL:apiURL,apiKeyEnv:'NAUMI_FIXTURE_KEY',models:[{id:'fixture-model',name:'原有模型',contextWindow:128000,maxTokens:1024,reasoningEfforts:false}]};
fs.writeFileSync(path.join(profile,'cordis.patch.yml'),stringify([{id:'ui-settings-general',config:{welcomeNoticeVersion:'2026-09-28.1'}},{id:'llm-pi-ai',config:{providers:{existing:originalProfile}}}]));
const socket=http.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));const base='http://127.0.0.1:'+port;
const env={...process.env,DSH_HOME:home,DSH_TELEMETRY_MODE:'DISABLED',NAUMI_FIXTURE_KEY:'original-fixture-key'};
let output='',browser;const child=spawn(process.execPath,[path.join(root,'node_modules/@deepseek-ai/dsh/lib/bin.js'),'web','--host','127.0.0.1','--port',String(port),'--no-open'],{cwd:root,env,windowsHide:true});child.stdout.on('data',b=>output+=b);child.stderr.on('data',b=>output+=b);
const checks=[];function check(name,condition){assert(condition,name);checks.push(name);console.log('AUTH_PASS '+name);}
try{
 let launch;for(let i=0;i<180;i++){launch=output.match(new RegExp('http://127\\.0\\.0\\.1:'+port+'/?\\?token=[A-Za-z0-9_~.%-]+'))?.[0];if(launch)break;if(child.exitCode!==null)throw Error('FIXTURE_BOOT_FAILED '+output.replace(/token=[A-Za-z0-9_~.%-]+/g,'token=REDACTED').slice(-4000));await new Promise(r=>setTimeout(r,500));}assert(launch,'FIXTURE_BOOT_TIMEOUT '+output.slice(-1500));
 const exchange=await fetch(launch,{redirect:'manual'}),cookie=exchange.headers.getSetCookie().map(v=>v.split(';')[0]).join('; ');assert(cookie);const headers={cookie,'Content-Type':'application/json','x-naumi-model-connections':'1',origin:base};
 async function call(body){const r=await fetch(base+'/naumi/model-connections',{headers,...body?{method:'POST',body:JSON.stringify(body)}:{}});return {status:r.status,value:await r.json()};}
 async function rpc(method,args={}){const r=await fetch(base+'/api/'+method,{method:'POST',headers,body:JSON.stringify({type:'client-request',rpcId:randomUUID(),method,payload:{args}})});const t=await r.text();try{return JSON.parse(t);}catch{return {http:r.status};}}
 let result=await call();check('actual_host_owner_http',result.status===200&&result.value.groups.length===1);const before=result.value;
 check('existing_group_metadata_preserved',before.groups[0].id==='existing'&&before.groups[0].models[0].name==='原有模型'&&before.groups[0].configured);
 const account=await rpc('account/watch',{});check('official_account_remote_unmounted',!account.result?.ok);
 const html=await (await fetch(base,{headers})).text();check('account_and_official_models_not_in_boot_roster',!html.includes('@deepseek-ai/dsh-client-ui-settings-account')&&!html.includes('@deepseek-ai/dsh-client-ui-settings-models'));
 result=await call({action:'save',id:'custom-team',expectedRevision:before.revision,displayName:'团队连接',baseURL:apiURL,api:'openai-completions',apiKey:'custom-fixture-key',models:[{id:'fixture-model'}]});check('actual_settings_save_live',result.status===200&&result.value.groups.length===2);
 let persisted=parse(fs.readFileSync(path.join(profile,'cordis.patch.yml'),'utf8')).find(x=>x.id==='llm-pi-ai').config.providers;
 check('existing_group_bytes_unchanged',sha(JSON.stringify(persisted.existing))===sha(JSON.stringify(originalProfile)));
 check('key_stored_outside_profile',!fs.readFileSync(path.join(profile,'cordis.patch.yml'),'utf8').includes('custom-fixture-key')&&fs.readFileSync(path.join(home,'.credentials.yaml'),'utf8').includes('custom-fixture-key'));
 check('key_never_returned',!JSON.stringify(result).includes('custom-fixture-key'));
 const stale=await call({action:'remove',id:'existing',expectedRevision:before.revision});check('actual_revision_conflict',stale.status===409);
 // Real headless Harness pipeline uses the same profile/credentials and new custom adapter route.
 const overlay=path.join(temporary,'probe.yml');fs.writeFileSync(overlay,stringify([{id:'agent-default-model',config:{provider:'custom-team',model:'fixture-model'}},{id:'credentials',disabled:false}]));
 // The headless profile needs the same model config and the account-free product bundle.
 const hp=path.join(home,'profiles/headless');fs.mkdirSync(hp,{recursive:true});fs.writeFileSync(path.join(hp,'package.json'),JSON.stringify({name:'naumi-headless-fixture',private:true,dsh:{profile:{bundles:['@deepseek-ai/dsh-base','@deepseek-ai/dsh-headless']}}}));fs.symlinkSync(path.join(profile,'node_modules'),path.join(hp,'node_modules'),'junction');fs.writeFileSync(path.join(hp,'cordis.patch.yml'),stringify([{id:'llm-pi-ai',config:{providers:persisted}},...['deepseek-account','llm-deepseek','llm-deepseek-account','session-log-deepseek','web-search-deepseek','web-deepseek-api'].map(id=>({id,disabled:true}))]));
 const probe=await new Promise(resolve=>{const p=spawn(process.execPath,[path.join(root,'node_modules/@deepseek-ai/dsh/lib/bin.js'),'--profile','headless','--patch',overlay,'Reply exactly OK. Do not use tools.'],{cwd:root,env,windowsHide:true});let text='';p.stdout.on('data',b=>text+=b);p.stderr.on('data',b=>text+=b);const timer=setTimeout(()=>p.kill(),60000);p.on('close',code=>{clearTimeout(timer);resolve({code,text});});});
 if(probe.code!==0)fs.writeFileSync(path.join(temporary,'failed-probe.log'),probe.text.replaceAll('custom-fixture-key','REDACTED'));
 check('custom_url_key_real_harness_model_call',probe.code===0&&/\bOK\b/.test(probe.text)&&upstreamRequests.some(r=>r.path==='/v1/chat/completions'&&r.authorization==='Bearer custom-fixture-key'&&r.body.model==='fixture-model'));
 browser=await chromium.launch({headless:true,channel:'chrome'});const context=await browser.newContext({viewport:{width:1360,height:900},colorScheme:'light'}),page=await context.newPage(),errors=[],outbound=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',route=>{const u=new URL(route.request().url());if(['http:','https:'].includes(u.protocol)&&u.origin!==base){outbound.push(u.hostname);return route.abort();}return route.continue();});
 await page.goto(launch);await page.waitForFunction(()=>document.body.getAttribute('data-naumi')==='enterprise');
 // Open native settings with the native launcher. No replacement page or injected React renderer.
 const settingsButton=page.getByRole('button',{name:/设置|Settings/}).first();await settingsButton.click();
 const modelsNav=page.getByRole('button',{name:'模型连接',exact:true});await modelsNav.click();const panel=page.locator('.nm-connections');await panel.getByRole('heading',{name:'团队连接',exact:true}).waitFor();
 check('real_settings_slot_and_light_ui',await panel.isVisible()&&await panel.evaluate(el=>getComputedStyle(el).backgroundColor==='rgb(255, 255, 255)'));
 check('no_official_login_or_onboarding',await page.getByText(/登录 DeepSeek|DeepSeek 账号|DeepSeek Account|Sign in to DeepSeek/).count()===0);
 await panel.getByRole('button',{name:'添加连接',exact:true}).click();await panel.getByLabel('分组名称',{exact:true}).fill('界面验证');await panel.getByLabel('API URL',{exact:true}).fill(apiURL);await panel.getByLabel('API Key',{exact:true}).fill('ui-fixture-key');await panel.getByLabel('模型 ID（每行一个）',{exact:true}).fill('fixture-model');await panel.getByRole('button',{name:'保存',exact:true}).click();await panel.getByRole('heading',{name:'界面验证',exact:true}).waitFor();check('ui_save_reaches_actual_settings_and_credentials',(await call()).value.groups.some(g=>g.displayName==='界面验证'&&g.configured));
 const card=panel.locator('article').filter({has:page.getByRole('heading',{name:'界面验证',exact:true})});await card.getByRole('button',{name:'编辑',exact:true}).click();check('existing_key_not_echoed',await panel.getByLabel('API Key',{exact:true}).inputValue()==='');
 await panel.getByLabel('分组名称',{exact:true}).fill('保留冲突草稿');const latest=(await call()).value;await call({action:'save',id:'other',expectedRevision:latest.revision,displayName:'并发修改',baseURL:apiURL,api:'openai-responses',apiKey:'parallel-fixture-key',models:[{id:'fixture-model'}]});await panel.getByRole('button',{name:'保存',exact:true}).click();await panel.getByRole('button',{name:'重新载入',exact:true}).waitFor();check('ui_conflict_keeps_draft',await panel.getByLabel('分组名称',{exact:true}).inputValue()==='保留冲突草稿'&&await panel.getByRole('button',{name:'保存',exact:true}).isDisabled());await panel.getByRole('button',{name:'重新载入',exact:true}).click();await panel.getByRole('heading',{name:'并发修改',exact:true}).waitFor();
 await panel.getByRole('button',{name:'添加连接',exact:true}).click();for(const width of [1360,580,360]){await page.setViewportSize({width,height:900});check('responsive_'+width,await panel.evaluate(el=>el.scrollWidth<=el.clientWidth+2));}
 await page.screenshot({path:path.join(e,'model-connections-narrow.png')});await page.setViewportSize({width:1360,height:900});await page.screenshot({path:path.join(e,'model-connections.png')});

 check('product_tab_title',await page.title()==='Naumi');
 await page.getByRole('button',{name:'通用设置',exact:true}).click();
 await page.getByText('Naumi 0.3.2',{exact:true}).waitFor();check('product_version_not_engine_version',await page.getByText('Naumi 0.3.2',{exact:true}).isVisible());
 await page.keyboard.press('Escape');
 const workspaceResult=await rpc('workspace/create',{request:{path:temporary}});assert(workspaceResult.result?.ok,JSON.stringify(workspaceResult));await page.getByRole('button',{name:'AI 协作',exact:true}).click();
 await page.getByRole('button',{name:'选择工作区',exact:true}).click();await page.getByText(path.basename(temporary),{exact:true}).last().click();
 const input=page.locator('[contenteditable="true"]').first();await input.waitFor();holdResponse=true;await input.fill('Reply exactly OK. Do not use tools.');await input.press('Enter');
 const running=page.locator('[data-chat-running]:not([data-holding])').first();await running.waitFor({state:'visible'});
 await page.waitForFunction(()=>document.querySelector('[data-chat-running]:not([data-holding])')?.textContent.includes('Naumi 正在处理'));
 check('native_running_copy_is_naumi',(await running.innerText()).includes('Naumi 正在处理'));
 const icon=running.locator('[class$="_runningIcon"]');check('native_running_logo_is_naumi',await icon.evaluate(el=>getComputedStyle(el).backgroundImage.includes('/naumi/assets/symbol.svg')&&[...el.children].every(c=>getComputedStyle(c).display==='none')));
 await page.emulateMedia({reducedMotion:'reduce'});check('running_logo_reduced_motion',await icon.evaluate(el=>getComputedStyle(el).animationName==='none'));await page.emulateMedia({reducedMotion:'no-preference'});
 await page.screenshot({path:path.join(e,'running-naumi.png')});check('visible_product_identity_only',!/DeepSeek|深度求索/.test(await page.locator('body').innerText()));
 for(let i=0;!pendingResponses.length&&i<200;i++)await new Promise(r=>setTimeout(r,50));assert(pendingResponses.length,'LOCAL_SUPPLIER_REQUEST_NOT_REACHED');holdResponse=false;for(const finish of pendingResponses.splice(0))finish();await running.waitFor({state:'hidden'});
 check('no_browser_page_errors',errors.length===0);check('no_vendor_network_requests',!outbound.some(h=>/deepseek/.test(h)));
 fs.writeFileSync(path.join(e,'INTEGRATION.json'),JSON.stringify({checks,passed:checks.length,pageErrors:errors,upstream:'isolated-http-sse-fixture',realSupplierCalls:0,liveEmployeeWrites:0,officialAccountMounted:false},null,2)+'\n');console.log('PRODUCT_IDENTITY_COMPLETE checks='+checks.length+' errors='+errors.length+' supplier_calls=0');
}catch(error){const page=browser?.contexts()[0]?.pages()[0];if(page){await page.screenshot({path:path.join(temporary,'failed-page.png')});fs.writeFileSync(path.join(temporary,'failed-ui.txt'),(await page.locator('body').innerText())+'\nBUTTONS\n'+(await page.getByRole('button').allTextContents()).join('|'));}throw error;}finally{await browser?.close();child.kill();await new Promise(r=>child.exitCode!==null?r():child.once('close',r));upstream.closeAllConnections();await new Promise(r=>upstream.close(r));
 // Keep private fixture for diagnostic reproducibility; it is under ignored runtime, never packaged.
}

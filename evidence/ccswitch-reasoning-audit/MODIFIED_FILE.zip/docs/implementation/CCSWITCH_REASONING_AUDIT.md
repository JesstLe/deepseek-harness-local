# CC Switch 模型复核与推理档位

日期：2026-11-17。负责人：当前任务；基线 541830103b4cd2782a3f8621f012c625932c95d1；分支 codex/ccswitch-reasoning-audit-20261117；独立 worktree E:/Workspace/naumi-model-reasoning-audit。首次同步主线 e16b369。功能迭代 1。

## 模块与职责
只读复核 CC Switch 来源、当前桌面绑定的实际 3080 后端，补齐模型连接配置和原生推理档位。凭据值不进入证据、Git 或日志。当前 18 个来源、8 个已导入分组、38 个模型；8 组密钥匹配，38 条原生目录均缺 reasoning。10 条路由各做一次原生小请求，6 条成功；对 4 条失败再定向检查一次，Kimi/open 配额错误，OpenCode/LAN 仍失败，保留原连接，不因模型列表 401/404 删除可用推理路由。

## 公共接口、依赖方向、数据/状态/事务归属
复用原 ModelConnections、settings 原始配置/CAS、credentials、PiAiAdapter、原生输入器旁模型/推理选择器和 Session 模型选择持久化。官方能力目录仅提供精确 ID 推荐；供应商代理支持与官方规格分开验收。未知别名保留，不按名字猜能力。

原生缺口：添加包含 off 的能力映射时，无指定档位会被 pi-ai 当作显式关闭。增加 opt-in preserveReasoningDefault，仅在已声明能力且未指定档位时，把 dispatch 副本的 off 设为 null；目录仍公开真实 off 能力，显式关闭仍发送 none/disabled。扩展脚本固定原始 SHA、原子替换、原始备份，sync 和打包共用；未启用路由不改变。

## 本次实现与迁移状态
开发中。模型连接页增加每模型官方/继承/关闭/自定义能力与协议模式，连接默认档位仅接受所有模型共有能力。继续复用原生选择器，不新增第二个发送区或全局拦截。预算、默认模型、凭据、会话消息、后台任务不随能力导入改变。

## 验证命令、结果及证据层级
基线 node --test tests/naumi-model-connections.test.mjs tests/naumi-model-specs.test.mjs tests/naumi-model-discovery.test.mjs：44/44。来源只读审计、模型列表和真实路由样例见 evidence/ccswitch-reasoning-audit；不是每模型全量可用证明。后续集中覆盖真实原生适配器 mock wire、设置 HTTP/CAS、原生目录/Session 档位、UI、全量与副本回滚。

## 未完成项与下一步
完成配置与原生扩展、官方映射验证、实际配置增量、集中验收、四件套、普通合并推送及运行接入。不打断正在运行的对话，不宣称未测模型可用。

window.__ModuleLoader__.load({
	id: "@deepseek-ai/dsh-client-ui-conversation",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		//#region \0rolldown/runtime.js
		var __create = Object.create;
		var __defProp = Object.defineProperty;
		var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
		var __getOwnPropNames = Object.getOwnPropertyNames;
		var __getProtoOf = Object.getPrototypeOf;
		var __hasOwnProp = Object.prototype.hasOwnProperty;
		var __copyProps = (to, from, except, desc) => {
			if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
				key = keys[i];
				if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
					get: ((k) => from[k]).bind(null, key),
					enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
				});
			}
			return to;
		};
		var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
			value: mod,
			enumerable: true
		}) : target, mod));
		//#endregion
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
		let _deepseek_ai_dsh_client_store = require("@deepseek-ai/dsh-client-store");
		let _deepseek_ai_dsh_client_ui_slots = require("@deepseek-ai/dsh-client-ui-slots");
		let _deepseek_ai_cordis = require("@deepseek-ai/cordis");
		let react_jsx_runtime = require("react/jsx-runtime");
		let react = require("react");
		react = __toESM(react, 1);
		let zod = require("zod");
		let react_dom = require("react-dom");
		//#region ../../../vendor/cosmokit/lib/index.js
		/** Return true when a value is `null` or `undefined`. */
		function isNullable(value) {
			return value === null || value === void 0;
		}
		/** Return true for non-array object values. */
		function isPlainObject(data) {
			return data && typeof data === "object" && !Array.isArray(data);
		}
		/** Filter object entries and return a new object. */
		function filterKeys(object, filter) {
			return Object.fromEntries(Object.entries(object).filter(([key, value]) => filter(key, value)));
		}
		/** Map object values while preserving the original key set. */
		function mapValues(object, transform) {
			return Object.fromEntries(Object.entries(object).map(([key, value]) => [key, transform(value, key)]));
		}
		/** Pick selected keys from an object, optionally including `undefined` values. */
		function pick(source, keys, forced) {
			if (!keys) return { ...source };
			const result = {};
			for (const key of keys) if (forced || source[key] !== void 0) result[key] = source[key];
			return result;
		}
		/** Shared config references used by schema validators and plugin runtimes. */
		const write = Symbol.for("cosmokit.volatile.write");
		function snapshot(value, ancestors = /* @__PURE__ */ new Set()) {
			if (typeof value === "function") throw new TypeError("volatile config cannot contain functions");
			if (value === null || typeof value !== "object") return value;
			if (ancestors.has(value)) throw new TypeError("volatile config cannot contain cycles");
			ancestors.add(value);
			try {
				if (Array.isArray(value)) return Object.freeze(value.map((item) => snapshot(item, ancestors)));
				if (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) throw new TypeError("volatile config objects must be plain objects or arrays");
				return Object.freeze(Object.fromEntries(Object.entries(value).map(([key, item]) => [key, snapshot(item, ancestors)])));
			} finally {
				ancestors.delete(value);
			}
		}
		/**
		* Create a detached reference containing an immutable copy of the supplied data.
		* @param value - validated config data; class instances and functions are unsupported.
		* @returns a reference whose value is updated only by its owning runtime.
		*/
		function createVolatile(value) {
			let current = snapshot(value);
			return Object.freeze({
				get: () => current,
				[write]: (value) => {
					current = value;
				}
			});
		}
		/**
		* Identify references across ESM/CJS copies of the shared library.
		* @param value - a parsed config value.
		* @returns whether the value implements the shared reference protocol.
		*/
		function isVolatile(value) {
			return typeof value === "object" && value !== null && write in value;
		}
		/** Test values using `instanceof` with a `toStringTag` fallback. */
		function is$1(type, value) {
			if (arguments.length === 1) return (value) => is$1(type, value);
			return type in globalThis && value instanceof globalThis[type] || Object.prototype.toString.call(value).slice(8, -1) === type;
		}
		function isArrayBufferLike(value) {
			return is$1("ArrayBuffer", value) || is$1("SharedArrayBuffer", value);
		}
		function isArrayBufferSource(value) {
			return isArrayBufferLike(value) || ArrayBuffer.isView(value);
		}
		/** Binary source detection and base64/hex conversion helpers. */
		var Binary;
		(function(Binary) {
			Binary.is = isArrayBufferLike;
			Binary.isSource = isArrayBufferSource;
			function fromSource(source) {
				if (ArrayBuffer.isView(source)) return source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
				else return source;
			}
			Binary.fromSource = fromSource;
			function toBase64(source) {
				source = fromSource(source);
				if (typeof Buffer !== "undefined") return Buffer.from(source).toString("base64");
				let binary = "";
				const bytes = new Uint8Array(source);
				for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
				return btoa(binary);
			}
			Binary.toBase64 = toBase64;
			function fromBase64(source) {
				if (typeof Buffer !== "undefined") return fromSource(Buffer.from(source, "base64"));
				return Uint8Array.from(atob(source), (c) => c.charCodeAt(0));
			}
			Binary.fromBase64 = fromBase64;
			function toHex(source) {
				source = fromSource(source);
				if (typeof Buffer !== "undefined") return Buffer.from(source).toString("hex");
				return Array.from(new Uint8Array(source), (byte) => byte.toString(16).padStart(2, "0")).join("");
			}
			Binary.toHex = toHex;
			function fromHex(source) {
				if (typeof Buffer !== "undefined") return fromSource(Buffer.from(source, "hex"));
				const hex = source.length % 2 === 0 ? source : source.slice(0, source.length - 1);
				const buffer = [];
				for (let i = 0; i < hex.length; i += 2) buffer.push(parseInt(`${hex[i]}${hex[i + 1]}`, 16));
				return Uint8Array.from(buffer).buffer;
			}
			Binary.fromHex = fromHex;
		})(Binary || (Binary = {}));
		Binary.fromBase64;
		Binary.toBase64;
		Binary.fromHex;
		Binary.toHex;
		/** Deep-clone common JavaScript values while preserving prototypes and cycles. */
		function clone(source, refs = /* @__PURE__ */ new Map()) {
			if (!source || typeof source !== "object") return source;
			if (is$1("Date", source)) return new Date(source.valueOf());
			if (is$1("RegExp", source)) return new RegExp(source.source, source.flags);
			if (isArrayBufferLike(source)) return source.slice(0);
			if (ArrayBuffer.isView(source)) return source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
			const cached = refs.get(source);
			if (cached) return cached;
			if (Array.isArray(source)) {
				const result = [];
				refs.set(source, result);
				source.forEach((value, index) => {
					result[index] = Reflect.apply(clone, null, [value, refs]);
				});
				return result;
			}
			const result = Object.create(Object.getPrototypeOf(source));
			refs.set(source, result);
			for (const key of Reflect.ownKeys(source)) {
				const descriptor = { ...Reflect.getOwnPropertyDescriptor(source, key) };
				if ("value" in descriptor) descriptor.value = Reflect.apply(clone, null, [descriptor.value, refs]);
				Reflect.defineProperty(result, key, descriptor);
			}
			return result;
		}
		/**
		* Compare values recursively, treating two volatile references as equal regardless of value.
		* Strict comparison distinguishes null/undefined, treats opaque objects by identity,
		* compares URLs by normalized href, treats array holes as undefined, and considers distinct cyclic structures unequal.
		* @param a - first value.
		* @param b - second value.
		* @param strict - whether to require strict data equality outside volatile references.
		* @returns whether the values compare equal.
		*/
		function deepEqual(a, b, strict) {
			const ancestors = /* @__PURE__ */ new Set();
			function compare(a, b) {
				if (a === b) return true;
				if (isVolatile(a) || isVolatile(b)) return isVolatile(a) && isVolatile(b);
				if (!strict && isNullable(a) && isNullable(b)) return true;
				if (typeof a !== typeof b || typeof a !== "object" || !a || !b) return false;
				if (ancestors.has(a)) return false;
				function check(test, then) {
					return test(a) ? test(b) ? then(a, b) : false : test(b) ? false : void 0;
				}
				ancestors.add(a);
				try {
					return check(Array.isArray, (a, b) => {
						if (a.length !== b.length) return false;
						for (let index = 0; index < a.length; index++) if (!compare(a[index], b[index])) return false;
						return true;
					}) ?? check(is$1("Date"), (a, b) => a.valueOf() === b.valueOf()) ?? check(is$1("URL"), (a, b) => a.href === b.href) ?? check(is$1("RegExp"), (a, b) => a.source === b.source && a.flags === b.flags) ?? check(isArrayBufferLike, (a, b) => {
						if (a.byteLength !== b.byteLength) return false;
						const viewA = new Uint8Array(a);
						const viewB = new Uint8Array(b);
						for (let i = 0; i < viewA.length; i++) if (viewA[i] !== viewB[i]) return false;
						return true;
					}) ?? ((!strict || [a, b].every((value) => Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null)) && Object.keys({
						...a,
						...b
					}).every((key) => compare(a[key], b[key])));
				} finally {
					ancestors.delete(a);
				}
			}
			return compare(a, b);
		}
		/** Time constants plus parsing and formatting helpers. */
		var Time;
		(function(Time) {
			Time.millisecond = 1;
			Time.second = 1e3;
			Time.minute = Time.second * 60;
			Time.hour = Time.minute * 60;
			Time.day = Time.hour * 24;
			Time.week = Time.day * 7;
			let timezoneOffset = (/* @__PURE__ */ new Date()).getTimezoneOffset();
			function setTimezoneOffset(offset) {
				timezoneOffset = offset;
			}
			Time.setTimezoneOffset = setTimezoneOffset;
			function getTimezoneOffset() {
				return timezoneOffset;
			}
			Time.getTimezoneOffset = getTimezoneOffset;
			function getDateNumber(date = /* @__PURE__ */ new Date(), offset) {
				if (typeof date === "number") date = new Date(date);
				if (offset === void 0) offset = timezoneOffset;
				return Math.floor((date.valueOf() / Time.minute - offset) / 1440);
			}
			Time.getDateNumber = getDateNumber;
			function fromDateNumber(value, offset) {
				const date = new Date(value * Time.day);
				if (offset === void 0) offset = timezoneOffset;
				return new Date(+date + offset * Time.minute);
			}
			Time.fromDateNumber = fromDateNumber;
			const numeric = /\d+(?:\.\d+)?/.source;
			const timeRegExp = new RegExp(`^${[
				"w(?:eek(?:s)?)?",
				"d(?:ay(?:s)?)?",
				"h(?:our(?:s)?)?",
				"m(?:in(?:ute)?(?:s)?)?",
				"s(?:ec(?:ond)?(?:s)?)?"
			].map((unit) => `(${numeric}${unit})?`).join("")}$`);
			function parseTime(source) {
				const capture = timeRegExp.exec(source);
				if (!capture) return 0;
				return (parseFloat(capture[1]) * Time.week || 0) + (parseFloat(capture[2]) * Time.day || 0) + (parseFloat(capture[3]) * Time.hour || 0) + (parseFloat(capture[4]) * Time.minute || 0) + (parseFloat(capture[5]) * Time.second || 0);
			}
			Time.parseTime = parseTime;
			function parseDate(date) {
				const parsed = parseTime(date);
				if (parsed) date = Date.now() + parsed;
				else if (/^\d{1,2}(:\d{1,2}){1,2}$/.test(date)) date = `${(/* @__PURE__ */ new Date()).toLocaleDateString()}-${date}`;
				else if (/^\d{1,2}-\d{1,2}-\d{1,2}(:\d{1,2}){1,2}$/.test(date)) date = `${(/* @__PURE__ */ new Date()).getFullYear()}-${date}`;
				return date ? new Date(date) : /* @__PURE__ */ new Date();
			}
			Time.parseDate = parseDate;
			function format(ms) {
				const abs = Math.abs(ms);
				if (abs >= Time.day - Time.hour / 2) return Math.round(ms / Time.day) + "d";
				else if (abs >= Time.hour - Time.minute / 2) return Math.round(ms / Time.hour) + "h";
				else if (abs >= Time.minute - Time.second / 2) return Math.round(ms / Time.minute) + "m";
				else if (abs >= Time.second) return Math.round(ms / Time.second) + "s";
				return ms + "ms";
			}
			Time.format = format;
			function toDigits(source, length = 2) {
				return source.toString().padStart(length, "0");
			}
			Time.toDigits = toDigits;
			function template(template, time = /* @__PURE__ */ new Date()) {
				return template.replace("yyyy", time.getFullYear().toString()).replace("yy", time.getFullYear().toString().slice(2)).replace("MM", toDigits(time.getMonth() + 1)).replace("dd", toDigits(time.getDate())).replace("hh", toDigits(time.getHours())).replace("mm", toDigits(time.getMinutes())).replace("ss", toDigits(time.getSeconds())).replace("SSS", toDigits(time.getMilliseconds(), 3));
			}
			Time.template = template;
		})(Time || (Time = {}));
		//#endregion
		//#region ../../../vendor/schemastery/lib/index.mjs
		const kSchema = Symbol.for("schemastery");
		const kValidationError = Symbol.for("ValidationError");
		globalThis.__schemastery_index__ ??= 0;
		globalThis.__schemastery_refs__ = void 0;
		var ValidationError = class extends TypeError {
			options;
			name = "ValidationError";
			constructor(message, options) {
				let prefix = "$";
				for (const segment of options.path || []) if (typeof segment === "string") prefix += "." + segment;
				else if (typeof segment === "number") prefix += "[" + segment + "]";
				else if (typeof segment === "symbol") prefix += `[Symbol(${segment.toString()})]`;
				if (prefix.startsWith(".")) prefix = prefix.slice(1);
				super((prefix === "$" ? "" : `${prefix} `) + message);
				this.options = options;
			}
			static is(error) {
				return !!error?.[kValidationError];
			}
		};
		Object.defineProperty(ValidationError.prototype, kValidationError, { value: true });
		const Schema = function(options) {
			const schema = function(data, options = {}) {
				return Schema.resolve(data, schema, options)[0];
			};
			if (options.refs) {
				const refs = mapValues(options.refs, (options) => new Schema(options));
				const getRef = (uid) => refs[uid];
				for (const key in refs) {
					const options = refs[key];
					options.sKey = getRef(options.sKey);
					options.inner = getRef(options.inner);
					options.list = options.list && options.list.map(getRef);
					options.dict = options.dict && mapValues(options.dict, getRef);
				}
				return refs[options.uid];
			}
			Object.assign(schema, options);
			if (typeof schema.callback === "string") try {
				schema.callback = new Function("return " + schema.callback)();
			} catch {}
			Object.defineProperty(schema, "uid", { value: globalThis.__schemastery_index__++ });
			Object.setPrototypeOf(schema, Schema.prototype);
			schema.meta ||= {};
			schema.toString = schema.toString.bind(schema);
			return schema;
		};
		Schema.prototype = Object.create(Function.prototype);
		Schema.prototype[kSchema] = true;
		Object.defineProperty(Schema.prototype, "~standard", { get() {
			return {
				version: 1,
				vendor: "schemastery",
				validate: (value) => {
					try {
						return { value: Schema.resolve(value, this, {})[0] };
					} catch (error) {
						if (ValidationError.is(error)) return { issues: [{
							message: error.message,
							path: error.options.path
						}] };
						throw error;
					}
				}
			};
		} });
		Schema.ValidationError = ValidationError;
		Schema.prototype.toJSON = function toJSON() {
			if (globalThis.__schemastery_refs__) {
				globalThis.__schemastery_refs__[this.uid] ??= JSON.parse(JSON.stringify({ ...this }));
				return this.uid;
			}
			globalThis.__schemastery_refs__ = { [this.uid]: { ...this } };
			globalThis.__schemastery_refs__[this.uid] = JSON.parse(JSON.stringify({ ...this }));
			const result = {
				uid: this.uid,
				refs: globalThis.__schemastery_refs__
			};
			globalThis.__schemastery_refs__ = void 0;
			return result;
		};
		Schema.prototype.set = function set(key, value) {
			this.dict[key] = value;
			return this;
		};
		Schema.prototype.push = function push(value) {
			this.list.push(value);
			return this;
		};
		function mergeDesc(original, messages) {
			const result = typeof original === "string" ? { "": original } : { ...original };
			for (const locale in messages) {
				const value = messages[locale];
				if (value?.$description || value?.$desc) result[locale] = value.$description || value.$desc;
				else if (typeof value === "string") result[locale] = value;
			}
			return result;
		}
		function getInner(value) {
			return value?.$value ?? value?.$inner;
		}
		function extractKeys(data) {
			return filterKeys(data ?? {}, (key) => !key.startsWith("$"));
		}
		Schema.prototype.i18n = function i18n(messages) {
			const schema = Schema(this);
			const desc = mergeDesc(schema.meta.description, messages);
			if (Object.keys(desc).length) schema.meta.description = desc;
			if (schema.dict) schema.dict = mapValues(schema.dict, (inner, key) => {
				return inner.i18n(mapValues(messages, (data) => getInner(data)?.[key] ?? data?.[key]));
			});
			if (schema.list) schema.list = schema.list.map((inner, index) => {
				return inner.i18n(mapValues(messages, (data = {}) => {
					if (Array.isArray(getInner(data))) return getInner(data)[index];
					if (Array.isArray(data)) return data[index];
					return extractKeys(data);
				}));
			});
			if (schema.inner) schema.inner = schema.inner.i18n(mapValues(messages, (data) => {
				if (getInner(data)) return getInner(data);
				return extractKeys(data);
			}));
			if (schema.sKey) schema.sKey = schema.sKey.i18n(mapValues(messages, (data) => data?.$key));
			return schema;
		};
		Schema.prototype.extra = function extra(key, value) {
			const schema = Schema(this);
			schema.meta = {
				...schema.meta,
				[key]: value
			};
			return schema;
		};
		for (const key of [
			"required",
			"disabled",
			"collapse",
			"hidden",
			"loose"
		]) Object.assign(Schema.prototype, { [key](value = true) {
			const schema = Schema(this);
			schema.meta = {
				...schema.meta,
				[key]: value
			};
			return schema;
		} });
		Schema.prototype.deprecated = function deprecated() {
			const schema = Schema(this);
			schema.meta.badges ||= [];
			schema.meta.badges.push({
				text: "deprecated",
				type: "danger"
			});
			return schema;
		};
		Schema.prototype.experimental = function experimental() {
			const schema = Schema(this);
			schema.meta.badges ||= [];
			schema.meta.badges.push({
				text: "experimental",
				type: "warning"
			});
			return schema;
		};
		Schema.prototype.pattern = function pattern(regexp) {
			const schema = Schema(this);
			const pattern = pick(regexp, ["source", "flags"]);
			schema.meta = {
				...schema.meta,
				pattern
			};
			return schema;
		};
		Schema.prototype.simplify = function simplify(value) {
			if (isVolatile(value)) value = value.get();
			if (deepEqual(value, this.meta.default, this.type === "dict")) return null;
			if (isNullable(value)) return value;
			if (this.type === "object" || this.type === "dict") {
				const result = {};
				for (const key in value) {
					const item = (this.type === "object" ? this.dict[key] : this.inner)?.simplify(value[key]);
					if (this.type === "dict" || !isNullable(item)) result[key] = item;
				}
				if (deepEqual(result, this.meta.default, this.type === "dict")) return null;
				return result;
			} else if (this.type === "array" || this.type === "tuple") {
				const result = [];
				value.forEach((value, index) => {
					const schema = this.type === "array" ? this.inner : this.list[index];
					const item = schema ? schema.simplify(value) : value;
					result.push(item);
				});
				return result;
			} else if (this.type === "intersect") {
				const result = {};
				for (const item of this.list) Object.assign(result, item.simplify(value));
				return result;
			} else if (this.type === "union") for (const schema of this.list) try {
				Schema.resolve(value, schema, {});
				return schema.simplify(value);
			} catch {}
			return value;
		};
		Schema.prototype.toString = function toString(inline) {
			return formatters[this.type]?.(this, inline) ?? `Schema<${this.type}>`;
		};
		Schema.prototype.role = function role(role, extra) {
			const schema = Schema(this);
			schema.meta = {
				...schema.meta,
				role,
				extra
			};
			return schema;
		};
		for (const key of [
			"default",
			"link",
			"comment",
			"description",
			"max",
			"min",
			"step"
		]) Object.assign(Schema.prototype, { [key](value) {
			const schema = Schema(this);
			schema.meta = {
				...schema.meta,
				[key]: value
			};
			return schema;
		} });
		Schema.prototype.volatile = function volatile() {
			if (this.meta.volatile) throw new TypeError("volatile schema is already wrapped");
			return this.extra("volatile", true);
		};
		const resolvers = {};
		const checkedVolatile = Symbol("checked-volatile-schema");
		function validateVolatileSchema(schema, path = [], blocked = false, seen = /* @__PURE__ */ new Map()) {
			const states = seen.get(schema) ?? /* @__PURE__ */ new Set();
			if (states.has(blocked)) return;
			states.add(blocked);
			seen.set(schema, states);
			if (schema.meta?.volatile && blocked) throw new ValidationError("volatile fields require a fixed object path without an enclosing volatile field", { path });
			const nested = blocked || !!schema.meta?.volatile;
			if (schema.dict) for (const [key, child] of Object.entries(schema.dict)) validateVolatileSchema(child, [...path, key], nested, seen);
			if (schema.sKey) validateVolatileSchema(schema.sKey, [...path, "<key>"], true, seen);
			if (schema.inner && (schema.type !== "lazy" || schema.inner[kSchema])) validateVolatileSchema(schema.inner, [...path, "*"], true, seen);
			if (schema.list) for (let index = 0; index < schema.list.length; index++) validateVolatileSchema(schema.list[index], [...path, String(index)], true, seen);
		}
		Schema.extend = function extend(type, resolve) {
			resolvers[type] = resolve;
		};
		Schema.resolve = function resolve(data, schema, options = {}, strict = false) {
			if (!schema) return [data];
			if (!options[checkedVolatile]) {
				validateVolatileSchema(schema, options.path);
				options = {
					...options,
					[checkedVolatile]: true
				};
			}
			if (schema.meta?.volatile) {
				const inner = Schema(schema);
				inner.meta = {
					...schema.meta,
					volatile: false
				};
				const [value, adapted] = Schema.resolve(data, inner, options, strict);
				try {
					return [createVolatile(value), adapted];
				} catch (error) {
					throw new ValidationError(error instanceof Error ? error.message : String(error), options);
				}
			}
			if (options.ignore?.(data, schema)) return [data];
			if (isNullable(data) && schema.type !== "lazy") {
				if (schema.meta.required) throw new ValidationError(`missing required value`, options);
				let current = schema;
				let fallback = schema.meta.default;
				while (current?.type === "intersect" && isNullable(fallback)) {
					current = current.list[0];
					fallback = current?.meta.default;
				}
				if (isNullable(fallback)) return [data];
				data = clone(fallback);
			}
			const callback = resolvers[schema.type];
			if (!callback) throw new ValidationError(`unsupported type "${schema.type}"`, options);
			try {
				return callback(data, schema, options, strict);
			} catch (error) {
				if (!schema.meta.loose) throw error;
				return [schema.meta.default];
			}
		};
		Schema.from = function from(source) {
			if (isNullable(source)) return Schema.any();
			else if ([
				"string",
				"number",
				"boolean"
			].includes(typeof source)) return Schema.const(source).required();
			else if (source[kSchema]) return source;
			else if (typeof source === "function") switch (source) {
				case String: return Schema.string().required();
				case Number: return Schema.number().required();
				case Boolean: return Schema.boolean().required();
				case Function: return Schema.function().required();
				default: return Schema.is(source).required();
			}
			else throw new TypeError(`cannot infer schema from ${source}`);
		};
		Schema.lazy = function lazy(builder) {
			const toJSON = () => {
				if (!schema.inner[kSchema]) {
					schema.inner = schema.builder();
					schema.inner.meta = {
						...schema.meta,
						...schema.inner.meta
					};
				}
				return schema.inner.toJSON();
			};
			const schema = new Schema({
				type: "lazy",
				builder,
				inner: { toJSON }
			});
			return schema;
		};
		Schema.natural = function natural() {
			return Schema.number().step(1).min(0);
		};
		Schema.percent = function percent() {
			return Schema.number().step(.01).min(0).max(1).role("slider");
		};
		Schema.date = function date() {
			return Schema.union([Schema.is(Date), Schema.transform(Schema.string().role("datetime"), (value, options) => {
				const date = new Date(value);
				if (isNaN(+date)) throw new ValidationError(`invalid date "${value}"`, options);
				return date;
			}, true)]);
		};
		Schema.regExp = function regExp(flag = "") {
			return Schema.union([Schema.is(RegExp), Schema.transform(Schema.string().role("regexp", { flag }), (value, options) => {
				try {
					return new RegExp(value, flag);
				} catch (e) {
					throw new ValidationError(e.message, options);
				}
			}, true)]);
		};
		Schema.arrayBuffer = function arrayBuffer(encoding) {
			return Schema.union([
				Schema.is(ArrayBuffer),
				Schema.is(SharedArrayBuffer),
				Schema.transform(Schema.any(), (value, options) => {
					if (Binary.isSource(value)) return Binary.fromSource(value);
					throw new ValidationError(`expected ArrayBufferSource but got ${value}`, options);
				}, true),
				...encoding ? [Schema.transform(Schema.string(), (value, options) => {
					try {
						return encoding === "base64" ? Binary.fromBase64(value) : Binary.fromHex(value);
					} catch (e) {
						throw new ValidationError(e.message, options);
					}
				}, true)] : []
			]);
		};
		Schema.extend("lazy", (data, schema, options, strict) => {
			if (!schema.inner[kSchema]) {
				schema.inner = schema.builder();
				schema.inner.meta = {
					...schema.meta,
					...schema.inner.meta
				};
				validateVolatileSchema(schema.inner, options.path, true);
			}
			return Schema.resolve(data, schema.inner, options, strict);
		});
		Schema.extend("any", (data) => {
			return [data];
		});
		Schema.extend("never", (data, _, options) => {
			throw new ValidationError(`expected nullable but got ${data}`, options);
		});
		Schema.extend("const", (data, { value }, options) => {
			if (deepEqual(data, value)) return [value];
			throw new ValidationError(`expected ${value} but got ${data}`, options);
		});
		function checkWithinRange(data, meta, description, options, skipMin = false) {
			const { max = Infinity, min = -Infinity } = meta;
			if (data > max) throw new ValidationError(`expected ${description} <= ${max} but got ${data}`, options);
			if (data < min && !skipMin) throw new ValidationError(`expected ${description} >= ${min} but got ${data}`, options);
		}
		Schema.extend("string", (data, { meta }, options) => {
			if (typeof data !== "string") throw new ValidationError(`expected string but got ${data}`, options);
			if (meta.pattern) {
				const regexp = new RegExp(meta.pattern.source, meta.pattern.flags);
				if (!regexp.test(data)) throw new ValidationError(`expect string to match regexp ${regexp}`, options);
			}
			checkWithinRange(data.length, meta, "string length", options);
			return [data];
		});
		function decimalShift(data, digits) {
			const str = data.toString();
			if (str.includes("e")) return data * Math.pow(10, digits);
			const index = str.indexOf(".");
			if (index === -1) return data * Math.pow(10, digits);
			const frac = str.slice(index + 1);
			const integer = str.slice(0, index);
			if (frac.length <= digits) return +(integer + frac.padEnd(digits, "0"));
			return +(integer + frac.slice(0, digits) + "." + frac.slice(digits));
		}
		function isMultipleOf(data, min, step) {
			step = Math.abs(step);
			if (!/^\d+\.\d+$/.test(step.toString())) return (data - min) % step === 0;
			const index = step.toString().indexOf(".");
			const digits = step.toString().slice(index + 1).length;
			return Math.abs(decimalShift(data, digits) - decimalShift(min, digits)) % decimalShift(step, digits) === 0;
		}
		Schema.extend("number", (data, { meta }, options) => {
			if (typeof data !== "number") throw new ValidationError(`expected number but got ${data}`, options);
			checkWithinRange(data, meta, "number", options);
			const { step } = meta;
			if (step && !isMultipleOf(data, meta.min ?? 0, step)) throw new ValidationError(`expected number multiple of ${step} but got ${data}`, options);
			return [data];
		});
		Schema.extend("boolean", (data, _, options) => {
			if (typeof data === "boolean") return [data];
			throw new ValidationError(`expected boolean but got ${data}`, options);
		});
		Schema.extend("bitset", (data, { bits, meta }, options) => {
			let value = 0, keys = [];
			if (typeof data === "number") {
				value = data;
				for (const key in bits) if (data & bits[key]) keys.push(key);
			} else if (Array.isArray(data)) {
				keys = data;
				for (const key of keys) {
					if (typeof key !== "string") throw new ValidationError(`expected string but got ${key}`, options);
					if (key in bits) value |= bits[key];
				}
			} else throw new ValidationError(`expected number or array but got ${data}`, options);
			if (value === meta.default) return [value];
			return [value, keys];
		});
		Schema.extend("function", (data, _, options) => {
			if (typeof data === "function") return [data];
			throw new ValidationError(`expected function but got ${data}`, options);
		});
		Schema.extend("is", (data, { constructor }, options) => {
			if (typeof constructor === "function") {
				if (data instanceof constructor) return [data];
				throw new ValidationError(`expected ${constructor.name} but got ${data}`, options);
			} else {
				if (isNullable(data)) throw new ValidationError(`expected ${constructor} but got ${data}`, options);
				let prototype = Object.getPrototypeOf(data);
				while (prototype) {
					if (prototype.constructor?.name === constructor) return [data];
					prototype = Object.getPrototypeOf(prototype);
				}
				throw new ValidationError(`expected ${constructor} but got ${data}`, options);
			}
		});
		function property(data, key, schema, options) {
			try {
				const [value, adapted] = Schema.resolve(data[key], schema, {
					...options,
					path: [...options.path || [], key]
				});
				if (adapted !== void 0) data[key] = adapted;
				return value;
			} catch (e) {
				if (!options?.autofix) throw e;
				delete data[key];
				return schema.meta.volatile ? createVolatile(schema.meta.default) : schema.meta.default;
			}
		}
		Schema.extend("array", (data, { inner, meta }, options) => {
			if (!Array.isArray(data)) throw new ValidationError(`expected array but got ${data}`, options);
			checkWithinRange(data.length, meta, "array length", options, !isNullable(inner.meta.default));
			return [data.map((_, index) => property(data, index, inner, options))];
		});
		Schema.extend("dict", (data, { inner, sKey }, options, strict) => {
			if (!isPlainObject(data)) throw new ValidationError(`expected object but got ${data}`, options);
			const result = {};
			for (const key in data) {
				let rKey;
				try {
					rKey = Schema.resolve(key, sKey, options)[0];
				} catch (error) {
					if (strict) continue;
					throw error;
				}
				result[rKey] = property(data, key, inner, options);
				data[rKey] = data[key];
				if (key !== rKey) delete data[key];
			}
			return [result];
		});
		Schema.extend("tuple", (data, { list }, options, strict) => {
			if (!Array.isArray(data)) throw new ValidationError(`expected array but got ${data}`, options);
			const result = list.map((inner, index) => property(data, index, inner, options));
			if (strict) return [result];
			result.push(...data.slice(list.length));
			return [result];
		});
		function merge(result, data) {
			for (const key in data) {
				if (key in result) continue;
				result[key] = data[key];
			}
		}
		Schema.extend("object", (data, { dict }, options, strict) => {
			if (!isPlainObject(data)) throw new ValidationError(`expected object but got ${data}`, options);
			const result = {};
			for (const key in dict) {
				const value = property(data, key, dict[key], options);
				if (!isNullable(value) || key in data) result[key] = value;
			}
			if (!strict) merge(result, data);
			return [result];
		});
		Schema.extend("union", (data, { list, toString }, options, strict) => {
			const messages = [];
			for (const inner of list) try {
				return Schema.resolve(data, inner, options, strict);
			} catch (error) {
				messages.push(error);
			}
			throw new ValidationError(`expected ${toString()} but got ${JSON.stringify(data)}`, options);
		});
		Schema.extend("intersect", (data, { list, toString }, options, strict) => {
			if (!list.length) return [data];
			let result;
			for (const inner of list) {
				const value = Schema.resolve(data, inner, options, true)[0];
				if (isNullable(value)) continue;
				if (isNullable(result)) result = value;
				else if (typeof result !== typeof value) throw new ValidationError(`expected ${toString()} but got ${JSON.stringify(data)}`, options);
				else if (typeof value === "object") merge(result ??= {}, value);
				else if (result !== value) throw new ValidationError(`expected ${toString()} but got ${JSON.stringify(data)}`, options);
			}
			if (!strict && isPlainObject(data)) merge(result, data);
			return [result];
		});
		Schema.extend("transform", (data, { inner, callback, preserve }, options) => {
			const [result, adapted = data] = Schema.resolve(data, inner, options, true);
			if (preserve) return [callback(result)];
			else return [callback(result), callback(adapted)];
		});
		const formatters = {};
		function defineMethod(name, keys, format) {
			formatters[name] = format;
			Object.assign(Schema, { [name](...args) {
				const schema = new Schema({ type: name });
				keys.forEach((key, index) => {
					switch (key) {
						case "sKey":
							schema.sKey = args[index] ?? Schema.string();
							break;
						case "inner":
							schema.inner = Schema.from(args[index]);
							break;
						case "list":
							schema.list = args[index].map(Schema.from);
							break;
						case "dict":
							schema.dict = mapValues(args[index], Schema.from);
							break;
						case "bits":
							schema.bits = {};
							for (const key in args[index]) {
								if (typeof args[index][key] !== "number") continue;
								schema.bits[key] = args[index][key];
							}
							break;
						case "callback": {
							const callback = schema.callback = args[index];
							callback["toJSON"] ||= () => callback.toString();
							break;
						}
						case "constructor": {
							const constructor = schema.constructor = args[index];
							if (typeof constructor === "function") constructor["toJSON"] ||= () => constructor["name"];
							break;
						}
						default: schema[key] = args[index];
					}
				});
				if (name === "object" || name === "dict") schema.meta.default = {};
				else if (name === "array" || name === "tuple") schema.meta.default = [];
				else if (name === "bitset") schema.meta.default = 0;
				return schema;
			} });
		}
		defineMethod("is", ["constructor"], ({ constructor }) => {
			if (typeof constructor === "function") return constructor.name;
			else return constructor;
		});
		defineMethod("any", [], () => "any");
		defineMethod("never", [], () => "never");
		defineMethod("const", ["value"], ({ value }) => typeof value === "string" ? JSON.stringify(value) : value);
		defineMethod("string", [], () => "string");
		defineMethod("number", [], () => "number");
		defineMethod("boolean", [], () => "boolean");
		defineMethod("bitset", ["bits"], () => "bitset");
		defineMethod("function", [], () => "function");
		defineMethod("array", ["inner"], ({ inner }) => `${inner.toString(true)}[]`);
		defineMethod("dict", ["inner", "sKey"], ({ inner, sKey }) => `{ [key: ${sKey.toString()}]: ${inner.toString()} }`);
		defineMethod("tuple", ["list"], ({ list }) => `[${list.map((inner) => inner.toString()).join(", ")}]`);
		defineMethod("object", ["dict"], ({ dict }) => {
			if (Object.keys(dict).length === 0) return "{}";
			return `{ ${Object.entries(dict).map(([key, inner]) => {
				return `${key}${inner.meta.required ? "" : "?"}: ${inner.toString()}`;
			}).join(", ")} }`;
		});
		defineMethod("union", ["list"], ({ list }, inline) => {
			const result = list.map(({ toString: format }) => format()).join(" | ");
			return inline ? `(${result})` : result;
		});
		defineMethod("intersect", ["list"], ({ list }) => {
			return `${list.map((inner) => inner.toString(true)).join(" & ")}`;
		});
		defineMethod("transform", [
			"inner",
			"callback",
			"preserve"
		], ({ inner }, isInner) => inner.toString(isInner));
		//#endregion
		//#region ../../util/values/lib/index.js
		/**
		* Lazily scanned view of one JSON object's top-level fields, built from text
		* that may still be streaming or from an already parsed object. Nothing is
		* scanned until a reader asks; the view remembers every question it answered
		* and reports changed answers when the owner refreshes for publication.
		* Used for model tool-call arguments: a row reads the fields it
		* cares about at whatever granularity it displays, at every stage of the call.
		* @module @deepseek-ai/dsh-util-values/src/partial-json
		*/
		const SIMPLE_ESCAPES = {
			"\"": "\"",
			"\\": "\\",
			"/": "/",
			b: "\b",
			f: "\f",
			n: "\n",
			r: "\r",
			t: "	"
		};
		const CONTENT_ESCAPE = /[\\\u0000-\u001f]/u;
		function isWhitespace(c) {
			return c === " " || c === "\n" || c === "\r" || c === "	";
		}
		function isHex(c) {
			return c >= "0" && c <= "9" || c >= "a" && c <= "f" || c >= "A" && c <= "F";
		}
		(class PartialArguments {
			/** The view of a call with no arguments available. */
			static EMPTY = PartialArguments.fromObject({});
			/**
			* View finished argument text without scanning it until a reader asks.
			* @param text - the complete argument JSON text.
			* @returns a sealed view.
			*/
			static fromText(text) {
				const view = new PartialArguments();
				view.append(text);
				view.sealed = true;
				return view;
			}
			/**
			* View an already parsed argument payload, such as a PTC dispatch object.
			* @param value - the parsed argument value.
			* @returns a sealed view; a non-object payload has no fields.
			*/
			static fromObject(value) {
				const view = new PartialArguments();
				view.object = typeof value === "object" && value !== null && !Array.isArray(value) ? value : {};
				view.sealed = true;
				return view;
			}
			/**
			* The source: text so far or a parsed object, plus whether it can still grow.
			* These are the only enumerable fields, so two views over the same source
			* compare equal structurally however far each has been read.
			*/
			chunks = [];
			object;
			sealed = false;
			#ends = [];
			#size = 0;
			#consumed = 0;
			#mode = "root";
			#escape = false;
			#keyStart = 0;
			#keyEscaped = false;
			#key = "";
			#current = null;
			#nestedEnds = [];
			#nestedInString = false;
			#invalidAt;
			#invalidValue = false;
			#entries = /* @__PURE__ */ new Map();
			#order = [];
			#reads = /* @__PURE__ */ new Map();
			/** Whether this view rejects further appends; does not scan text or register reads. */
			get isSealed() {
				return this.sealed;
			}
			/** Whether indexing or a content read found invalid JSON; unread value contents are not validated. */
			get invalid() {
				this.scan();
				return this.#mode === "invalid" || this.#invalidValue;
			}
			/**
			* Retain streamed argument text without scanning or comparing observed answers.
			* @param fragment - the text following every fragment appended before.
			*/
			append(fragment) {
				if (this.sealed) throw new Error("PartialArguments: cannot append to a sealed view");
				if (fragment.length === 0) return;
				this.chunks.push(fragment);
				this.#size += fragment.length;
				this.#ends.push(this.#size);
			}
			/**
			* Reconcile a streamed prefix with authoritative complete text without joining the fragments.
			* @param text - the final argument text, which replaces missing or conflicting deltas.
			* @returns this view sealed with its caches retained when every character matches; otherwise a new sealed view.
			*/
			settle(text) {
				if (this.object !== void 0 || text.length !== this.#size) return PartialArguments.fromText(text);
				let offset = 0;
				for (const chunk of this.chunks) {
					if (!text.startsWith(chunk, offset)) return PartialArguments.fromText(text);
					offset += chunk.length;
				}
				this.chunks = text.length === 0 ? [] : [text];
				this.#ends = text.length === 0 ? [] : [text.length];
				this.sealed = true;
				return this;
			}
			/**
			* Compare observed answers and advance their publication baseline. Unread views remain unscanned.
			* @returns whether any observed answer changed since its first read or the preceding refresh.
			*/
			refresh() {
				if (this.#reads.size === 0) return false;
				this.scan();
				let changed = false;
				let completions = false;
				for (const read of this.#reads.values()) {
					if (read.completion) {
						completions = true;
						continue;
					}
					changed = this.refreshRead(read) || changed;
				}
				if (completions) {
					for (const read of this.#reads.values()) if (read.completion) changed = this.refreshRead(read) || changed;
				}
				if (this.sealed) this.#reads.clear();
				return changed;
			}
			refreshRead(read) {
				const now = read.answer();
				if (Object.is(now, read.last)) return false;
				read.last = now;
				return true;
			}
			/**
			* Check whether no further fields can arrive.
			* @returns whether the outer object closed, indexing failed, or the view is sealed; unread values are not validated.
			*/
			closed() {
				return this.remember("closed", "", () => this.closedNow());
			}
			/**
			* List discovered fields in first-appearance order.
			* @returns top-level keys seen so far, in first-appearance order.
			*/
			keys() {
				return this.remember("keys", "", () => this.keysNow(), (keys) => keys.length);
			}
			/**
			* Check whether a top-level field has appeared.
			* @param key - argument name.
			* @returns whether the field has appeared (a string opened or another value began).
			*/
			has(key) {
				return this.remember("has", key, () => this.hasNow(key));
			}
			/**
			* Check whether a field's closing delimiter has arrived, without validating its contents.
			* @param key - argument name.
			* @returns whether its delimiter arrived and no content reader has reported an error for this value.
			*/
			complete(key) {
				return this.remember("complete", key, () => this.completeNow(key));
			}
			/**
			* Read string length without materializing its text.
			* @param key - argument name.
			* @param options - change granularity for a streaming string.
			* @returns decoded UTF-16 length of the string field so far; undefined when absent or not a string.
			*/
			stringLength(key, options) {
				const step = Math.max(1, Math.floor(options?.step ?? 1));
				const offset = options?.offset ?? 0;
				return this.remember(`length:${step}:${offset}`, key, () => this.lengthNow(key), (length) => length === void 0 ? void 0 : Math.ceil((length + offset) / step));
			}
			/**
			* Check a string against a decoded UTF-16 length limit without materializing it.
			* @param key - argument name.
			* @param maxLength - decoded UTF-16 limit, floored to at least zero.
			* @returns whether the string is longer than the limit; false when absent or not a string.
			*/
			stringExceeds(key, maxLength) {
				const limit = Math.max(0, Math.floor(maxLength));
				return this.remember(`exceeds:${limit}`, key, () => (this.lengthNow(key, limit + 1) ?? 0) > limit);
			}
			/**
			* Read a decoded string, including a streaming prefix.
			* @param key - argument name.
			* @returns the string field's decoded text so far; undefined when absent or not a string.
			*/
			text(key) {
				return this.remember("text", key, () => this.textNow(key));
			}
			/**
			* Read at most the first decoded UTF-16 units of a string.
			* @param key - argument name.
			* @param maxLength - maximum decoded UTF-16 length, floored to at least one.
			* @returns the bounded string prefix; undefined when absent or not a string.
			*/
			textPrefix(key, maxLength) {
				const limit = Math.max(1, Math.floor(maxLength));
				return this.remember(`prefix:${limit}`, key, () => this.textPrefixNow(key, limit));
			}
			/**
			* Read a completed non-string argument.
			* @param key - argument name.
			* @returns the parsed non-string value once it closed; undefined while open, absent, or a string.
			*/
			value(key) {
				return this.remember("value", key, () => this.valueNow(key));
			}
			/** Answer a question and, on a streaming view, remember it for change detection. */
			remember(kind, key, read, comparison) {
				this.scan();
				const result = read();
				if (!this.sealed) {
					const id = `${kind}/${key}`;
					if (!this.#reads.has(id)) this.#reads.set(id, {
						completion: kind === "complete",
						answer: comparison === void 0 ? read : () => comparison(read()),
						last: comparison === void 0 ? result : comparison(result)
					});
				}
				return result;
			}
			closedNow() {
				return this.sealed || this.#mode === "closed" || this.#mode === "invalid";
			}
			keysNow() {
				return this.object === void 0 ? this.#order : Object.keys(this.object);
			}
			hasNow(key) {
				return this.object === void 0 ? this.#entries.has(key) : Object.hasOwn(this.object, key);
			}
			completeNow(key) {
				if (this.object !== void 0) return Object.hasOwn(this.object, key);
				const entry = this.#entries.get(key);
				return entry !== void 0 && entry.end >= 0 && (entry.kind === "string" ? entry.invalidAt === void 0 : !entry.invalid);
			}
			lengthNow(key, limit = Number.POSITIVE_INFINITY) {
				if (this.object !== void 0) {
					const field = Object.hasOwn(this.object, key) ? this.object[key] : void 0;
					return typeof field === "string" ? field.length : void 0;
				}
				const entry = this.#entries.get(key);
				if (entry?.kind !== "string") return void 0;
				if (entry.text !== void 0 && entry.text.at === entry.end) return entry.text.length;
				const read = entry.length ??= {
					at: entry.start,
					length: 0,
					text: ""
				};
				this.readString(entry, read, limit, false);
				return read.length;
			}
			textNow(key) {
				if (this.object !== void 0) {
					const field = Object.hasOwn(this.object, key) ? this.object[key] : void 0;
					return typeof field === "string" ? field : void 0;
				}
				const entry = this.#entries.get(key);
				if (entry?.kind !== "string") return void 0;
				if (entry.text === void 0 && entry.end >= 0 && entry.needsDecoding && entry.invalidAt === void 0) {
					let text;
					try {
						text = JSON.parse(`"${this.slice(entry.start, entry.end)}"`);
					} catch (_error) {}
					if (text !== void 0) entry.text = {
						at: entry.end,
						length: text.length,
						text
					};
				}
				const read = entry.text ??= {
					at: entry.start,
					length: 0,
					text: ""
				};
				this.readString(entry, read, Number.POSITIVE_INFINITY, true);
				return read.text;
			}
			textPrefixNow(key, maxLength) {
				if (this.object !== void 0) {
					const field = Object.hasOwn(this.object, key) ? this.object[key] : void 0;
					return typeof field === "string" ? field.slice(0, maxLength) : void 0;
				}
				const entry = this.#entries.get(key);
				if (entry?.kind !== "string") return void 0;
				const prefixes = entry.prefixes ??= /* @__PURE__ */ new Map();
				let read = prefixes.get(maxLength);
				if (read === void 0) {
					read = {
						at: entry.start,
						length: 0,
						text: ""
					};
					prefixes.set(maxLength, read);
				}
				this.readString(entry, read, maxLength, true);
				return read.text;
			}
			valueNow(key) {
				if (this.object !== void 0) {
					if (!Object.hasOwn(this.object, key)) return void 0;
					const field = this.object[key];
					return typeof field === "string" ? void 0 : field;
				}
				const entry = this.#entries.get(key);
				if (entry?.kind !== "value" || entry.end < 0 || entry.invalid) return void 0;
				if (entry.parsed === void 0) try {
					entry.parsed = JSON.parse(this.slice(entry.start, entry.end));
				} catch (_error) {
					entry.invalid = true;
					this.#invalidValue = true;
				}
				return entry.parsed;
			}
			chunkAt(at) {
				let low = 0;
				let high = this.#ends.length;
				while (low < high) {
					const mid = low + high >>> 1;
					if (this.#ends[mid] <= at) low = mid + 1;
					else high = mid;
				}
				return low;
			}
			/** Materialize only a requested range, never the cumulative source. */
			slice(start, end) {
				if (start >= end) return "";
				const first = this.chunkAt(start);
				const last = this.chunkAt(end - 1);
				const base = first === 0 ? 0 : this.#ends[first - 1];
				if (first === last) return this.chunks[first].slice(start - base, end - base);
				const parts = [this.chunks[first].slice(start - base)];
				for (let i = first + 1; i < last; i++) parts.push(this.chunks[i]);
				parts.push(this.chunks[last].slice(0, end - this.#ends[last - 1]));
				return parts.join("");
			}
			readString(entry, read, limit, materialize) {
				const end = Math.min(entry.end < 0 ? this.#consumed : entry.end, entry.invalidAt ?? Number.POSITIVE_INFINITY, this.#invalidAt ?? Number.POSITIVE_INFINITY);
				if (!entry.needsDecoding) {
					const length = Math.min(end - read.at, limit - read.length);
					if (length <= 0) return;
					if (materialize) read.text += this.slice(read.at, read.at + length);
					read.at += length;
					read.length += length;
					return;
				}
				let chunkIndex = this.chunkAt(read.at);
				while (read.at < end && read.length < limit) {
					const base = chunkIndex === 0 ? 0 : this.#ends[chunkIndex - 1];
					const chunk = this.chunks[chunkIndex];
					const remaining = chunk.slice(read.at - base, Math.min(chunk.length, end - base));
					const boundary = remaining.search(CONTENT_ESCAPE);
					const length = Math.min(boundary < 0 ? remaining.length : boundary, limit - read.length);
					if (length > 0) {
						if (materialize) read.text += remaining.slice(0, length);
						read.at += length;
						read.length += length;
						if (read.at === base + chunk.length) chunkIndex++;
						continue;
					}
					const type = remaining.length > 1 ? remaining[1] : read.at + 1 < end ? this.chunks[chunkIndex + 1][0] : void 0;
					let decoded;
					let width = 2;
					if (remaining[0] === "\\" && type === void 0 && entry.end < 0) return;
					if (remaining[0] === "\\" && type === "u") {
						const hex = this.slice(read.at + 2, Math.min(end, read.at + 6));
						let valid = true;
						for (let i = 0; i < hex.length; i++) if (!isHex(hex[i])) valid = false;
						if (valid) {
							if (hex.length < 4 && entry.end < 0) return;
							if (hex.length === 4) decoded = String.fromCharCode(Number.parseInt(hex, 16));
						}
						width = 6;
					} else if (remaining[0] === "\\" && type !== void 0) decoded = SIMPLE_ESCAPES[type];
					if (decoded === void 0) {
						entry.invalidAt = read.at;
						this.#invalidValue = true;
						return;
					}
					if (materialize) read.text += decoded;
					read.length++;
					read.at += width;
					while (chunkIndex < this.chunks.length && read.at >= this.#ends[chunkIndex]) chunkIndex++;
				}
			}
			/** Locate new field ranges without decoding or parsing their contents. */
			scan() {
				if (this.object !== void 0 || this.#consumed === this.#size) return;
				for (let i = this.chunkAt(this.#consumed); i < this.chunks.length && this.#invalidAt === void 0; i++) {
					const pending = this.chunks[i];
					const base = i === 0 ? 0 : this.#ends[i - 1];
					for (let index = this.#consumed - base; index < pending.length && this.#mode !== "invalid"; index++) {
						if (this.#mode === "string" || this.#mode === "nested" && this.#nestedInString) {
							const end = this.stringBoundary(pending, index);
							this.#consumed += end - index;
							index = end;
							if (index === pending.length) break;
						}
						this.step(pending[index], this.#consumed);
						this.#consumed++;
					}
				}
			}
			/** Only raw quotes and their preceding backslash runs can terminate a string. */
			stringBoundary(fragment, start) {
				let at = start;
				while (true) {
					const quote = fragment.indexOf("\"", at);
					const end = quote < 0 ? fragment.length : quote;
					if (this.#mode === "string") {
						const entry = this.#current;
						if (!entry.needsDecoding && CONTENT_ESCAPE.test(fragment.slice(at, end))) entry.needsDecoding = true;
					}
					let slashStart = end;
					while (slashStart > at && fragment[slashStart - 1] === "\\") slashStart--;
					const escaped = (end - slashStart) % 2 === 1 !== (slashStart === at && this.#escape);
					this.#escape = quote < 0 && escaped;
					if (quote < 0 || !escaped) return end;
					at = quote + 1;
				}
			}
			step(c, at) {
				switch (this.#mode) {
					case "root":
						if (isWhitespace(c)) return;
						if (c === "{") {
							this.#mode = "key-or-end";
							return;
						}
						this.fail();
						return;
					case "key-or-end":
						if (isWhitespace(c)) return;
						if (c === "}") {
							this.#mode = "closed";
							return;
						}
						if (c === "\"") {
							this.beginKey(at);
							return;
						}
						this.fail();
						return;
					case "key-only":
						if (isWhitespace(c)) return;
						if (c === "\"") {
							this.beginKey(at);
							return;
						}
						this.fail();
						return;
					case "key":
						this.stepKey(c, at);
						return;
					case "colon":
						if (isWhitespace(c)) return;
						if (c === ":") {
							this.#mode = "value";
							return;
						}
						this.fail();
						return;
					case "value":
						this.beginValue(c, at);
						return;
					case "string": {
						const entry = this.#current;
						entry.end = at;
						this.#current = null;
						this.#mode = "comma-or-end";
						return;
					}
					case "scalar":
						this.stepScalar(c, at);
						return;
					case "nested":
						this.stepNested(c, at);
						return;
					case "comma-or-end":
						if (isWhitespace(c)) return;
						if (c === ",") {
							this.#mode = "key-only";
							return;
						}
						if (c === "}") {
							this.#mode = "closed";
							return;
						}
						this.fail();
						return;
					case "closed":
						if (isWhitespace(c)) return;
						this.fail();
						return;
					/* v8 ignore next 2 -- scan() stops stepping once the view is invalid. */
					case "invalid": return;
					/* v8 ignore next 2 -- Every scanner mode has a handler above. */
					default: assertNever$1(this.#mode);
				}
			}
			fail() {
				this.#invalidAt = this.#consumed;
				this.#mode = "invalid";
				this.#current = null;
			}
			beginKey(at) {
				this.#mode = "key";
				this.#keyStart = at + 1;
				this.#keyEscaped = false;
				this.#escape = false;
			}
			stepKey(c, at) {
				if (c < " ") {
					this.fail();
					return;
				}
				if (this.#escape) {
					this.#escape = false;
					return;
				}
				if (c === "\\") {
					this.#escape = true;
					this.#keyEscaped = true;
					return;
				}
				if (c !== "\"") return;
				const raw = this.slice(this.#keyStart, at);
				if (this.#keyEscaped) try {
					this.#key = JSON.parse(`"${raw}"`);
				} catch (_error) {
					this.fail();
					return;
				}
				else this.#key = raw;
				this.#mode = "colon";
			}
			open(entry) {
				if (!this.#entries.has(this.#key)) this.#order.push(this.#key);
				this.#entries.set(this.#key, entry);
				this.#current = entry;
			}
			beginValue(c, at) {
				if (isWhitespace(c)) return;
				if (c === "\"") {
					this.open({
						kind: "string",
						start: at + 1,
						end: -1,
						needsDecoding: false,
						invalidAt: void 0,
						length: void 0,
						text: void 0,
						prefixes: void 0
					});
					this.#escape = false;
					this.#mode = "string";
					return;
				}
				if (c === "}" || c === "," || c === ":" || c === "]") {
					this.fail();
					return;
				}
				this.open({
					kind: "value",
					start: at,
					end: -1,
					parsed: void 0,
					invalid: false
				});
				if (c === "{" || c === "[") {
					this.#mode = "nested";
					this.#nestedEnds = [c === "{" ? "}" : "]"];
					this.#nestedInString = false;
					this.#escape = false;
					return;
				}
				this.#mode = "scalar";
			}
			stepScalar(c, at) {
				if (c !== "," && c !== "}" && !isWhitespace(c)) return;
				this.closeValue(at);
				this.#mode = c === "," ? "key-only" : c === "}" ? "closed" : "comma-or-end";
			}
			stepNested(c, at) {
				if (this.#nestedInString) {
					this.#nestedInString = false;
					return;
				}
				if (c === "\"") {
					this.#nestedInString = true;
					return;
				}
				if (c === "{" || c === "[") {
					this.#nestedEnds.push(c === "{" ? "}" : "]");
					return;
				}
				if (c === "}" || c === "]") {
					if (this.#nestedEnds.pop() !== c) {
						this.fail();
						return;
					}
					if (this.#nestedEnds.length === 0) {
						this.closeValue(at + 1);
						this.#mode = "comma-or-end";
					}
				}
			}
			closeValue(end) {
				const entry = this.#current;
				entry.end = end;
				this.#current = null;
			}
		});
		/** Duplicate-install-safe JSON and immutable-value helpers. @module @deepseek-ai/dsh-util-values */
		/**
		* Mark an unreachable closed-union branch.
		* @param value - impossible value; an unhandled typed variant fails at the call site.
		* @param context - optional switch-site label included in the failure message.
		* @returns never; a runtime value that escaped its type always throws.
		*/
		function assertNever$1(value, context) {
			const rendered = JSON.stringify(value) ?? String(value);
			throw new Error(`unreachable variant${context ? ` in ${context}` : ""}: ${rendered}`);
		}
		/**
		* Weak-key lookup with a strongly retained iterable set of associated values.
		*
		* Each value must belong to only one key. The container performs no automatic
		* cleanup; owners delete associations or clear the container at lifecycle end.
		*/
		var WeakMapWithValues = class {
			keys = /* @__PURE__ */ new WeakMap();
			valueSet = /* @__PURE__ */ new Set();
			/** Live strongly retained values in insertion order. */
			values = this.valueSet;
			/**
			* Read the value associated with a key.
			* @param key - weakly held lookup key.
			* @returns the associated value, or absence.
			*/
			get(key) {
				return this.keys.get(key);
			}
			/**
			* Test whether a key has an association.
			* @param key - weakly held lookup key.
			* @returns whether the key is present.
			*/
			has(key) {
				return this.keys.has(key);
			}
			/**
			* Associate one key with one caller-unique value.
			* @param key - weakly held lookup key.
			* @param value - strongly retained value that belongs to no other key.
			* @returns this container.
			*/
			set(key, value) {
				if (this.keys.has(key)) {
					const previous = this.keys.get(key);
					if (previous === value) return this;
					this.valueSet.delete(previous);
				}
				this.keys.set(key, value);
				this.valueSet.add(value);
				return this;
			}
			/**
			* Remove one association and its strongly retained value.
			* @param key - weakly held lookup key.
			* @returns whether an association was removed.
			*/
			delete(key) {
				if (!this.keys.has(key)) return false;
				const value = this.keys.get(key);
				const deleted = this.keys.delete(key);
				this.valueSet.delete(value);
				return deleted;
			}
			/** Remove every association and strongly retained value. */
			clear() {
				this.keys = /* @__PURE__ */ new WeakMap();
				this.valueSet.clear();
			}
		};
		//#endregion
		//#region lib/types/client/contract/request-inspection.js
		/**
		* Canonicalize one request header against the system node in force and
		* classify the model-visible prompt change.
		* @param previous - Prompt from the preceding loaded request header, when available.
		* @param event - Durable full request header to inspect.
		* @param system - Effective nonempty system prompt after loaded surface replacements; empty when removed.
		* An in-history update already presented its text at its own position, so the header reports no system change for it.
		* @returns The canonical prompt and an initial/system/tool change when it can be established.
		*/
		function inspectRequestPrompt(previous, event, system) {
			const header = event.data.header;
			const rawTools = header.tools;
			const prompt = {
				config: header.config,
				system: system?.text ?? "",
				tools: Array.isArray(rawTools) ? rawTools : []
			};
			if (previous === void 0 && event.data.reason !== "initial") return { prompt };
			const systemChanged = previous !== void 0 && previous.system !== prompt.system && system?.update !== true;
			const toolsChanged = previous !== void 0 && JSON.stringify(previous.tools) !== JSON.stringify(prompt.tools);
			if (previous !== void 0 && !systemChanged && !toolsChanged) return { prompt };
			const origin = system !== void 0 && (previous === void 0 || systemChanged) ? system : event;
			return {
				prompt,
				change: {
					seq: origin.seq,
					time: origin.time,
					kind: previous === void 0 ? "initial" : systemChanged && toolsChanged ? "system-and-tools" : systemChanged ? "system" : "tools",
					...previous === void 0 ? {} : { previous }
				}
			};
		}
		//#endregion
		//#region ../../core/session/lib/types/surface.js
		/** Runtime counterpart of the message-producing event union. */
		const SURFACE_EVENT_TYPES = new Set([
			"system/message",
			"developer/message",
			"user/message",
			"assistant/message",
			"tool/result"
		]);
		/**
		* Narrow an event to a surface-eligible event carrying its required marker.
		* @param event - event to test.
		* @returns true when both the type and marker identify a surface event.
		*/
		function isSurfaceEvent(event) {
			if (!SURFACE_EVENT_TYPES.has(event.type)) return false;
			return event.surfaceOp !== void 0;
		}
		//#endregion
		//#region lib/types/client/contract/system-prompt.js
		/**
		* Apply a system event or positional replacement without retaining ordinary messages.
		* Replacement positions inherit their start endpoint, not their chronological seq.
		* Unknown older endpoint order withholds the prompt until prepend replay resolves it.
		* @param previous - Interpretation at the preceding relevant event in the loaded window.
		* @param event - System message or surface replacement already admitted by Session.
		* @returns Immutable surviving system facts and the effective nonempty prompt.
		*/
		function inspectSystemPrompt(previous, event) {
			const op = isSurfaceEvent(event) ? event.surfaceOp : void 0;
			const firstSeq = previous?.firstSeq ?? event.seq;
			let nodes = previous?.nodes ?? [];
			let replacements = previous?.replacements ?? /* @__PURE__ */ new Map();
			const unknownEndpoint = (seq) => seq < firstSeq && !replacements.has(seq);
			const uncertain = previous?.uncertain === true || op !== void 0 && op !== "append" && (unknownEndpoint(op.startSeq) || unknownEndpoint(op.endSeq));
			if (uncertain) return {
				firstSeq,
				uncertain,
				nodes: [],
				replacements: /* @__PURE__ */ new Map(),
				effective: void 0,
				introduced: void 0
			};
			let position = event.seq;
			if (op !== void 0 && op !== "append") {
				position = replacements.get(op.startSeq) ?? op.startSeq;
				const end = replacements.get(op.endSeq) ?? op.endSeq;
				nodes = nodes.filter((item) => item.position < position || item.position > end);
				const retained = new Map([...replacements].filter(([, value]) => value < position || value > end));
				retained.set(event.seq, position);
				replacements = retained;
			}
			const introduced = event.type === "system/message" ? {
				seq: event.seq,
				time: event.time,
				turn: event.data.turn,
				step: event.data.step,
				text: event.data.message.content.flatMap((block) => block.type === "text" ? [block.text] : []).join(""),
				update: op === "append" && previous?.nodes.some((item) => item.node.text !== "") === true
			} : void 0;
			if (introduced !== void 0) nodes = [...nodes, {
				position,
				node: introduced
			}].sort((a, b) => a.position - b.position);
			const surviving = nodes.findLast((item) => item.node.text !== "")?.node;
			const effective = surviving === previous?.nodes.findLast((item) => item.node.text !== "")?.node ? previous?.effective : introduced !== void 0 && introduced === surviving ? introduced : {
				seq: event.seq,
				time: event.time,
				turn: surviving?.turn ?? 0,
				step: surviving?.step ?? 0,
				text: surviving?.text ?? "",
				update: false
			};
			return {
				firstSeq,
				uncertain,
				nodes,
				replacements,
				effective,
				introduced
			};
		}
		//#endregion
		//#region lib/types/client/contract/conversation.js
		/**
		* Build a stable collision-free key for one Definition-local business identity.
		* @param kind - Definition kind.
		* @param id - Definition-local business identity.
		* @returns engine-owned Context key.
		*/
		function conversationContextKey(kind, id) {
			return `${kind.length}:${kind}${id}`;
		}
		//#endregion
		//#region lib/types/client/conversation/group-store.js
		/** Keyed group publication and incremental validation of rendering positions. */
		function sameNodeReference(left, right) {
			return left.key === right.key && left.groupPart === right.groupPart;
		}
		function sameEntry(left, right) {
			return left.kind === right.kind && left.key === right.key && (left.kind === "group" || right.kind === "node" && left.groupPart === right.groupPart);
		}
		function reuseReferences(previous, next, equal) {
			return previous === next || previous.length === next.length && previous.every((value, index) => equal(value, next[index])) ? previous : next;
		}
		/** Validates a complete batch before installing its group and root-list changes. */
		var ConversationGroupStore = class {
			root = [];
			rootGroups = /* @__PURE__ */ new Set();
			groups = /* @__PURE__ */ new Map();
			placements = /* @__PURE__ */ new Map();
			sources = /* @__PURE__ */ new Map();
			dirty = /* @__PURE__ */ new Set();
			/** @returns the identity-stable ordered root references. */
			get entries() {
				return this.root;
			}
			groupSource(key) {
				let source = this.sources.get(key);
				if (source === void 0) {
					const publication = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(this.groups.get(key));
					source = {
						publication,
						observable: {
							getSnapshot: () => this.groups.get(key),
							subscribe: (listener) => publication.subscribe(listener)
						}
					};
					this.sources.set(key, source);
				}
				return source.observable;
			}
			/**
			* Install one validated update without notifying readers.
			* @param update - root replacement and complete or incremental group records.
			* @param readNode - synchronous reader of the current target Nodes.
			*/
			prepareAndInstall(update, readNode) {
				const nextRoot = update.entries === void 0 ? this.root : reuseReferences(this.root, update.entries, sameEntry);
				const nextRootGroups = nextRoot === this.root ? this.rootGroups : this.collectRootGroups(nextRoot);
				const { upserts, removes } = this.collectChanges(update);
				const replaceReferences = update.groups.kind === "replace";
				if (this.groups.size - removes.size + [...upserts.keys()].filter((key) => !this.groups.has(key)).length !== nextRootGroups.size) throw new Error("conversation group records and root references must correspond one-to-one");
				for (const key of removes) if (nextRootGroups.has(key)) throw new Error(`conversation group "${key}" is still referenced`);
				for (const key of upserts.keys()) if (!nextRootGroups.has(key)) throw new Error(`conversation group "${key}" has no root reference`);
				if (nextRootGroups !== this.rootGroups) {
					for (const key of nextRootGroups) if (!upserts.has(key) && !this.groups.has(key)) throw new Error(`conversation root references missing group "${key}"`);
				}
				const affectedParts = /* @__PURE__ */ new Map();
				const partsOf = (key) => {
					let parts = affectedParts.get(key);
					if (parts === void 0) {
						parts = new Set(this.placements.get(key));
						affectedParts.set(key, parts);
					}
					return parts;
				};
				const removeReference = (reference) => {
					partsOf(reference.key).delete(reference.groupPart);
				};
				const addReference = (reference) => {
					if (readNode(reference.key) === void 0) throw new Error(`conversation group references missing Node "${reference.key}"`);
					const parts = partsOf(reference.key);
					if (parts.has(reference.groupPart) || reference.groupPart === void 0 && parts.size > 0 || parts.has(void 0)) throw new Error(`conversation Node "${reference.key}" has overlapping rendering positions`);
					parts.add(reference.groupPart);
				};
				if (replaceReferences || nextRoot !== this.root) {
					for (const entry of this.root) if (entry.kind === "node") removeReference(entry);
				}
				for (const key of removes) for (const member of this.groups.get(key).members) removeReference(member);
				for (const [key, next] of upserts) {
					const previous = this.groups.get(key);
					if (previous !== void 0 && (replaceReferences || previous.members !== next.members)) for (const member of previous.members) removeReference(member);
				}
				if (replaceReferences || nextRoot !== this.root) {
					for (const entry of nextRoot) if (entry.kind === "node") addReference(entry);
				}
				for (const [key, next] of upserts) if (replaceReferences || this.groups.get(key)?.members !== next.members) for (const member of next.members) addReference(member);
				for (const [key, parts] of affectedParts) if (parts.size === 0) this.placements.delete(key);
				else this.placements.set(key, parts);
				for (const key of removes) {
					this.groups.delete(key);
					this.dirty.add(key);
				}
				for (const [key, next] of upserts) {
					if (this.groups.get(key) === next) continue;
					this.groups.set(key, next);
					this.dirty.add(key);
				}
				this.root = nextRoot;
				this.rootGroups = nextRootGroups;
			}
			/** Publish changed group sources after all related target data has been installed. */
			publish() {
				const keys = [...this.dirty];
				this.dirty.clear();
				for (const key of keys) this.sources.get(key)?.publication.set(this.groups.get(key));
			}
			/** Remove grouping without deleting its source Nodes; publication remains deferred. */
			clear() {
				this.prepareAndInstall(
					{
						entries: [],
						groups: {
							kind: "replace",
							snapshots: []
						}
					},
					/* v8 ignore next -- an empty replacement never reads a Node reference. */
					() => void 0
				);
			}
			collectRootGroups(entries) {
				const keys = /* @__PURE__ */ new Set();
				for (const entry of entries) {
					if (entry.kind !== "group") continue;
					if (keys.has(entry.key)) throw new Error(`conversation group "${entry.key}" has duplicate root references`);
					keys.add(entry.key);
				}
				return keys;
			}
			collectChanges(update) {
				const upserts = /* @__PURE__ */ new Map();
				const removes = /* @__PURE__ */ new Set();
				const add = (snapshot) => {
					if (upserts.has(snapshot.key)) throw new Error(`conversation group "${snapshot.key}" has duplicate upserts`);
					const previous = this.groups.get(snapshot.key);
					if (previous === void 0) {
						upserts.set(snapshot.key, snapshot);
						return;
					}
					const members = reuseReferences(previous.members, snapshot.members, sameNodeReference);
					upserts.set(snapshot.key, previous.data === snapshot.data && previous.members === members ? previous : {
						...snapshot,
						members
					});
				};
				switch (update.groups.kind) {
					case "replace":
						for (const snapshot of update.groups.snapshots) add(snapshot);
						for (const key of this.groups.keys()) if (!upserts.has(key)) removes.add(key);
						break;
					case "apply":
						for (const snapshot of update.groups.upserts) add(snapshot);
						for (const key of update.groups.removes) {
							if (removes.has(key)) throw new Error(`conversation group "${key}" has duplicate removals`);
							if (!this.groups.has(key)) throw new Error(`conversation group "${key}" cannot be removed because it is absent`);
							if (upserts.has(key)) throw new Error(`conversation group "${key}" cannot be upserted and removed together`);
							removes.add(key);
						}
						break;
					/* v8 ignore next 2 -- closed update union; TypeScript rejects other operation tags. */
					default: assertNever$1(update.groups);
				}
				return {
					upserts,
					removes
				};
			}
		};
		//#endregion
		//#region lib/types/client/conversation/location-index.js
		var MutableLocationDataSource = class {
			store;
			key;
			listeners = /* @__PURE__ */ new Set();
			published;
			constructor(store, key) {
				this.store = store;
				this.key = key;
				this.published = store.get(key);
			}
			getSnapshot = () => this.store.get(this.key);
			subscribe = (listener) => {
				this.listeners.add(listener);
				return () => {
					this.listeners.delete(listener);
				};
			};
			publish() {
				const next = this.getSnapshot();
				if (this.published === next) return;
				this.published = next;
				(0, _deepseek_ai_dsh_client_store.notifySubscribers)(this.listeners, `[ui-conversation] Location data ${this.key}`);
			}
		};
		var MutableLocationDataStore = class {
			markDirty;
			entries = /* @__PURE__ */ new Map();
			sources = /* @__PURE__ */ new Map();
			dirtyKeys = /* @__PURE__ */ new Set();
			constructor(markDirty) {
				this.markDirty = markDirty;
			}
			get(key) {
				return this.entries.get(key)?.value;
			}
			source(key) {
				let source = this.sources.get(key);
				if (source === void 0) {
					source = new MutableLocationDataSource(this, key);
					this.sources.set(key, source);
				}
				return source;
			}
			remove(owner, key) {
				if (this.entries.get(key)?.owner !== owner) return false;
				this.entries.delete(key);
				this.changed(key);
				return true;
			}
			set(owner, key, value) {
				const current = this.entries.get(key);
				if (current !== void 0 && current.owner !== owner) throw new Error(`conversation Location data "${key}" is already owned by ${current.owner}`);
				if (current?.value === value) return false;
				this.entries.set(key, {
					owner,
					value
				});
				this.changed(key);
				return true;
			}
			replace(entries) {
				const changedKeys = [];
				for (const key of new Set([...this.entries.keys(), ...entries.keys()])) {
					const current = this.entries.get(key);
					const next = entries.get(key);
					if (current?.owner !== next?.owner || current?.value !== next?.value) changedKeys.push(key);
				}
				if (changedKeys.length === 0) return false;
				this.entries = new Map(entries);
				for (const key of changedKeys) this.changed(key);
				return true;
			}
			publish() {
				const dirty = [...this.dirtyKeys];
				this.dirtyKeys.clear();
				for (const key of dirty) this.sources.get(key)?.publish();
			}
			changed(key) {
				this.dirtyKeys.add(key);
				this.markDirty(this);
			}
		};
		const SESSION_LOCATION = { kind: "session" };
		const UNRESOLVED_LOCATION = { kind: "unresolved" };
		function payloadCoordinates(event) {
			const data = event.data;
			if (data.turn === null) return {
				session: true,
				location: void 0
			};
			const turn = Number.isSafeInteger(data.turn) && data.turn >= 0 ? data.turn : void 0;
			const step = Number.isSafeInteger(data.step) && data.step >= 0 ? data.step : void 0;
			if (turn === void 0) return step === void 0 ? { location: void 0 } : {
				step,
				location: void 0
			};
			return step === void 0 ? {
				turn,
				location: void 0
			} : {
				turn,
				step,
				location: void 0
			};
		}
		function sameReferences(left, right) {
			return left.length === right.length && left.every((value, index) => value === right[index]);
		}
		function sameStep(left, right) {
			return left !== void 0 && left.start === right.start && left.end === right.end && left.status === right.status && left.data === right.data;
		}
		function sameTurn(left, right) {
			return left !== void 0 && left.start === right.start && left.end === right.end && left.status === right.status && left.data === right.data && sameReferences(left.steps, right.steps);
		}
		function sameLocation(left, right) {
			if (left === void 0 || right === void 0 || left.kind !== right.kind) return left === right;
			if (left.kind === "session" || left.kind === "unresolved") return true;
			if (right.kind === "session" || right.kind === "unresolved") return false;
			if (left.kind === "turn" || right.kind === "turn") return left.kind === "turn" && right.kind === "turn" && left.turn === right.turn;
			return left.turn === right.turn && left.step === right.step;
		}
		/** Session-owned Turn/Step timeline and event-to-Location index. */
		var ConversationLocationIndex = class {
			coordinates = /* @__PURE__ */ new Map();
			seqsByTurn = /* @__PURE__ */ new Map();
			stepsByTurn = /* @__PURE__ */ new Map();
			timeline = {
				turnOrder: [],
				turns: /* @__PURE__ */ new Map()
			};
			turnDataStores = /* @__PURE__ */ new Map();
			stepDataStores = /* @__PURE__ */ new Map();
			dirtyDataStores = /* @__PURE__ */ new Set();
			changedTurns = /* @__PURE__ */ new Set();
			currentTurn;
			currentStep;
			/**
			* Return the current reference-stable timeline.
			* @returns current timeline snapshot.
			*/
			snapshot() {
				return this.timeline;
			}
			/**
			* Drain the Turn changes accumulated for one assembly flush.
			* @returns Turn identities changed since the preceding drain.
			*/
			takeChangedTurns() {
				const turns = [...this.changedTurns];
				this.changedTurns.clear();
				return turns;
			}
			/**
			* Replace all Definition-owned Location values while preserving reader identities.
			* @param entries - complete current set of Definition-owned Location values.
			* @returns whether any published Location data changed.
			*/
			replaceData(entries) {
				const turns = /* @__PURE__ */ new Map();
				const steps = /* @__PURE__ */ new Map();
				for (const { owner, data } of entries) {
					const values = data.kind === "turn" ? turns.get(data.turn) ?? /* @__PURE__ */ new Map() : steps.get(stepDataKey(data.turn, requireStep(data))) ?? /* @__PURE__ */ new Map();
					const current = values.get(data.key);
					if (current !== void 0 && current.owner !== owner) throw new Error(`conversation Location data "${data.key}" is already owned by ${current.owner}`);
					values.set(data.key, {
						owner,
						value: data.value
					});
					if (data.kind === "turn") turns.set(data.turn, values);
					else steps.set(stepDataKey(data.turn, requireStep(data)), values);
				}
				let changed = false;
				for (const turn of new Set([...this.turnDataStores.keys(), ...turns.keys()])) changed = this.mutableTurnData(turn).replace(turns.get(turn) ?? /* @__PURE__ */ new Map()) || changed;
				for (const step of new Set([...this.stepDataStores.keys(), ...steps.keys()])) changed = this.mutableStepData(step).replace(steps.get(step) ?? /* @__PURE__ */ new Map()) || changed;
				return changed;
			}
			/**
			* Apply changed Context publications without rebuilding Turn/Step membership.
			* @param changes - incremental removals and replacements from published Contexts.
			* @returns whether any published Location data changed.
			*/
			applyData(changes) {
				let changed = false;
				for (const change of changes) {
					const previous = change.previous;
					if (previous === null) continue;
					changed = this.storeFor(previous).remove(change.owner, previous.key) || changed;
				}
				for (const change of changes) {
					const next = change.next;
					if (next === null) continue;
					changed = this.storeFor(next).set(change.owner, next.key, next.value) || changed;
				}
				return changed;
			}
			/** Publish committed Location-data changes to their keyed sources. */
			publishData() {
				const dirty = [...this.dirtyDataStores];
				this.dirtyDataStores.clear();
				for (const store of dirty) store.publish();
			}
			/**
			* Resolve the latest Location for one event.
			* @param event - event already ingested into this index.
			* @returns current Location, falling back to session when it has no Turn/Step affinity.
			*/
			locationOf(event) {
				return this.coordinates.get(event.seq)?.location ?? SESSION_LOCATION;
			}
			/**
			* Rebuild timeline facts after replace/prepend or a boundary append.
			* @param entries - complete current window in ascending seq order.
			* @returns seqs whose resolved Location changed.
			*/
			rebuild(entries) {
				const previousCoordinates = this.coordinates;
				const turns = /* @__PURE__ */ new Map();
				const coordinates = /* @__PURE__ */ new Map();
				let currentTurn;
				let currentStep;
				const turnDraft = (turn, seq) => {
					let draft = turns.get(turn);
					if (draft === void 0) {
						draft = {
							turn,
							firstSeq: seq,
							steps: /* @__PURE__ */ new Map()
						};
						turns.set(turn, draft);
					} else draft.firstSeq = Math.min(draft.firstSeq, seq);
					return draft;
				};
				const stepDraft = (turn, step, seq) => {
					const owner = turnDraft(turn, seq);
					let draft = owner.steps.get(step);
					if (draft === void 0) {
						draft = {
							turn,
							step,
							firstSeq: seq
						};
						owner.steps.set(step, draft);
					} else draft.firstSeq = Math.min(draft.firstSeq, seq);
					return draft;
				};
				for (const { event } of entries) {
					const explicit = payloadCoordinates(event);
					if (event.type === "turn/start") {
						currentTurn = event.data.turn;
						currentStep = void 0;
					}
					if (event.type === "step/start") {
						currentTurn = event.data.turn;
						currentStep = event.data.step;
					}
					if (explicit.session !== true && explicit.turn !== void 0) {
						if (currentTurn !== explicit.turn) currentStep = void 0;
						currentTurn = explicit.turn;
						if (explicit.step !== void 0) currentStep = explicit.step;
					}
					const turn = explicit.session === true ? void 0 : explicit.turn ?? currentTurn;
					const step = explicit.session === true || event.type === "turn/start" || event.type === "turn/end" ? void 0 : explicit.step ?? (turn === currentTurn ? currentStep : void 0);
					coordinates.set(event.seq, {
						...turn === void 0 ? {} : { turn },
						...turn === void 0 || step === void 0 ? {} : { step },
						location: void 0
					});
					if (turn !== void 0) turnDraft(turn, event.seq);
					if (turn !== void 0 && step !== void 0) stepDraft(turn, step, event.seq);
					if (event.type === "turn/start") turnDraft(event.data.turn, event.seq).start = event;
					else if (event.type === "turn/end") turnDraft(event.data.turn, event.seq).end = event;
					else if (event.type === "step/start") stepDraft(event.data.turn, event.data.step, event.seq).start = event;
					else if (event.type === "step/end") stepDraft(event.data.turn, event.data.step, event.seq).end = event;
					if (event.type === "step/end" && currentTurn === event.data.turn && currentStep === event.data.step) currentStep = void 0;
					if (event.type === "turn/end" && currentTurn === event.data.turn) {
						currentTurn = void 0;
						currentStep = void 0;
					}
				}
				const previousTurns = this.timeline.turns;
				const nextTurns = /* @__PURE__ */ new Map();
				const orderedDrafts = [...turns.values()].sort((left, right) => left.firstSeq - right.firstSeq);
				for (const draft of orderedDrafts) {
					const previousTurn = previousTurns.get(draft.turn);
					const previousSteps = new Map(previousTurn?.steps.map((step) => [step.step, step]) ?? []);
					const steps = [...draft.steps.values()].sort((left, right) => left.firstSeq - right.firstSeq).map((candidate) => {
						const value = {
							turn: candidate.turn,
							step: candidate.step,
							start: candidate.start,
							end: candidate.end,
							status: candidate.end !== void 0 ? "closed" : candidate.start === void 0 ? "unknown" : "open",
							data: this.stepData(candidate.turn, candidate.step)
						};
						const previous = previousSteps.get(candidate.step);
						return sameStep(previous, value) ? previous : value;
					});
					const value = {
						turn: draft.turn,
						start: draft.start,
						end: draft.end,
						status: draft.end !== void 0 ? "closed" : draft.start === void 0 ? "unknown" : "open",
						steps,
						data: this.turnData(draft.turn)
					};
					nextTurns.set(draft.turn, sameTurn(previousTurn, value) ? previousTurn : value);
				}
				const nextOrder = orderedDrafts.map((draft) => draft.turn);
				const turnOrder = this.timeline.turnOrder.length === nextOrder.length && this.timeline.turnOrder.every((turn, index) => turn === nextOrder[index]) ? this.timeline.turnOrder : nextOrder;
				let sameMap = previousTurns.size === nextTurns.size;
				if (sameMap) {
					for (const [turn, value] of nextTurns) if (previousTurns.get(turn) !== value) {
						sameMap = false;
						break;
					}
				}
				for (const turn of new Set([...previousTurns.keys(), ...nextTurns.keys()])) if (previousTurns.get(turn) !== nextTurns.get(turn)) this.changedTurns.add(turn);
				this.timeline = sameMap && turnOrder === this.timeline.turnOrder ? this.timeline : {
					turnOrder,
					turns: nextTurns
				};
				this.stepsByTurn.clear();
				for (const [number, turn] of this.timeline.turns) this.stepsByTurn.set(number, new Map(turn.steps.map((step) => [step.step, step])));
				this.coordinates = coordinates;
				this.seqsByTurn = /* @__PURE__ */ new Map();
				for (const { event } of entries) {
					const coordinates = this.coordinates.get(event.seq);
					if (coordinates.turn !== void 0) this.indexTurnSeq(coordinates.turn, event.seq);
					coordinates.location = this.resolve(event.seq);
				}
				this.currentTurn = currentTurn;
				this.currentStep = currentStep;
				const changed = /* @__PURE__ */ new Set();
				for (const { event } of entries) if (!sameLocation(previousCoordinates.get(event.seq)?.location, this.coordinates.get(event.seq)?.location)) changed.add(event.seq);
				return changed;
			}
			/**
			* Append one Turn/Step boundary while revisiting only the owning Turn.
			* @param event - contiguous tail boundary event.
			* @returns seqs whose immutable Location reference changed.
			*/
			appendBoundary(event) {
				if (event.type !== "turn/start" && event.type !== "turn/end" && event.type !== "step/start" && event.type !== "step/end") throw new Error(`conversation Location boundary expected, received ${event.type}`);
				const explicit = payloadCoordinates(event);
				if (event.type === "turn/start") {
					this.currentTurn = event.data.turn;
					this.currentStep = void 0;
				} else if (event.type === "step/start") {
					this.currentTurn = event.data.turn;
					this.currentStep = event.data.step;
				}
				if (explicit.turn !== void 0) {
					if (this.currentTurn !== explicit.turn) this.currentStep = void 0;
					this.currentTurn = explicit.turn;
					if (explicit.step !== void 0) this.currentStep = explicit.step;
				}
				const turnNumber = explicit.turn ?? this.currentTurn;
				if (turnNumber === void 0) throw new Error(`conversation boundary ${event.type} has no turn`);
				const stepNumber = event.type === "turn/start" || event.type === "turn/end" ? void 0 : explicit.step ?? (turnNumber === this.currentTurn ? this.currentStep : void 0);
				this.coordinates.set(event.seq, {
					turn: turnNumber,
					...stepNumber === void 0 ? {} : { step: stepNumber },
					location: this.coordinates.get(event.seq)?.location
				});
				this.indexTurnSeq(turnNumber, event.seq);
				const previousTurn = this.timeline.turns.get(turnNumber);
				let steps = previousTurn?.steps ?? [];
				if (event.type === "step/start" || event.type === "step/end") {
					const number = event.data.step;
					const indexedSteps = this.stepsByTurn.get(turnNumber) ?? /* @__PURE__ */ new Map();
					const previousStep = indexedSteps.get(number);
					const candidate = {
						turn: turnNumber,
						step: number,
						start: event.type === "step/start" ? event : previousStep?.start,
						end: event.type === "step/end" ? event : previousStep?.end,
						status: event.type === "step/end" || previousStep?.end !== void 0 ? "closed" : "open",
						data: this.stepData(turnNumber, number)
					};
					const nextStep = sameStep(previousStep, candidate) ? previousStep : candidate;
					indexedSteps.set(number, nextStep);
					this.stepsByTurn.set(turnNumber, indexedSteps);
					const index = steps.findIndex((step) => step.step === number);
					steps = index < 0 ? [...steps, nextStep] : steps.map((step, at) => at === index ? nextStep : step);
				}
				const candidate = {
					turn: turnNumber,
					start: event.type === "turn/start" ? event : previousTurn?.start,
					end: event.type === "turn/end" ? event : previousTurn?.end,
					status: event.type === "turn/end" || previousTurn?.end !== void 0 ? "closed" : event.type === "turn/start" || previousTurn?.start !== void 0 ? "open" : "unknown",
					steps,
					data: this.turnData(turnNumber)
				};
				const turn = sameTurn(previousTurn, candidate) ? previousTurn : candidate;
				const turns = new Map(this.timeline.turns);
				turns.set(turnNumber, turn);
				const turnOrder = previousTurn === void 0 ? [...this.timeline.turnOrder, turnNumber] : this.timeline.turnOrder;
				this.timeline = {
					turnOrder,
					turns
				};
				if (turn !== previousTurn) this.changedTurns.add(turnNumber);
				const changed = /* @__PURE__ */ new Set();
				for (const seq of this.seqsByTurn.get(turnNumber) ?? []) {
					const coordinates = this.coordinates.get(seq);
					const previous = coordinates.location;
					const next = this.resolve(seq);
					coordinates.location = next;
					if (!sameLocation(previous, next)) changed.add(seq);
				}
				if (event.type === "step/end" && this.currentTurn === event.data.turn && this.currentStep === event.data.step) this.currentStep = void 0;
				if (event.type === "turn/end" && this.currentTurn === event.data.turn) {
					this.currentTurn = void 0;
					this.currentStep = void 0;
				}
				return changed;
			}
			/**
			* Index one non-boundary tail event without scanning the window or the Turn's Steps.
			* @param event - contiguous appended event.
			*/
			appendNonBoundary(event) {
				const explicit = payloadCoordinates(event);
				if (explicit.session === true) {
					this.coordinates.set(event.seq, { location: SESSION_LOCATION });
					return;
				}
				if (explicit.turn !== void 0) {
					if (this.currentTurn !== explicit.turn) this.currentStep = void 0;
					this.currentTurn = explicit.turn;
					if (explicit.step !== void 0) this.currentStep = explicit.step;
				}
				const turn = explicit.turn ?? this.currentTurn;
				const step = explicit.step ?? (turn === this.currentTurn ? this.currentStep : void 0);
				const coordinates = explicit.turn !== void 0 && explicit.step !== void 0 ? explicit : {
					...turn === void 0 ? {} : { turn },
					...turn === void 0 || step === void 0 ? {} : { step },
					location: void 0
				};
				this.coordinates.set(event.seq, coordinates);
				if (turn !== void 0) this.indexTurnSeq(turn, event.seq);
				coordinates.location = this.resolve(event.seq);
			}
			/**
			* Remove indexed Assistant transients without rebuilding the Turn/Step timeline.
			* @param events - transient events retired by one Assistant settlement.
			*/
			removeAssistantTransients(events) {
				for (const event of events) {
					const turn = this.coordinates.get(event.seq)?.turn;
					if (turn !== void 0) {
						const seqs = this.seqsByTurn.get(turn);
						seqs?.delete(event.seq);
						if (seqs?.size === 0) this.seqsByTurn.delete(turn);
					}
					this.coordinates.delete(event.seq);
				}
			}
			/**
			* Index one durable Assistant settlement inserted before an already visible tail.
			* @param event - message or attempt settlement with explicit Turn and Step coordinates.
			*/
			insertAssistantSettlement(event) {
				const coordinates = {
					turn: event.data.turn,
					step: event.data.step,
					location: void 0
				};
				this.coordinates.set(event.seq, coordinates);
				this.indexTurnSeq(event.data.turn, event.seq);
				coordinates.location = this.resolve(event.seq);
			}
			indexTurnSeq(turn, seq) {
				let current = this.seqsByTurn.get(turn);
				if (current === void 0) {
					current = /* @__PURE__ */ new Set();
					this.seqsByTurn.set(turn, current);
				}
				current.add(seq);
			}
			turnData(turn) {
				return this.mutableTurnData(turn);
			}
			stepData(turn, step) {
				return this.mutableStepData(stepDataKey(turn, step));
			}
			mutableTurnData(turn) {
				const current = this.turnDataStores.get(turn) ?? this.createDataStore(turn);
				this.turnDataStores.set(turn, current);
				return current;
			}
			mutableStepData(key) {
				const current = this.stepDataStores.get(key) ?? this.createDataStore(Number(key.slice(0, key.indexOf(":"))));
				this.stepDataStores.set(key, current);
				return current;
			}
			createDataStore(turn) {
				return new MutableLocationDataStore((store) => {
					this.dirtyDataStores.add(store);
					this.changedTurns.add(turn);
				});
			}
			storeFor(data) {
				return data.kind === "turn" ? this.mutableTurnData(data.turn) : this.mutableStepData(stepDataKey(data.turn, requireStep(data)));
			}
			resolve(seq) {
				const coordinates = this.coordinates.get(seq);
				if (coordinates?.turn === void 0) return SESSION_LOCATION;
				const turn = this.timeline.turns.get(coordinates.turn);
				if (turn === void 0) return UNRESOLVED_LOCATION;
				if (coordinates.step === void 0) return {
					kind: "turn",
					turn
				};
				const step = this.stepsByTurn.get(coordinates.turn)?.get(coordinates.step);
				return step === void 0 ? {
					kind: "turn",
					turn
				} : {
					kind: "step",
					turn,
					step
				};
			}
		};
		function stepDataKey(turn, step) {
			return `${turn}:${step}`;
		}
		function requireStep(data) {
			if (data.kind === "step" && data.step !== void 0) return data.step;
			throw new Error(`conversation Step data "${data.key}" requires a step`);
		}
		//#endregion
		//#region lib/types/client/conversation/assembler.js
		const PUBLICATION_RANK = {
			none: 0,
			"animation-frame": 1,
			immediate: 2
		};
		const LOCATION_DATA_SCOPES = ["step", "turn"];
		function emptyLocationData() {
			return {
				step: null,
				turn: null
			};
		}
		function maximumPublication(left, right) {
			return PUBLICATION_RANK[left] >= PUBLICATION_RANK[right] ? left : right;
		}
		function startSeq(context) {
			return context.startSeq;
		}
		function insertionIndex(contexts, seq) {
			let low = 0;
			let high = contexts.length;
			while (low < high) {
				const middle = low + Math.floor((high - low) / 2);
				const candidate = contexts[middle];
				if (candidate !== void 0 && candidate.startSeq < seq) low = middle + 1;
				else high = middle;
			}
			return low;
		}
		function contextSnapshot(context) {
			return {
				key: context.key,
				kind: context.kind,
				id: context.id,
				matches: context.matches,
				start: context.start,
				state: context.state,
				current: context.current
			};
		}
		function mergeMatches(key, additions, existing) {
			const merged = [];
			let added = 0;
			let current = 0;
			while (added < additions.length || current < existing.length) {
				const left = additions[added];
				const right = existing[current];
				if (left !== void 0 && right !== void 0 && left.event.seq === right.event.seq) throw new Error(`conversation Context ${key} received duplicate Match ${left.event.seq}`);
				if (right === void 0 || left !== void 0 && left.event.seq < right.event.seq) {
					merged.push(left);
					added++;
				} else {
					merged.push(right);
					current++;
				}
			}
			return merged;
		}
		function conversationMatch(input, role, location) {
			return {
				event: input.event,
				role,
				location
			};
		}
		const NO_GROUPS = {
			entries: () => [],
			forTarget: () => void 0
		};
		/**
		* Session-owned incremental engine that assembles business Contexts from a
		* contiguous Event window and materializes registered view snapshots.
		*/
		var ConversationNodeAssembler = class {
			eventDefinitions;
			viewDefinitions;
			groupDefinitions;
			contexts = /* @__PURE__ */ new Map();
			contextsByKind = /* @__PURE__ */ new Map();
			contextsBySeq = /* @__PURE__ */ new Map();
			contextsByTarget = /* @__PURE__ */ new Map();
			inputs = /* @__PURE__ */ new Map();
			locationIndex = new ConversationLocationIndex();
			dirty = /* @__PURE__ */ new Set();
			dirtyByTarget = /* @__PURE__ */ new Map();
			revised = /* @__PURE__ */ new Set();
			dependents = /* @__PURE__ */ new Map();
			views = /* @__PURE__ */ new Map();
			groups = /* @__PURE__ */ new Map();
			pendingGroupStores = /* @__PURE__ */ new Set();
			activeTargets = /* @__PURE__ */ new Set();
			/** Matches of the event in dispatch, kept by index; dispatch is not reentrant and reuses both arrays. */
			matchedDefinitions = [];
			matchedResults = [];
			hasMore = false;
			replacePending = true;
			timelineDirty = true;
			/**
			* @param eventDefinitions - live Event Definition registry.
			* @param viewDefinitions - live view builder registry.
			* @param groupDefinitions - optional registered grouping rules, independent of presentation modes.
			*/
			constructor(eventDefinitions, viewDefinitions, groupDefinitions = NO_GROUPS) {
				this.eventDefinitions = eventDefinitions;
				this.viewDefinitions = viewDefinitions;
				this.groupDefinitions = groupDefinitions;
				this.resetViewBuilders();
			}
			/**
			* Read the current open turn without activating a View.
			* @returns the latest turn number when its start is loaded and it remains open, otherwise undefined.
			*/
			openTurn() {
				const snapshot = this.locationIndex.snapshot();
				const latest = snapshot.turnOrder.at(-1);
				const turn = latest === void 0 ? void 0 : snapshot.turns.get(latest);
				return turn?.status === "open" && turn.start !== void 0 ? turn.turn : void 0;
			}
			/**
			* Replace the complete loaded window after open, resync, or gap repair.
			* @param entries - complete contiguous window.
			* @param hasMore - whether older history remains outside the window.
			* @returns immediate publication request.
			*/
			replaceWindow(entries, hasMore) {
				this.contexts.clear();
				this.contextsByKind.clear();
				this.contextsBySeq.clear();
				this.contextsByTarget.clear();
				this.inputs.clear();
				this.dirty.clear();
				this.dirtyByTarget.clear();
				this.revised.clear();
				this.dependents.clear();
				this.hasMore = hasMore;
				const sorted = [...entries].sort((left, right) => left.event.seq - right.event.seq);
				for (const entry of sorted) this.inputs.set(entry.event.seq, entry);
				this.locationIndex.rebuild(sorted);
				this.timelineDirty = true;
				for (const entry of sorted) this.matchInput(entry);
				this.replayDependencies();
				this.revised.clear();
				for (const context of this.contexts.values()) this.markDirty(context);
				this.replacePending = true;
				return "immediate";
			}
			/**
			* Add one contiguous live tail event without scanning existing Contexts.
			* @param record - appended Session event entry.
			* @returns highest requested publication cadence.
			*/
			append(record) {
				const event = record.event;
				if (this.inputs.has(event.seq)) return "none";
				if (this.revised.size > 0) this.revised.clear();
				this.inputs.set(event.seq, record);
				let publication = "none";
				if (event.type !== "assistant/live-chunk" && isLocationBoundary(event.type)) {
					const previousTimeline = this.locationIndex.snapshot();
					const changed = this.locationIndex.appendBoundary(event);
					if (this.locationIndex.snapshot() !== previousTimeline) {
						this.timelineDirty = true;
						publication = "immediate";
					}
					this.replayContexts(this.refreshMatchLocations(changed));
					if (changed.size > 0) publication = "immediate";
				} else this.locationIndex.appendNonBoundary(event);
				publication = maximumPublication(publication, this.matchInput(record));
				if (this.replayRevisedDependents()) publication = "immediate";
				if (this.revised.size > 0) this.revised.clear();
				return publication;
			}
			/**
			* Retire one Assistant attempt's transient matches and apply its optional durable settlement.
			* Empty Contexts retain their keys and published nodes until the loaded window is rebuilt;
			* Definitions may hide those nodes when no start remains instead of withdrawing their identities.
			* @param attemptId - process-local attempt whose transient presentation ended.
			* @param entry - durable message or attempt event committed for the stream.
			* @returns highest requested publication cadence.
			*/
			settleAssistant(attemptId, entry) {
				this.revised.clear();
				const retired = [...this.inputs.values()].filter((candidate) => candidate.type === "transient" && candidate.event.data.attemptId === attemptId);
				const retiredSeqs = new Set(retired.map((candidate) => candidate.event.seq));
				const affected = /* @__PURE__ */ new Set();
				for (const seq of retiredSeqs) {
					this.inputs.delete(seq);
					for (const context of this.contextsBySeq.get(seq) ?? []) affected.add(context);
					this.contextsBySeq.delete(seq);
				}
				for (const context of affected) context.matches = context.matches.filter((match) => !retiredSeqs.has(match.event.seq));
				this.locationIndex.removeAssistantTransients(retired.map((candidate) => candidate.event));
				let publication = retired.length === 0 ? "none" : "immediate";
				if (entry !== void 0 && !this.inputs.has(entry.event.seq)) {
					this.inputs.set(entry.event.seq, entry);
					this.locationIndex.insertAssistantSettlement(entry.event);
					const pending = /* @__PURE__ */ new Map();
					publication = maximumPublication(publication, this.collectInput(entry, pending));
					this.applyPendingMatches(pending, affected);
				}
				this.replayContexts(affected);
				if (this.replayRevisedDependents()) publication = "immediate";
				this.revised.clear();
				return publication;
			}
			/**
			* Add an older page while preserving existing Context and view identities.
			* @param entries - newly loaded older Events.
			* @param hasMore - whether history still precedes the expanded window.
			* @returns highest requested publication cadence.
			*/
			prepend(entries, hasMore) {
				this.revised.clear();
				let publication = "none";
				const previousHasMore = this.hasMore;
				const fresh = entries.filter((entry) => !this.inputs.has(entry.event.seq)).sort((left, right) => left.event.seq - right.event.seq);
				for (const entry of fresh) this.inputs.set(entry.event.seq, entry);
				this.hasMore = hasMore;
				const previousTimeline = this.locationIndex.snapshot();
				const changedLocations = this.locationIndex.rebuild(this.sortedInputs());
				if (this.locationIndex.snapshot() !== previousTimeline) this.timelineDirty = true;
				const affected = this.refreshMatchLocations(changedLocations);
				const pending = /* @__PURE__ */ new Map();
				for (const entry of fresh) publication = maximumPublication(publication, this.collectInput(entry, pending));
				this.applyPendingMatches(pending, affected);
				this.replayContexts(affected);
				if ((this.revised.size > 0 || previousHasMore !== hasMore) && this.replayDependencies()) publication = "immediate";
				if (changedLocations.size > 0) publication = "immediate";
				this.revised.clear();
				return publication;
			}
			/**
			* Rebuild against the current Registry set after a low-frequency plugin change.
			* @returns immediate publication request.
			*/
			rebuildRegistry() {
				this.resetViewBuilders();
				return this.replaceWindow(this.sortedInputs(), this.hasMore);
			}
			/**
			* Materialize dirty Contexts and advance every active view builder.
			* @returns whether any view snapshot was rebuilt or incrementally applied.
			*/
			flush() {
				if (!this.replacePending && this.dirty.size === 0 && !this.timelineDirty) return false;
				if (this.replacePending) {
					this.replaceLocationData();
					const updated = [];
					const changedTurns = this.locationIndex.takeChangedTurns();
					for (const target of this.activeTargets) {
						const view = this.views.get(target);
						if (view === void 0) continue;
						this.updateView(view, true, this.buildTargetNodes(target, this.contextsByTarget.get(target)), changedTurns);
						updated.push(view);
					}
					this.replacePending = false;
					this.dirty.clear();
					this.dirtyByTarget.clear();
					this.timelineDirty = false;
					return this.publishViews(updated);
				}
				const updated = [];
				if (this.applyDirtyLocationData()) this.timelineDirty = true;
				const changedTurns = this.locationIndex.takeChangedTurns();
				const timelineDirty = this.timelineDirty;
				for (const target of this.activeTargets) {
					const view = this.views.get(target);
					if (view === void 0) continue;
					if (view.builder === void 0) continue;
					const upserts = this.buildTargetUpserts(target, this.dirtyByTarget.get(target));
					if (upserts.length === 0 && !timelineDirty) continue;
					this.updateView(view, false, upserts, changedTurns);
					updated.push(view);
				}
				this.dirty.clear();
				this.dirtyByTarget.clear();
				this.timelineDirty = false;
				return this.publishViews(updated);
			}
			/**
			* Add one target to the monotonic active set and materialize its current snapshot.
			* Pending Context work is flushed before the first complete replacement.
			* @param target - registered or subsequently registered view target.
			* @returns whether any active target snapshot changed.
			*/
			activateTarget(target) {
				const view = this.views.get(target);
				if (this.activeTargets.has(target)) return false;
				const published = this.flush();
				this.activeTargets.add(target);
				if (view === void 0) return published;
				this.replaceView(view);
				this.publishViews([view]);
				return true;
			}
			/**
			* Read the latest snapshot of a registered target.
			* @param target - registered view target.
			* @returns target snapshot, or undefined before registration or activation.
			*/
			snapshot(target) {
				return this.views.get(target)?.snapshot;
			}
			get(target) {
				return this.snapshot(target);
			}
			grouped(target) {
				return this.groups.get(target)?.store;
			}
			/**
			* Read targets whose owners classify their latest snapshot as visible activity.
			* @returns target ids contributing visible activity.
			*/
			activityTargets() {
				const active = /* @__PURE__ */ new Set();
				for (const target of this.activeTargets) {
					const view = this.views.get(target);
					if (view === void 0) continue;
					if (view.isActive?.(view.snapshot) === true) active.add(view.target);
				}
				return active;
			}
			sortedInputs() {
				return [...this.inputs.values()].sort((left, right) => left.event.seq - right.event.seq);
			}
			matchInput(input) {
				return this.dispatchInput(input, this.acceptMatch);
			}
			collectInput(input, pending) {
				return this.dispatchInput(input, (definition, id, match) => {
					const key = conversationContextKey(definition.kind, id);
					const matches = pending.get(key) ?? [];
					matches.push({
						definition,
						id,
						match
					});
					pending.set(key, matches);
					return definition.publication?.(match) ?? "immediate";
				});
			}
			dispatchInput(input, accept) {
				const event = input.event;
				let startMatch;
				let updateMatch;
				let location;
				const matchFor = (role) => {
					location ??= this.locationIndex.locationOf(event);
					return role === "start" ? startMatch ??= conversationMatch(input, role, location) : updateMatch ??= conversationMatch(input, role, location);
				};
				const definitions = this.matchedDefinitions;
				const results = this.matchedResults;
				definitions.length = 0;
				results.length = 0;
				const routes = this.eventDefinitions.forEvent?.(event.type);
				if (routes === void 0) for (const definition of this.eventDefinitions.entries()) {
					const result = definition.match(event);
					if (result === null) continue;
					definitions.push(definition);
					results.push(result);
				}
				else for (const { definition, match } of routes) {
					const result = match(event);
					if (result === null) continue;
					definitions.push(definition);
					results.push(result);
				}
				let claims;
				for (let index = 0; index < results.length; index++) {
					if (results[index].exclusive !== true) continue;
					const definition = definitions[index];
					const target = definition.target;
					if (target === void 0) throw new Error(`conversation Definition "${definition.kind}" claims ${event.type} at seq ${String(event.seq)} without a target`);
					const claimant = claims?.get(target);
					if (claimant !== void 0) throw new Error(`conversation Definitions "${claimant}" and "${definition.kind}" both claim ${event.type} at seq ${String(event.seq)} on target "${target}"`);
					(claims ??= /* @__PURE__ */ new Map()).set(target, definition.kind);
				}
				let firstTarget;
				let secondTarget;
				let otherTargets;
				let publication = "none";
				for (let index = 0; index < results.length; index++) {
					const definition = definitions[index];
					const result = results[index];
					const target = definition.target;
					if (target !== void 0 && result.exclusive !== true && claims?.has(target) === true) continue;
					if (target !== void 0 && target !== firstTarget && target !== secondTarget) if (firstTarget === void 0) firstTarget = target;
					else if (secondTarget === void 0) secondTarget = target;
					else (otherTargets ??= /* @__PURE__ */ new Set()).add(target);
					publication = maximumPublication(publication, accept.call(this, definition, result.id, matchFor(result.role)));
				}
				const fallback = this.eventDefinitions.fallbackEntry();
				const target = fallback?.target;
				if (fallback !== void 0 && target !== void 0 && target !== firstTarget && target !== secondTarget && otherTargets?.has(target) !== true) {
					const result = fallback.match(event);
					if (result !== null) publication = maximumPublication(publication, accept.call(this, fallback, result.id, matchFor(result.role)));
				}
				return publication;
			}
			createContext(definition, id, key) {
				const context = {
					key,
					kind: definition.kind,
					id,
					definition,
					startSeq: void 0,
					start: void 0,
					matches: [],
					state: void 0,
					revision: 0,
					current: /* @__PURE__ */ new Map(),
					locationData: emptyLocationData(),
					dependencies: /* @__PURE__ */ new Map()
				};
				this.contexts.set(key, context);
				this.indexTargetContext(context);
				return context;
			}
			acceptMatch(definition, id, match) {
				const latest = this.contextsByKind.get(definition.kind)?.at(-1);
				const key = latest?.id === id ? latest.key : conversationContextKey(definition.kind, id);
				let context = this.contexts.get(key);
				context ??= this.createContext(definition, id, key);
				const starting = match.role === "start" && context.start === void 0;
				const previous = context.matches.at(-1);
				if (previous !== void 0 && previous.event.seq >= match.event.seq) throw new Error(`conversation Context ${key} received non-appended Match ${match.event.seq}`);
				if (starting && context.matches.length > 0) throw new Error(`conversation Context ${key} received an update before its start Match`);
				context.matches.push(match);
				if (starting) {
					context.startSeq = match.event.seq;
					context.start = match;
					this.indexStartedContext(context);
				}
				let owners = this.contextsBySeq.get(match.event.seq);
				if (owners === void 0) {
					owners = [];
					this.contextsBySeq.set(match.event.seq, owners);
				}
				owners.push(context);
				if (starting) this.replayContext(context);
				else if (context.state !== void 0) {
					const typed = contextSnapshot(context);
					context.state = requireState(definition, "update", definition.update(typed, match));
					context.revision++;
					this.revised.add(context);
				}
				this.markDirty(context);
				return definition.publication?.(match) ?? "immediate";
			}
			applyPendingMatches(pending, affected) {
				for (const [key, entries] of pending) {
					const first = entries[0];
					if (first === void 0) continue;
					let context = this.contexts.get(key);
					context ??= this.createContext(first.definition, first.id, key);
					const additions = entries.map((entry) => {
						if (entry.definition !== context.definition || entry.id !== context.id) throw new Error(`conversation Context ${key} received inconsistent Definition identity`);
						let owners = this.contextsBySeq.get(entry.match.event.seq);
						if (owners === void 0) {
							owners = [];
							this.contextsBySeq.set(entry.match.event.seq, owners);
						}
						owners.push(context);
						return entry.match;
					}).sort((left, right) => left.event.seq - right.event.seq);
					context.matches = mergeMatches(context.key, additions, context.matches);
					affected.add(context);
					this.markDirty(context);
				}
			}
			replayContexts(contexts) {
				this.refreshStarts(contexts);
				const ordered = [...contexts].sort((left, right) => (left.startSeq ?? Number.POSITIVE_INFINITY) - (right.startSeq ?? Number.POSITIVE_INFINITY));
				for (const context of ordered) {
					if (context.start === void 0) {
						context.state = void 0;
						this.replaceDependencies(context, /* @__PURE__ */ new Map());
						context.revision++;
						this.revised.add(context);
						this.markDirty(context);
						continue;
					}
					this.replayContext(context);
				}
			}
			refreshStarts(contexts) {
				const changed = /* @__PURE__ */ new Set();
				const startsByKind = /* @__PURE__ */ new Map();
				for (const context of contexts) {
					const start = context.matches.find((match) => match.role === "start");
					if (start === context.start) continue;
					context.start = start;
					context.startSeq = start?.event.seq;
					changed.add(context);
					const starts = startsByKind.get(context.kind) ?? [];
					if (start !== void 0) starts.push(context);
					startsByKind.set(context.kind, starts);
				}
				for (const [kind, starts] of startsByKind) {
					const existing = this.contextsByKind.get(kind) ?? [];
					this.contextsByKind.set(kind, existing.filter((context) => !changed.has(context)));
					this.indexStartedContexts(kind, starts);
				}
			}
			replayContext(context) {
				const start = context.start;
				if (start === void 0) {
					context.state = void 0;
					return;
				}
				if (context.matches[0] !== start) throw new Error(`conversation Context ${context.key} received an update before its start Match`);
				const dependencies = /* @__PURE__ */ new Map();
				const reader = this.readerFor(start.event.seq, dependencies);
				context.state = void 0;
				context.state = requireState(context.definition, "start", context.definition.start(contextSnapshot(context), start, reader));
				this.replaceDependencies(context, dependencies);
				for (let index = 1; index < context.matches.length; index++) {
					const match = context.matches[index];
					if (match === void 0) continue;
					const typed = contextSnapshot(context);
					context.state = requireState(context.definition, "update", context.definition.update(typed, match));
				}
				context.revision++;
				this.revised.add(context);
				this.markDirty(context);
			}
			indexTargetContext(context) {
				const target = context.definition.target;
				if (target === void 0) return;
				const contexts = this.contextsByTarget.get(target) ?? /* @__PURE__ */ new Set();
				contexts.add(context);
				this.contextsByTarget.set(target, contexts);
			}
			markDirty(context) {
				if (this.dirty.has(context)) return;
				this.dirty.add(context);
				const target = context.definition.target;
				if (target === void 0 || !this.activeTargets.has(target)) return;
				let contexts = this.dirtyByTarget.get(target);
				if (contexts === void 0) {
					contexts = /* @__PURE__ */ new Set();
					this.dirtyByTarget.set(target, contexts);
				}
				contexts.add(context);
			}
			replaceDependencies(context, dependencies) {
				for (const dependency of context.dependencies.values()) {
					if (dependency.key === void 0) continue;
					const current = this.dependents.get(dependency.key);
					current?.delete(context);
					if (current?.size === 0) this.dependents.delete(dependency.key);
				}
				context.dependencies = dependencies;
				for (const dependency of dependencies.values()) {
					if (dependency.key === void 0) continue;
					const current = this.dependents.get(dependency.key) ?? /* @__PURE__ */ new Set();
					current.add(context);
					this.dependents.set(dependency.key, current);
				}
			}
			replayRevisedDependents() {
				if (this.dependents.size === 0) return false;
				const pending = [...this.revised];
				const affected = /* @__PURE__ */ new Set();
				for (let index = 0; index < pending.length; index++) {
					const dependency = pending[index];
					if (dependency === void 0) continue;
					for (const dependent of this.dependents.get(dependency.key) ?? []) {
						if (affected.has(dependent)) continue;
						affected.add(dependent);
						pending.push(dependent);
					}
				}
				if (affected.size > 0) this.replayContexts(affected);
				return affected.size > 0;
			}
			readerFor(beforeSeq, dependencies) {
				return { previous: (kind) => {
					const predecessor = this.previousContext(kind, beforeSeq);
					dependencies.set(kind, {
						kind,
						key: predecessor?.key,
						revision: predecessor?.revision,
						windowGap: predecessor === void 0 && this.hasMore
					});
					if (predecessor?.state === void 0) return void 0;
					const seq = startSeq(predecessor);
					if (seq === void 0) return void 0;
					return {
						key: predecessor.key,
						kind: predecessor.kind,
						id: predecessor.id,
						startSeq: seq,
						state: predecessor.state,
						matches: predecessor.matches
					};
				} };
			}
			previousContext(kind, beforeSeq) {
				const candidates = this.contextsByKind.get(kind) ?? [];
				const indexBefore = insertionIndex(candidates, beforeSeq);
				for (let index = indexBefore - 1; index >= 0; index--) {
					const candidate = candidates[index];
					if (candidate?.state !== void 0) return candidate;
				}
			}
			/** Insert one newly discovered start into its Definition's ordered predecessor index. */
			indexStartedContext(context) {
				const seq = context.startSeq;
				if (seq === void 0) return;
				const candidates = this.contextsByKind.get(context.kind) ?? [];
				const previous = candidates.at(-1);
				if (previous === void 0 || previous.startSeq < seq) candidates.push(context);
				else candidates.splice(insertionIndex(candidates, seq), 0, context);
				this.contextsByKind.set(context.kind, candidates);
			}
			indexStartedContexts(kind, additions) {
				if (additions.length === 0) return;
				const sorted = [...additions].sort((left, right) => left.startSeq - right.startSeq);
				const existing = this.contextsByKind.get(kind) ?? [];
				const merged = [];
				let before = 0;
				let added = 0;
				while (before < existing.length || added < sorted.length) {
					const left = existing[before];
					const right = sorted[added];
					if (right === void 0 || left !== void 0 && left.startSeq < right.startSeq) {
						merged.push(left);
						before++;
					} else {
						merged.push(right);
						added++;
					}
				}
				this.contextsByKind.set(kind, merged);
			}
			replayDependencies() {
				let replayed = false;
				const ordered = [...this.contexts.values()].filter((context) => startSeq(context) !== void 0).sort((left, right) => startSeq(left) - startSeq(right));
				for (const context of ordered) {
					if (context.state === void 0 || context.dependencies.size === 0) continue;
					const before = startSeq(context);
					if (before === void 0) continue;
					let changed = false;
					for (const dependency of context.dependencies.values()) {
						const current = this.previousContext(dependency.kind, before);
						const windowGap = current === void 0 && this.hasMore;
						if (current?.key !== dependency.key || current?.revision !== dependency.revision || windowGap !== dependency.windowGap) {
							changed = true;
							break;
						}
					}
					if (changed) {
						this.replayContext(context);
						replayed = true;
					}
				}
				return replayed;
			}
			refreshMatchLocations(changedSeqs) {
				const affected = /* @__PURE__ */ new Set();
				if (changedSeqs.size === 0) return affected;
				for (const seq of changedSeqs) for (const context of this.contextsBySeq.get(seq) ?? []) affected.add(context);
				for (const context of affected) {
					let start = context.start;
					context.matches = context.matches.map((match) => {
						if (!changedSeqs.has(match.event.seq)) return match;
						if (match.role === "start") {
							const refreshed = {
								...match,
								location: this.locationIndex.locationOf(match.event)
							};
							if (match === start) start = refreshed;
							return refreshed;
						}
						return {
							...match,
							location: this.locationIndex.locationOf(match.event)
						};
					});
					context.start = start;
				}
				return affected;
			}
			buildNode(context, target) {
				if (context.definition.target !== target || context.definition.buildViewNode === void 0) return null;
				const node = context.definition.buildViewNode(contextSnapshot(context));
				if (node === null) return null;
				if (node.key !== context.key) throw new Error(`conversation Definition "${context.kind}" returned unstable key "${node.key}"; expected "${context.key}"`);
				if (node.target !== target) throw new Error(`conversation Definition "${context.kind}" returned target "${node.target}" while building "${target}"`);
				return node;
			}
			replaceView(view) {
				this.updateView(view, true, this.buildTargetNodes(view.target, this.contextsByTarget.get(view.target)), []);
			}
			updateView(view, replacing, nodes, changedTurns) {
				const builder = view.builder ?? view.definition.create();
				const definition = view.groupDefinition;
				if (definition !== void 0 && builder.groupInput === void 0) throw new Error(`conversation group target "${view.target}" requires builder.groupInput()`);
				view.builder = builder;
				const timeline = this.locationIndex.snapshot();
				const snapshot = replacing ? builder.replace({
					nodes,
					timeline,
					changedTurns
				}) : builder.apply({
					upserts: nodes,
					timeline,
					changedTurns
				});
				if (definition !== void 0 && builder.groupInput !== void 0) {
					let context = this.groups.get(view.target);
					const initial = context === void 0;
					if (context === void 0) context = {
						definition,
						state: definition.create(),
						store: new ConversationGroupStore()
					};
					const input = builder.groupInput();
					context.state = definition.update(context, input);
					const change = definition.buildGroups(context);
					if ((initial || input.kind === "replace") && (change === null || change.entries === void 0 || change.groups.kind !== "replace")) throw new Error(`conversation group target "${view.target}" requires complete grouping for replacement input`);
					if (change !== null) {
						context.store.prepareAndInstall(change, input.readNode);
						this.pendingGroupStores.add(context.store);
					}
					this.groups.set(view.target, context);
				}
				view.snapshot = snapshot;
			}
			publishViews(updated) {
				const changed = updated.length > 0 || this.pendingGroupStores.size > 0;
				const stores = [...this.pendingGroupStores];
				this.pendingGroupStores.clear();
				for (const view of updated) view.builder?.publish?.();
				for (const store of stores) store.publish();
				this.locationIndex.publishData();
				return changed;
			}
			buildTargetNodes(target, contexts) {
				const nodes = [];
				for (const context of contexts ?? []) {
					const node = this.buildNode(context, target);
					context.current.set(target, node);
					if (node !== null) nodes.push(node);
				}
				return nodes;
			}
			buildTargetUpserts(target, contexts) {
				const upserts = [];
				for (const context of contexts ?? []) {
					const previous = context.current.get(target) ?? null;
					const node = this.buildNode(context, target);
					if (node === null && previous !== null) throw new Error(`conversation Definition "${context.kind}" withdrew materialized target "${target}"; return the same key with hidden visibility instead`);
					context.current.set(target, node);
					if (node !== null) upserts.push(node);
				}
				return upserts;
			}
			buildLocationData(context, scope, previous) {
				if (context.definition.buildLocationData === void 0) return null;
				const data = context.definition.buildLocationData(contextSnapshot(context), scope, previous);
				if (data === null) return null;
				if (data.kind !== scope) throw new Error(`conversation Definition "${context.kind}" published ${data.kind} data through its ${scope} scope`);
				if (data.key !== context.kind) throw new Error(`conversation Definition "${context.kind}" published Location data key "${data.key}"; expected its owned kind`);
				if (!Number.isSafeInteger(data.turn) || data.turn < 0) throw new Error(`conversation Definition "${context.kind}" published invalid turn ${data.turn}`);
				if (data.kind === "step" && (!Number.isSafeInteger(data.step) || data.step < 0)) throw new Error(`conversation Definition "${context.kind}" published invalid step ${String(data.step)}`);
				return data;
			}
			replaceLocationData() {
				const entries = [];
				for (const scope of LOCATION_DATA_SCOPES) {
					for (const context of this.contexts.values()) {
						const data = this.buildLocationData(context, scope, context.locationData[scope]);
						context.locationData[scope] = data;
						if (data !== null) entries.push({
							owner: context.key,
							data
						});
					}
					this.locationIndex.replaceData(entries);
				}
			}
			applyDirtyLocationData() {
				let changed = false;
				for (const scope of LOCATION_DATA_SCOPES) {
					const changes = [];
					for (const context of this.dirty) {
						const previous = context.locationData[scope];
						const next = this.buildLocationData(context, scope, previous);
						if (previous === next) continue;
						context.locationData[scope] = next;
						changes.push({
							owner: context.key,
							previous,
							next
						});
					}
					changed = this.locationIndex.applyData(changes) || changed;
				}
				return changed;
			}
			resetViewBuilders() {
				const definitions = this.viewDefinitions.entries();
				const targets = new Set(definitions.map((definition) => definition.target));
				for (const [target, group] of this.groups) if (!targets.has(target) || this.groupDefinitions.forTarget(target) !== group.definition) {
					group.store.clear();
					this.pendingGroupStores.add(group.store);
					this.groups.delete(target);
				}
				this.views.clear();
				for (const definition of definitions) {
					const view = {
						target: definition.target,
						definition,
						groupDefinition: this.groupDefinitions.forTarget(definition.target),
						isActive: definition.isActive === void 0 ? void 0 : (snapshot) => definition.isActive?.(snapshot) === true,
						builder: void 0,
						snapshot: void 0
					};
					this.views.set(definition.target, view);
				}
				this.replacePending = true;
			}
		};
		function isLocationBoundary(type) {
			return type === "turn/start" || type === "turn/end" || type === "step/start" || type === "step/end";
		}
		function requireState(definition, phase, state) {
			if (state === void 0) throw new Error(`conversation Definition "${definition.kind}" returned undefined from ${phase}()`);
			return state;
		}
		//#endregion
		//#region lib/types/client/conversation/definition-registry.js
		/** Shared lifecycle and stable-entry storage for one Conversation Definition registry. */
		var ConversationDefinitionRegistry = class {
			ctx;
			definitions = /* @__PURE__ */ new Map();
			listeners = /* @__PURE__ */ new Set();
			cached = [];
			/** @param ctx - Context whose effects own contributed Definitions. */
			constructor(ctx) {
				this.ctx = ctx;
				Object.defineProperty(this, _deepseek_ai_cordis.Service.tracker, { value: { property: "ctx" } });
			}
			/**
			* Return reference-stable Definitions in registration order.
			* @returns current Definitions.
			*/
			entries() {
				return this.cached;
			}
			/**
			* Observe low-frequency registry changes.
			* @param listener - synchronous invalidation callback.
			* @returns unsubscribe callback.
			*/
			subscribe(listener) {
				this.listeners.add(listener);
				return () => {
					this.listeners.delete(listener);
				};
			}
			/**
			* Register one uniquely keyed Definition for the caller's lifetime.
			* @param key - registry-local unique key.
			* @param definition - contributed Definition.
			* @param duplicateMessage - error raised when the key is already owned.
			* @param effectName - Cordis effect diagnostic label.
			* @returns idempotent disposer.
			*/
			registerDefinition(key, definition, duplicateMessage, effectName) {
				if (this.definitions.has(key)) throw new Error(duplicateMessage);
				const dispose = this.ctx.effect(() => {
					this.definitions.set(key, definition);
					this.refresh();
					return () => {
						if (this.definitions.get(key) !== definition) return;
						this.definitions.delete(key);
						this.refresh();
					};
				}, effectName);
				return () => {
					dispose();
				};
			}
			/** Refresh cached entries and synchronously invalidate subscribers. */
			refresh() {
				this.cached = [...this.definitions.values()];
				(0, _deepseek_ai_dsh_client_store.notifySubscribers)(this.listeners, "[ui-conversation] definition registry");
			}
		};
		//#endregion
		//#region lib/types/client/conversation/event-registry.js
		/** Runtime registry of independently owned Conversation business Definitions. */
		var ConversationEventRegistry = class extends ConversationDefinitionRegistry {
			fallback;
			routes = /* @__PURE__ */ new Map();
			unrestricted = /* @__PURE__ */ new Set();
			tables = /* @__PURE__ */ new WeakMap();
			/**
			* Register a uniquely named business Definition for the caller's lifetime.
			* @param definition - Definition contribution.
			* @returns idempotent disposer.
			*/
			register(definition) {
				assertDefinitionTarget(definition);
				return this.registerDefinition(definition.kind, this.resolve(definition), `conversation Definition "${definition.kind}" is already registered`, `uiConversation.events.register(${JSON.stringify(definition.kind)})`);
			}
			/**
			* Register the sole fallback used only when no ordinary Definition matches.
			* @param input - fallback Definition.
			* @returns idempotent disposer.
			*/
			registerFallback(input) {
				assertDefinitionTarget(input);
				if (input.target === void 0) throw new Error("conversation fallback Definition must declare a target");
				if (this.fallback !== void 0) throw new Error("conversation fallback Definition is already registered");
				const definition = this.resolve(input);
				const dispose = this.ctx.effect(() => {
					this.fallback = definition;
					this.refresh();
					return () => {
						if (this.fallback !== definition) return;
						this.fallback = void 0;
						this.refresh();
					};
				}, `uiConversation.events.registerFallback(${JSON.stringify(definition.kind)})`);
				return () => {
					dispose();
				};
			}
			/**
			* Return the current unmatched-event fallback.
			* @returns installed fallback, when present.
			*/
			fallbackEntry() {
				return this.fallback;
			}
			/**
			* Read precomputed candidates in registration order; the returned Set is borrowed read-only.
			* @param type - current event type.
			* @returns table handlers for this type together with all function-form handlers.
			*/
			forEvent(type) {
				return this.routes.get(type) ?? this.unrestricted;
			}
			resolve(input) {
				if (typeof input.match === "function") return input;
				const table = new Map(Object.entries(input.match));
				const definition = {
					...input,
					match: (event) => table.get(event.type)?.call(definition, event) ?? null
				};
				this.tables.set(definition, table);
				return definition;
			}
			refresh() {
				const routes = /* @__PURE__ */ new Map();
				const unrestricted = /* @__PURE__ */ new Set();
				for (const definition of this.definitions.values()) {
					const table = this.tables.get(definition);
					if (table === void 0) {
						const route = {
							definition,
							match: definition.match.bind(definition)
						};
						unrestricted.add(route);
						for (const candidates of routes.values()) candidates.add(route);
					} else for (const [type, match] of table) {
						let candidates = routes.get(type);
						if (candidates === void 0) {
							candidates = new Set(unrestricted);
							routes.set(type, candidates);
						}
						candidates.add({
							definition,
							match: match.bind(definition)
						});
					}
				}
				this.routes = routes;
				this.unrestricted = unrestricted;
				super.refresh();
			}
		};
		function assertDefinitionTarget(definition) {
			if (definition.target === void 0 !== (definition.buildViewNode === void 0)) throw new Error(`conversation Definition "${definition.kind}" must declare target and buildViewNode together`);
		}
		//#endregion
		//#region ../../util/crypto/lib/index.js
		/**
		* UUID minting that works in every JavaScript context this repository ships
		* to. `crypto.randomUUID` is a secure-context Web API — a page or worker
		* served over plain HTTP on a LAN address has no such method — while
		* `crypto.getRandomValues` is unrestricted everywhere (browsers, workers,
		* Node ≥ 19). One implementation here replaces per-caller polyfills; the
		* `no-restricted-properties` lint rule points `crypto.randomUUID` callers at
		* this module.
		* @module @deepseek-ai/dsh-util-crypto
		*/
		/**
		* Encode bytes as canonical base64 without overflowing function argument limits.
		* @param data - Bytes to encode.
		* @returns base64 text.
		*/
		function bytesToBase64(data) {
			let binary = "";
			const chunk = 32768;
			for (let offset = 0; offset < data.length; offset += chunk) binary += String.fromCharCode(...data.subarray(offset, offset + chunk));
			return btoa(binary);
		}
		/**
		* Random v4 UUID, minted from `crypto.getRandomValues`.
		* @returns the UUID string.
		*/
		function randomUUID() {
			const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16));
			const hex = Array.from(bytes, (byte, index) => {
				return (index === 6 ? byte & 15 | 64 : index === 8 ? byte & 63 | 128 : byte).toString(16).padStart(2, "0");
			}).join("");
			return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
		}
		//#endregion
		//#region lib/types/client/conversation/historical-images.js
		/** Resolve durable Conversation images and release their browser URLs with Session scope. */
		var HistoricalImageCache = class {
			sessions;
			entries = new WeakMapWithValues();
			scopeDisposers = new WeakMapWithValues();
			urls = /* @__PURE__ */ new Set();
			disposed = false;
			/**
			* @param ctx - Owning ui-conversation fiber.
			* @param sessions - Session Controller object layer.
			*/
			constructor(ctx, sessions) {
				this.sessions = sessions;
				ctx.effect(() => () => {
					this.dispose();
				}, "ui-conversation historical image cache");
			}
			/**
			* Resolve and cache one stored image URL.
			* @param sessionId - Session binding that owns the cached URL lifetime.
			* @param attachment - Durable image reference.
			* @returns browser URL valid until the Session binding is released.
			*/
			resolve(sessionId, attachment) {
				if (this.disposed) return Promise.reject(/* @__PURE__ */ new Error("ui-conversation image cache is disposed"));
				const binding = this.sessions.binding(sessionId);
				if (binding === void 0) return Promise.reject(/* @__PURE__ */ new Error(`ui-conversation: unknown session "${sessionId}"`));
				const entries = this.bindScope(binding);
				const key = attachment.attachmentId;
				const cached = entries.get(key);
				if (cached !== void 0) return cached.pending;
				const entry = {
					binding,
					pending: Promise.resolve("")
				};
				entries.set(key, entry);
				entry.pending = this.loadCanonical(key, entry, attachment);
				return entry.pending;
			}
			/**
			* Return an already-displayable URL without starting a read.
			* @param sessionId - Session binding that owns the cached URL lifetime.
			* @param attachment - Durable image reference.
			* @returns current preview or canonical URL when cached.
			*/
			peek(sessionId, attachment) {
				const binding = this.sessions.binding(sessionId);
				return binding === void 0 ? void 0 : this.entries.get(binding)?.get(attachment.attachmentId)?.current;
			}
			/**
			* Adopt a submission preview while fetching the durable admitted bytes.
			* The preview is available synchronously, then replaced and revoked when
			* the canonical attachment read completes.
			* @param sessionId - Session binding that owns the cached URL lifetime.
			* @param attachment - Durable image reference the URL temporarily displays.
			* @param url - browser URL to adopt.
			* @returns whether the cache took ownership.
			*/
			seed(sessionId, attachment, url) {
				if (this.disposed) return false;
				const binding = this.sessions.binding(sessionId);
				if (binding === void 0) return false;
				const entries = this.bindScope(binding);
				const key = attachment.attachmentId;
				if (entries.has(key)) return false;
				const entry = {
					binding,
					current: url,
					pending: Promise.resolve(url)
				};
				this.urls.add(url);
				entries.set(key, entry);
				entry.pending = this.loadCanonical(key, entry, attachment).catch((error) => {
					if (entries.get(key) === entry && entry.current === url) {
						entries.delete(key);
						this.releaseUrl(url);
					}
					throw error;
				});
				entry.pending.catch(() => {});
				return true;
			}
			loadCanonical(key, entry, attachment) {
				return entry.binding.session.readAttachment(attachment).then((result) => {
					if (!result.ok) throw new Error(`${result.error.code}: ${result.error.message}`);
					this.assertLive(key, entry);
					let url;
					if (typeof URL.createObjectURL !== "function") url = `data:${result.value.attachment.mediaType};base64,${bytesToBase64(result.value.data)}`;
					else {
						const bytes = Uint8Array.from(result.value.data);
						url = URL.createObjectURL(new Blob([bytes.buffer], { type: result.value.attachment.mediaType }));
					}
					this.assertLive(key, entry);
					this.urls.add(url);
					const previous = entry.current;
					entry.current = url;
					if (previous !== void 0 && previous !== url) this.releaseUrl(previous);
					return url;
				}).catch((error) => {
					const entries = this.entries.get(entry.binding);
					if (entries?.get(key) === entry && entry.current === void 0) entries.delete(key);
					throw error;
				});
			}
			assertLive(key, entry) {
				if (this.disposed) throw new Error("ui-conversation image cache was disposed before loading completed");
				if (this.entries.get(entry.binding)?.get(key) !== entry) throw new Error("ui-conversation image scope was released before loading completed");
			}
			bindScope(binding) {
				const existing = this.entries.get(binding);
				if (existing !== void 0) return existing;
				const entries = /* @__PURE__ */ new Map();
				this.entries.set(binding, entries);
				const dispose = binding.ctx.effect(() => () => {
					this.scopeDisposers.delete(binding);
					this.release(binding, entries);
				}, "ui-conversation historical image scope");
				const release = () => {
					dispose();
				};
				this.scopeDisposers.set(binding, release);
				return entries;
			}
			release(binding, entries) {
				if (this.entries.get(binding) === entries) this.entries.delete(binding);
				for (const entry of entries.values()) if (entry.current !== void 0) this.releaseUrl(entry.current);
				entries.clear();
			}
			releaseUrl(url) {
				if (!this.urls.delete(url)) return;
				revokeUrl(url);
			}
			dispose() {
				if (this.disposed) return;
				this.disposed = true;
				for (const dispose of [...this.scopeDisposers.values]) dispose();
				this.scopeDisposers.clear();
				for (const url of this.urls) revokeUrl(url);
				this.urls.clear();
				for (const entries of this.entries.values) entries.clear();
				this.entries.clear();
			}
		};
		function revokeUrl(url) {
			if (url.startsWith("blob:")) URL.revokeObjectURL(url);
		}
		//#endregion
		//#region lib/types/client/conversation/view-registry.js
		/** Runtime registry of per-target Conversation snapshot builders. */
		var ConversationViewRegistry = class extends ConversationDefinitionRegistry {
			/**
			* Register a uniquely named view builder factory for the caller's lifetime.
			* @param definition - target builder contribution.
			* @returns idempotent disposer.
			*/
			register(definition) {
				return this.registerDefinition(definition.target, definition, `conversation view target "${definition.target}" is already registered`, `uiConversation.views.register(${JSON.stringify(definition.target)})`);
			}
		};
		//#endregion
		//#region lib/types/client/conversation/group-registry.js
		/** One Group Definition per target; registration never instantiates its Builder. */
		var ConversationGroupRegistry = class extends ConversationDefinitionRegistry {
			views;
			/**
			* @param ctx - owning plugin context.
			* @param views - registered target Builder definitions.
			*/
			constructor(ctx, views) {
				super(ctx);
				this.views = views;
			}
			/**
			* Register grouping rules for an existing target.
			* @param definition - business State and grouping output for the declared target data.
			* @returns the effect-owned, idempotent registration disposer.
			*/
			register(definition) {
				if (!this.views.entries().some((view) => view.target === definition.target)) throw new Error(`conversation group target "${definition.target}" is not registered`);
				return this.registerDefinition(definition.target, definition, `conversation group target "${definition.target}" is already registered`, `uiConversation.groups.register(${JSON.stringify(definition.target)})`);
			}
			/**
			* Find the grouping rules registered for one target.
			* @param target - View target.
			* @returns its grouping Definition, when registered.
			*/
			forTarget(target) {
				return this.definitions.get(target);
			}
		};
		//#endregion
		//#region lib/types/client/conversation/interaction-registry.js
		/** Effect-owned registrations; active surfaces belong to individual Chat views. */
		var ConversationInteractionRegistry = class extends ConversationDefinitionRegistry {
			ids = [];
			/**
			* Register a synchronous handler and its keyed renderer identity.
			* @param definition - uniquely named plugin handler.
			* @returns idempotent disposer tied to the registering plugin's lifetime.
			*/
			register(definition) {
				if (definition.id === "") throw new Error("text interaction ID must not be empty");
				return this.registerDefinition(definition.id, definition, `Duplicate text interaction: ${definition.id}`, `uiConversation.interactions.register(${JSON.stringify(definition.id)})`);
			}
			/**
			* Offer a gesture until one handler opens its surface; opening never prevents browser defaults.
			* @param sessionId - conversation where the gesture occurred.
			* @param gesture - synchronous access to the browser event and DOM text.
			* @returns selected renderer ID, or null when no plugin opens a surface.
			*/
			dispatch(sessionId, gesture) {
				for (const definition of this.entries()) {
					const state = { opened: false };
					let dispatching = true;
					try {
						definition.onInteraction({
							...gesture,
							sessionId,
							open: () => {
								if (dispatching) state.opened = true;
							},
							preventDefault: () => {
								if (dispatching) gesture.preventDefault();
							}
						});
					} finally {
						dispatching = false;
					}
					if (state.opened) return definition.id;
				}
				return null;
			}
			/**
			* Observe registration changes so Chat views can dismiss stale surfaces.
			* @returns stable IDs until the registry changes.
			*/
			getSnapshot() {
				return this.ids;
			}
			refresh() {
				this.ids = [...this.definitions.keys()];
				super.refresh();
			}
		};
		//#endregion
		//#region lib/types/client/conversation/user-text-document.js
		var UserTextTransformError = class extends Error {
			ruleId;
			constructor(ruleId, cause) {
				super(`user-text rule "${ruleId}" failed to evaluate`, { cause });
				this.ruleId = ruleId;
				this.name = "UserTextTransformError";
			}
		};
		/** Data-layer cache owned by one caller; initialization and refresh share one reconciliation. */
		var UserTextDocument = class {
			text;
			rules;
			initial = [];
			output = [];
			matchers = /* @__PURE__ */ new Map();
			complete = false;
			evaluating = false;
			/**
			* Reconcile original text using current rule definitions and valid query records.
			* @param input - original text and readonly Facts, compared by fields actually read.
			* @param rules - unique definitions ordered by ascending order and stable ID.
			* @returns complete readonly nodes; failures retain caches but publish no partial result.
			*/
			evaluate(input, rules) {
				if (this.evaluating) throw new Error("user-text document evaluation cannot be reentrant");
				this.evaluating = true;
				try {
					const { changed, matchers } = this.prepare(input, rules);
					if (!changed && this.complete) return this.output;
					this.complete = false;
					this.output = alignNodes(this.reconcile(input, matchers), this.output, this.initial);
					this.complete = true;
					return this.output;
				} finally {
					this.evaluating = false;
				}
			}
			prepare(input, rules) {
				let changed = this.rules !== rules;
				if (this.text !== input.text) {
					changed = true;
					this.text = input.text;
					this.matchers.clear();
					this.initial = input.text.length === 0 ? [] : [textNode(input.text, 0, input.text.length)];
					this.output = this.initial;
				}
				const ids = new Set(rules.map((rule) => rule.id));
				const matchers = [];
				for (const definition of rules) {
					let matcher = this.matchers.get(definition.id);
					if (matcher === void 0 || matcher.definition !== definition || factsChanged(matcher.reads, input)) {
						matcher = {
							definition,
							queries: [],
							reads: /* @__PURE__ */ new Map()
						};
						this.matchers.set(definition.id, matcher);
						changed = true;
					}
					matchers.push(matcher);
				}
				for (const id of this.matchers.keys()) if (!ids.has(id)) this.matchers.delete(id);
				this.rules = rules;
				return {
					changed,
					matchers
				};
			}
			reconcile(input, matchers) {
				const traversals = matchers.map((matcher) => ({
					matcher,
					added: [],
					index: -1,
					head: void 0
				}));
				const nodes = [];
				let cursor = 0;
				try {
					while (true) {
						let winner;
						for (const traversal of traversals) {
							const node = nextCandidate(traversal, input, cursor);
							if (node !== void 0 && (winner === void 0 || node.start < winner.start)) winner = node;
						}
						if (winner === void 0) {
							if (cursor < input.text.length) nodes.push(textNode(input.text, cursor, input.text.length));
							return nodes;
						}
						if (cursor < winner.start) nodes.push(textNode(input.text, cursor, winner.start));
						nodes.push(winner);
						cursor = winner.end;
					}
				} finally {
					for (const { matcher, added } of traversals) if (added.length > 0) matcher.queries = mergeQueries(matcher.queries, added);
				}
			}
		};
		function factsChanged(reads, input) {
			for (const [key, value] of reads) if (!Object.is(value, input.facts[key])) return true;
			return false;
		}
		function withFacts(input, reads, run) {
			let active = true;
			try {
				return run({ read: (key) => {
					if (!active) throw new Error("user-text transform context is closed; read is synchronous only");
					const value = input.facts[key];
					reads.set(key, value);
					return value;
				} });
			} finally {
				active = false;
			}
		}
		function nextCandidate(traversal, input, cursor) {
			const { matcher } = traversal;
			if (traversal.head === void 0 || traversal.head.node !== void 0 && traversal.head.node.start < cursor) {
				let next = matcher.queries[traversal.index + 1];
				while (next !== void 0 && next.from <= cursor) {
					traversal.index++;
					next = matcher.queries[traversal.index + 1];
				}
				const recorded = matcher.queries[traversal.index];
				if (recorded !== void 0 && (recorded.error !== void 0 ? recorded.from === cursor : recorded.node === void 0 || recorded.node.start >= cursor)) traversal.head = recorded;
				else {
					let node;
					let error;
					try {
						node = withFacts(input, matcher.reads, (context) => matcher.definition.match(input.text, cursor, context));
						if (node !== void 0) validateCandidate(input.text, matcher.definition.id, cursor, node);
					} catch (cause) {
						error = new UserTextTransformError(matcher.definition.id, cause);
					}
					traversal.head = {
						from: cursor,
						node,
						error
					};
					traversal.added.push(traversal.head);
				}
			}
			if (traversal.head.error !== void 0) throw traversal.head.error;
			return traversal.head.node;
		}
		function validateCandidate(text, ruleId, from, node) {
			if (!Number.isInteger(node.start) || !Number.isInteger(node.end) || node.start < from || node.end <= node.start || node.end > text.length) throw new Error(`invalid candidate range [${node.start}, ${node.end}); expected a nonempty range from ${from} to ${text.length}`);
			if (node.id === "text") {
				if (node.data.text !== text.slice(node.start, node.end)) throw new Error("text candidate must preserve its original substring");
			} else if (node.id !== ruleId) throw new Error(`candidate must use rule ID "${ruleId}" or text`);
		}
		function mergeQueries(previous, added) {
			if (previous.length === 0) return added;
			const merged = [];
			const remaining = previous.values();
			let old = remaining.next().value;
			for (const query of added) {
				while (old !== void 0 && old.from < query.from) {
					merged.push(old);
					old = remaining.next().value;
				}
				merged.push(query);
			}
			while (old !== void 0) {
				merged.push(old);
				old = remaining.next().value;
			}
			return merged;
		}
		function textNode(text, start, end) {
			return {
				id: "text",
				start,
				end,
				data: { text: text.slice(start, end) }
			};
		}
		function alignNodes(output, previous, input) {
			let previousIndex = 0;
			let inputIndex = 0;
			let aligned;
			for (const [index, node] of output.entries()) {
				let inputNode = input[inputIndex];
				while (inputNode && inputNode.start < node.start) inputNode = input[++inputIndex];
				let previousNode = previous[previousIndex];
				while (previousNode && previousNode.start < node.start) previousNode = previous[++previousIndex];
				const reused = inputNode && equalNode(node, inputNode) ? inputNode : previousNode && equalNode(node, previousNode) ? previousNode : node;
				if (reused !== node && !aligned) aligned = output.slice(0, index);
				aligned?.push(reused);
			}
			const nodes = aligned ?? output;
			if (equalElements(nodes, previous)) return previous;
			return equalElements(nodes, input) ? input : nodes;
		}
		function equalElements(left, right) {
			return left === right || left.length === right.length && left.every((node, index) => node === right[index]);
		}
		function equalNode(left, right) {
			return Object.is(left, right) || left.id === right.id && left.start === right.start && left.end === right.end && equalJson(left.data, right.data);
		}
		function equalJson(left, right) {
			if (Object.is(left, right)) return true;
			if (left === null || right === null || typeof left !== "object" || typeof right !== "object") return false;
			if (Array.isArray(left) !== Array.isArray(right)) return false;
			const keys = Object.keys(left);
			if (keys.length !== Object.keys(right).length) return false;
			return keys.every((key) => Object.hasOwn(right, key) && equalJson(Reflect.get(left, key), Reflect.get(right, key)));
		}
		//#endregion
		//#region lib/types/client/conversation/user-text-registry.js
		/** Observable rule revision with no retained documents or document subscriptions. */
		var UserTextRegistry = class extends ConversationDefinitionRegistry {
			rules = [];
			revision = 0;
			/**
			* Register a uniquely named rule; invalid IDs, duplicate IDs and non-finite order throw before publication.
			* @param rule - readonly synchronous candidate matcher with a nonempty ID other than the reserved `text` ID.
			* @returns idempotent disposer; removal synchronously publishes a new revision.
			*/
			register(rule) {
				if (rule.id.length === 0) throw new Error("user-text rule ID must not be empty");
				if (rule.id === "text") throw new Error("user-text rule \"text\" is reserved for original text");
				if (!Number.isFinite(rule.order)) throw new Error(`user-text rule "${rule.id}" order must be finite`);
				return this.registerDefinition(rule.id, rule, `user-text rule "${rule.id}" is already registered`, `uiConversation.userText.register(${JSON.stringify(rule.id)})`);
			}
			/**
			* Create an independent document evaluator; it reads current rules at each call and never subscribes.
			* @returns callback owning its document cache, released when the caller releases the callback.
			*/
			createEvaluator() {
				const document = new UserTextDocument();
				return (input) => document.evaluate(input, this.rules);
			}
			/**
			* Read the observable rule revision.
			* @returns monotonic revision, stable until a successful registration or disposal.
			*/
			getSnapshot() {
				return this.revision;
			}
			refresh() {
				this.rules = [...this.definitions.values()].sort((a, b) => a.order - b.order || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
				this.revision++;
				super.refresh();
			}
		};
		//#endregion
		//#region lib/types/client/conversation/assembly.js
		/** Per-Session target-neutral Conversation assembly. */
		var BoundConversation = class {
			assembler;
			snapshot;
			openTurn;
			viewStore;
			targetSources = /* @__PURE__ */ new Map();
			revision = -1;
			frame;
			disposeFeed = () => {};
			constructor(feed, assembler) {
				this.assembler = assembler;
				this.viewStore = assembler;
				this.snapshot = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(this.currentSnapshot());
				this.openTurn = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(assembler.openTurn());
				this.replace(feed.getSnapshot());
				this.disposeFeed = feed.subscribe(() => {
					this.accept(feed.getSnapshot());
				});
			}
			target(target) {
				let source = this.targetSources.get(target);
				if (source === void 0) {
					const views = this.viewStore;
					source = {
						getSnapshot: () => views.get(target),
						subscribe: (listener) => {
							const unsubscribe = this.snapshot.subscribe(listener);
							this.activate(target);
							return unsubscribe;
						}
					};
					this.targetSources.set(target, source);
				}
				return source;
			}
			activate(target) {
				if (this.assembler.activateTarget(target)) this.snapshot.set(this.currentSnapshot());
				this.openTurn.set(this.assembler.openTurn());
			}
			rebuild() {
				this.publish(this.assembler.rebuildRegistry());
			}
			dispose() {
				this.cancelFrame();
				this.disposeFeed();
			}
			replace(window) {
				this.revision = window.revision;
				this.publish(this.assembler.replaceWindow(window.entries, window.hasMore));
			}
			accept(window) {
				if (window.revision === this.revision) return;
				if (window.revision !== this.revision + 1 || window.change.kind === "replace") {
					this.replace(window);
					return;
				}
				this.revision = window.revision;
				switch (window.change.kind) {
					case "prepend":
						this.publish(this.assembler.prepend(window.change.entries, window.hasMore));
						return;
					case "append": {
						let publication = "none";
						for (const event of window.change.entries) {
							const next = this.assembler.append(event);
							if (next === "immediate" || publication === "none") publication = next;
						}
						this.publish(publication);
						return;
					}
					case "settle-assistant":
						this.publish(this.assembler.settleAssistant(window.change.attemptId, window.change.entry));
						return;
				}
			}
			publish(publication) {
				if (publication === "none") return;
				if (publication === "animation-frame" && typeof requestAnimationFrame === "function") {
					if (this.frame !== void 0) return;
					this.frame = requestAnimationFrame(() => {
						this.frame = requestAnimationFrame(() => {
							this.frame = requestAnimationFrame(() => {
								this.frame = void 0;
								this.flush();
							});
						});
					});
					return;
				}
				this.cancelFrame();
				this.flush();
			}
			cancelFrame() {
				if (this.frame !== void 0 && typeof cancelAnimationFrame === "function") cancelAnimationFrame(this.frame);
				this.frame = void 0;
			}
			flush() {
				if (this.assembler.flush()) this.snapshot.set(this.currentSnapshot());
				this.openTurn.set(this.assembler.openTurn());
			}
			currentSnapshot() {
				return {
					views: this.viewStore,
					activeTargets: this.assembler.activityTargets()
				};
			}
		};
		/** Root service owning Conversation registries and per-Session bindings. */
		var UiConversation = class extends _deepseek_ai_cordis.Service {
			sessions;
			/** Registry of event matchers and target snapshot builders. */
			events;
			/** Registry of target View definitions. */
			views;
			/** Business grouping rules over already materialized target Nodes. */
			groups;
			/** Pure text rules and parser snapshots, independent of durable Session assembly. */
			userText;
			/** Plugin-owned handlers for selection and context-menu gestures. */
			interactions;
			bindings = new WeakMapWithValues();
			images;
			/**
			* @param ctx - owning Client context.
			* @param sessions - Session Controller object layer.
			*/
			constructor(ctx, sessions) {
				super(ctx, "uiConversation");
				this.sessions = sessions;
				this.events = new ConversationEventRegistry(ctx);
				this.views = new ConversationViewRegistry(ctx);
				this.groups = new ConversationGroupRegistry(ctx, this.views);
				this.userText = new UserTextRegistry(ctx);
				this.interactions = new ConversationInteractionRegistry(ctx);
				this.images = new HistoricalImageCache(ctx, sessions);
				const rebuild = () => {
					for (const record of this.bindings.values) record.binding.rebuild();
				};
				let rebuildQueued = false;
				const scheduleRebuild = () => {
					if (rebuildQueued) return;
					rebuildQueued = true;
					queueMicrotask(() => {
						rebuildQueued = false;
						rebuild();
					});
				};
				ctx.effect(() => {
					const disposeEvents = this.events.subscribe(scheduleRebuild);
					const disposeViews = this.views.subscribe(scheduleRebuild);
					const disposeGroups = this.groups.subscribe(scheduleRebuild);
					return () => {
						disposeGroups();
						disposeViews();
						disposeEvents();
						for (const record of [...this.bindings.values]) this.drop(record, true);
					};
				}, "ui-conversation assembly");
			}
			/**
			* Resolve the Conversation binding for one Controller binding or Session id.
			* @param source - Session binding or identity.
			* @returns stable Conversation binding.
			* @throws if the Session is unknown or its binding is no longer current.
			*/
			binding(source) {
				const sessionId = typeof source === "string" ? source : source.sessionId;
				const owner = typeof source === "string" ? this.sessions.binding(source) : source;
				if (owner === void 0) throw new Error(`uiConversation.binding: unknown session "${sessionId}"`);
				if (this.sessions.binding(sessionId) !== owner) throw new Error(`uiConversation.binding: inactive session "${sessionId}"`);
				const current = this.bindings.get(owner);
				if (current !== void 0) return current.binding;
				const binding = new BoundConversation(owner.eventSource, new ConversationNodeAssembler(this.events, this.views, this.groups));
				const record = {
					source: owner,
					binding,
					disposeScope: () => {}
				};
				this.bindings.set(owner, record);
				const disposeScope = owner.ctx.effect(() => () => {
					this.drop(record, false);
				}, "ui-conversation binding");
				record.disposeScope = () => {
					disposeScope();
				};
				return binding;
			}
			/**
			* Resolve one Gateway-authorized durable image URL, cached per Session so
			* every Conversation target shares one read and one browser URL.
			* @param sessionId - Session binding that owns the cached URL lifetime.
			* @param attachment - Durable image reference from a session event.
			* @returns browser URL valid until the Session binding is released.
			*/
			imageUrl(sessionId, attachment) {
				return this.images.resolve(sessionId, attachment);
			}
			/**
			* Read a cached durable image URL synchronously when one is available.
			* @param sessionId - Session binding that owns the cached URL lifetime.
			* @param attachment - Durable image reference from a session event.
			* @returns current preview or canonical URL, if cached.
			*/
			peekImageUrl(sessionId, attachment) {
				return this.images.peek(sessionId, attachment);
			}
			/**
			* Adopt an already-displayable URL for one durable reference (see
			* HistoricalImageCache.seed): the transcript node then renders it without a
			* byte round-trip.
			* @param sessionId - Session binding that owns the cached URL lifetime.
			* @param attachment - Durable image reference the URL displays.
			* @param url - browser URL to adopt.
			* @returns whether the cache took URL ownership.
			*/
			seedImageUrl(sessionId, attachment, url) {
				return this.images.seed(sessionId, attachment, url);
			}
			/**
			* Interpret a system message or surface replacement for target-owned prompt Definitions.
			* @param previous - System facts at the preceding relevant loaded event.
			* @param event - Durable system message or positional replacement.
			* @returns Immutable prompt interpretation at this event.
			*/
			inspectSystemPrompt(previous, event) {
				return inspectSystemPrompt(previous, event);
			}
			/**
			* Canonicalize one `request/header` event against the previous prompt state
			* and the `system/message` node in force.
			*
			* A pure interpretation shared by the Chat and Trajectory Definitions, exposed
			* as a service method because cross-plugin value imports are forbidden in
			* client bundles.
			* @param previous - prompt recorded by the preceding loaded header, if any.
			* @param event - the `request/header` session event to interpret.
			* @param system - effective prompt after loaded surface replacements, if any.
			* @returns the canonical prompt snapshot and any model-visible change.
			*/
			inspectRequestPrompt(previous, event, system) {
				return inspectRequestPrompt(previous, event, system);
			}
			drop(record, releaseScope) {
				if (this.bindings.get(record.source) !== record) return;
				this.bindings.delete(record.source);
				record.binding.dispose();
				if (releaseScope) record.disposeScope();
			}
		};
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/user-text/UserText.module.css.mjs
		const css$9 = ".BNl2La_root{display:contents}.BNl2La_ellipsis{text-overflow:ellipsis;white-space:nowrap;min-width:0;max-width:100%;display:block;overflow:hidden}";
		const tagId$9 = "@deepseek-ai/dsh-client-ui-conversation/UserText.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$9) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$9;
			tag.textContent = css$9;
			document.head.appendChild(tag);
		}
		var UserText_module_css_default = {
			"ellipsis": "BNl2La_ellipsis",
			"root": "BNl2La_root"
		};
		//#endregion
		//#region lib/types/client/user-text/UserText.js
		/** User-text presentation delegates evaluation to its data-layer document and renders JSON business nodes. */
		/**
		* Render original text through pure matching rules and business-owned node Slots.
		* A failed parse retains the entire original text and reports the rule error.
		* @param props - original text, confirmed facts, display policy, and framework seats.
		* @returns ordered inline nodes with raw-text fallbacks for missing registrations.
		*/
		function UserText({ text, facts, interactive = false, ellipsis = false, useUserTextRevision, createUserTextEvaluator, reportTransformFailure, renderSlot }) {
			useUserTextRevision((revision) => revision);
			const evaluate = (0, react.useMemo)(createUserTextEvaluator, [createUserTextEvaluator]);
			let nodes;
			let error;
			try {
				nodes = evaluate({
					text,
					facts
				});
			} catch (cause) {
				error = cause;
			}
			const failed = nodes === void 0;
			(0, react.useEffect)(() => {
				if (failed) reportTransformFailure(error);
			}, [
				failed,
				error,
				reportTransformFailure
			]);
			const content = (0, react.useMemo)(() => nodes === void 0 ? (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.UserTextRun, { text }) : (0, react_jsx_runtime.jsx)(react_jsx_runtime.Fragment, { children: nodes.map((node) => {
				const raw = text.slice(node.start, node.end);
				return (0, react_jsx_runtime.jsx)(react.Fragment, { children: renderSlot("conversation.user.text.node", {
					node,
					raw,
					interactive
				}, {
					entryKey: node.id,
					fallback: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.UserTextRun, { text: node.id === "text" ? node.data.display ?? raw : raw })
				}) }, `${node.id}:${node.start}`);
			}) }), [
				nodes,
				text,
				interactive,
				renderSlot
			]);
			return (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.HoverCardGroup, {
				as: "span",
				className: ellipsis ? UserText_module_css_default.ellipsis : UserText_module_css_default.root,
				children: content
			});
		}
		/**
		* Display an unmatched substring without business interpretation.
		* @param props - parser-produced plain-text node.
		* @returns its inline text.
		*/
		function PlainUserText({ node }) {
			return (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.UserTextRun, { text: node.data.display ?? node.data.text });
		}
		/**
		* Display a confirmed Session label without inventing navigation behavior.
		* @param props - Session reference JSON and its original spelling.
		* @returns the existing non-interactive Session chip.
		*/
		function SessionReference({ node, raw }) {
			return (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.ReferenceChip, {
				appearance: "session",
				label: node.data.label,
				title: raw
			});
		}
		//#endregion
		//#region lib/types/client/user-text/session-reference-rule.js
		/** Find the nearest Session reference; bare labels read their Facts only at a non-wire @ position. */
		const sessionReferenceRule = {
			id: "session",
			order: 10,
			match(text, from, context) {
				let labels;
				let readLabels = false;
				const wire = /@\[([^\]\n]+)\]\(dsh-session:[^)\s]+\)/uy;
				for (let start = text.indexOf("@", from); start >= 0; start = text.indexOf("@", start + 1)) {
					wire.lastIndex = start;
					const explicit = wire.exec(text);
					if (explicit !== null) return {
						id: "session",
						start,
						end: start + explicit[0].length,
						data: { label: explicit[1] }
					};
					if (!readLabels) {
						labels = context.read("sessionLabels");
						readLabels = true;
					}
					let best;
					for (const label of labels ?? []) {
						if (label.length === 0 || !text.startsWith(label, start + 1)) continue;
						const end = start + label.length + 1;
						if (best === void 0 || end > best.end) best = {
							id: "session",
							start,
							end,
							data: { label }
						};
					}
					if (best !== void 0) return best;
				}
			}
		};
		//#endregion
		//#region lib/types/client/user-text/whitespace-rules.js
		function replacement(text, start, end, display) {
			return {
				id: "text",
				start,
				end,
				data: {
					text: text.slice(start, end),
					display
				}
			};
		}
		/** Offer the next whitespace run whose display collapses to one space. */
		const collapseWhitespaceRule = {
			id: "text.collapse-whitespace",
			order: 1010,
			match(text, from, context) {
				if (!context.read("collapseWhitespace")) return void 0;
				const spaces = /\s+/gu;
				spaces.lastIndex = from;
				for (let match = spaces.exec(text); match !== null; match = spaces.exec(text)) {
					if (match.index > 0 && /\s/u.test(text.slice(match.index - 1, match.index)) || match[0] === " ") continue;
					return replacement(text, match.index, match.index + match[0].length, " ");
				}
			}
		};
		/** Offer original document-edge whitespace, winning same-start collisions with collapse. */
		const trimWhitespaceRule = {
			id: "text.trim-whitespace",
			order: 1e3,
			match(text, from, context) {
				if (!context.read("trimWhitespace")) return void 0;
				if (from === 0) {
					const leading = /^\s+/u.exec(text);
					if (leading !== null) return replacement(text, 0, leading[0].length, "");
				}
				let start = text.length;
				const whitespace = /\s/u;
				while (start > 0 && whitespace.test(text.charAt(start - 1))) start--;
				return start === text.length || start < from ? void 0 : replacement(text, start, text.length, "");
			}
		};
		//#endregion
		//#region lib/types/client/draft.js
		/** Semantic draft snapshots shared by storage, programmatic input, and editor restoration. */
		const referenceSchema = zod.z.object({
			source: zod.z.string(),
			ref: zod.z.string(),
			offset: zod.z.number().int().nonnegative(),
			length: zod.z.number().int().positive(),
			label: zod.z.string(),
			appearance: zod.z.enum([
				"session",
				"file",
				"folder"
			]).optional(),
			clipboardText: zod.z.string(),
			invalid: zod.z.boolean().optional()
		});
		const commandSchema = zod.z.object({ token: zod.z.string() });
		const quoteSchema = zod.z.object({
			offset: zod.z.number().int().nonnegative(),
			length: zod.z.number().int().positive(),
			text: zod.z.string().refine((text) => text.trim() !== "")
		});
		const snapshotSchema = zod.z.object({
			text: zod.z.string(),
			references: zod.z.array(referenceSchema),
			command: commandSchema.optional(),
			quotes: zod.z.array(quoteSchema).optional()
		}).refine((draft) => {
			const spelling = draft.command?.token.trimEnd();
			if (spelling !== void 0 && (!/^\/\S/u.test(spelling) || !draft.text.startsWith(spelling))) return false;
			let end = spelling?.length ?? 0;
			for (const reference of draft.references) {
				if (reference.offset < end || reference.length !== reference.clipboardText.length) return false;
				end = reference.offset + reference.length;
				if (end > draft.text.length || draft.text.slice(reference.offset, end) !== reference.clipboardText) return false;
			}
			for (const quote of draft.quotes ?? []) if (quote.length !== (0, _deepseek_ai_dsh_client_ui_primitives.formatQuoteText)(quote.text).length || draft.text.slice(quote.offset, quote.offset + quote.length) !== (0, _deepseek_ai_dsh_client_ui_primitives.formatQuoteText)(quote.text)) return false;
			end = spelling?.length ?? 0;
			for (const span of [...draft.references, ...draft.quotes ?? []].sort((a, b) => a.offset - b.offset)) {
				if (span.offset < end) return false;
				end = span.offset + span.length;
				if (end > draft.text.length) return false;
			}
			return true;
		}, "Draft references must identify ordered, non-overlapping text spans after the leading command token");
		/**
		* Copy input into the semantic draft representation without editor runtime identities.
		* @param input - plain text or caller-owned structured content.
		* @returns an owned snapshot ready for editor import.
		*/
		function resolveDraftInput(input) {
			if (typeof input === "string") return {
				text: input,
				references: []
			};
			return {
				text: input.text,
				references: input.references.map(copyReference),
				...input.command === void 0 ? {} : { command: { token: input.command.token } },
				...input.quotes === void 0 ? {} : { quotes: input.quotes.map((quote) => ({ ...quote })) }
			};
		}
		/**
		* Decode persisted drafts, accepting the earlier plain-string representation.
		* @param value - JSON value read from browser storage.
		* @returns the decoded draft, or undefined for invalid data.
		*/
		function parseStoredDraft(value) {
			if (typeof value === "string") return resolveDraftInput(value);
			const parsed = snapshotSchema.safeParse(value);
			if (!parsed.success) return void 0;
			return {
				text: parsed.data.text,
				...parsed.data.quotes === void 0 ? {} : { quotes: parsed.data.quotes },
				references: parsed.data.references.map(({ appearance, invalid, ...reference }) => ({
					...reference,
					...appearance === void 0 ? {} : { appearance },
					...invalid === void 0 ? {} : { invalid }
				})),
				...parsed.data.command === void 0 ? {} : { command: { token: parsed.data.command.token } }
			};
		}
		/**
		* Export reference identities without their editor-local occurrence ids.
		* @param text - current clipboard projection.
		* @param occurrences - matching reference projections from the same document revision.
		* @param commandToken - claim token of the command chip opening the document, if any.
		* @param quotes - atomic quotes from the same document revision.
		* @returns an editor-independent snapshot.
		*/
		function snapshotDraft(text, occurrences, commandToken, quotes = []) {
			return {
				text,
				references: occurrences.map(copyReference),
				...commandToken === void 0 ? {} : { command: { token: commandToken } },
				...quotes.length === 0 ? {} : { quotes: quotes.map((quote) => ({ ...quote })) }
			};
		}
		function copyReference(reference) {
			return {
				source: reference.source,
				ref: reference.ref,
				offset: reference.offset,
				length: reference.length,
				label: reference.label,
				clipboardText: reference.clipboardText,
				...reference.appearance === void 0 ? {} : { appearance: reference.appearance },
				...reference.invalid === void 0 ? {} : { invalid: reference.invalid }
			};
		}
		//#endregion
		//#region lib/types/client/stores.js
		/** Per-session Conversation store shared by the shell body and header. */
		const CONVERSATION_STORE_KEY = "dsh.conversation";
		/**
		* Declare per-session draft persistence and View selection.
		* @returns the store handle.
		*/
		function createConversationStore() {
			return (0, _deepseek_ai_dsh_client_store.defineStore)({
				init: () => ({
					draft: "",
					view: null,
					viewRequest: null
				}),
				persist: CONVERSATION_STORE_KEY,
				actions: {
					setDraft: (d, text) => {
						d.draft = text;
					},
					setView: (d, view) => {
						d.view = view;
					},
					openView: (d, view, focus) => {
						d.view = view;
						d.viewRequest = {
							view,
							focus
						};
					},
					completeViewRequest: (d) => {
						d.viewRequest = null;
					}
				}
			});
		}
		/**
		* Read a Session's draft before its input source is published to React.
		* @param sessionId - Session-scoped persistence suffix.
		* @returns saved semantic content, or an empty document when storage is absent or invalid.
		*/
		function readConversationDraft(sessionId) {
			const empty = {
				text: "",
				references: []
			};
			if (typeof localStorage === "undefined") return empty;
			try {
				const raw = localStorage.getItem(`${CONVERSATION_STORE_KEY}.${sessionId}`);
				if (raw === null) return empty;
				const stored = JSON.parse(raw);
				if (typeof stored !== "object" || stored === null || !("draft" in stored)) return empty;
				return parseStoredDraft(stored.draft) ?? empty;
			} catch (_error) {
				return empty;
			}
		}
		/**
		* Read the persisted View preference before the Slot store is materialized.
		* @param sessionId - Session-scoped persistence suffix.
		* @returns the preferred View id, or null when storage has no usable value.
		*/
		function readConversationViewPreference(sessionId) {
			if (typeof localStorage === "undefined") return null;
			try {
				const raw = localStorage.getItem(`${CONVERSATION_STORE_KEY}.${sessionId}`);
				if (raw === null) return null;
				const stored = JSON.parse(raw);
				if (typeof stored !== "object" || stored === null || !("view" in stored)) return null;
				return typeof stored.view === "string" ? stored.view : null;
			} catch {
				return null;
			}
		}
		//#endregion
		//#region ../../context/file-reference/lib/types/grammar.js
		/**
		* Format a selected path as prompt text. Whitespace uses the quoted
		* `@"path"` grammar; a quoted directory keeps that quote open after its
		* trailing slash so completion can descend another level.
		* @param candidate - selected file or directory.
		* @param preserveQuote - retain an explicitly opened quote even when unnecessary.
		* @returns the insertion value, or `undefined` for a path the editor grammar cannot represent safely.
		*/
		function formatFileMention(candidate, preserveQuote) {
			const path = candidate.kind === "directory" ? `${candidate.path}/` : candidate.path;
			if (/[\u0000-\u001f\u007f-\u009f"]/u.test(path)) return void 0;
			if (!(preserveQuote || /\s/u.test(path))) return `@${path}`;
			if (candidate.kind === "directory") return `@"${path}`;
			return `@"${path}"`;
		}
		//#endregion
		//#region ../../util/workspace-path/lib/index.js
		/**
		* Read the final non-empty segment of a Workspace path for display.
		* Workspace-label surfaces use this helper instead of deriving another basename.
		* @param path - Workspace directory path using POSIX or Windows separators.
		* @returns the final segment, or an empty string for a separator-only path.
		*/
		function workspaceTitleOf(path) {
			const trimmed = path.replace(/[/\\]+$/, "");
			const separator = Math.max(trimmed.lastIndexOf("/"), trimmed.lastIndexOf("\\"));
			return trimmed.slice(separator + 1);
		}
		/**
		* Strip the workspace root from a workspace-rooted absolute path (display only).
		* @param text - the path to shorten.
		* @param cwd - session workspace root; absent or empty leaves the path unchanged.
		* @returns the path relative to the workspace root, or unchanged when it is not rooted there.
		*/
		function relativizeToCwd(text, cwd) {
			if (cwd === void 0 || cwd === "") return text;
			const root = cwd.replace(/[/\\]+$/, "");
			if (text.startsWith(`${root}/`) || text.startsWith(`${root}\\`)) return text.slice(root.length + 1);
			return text;
		}
		//#endregion
		//#region lib/types/client/service.js
		/**
		* Scope-addressed conversation send, cancel, and history orchestration.
		*
		* Scope addressing rides the cordis Service tracker: property access through
		* `ctx.conversation` rebinds `this.ctx` to the caller's context, so methods
		* read the session tag with `scopeOf`. Mutable state must remain reachable
		* through one property read; assignment through the tracker proxy and `#`
		* private fields bypass that rebinding.
		*/
		/** Create one browser-only image draft descriptor; only its id enters input state. */
		function browserDraftAttachment(file) {
			return {
				kind: "image",
				id: randomUUID(),
				previewUrl: URL.createObjectURL(file),
				file
			};
		}
		/**
		* Fill the draft's intrinsic dimensions once the browser parses the image
		* header (a metadata read off the preview URL, not a full decode). Failures
		* and non-browser runtimes leave them absent — consumers size those images
		* from CSS constraints instead. The descriptors stay registry-owned; submit
		* reads the dimensions into an immutable echo snapshot, so this late write
		* does not require a store notification.
		*/
		function probeDimensions(attachment) {
			if (typeof Image !== "function") return;
			const probe = new Image();
			probe.onload = () => {
				attachment.width = probe.naturalWidth;
				attachment.height = probe.naturalHeight;
			};
			probe.src = attachment.previewUrl;
		}
		/** Give the echo one paint opportunity without letting a throttled frame clock block admission. */
		function nextPaint() {
			return new Promise((resolve) => {
				if (typeof requestAnimationFrame === "function") {
					if (typeof document !== "undefined" && document.visibilityState === "hidden") {
						setTimeout(resolve, 0);
						return;
					}
					let settled = false;
					const finish = () => {
						if (settled) return;
						settled = true;
						clearTimeout(fallback);
						setTimeout(resolve, 0);
					};
					const fallback = setTimeout(finish, 100);
					requestAnimationFrame(finish);
				} else setTimeout(resolve, 0);
			});
		}
		/** Native canonical base64 of one browser image (FileReader data-URL encode; no main-thread byte loop). */
		function base64ImageOf(file) {
			return new Promise((resolve, reject) => {
				const reader = new FileReader();
				reader.onload = () => {
					const url = reader.result;
					resolve(url.slice(url.indexOf(",") + 1));
				};
				reader.onerror = () => {
					reject(reader.error ?? /* @__PURE__ */ new Error("conversation: image read failed"));
				};
				reader.readAsDataURL(file);
			});
		}
		/** Unsupported browser-declared image type, localized by the UI boundary. */
		var UnsupportedImageMediaTypeError = class extends Error {
			/** Browser-declared MIME value, possibly empty. */
			mediaType;
			/** @param mediaType - Browser-declared MIME value, possibly empty. */
			constructor(mediaType) {
				super(`unsupported image media type: ${mediaType || "(empty)"}`);
				this.name = "UnsupportedImageMediaTypeError";
				this.mediaType = mediaType;
			}
		};
		/** Scope-addressed conversation service (root singleton, provided as `conversation`). */
		var ConversationController = class extends _deepseek_ai_cordis.Service {
			/** The per-session input machine registry (SessionInputResolver face). */
			input;
			/** The per-session composer-block registry. */
			blocks;
			/** Live upload state per draft that uploads when added: every file draft and every uploaded image draft. */
			fileUploads = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)({});
			draftAttachments = /* @__PURE__ */ new Map();
			fileUploadOperations = /* @__PURE__ */ new Map();
			pendingFileUploads = /* @__PURE__ */ new Set();
			fileUploadQueue = [];
			activeFileUploads = 0;
			maxConcurrentFileUploads;
			/**
			* @param ctx - owning root context (the plugin apply context; the service
			* registers itself and follows that fiber's lifetime).
			* @param config - carries the SessionInputResolver and composer-block registry
			* constructed by the plugin apply (the same instances the slot inject
			* factories close over).
			*/
			constructor(ctx, config) {
				super(ctx, "conversation");
				this.input = config.input;
                // Naumi scoped composer transport v1
                this.composerTransports = new Map();
                ctx.effect(() => () => this.composerTransports.clear());
				this.blocks = config.blocks;
				this.maxConcurrentFileUploads = config.maxConcurrentFileUploads;
				ctx.effect(() => async () => {
					const operations = [...this.fileUploadOperations.values()];
					for (const operation of operations) operation.controller.abort();
					await Promise.allSettled([...this.pendingFileUploads]);
					this.fileUploadOperations.clear();
					this.fileUploadQueue.length = 0;
					for (const attachment of this.draftAttachments.values()) if (attachment.kind === "image") revokePreview(attachment.previewUrl);
					this.draftAttachments.clear();
					this.fileUploads.set({});
				}, "conversation draft attachments");
			}
			/**
			* Send a prompt into the scoped session. Business failures also land in the
			* session snapshot's promptError (object-layer state); the rejection here
			* exists for caller choreography (the composer restores the draft on it).
			* @param text - prompt text, sent verbatim as one text block.
			*/
			async send(text) {
				const result = await this.scopedSession("send").prompt([{
					type: "text",
					text
				}], "queue");
				if (!result.ok) throw new Error(`conversation.send failed: ${result.error.code}: ${result.error.message}`);
			}
			/**
			* Submit ordered draft attachments with text through one host admission. A
			* local submission echo is registered first and enters the session snapshot
			* once the Host accepts the prompt; serialization and the prompt round-trip
			* start after the browser can paint the composer's sending state. The
			* outcome is success as soon as the Host accepts the prompt, which an Inbox
			* row carrying the request id can show before the receipt. The echo's
			* observed retirement seeds admitted image previews into the durable cache
			* and removes every attachment from the draft registry; an accepted prompt
			* whose echo retires unobserved also releases them. Until the Host accepts
			* the prompt, every attachment remains registered for the composer.
			* @param session - target session.
			* @param text - serialized prompt text.
			* @param attachmentIds - ordered draft-local attachment ids.
			* @param mode - queue or steer delivery selected by composer policy.
			* @param signal - optional cancellation for the complete Host admission.
			* @param accept - called inside the Session's acceptance, before the echo renders, so the composer settles with it.
			* @returns the Host admission outcome; local attachment preparation failures reject.
			*/
			registerComposerTransport(sessionId, transport) {
                if(this.composerTransports.has(sessionId))throw Error('COMPOSER_TRANSPORT_IN_USE');
                this.composerTransports.set(sessionId, transport);
                return () => {if(this.composerTransports.get(sessionId) === transport)this.composerTransports.delete(sessionId);};
            }
            async sendSession(session, text, attachmentIds, mode, signal, accept) {
                const transport = this.composerTransports.get(session.sessionId);
                if(transport){
                    const {attachments} = await this.serializeDraftAttachments(attachmentIds,true);
                    signal?.throwIfAborted();
                    const result = await transport.submit({text, attachments, mode, signal});
                    if(result.kind === 'success'){
                        accept?.();
                        for(const id of attachmentIds)this.releaseDraftAttachment(id);
                    }
                    return result;
                }
				const attachments = this.resolveDraftAttachments(attachmentIds);
				if (attachments.length !== attachmentIds.length) throw new Error("conversation.sendSession: one or more draft attachments are no longer available");
				const uploads = this.fileUploads.getSnapshot();
				const uploadFor = (attachment) => {
					const upload = uploads[attachment.id];
					if (upload === void 0 || upload.status !== "ready") throw new Error("conversation.sendSession: one or more files have not finished uploading");
					return upload;
				};
				const storedFileOf = (attachment) => uploadFor(attachment).file;
				const imageReceipts = new Map(attachments.flatMap((attachment) => attachment.kind === "image" && uploads[attachment.id] !== void 0 ? [[attachment.id, uploadFor(attachment).receiptId]] : []));
				const pendingAttachments = attachments.map((attachment) => attachment.kind === "image" ? {
					type: "image",
					value: {
						previewUrl: attachment.previewUrl,
						...attachment.file.name === "" ? {} : { name: attachment.file.name },
						...attachment.width === void 0 ? {} : { width: attachment.width },
						...attachment.height === void 0 ? {} : { height: attachment.height }
					}
				} : {
					type: "file",
					value: storedFileOf(attachment)
				});
				const serializeAttachments = () => Promise.all(attachments.map(async (attachment) => {
					if (attachment.kind === "file") return {
						type: "file",
						receiptId: uploadFor(attachment).receiptId
					};
					const receiptId = imageReceipts.get(attachment.id);
					return receiptId === void 0 ? {
						type: "image",
						...await this.encodeImage(attachment.file)
					} : {
						type: "file",
						receiptId
					};
				}));
				const ownership = {
					accepted: false,
					retiredUnobserved: false
				};
				const acceptance = Promise.withResolvers();
				const submission = session.beginSubmission({
					mode,
					text,
					attachments: pendingAttachments,
					onAccept: () => {
						ownership.accepted = true;
						accept?.();
						acceptance.resolve(void 0);
					},
					onRetire: (settlement) => {
						if (settlement.reason === "observed") this.settleSubmittedAttachments(session.sessionId, attachments, settlement);
						else if (ownership.accepted) this.releaseDraftAttachments(attachments);
						else ownership.retiredUnobserved = true;
					}
				});
				let content;
				try {
					await nextPaint();
					content = [...await serializeAttachments(), ...text === "" ? [] : [{
						type: "text",
						text
					}]];
				} catch (error) {
					submission.abandon();
					throw error;
				}
				const result = await Promise.race([session.prompt(content, mode, signal, submission.requestId), acceptance.promise]);
				if (result !== void 0 && !result.ok) return { kind: "error" };
				ownership.accepted = true;
				if (ownership.retiredUnobserved) this.releaseDraftAttachments(attachments);
				return { kind: "success" };
			}
			/**
			* Create runtime-only draft attachments. Files whose browser MIME is an
			* accepted image type become image drafts with an object URL preview; every
			* other file becomes a file draft. A file draft's background upload starts
			* immediately, and so does an image draft's when `uploadImages` is set; the
			* upload remains owned by this service across Session navigation until
			* completion or explicit removal. An image draft without an upload sends its
			* bytes with the prompt.
			* @param sessionId - target Agent-scope identity.
			* @param files - browser files to register.
			* @param uploadImages - whether the Session accepts image uploads; a subagent continuation does not.
			* @returns ordered draft descriptors.
			*/
			createDrafts(sessionId, files, uploadImages) {
				return files.map((file) => {
					if (isImageMediaType(file.type)) {
						const attachment = browserDraftAttachment(file);
						this.draftAttachments.set(attachment.id, attachment);
						probeDimensions(attachment);
						if (uploadImages) this.beginFileUpload(sessionId, attachment);
						return attachment;
					}
					const attachment = {
						kind: "file",
						id: randomUUID(),
						file
					};
					this.draftAttachments.set(attachment.id, attachment);
					this.beginFileUpload(sessionId, attachment);
					return attachment;
				});
			}
			/**
			* Restart one failed file or image upload.
			* @param sessionId - target Agent-scope identity.
			* @param id - draft attachment id whose upload previously failed.
			*/
			retryFileUpload(sessionId, id) {
				const attachment = this.draftAttachments.get(id);
				if (attachment === void 0) return;
				if (this.fileUploads.getSnapshot()[id]?.status !== "error") return;
				this.beginFileUpload(sessionId, attachment);
			}
			/**
			* Stage carried file and image drafts again for a new Session.
			* @param sessionId - target Agent-scope identity after a Workspace switch.
			* @param ids - carried draft attachment ids.
			* @param uploadImages - whether the target Session stages image uploads; an image draft otherwise sends inline.
			*/
			rebindDraftFiles(sessionId, ids, uploadImages) {
				for (const id of ids) {
					const attachment = this.draftAttachments.get(id);
					if (attachment === void 0) continue;
					if (attachment.kind === "image" && !uploadImages) this.dropUpload(id);
					else this.beginFileUpload(sessionId, attachment);
				}
			}
			beginFileUpload(sessionId, attachment) {
				this.fileUploadOperations.get(attachment.id)?.controller.abort();
				const controller = new AbortController();
				this.fileUploads.update((draft) => {
					draft[attachment.id] = {
						status: "uploading",
						loaded: 0
					};
				});
				let settle;
				const done = new Promise((resolve) => {
					settle = resolve;
				});
				this.fileUploadOperations.set(attachment.id, {
					controller,
					done
				});
				this.pendingFileUploads.add(done);
				done.then(() => {
					this.pendingFileUploads.delete(done);
				});
				const name = attachment.file.name === "" ? void 0 : attachment.file.name;
				const onProgress = (progress) => {
					if (this.fileUploadOperations.get(attachment.id)?.controller !== controller) return;
					this.fileUploads.update((draft) => {
						if (!(attachment.id in draft)) return;
						draft[attachment.id] = {
							status: "uploading",
							loaded: progress.loaded,
							...progress.total === void 0 ? {} : { total: progress.total }
						};
					});
				};
				const run = async () => {
					try {
						if (controller.signal.aborted || this.fileUploadOperations.get(attachment.id)?.controller !== controller) return;
						const result = attachment.kind === "image" ? await this.ctx.fileUpload.uploadImage(sessionId, attachment.file, imageMediaType(attachment.file.type), name, controller.signal, onProgress) : await this.ctx.fileUpload.upload(sessionId, attachment.file, name, controller.signal, onProgress);
						if (this.fileUploadOperations.get(attachment.id)?.controller !== controller) return;
						this.fileUploads.update((draft) => {
							if (!(attachment.id in draft)) return;
							if (result.ok) {
								draft[attachment.id] = "file" in result.value ? {
									status: "ready",
									receiptId: result.value.receiptId,
									file: result.value.file
								} : {
									status: "ready",
									receiptId: result.value.receiptId
								};
								return;
							}
							const { error } = result;
							draft[attachment.id] = error.code === "session/attachment-invalid" || error.code === "subagent/attachment-invalid" ? {
								status: "error",
								message: error.message,
								reason: error.details.reason
							} : {
								status: "error",
								message: error.message
							};
						});
					} catch (error) {
						if (this.fileUploadOperations.get(attachment.id)?.controller !== controller) return;
						this.fileUploads.update((draft) => {
							if (!(attachment.id in draft)) return;
							draft[attachment.id] = {
								status: "error",
								message: error instanceof Error ? error.message : String(error)
							};
						});
					} finally {
						if (this.fileUploadOperations.get(attachment.id)?.controller === controller) this.fileUploadOperations.delete(attachment.id);
					}
				};
				this.fileUploadQueue.push({
					run,
					settle
				});
				this.pumpFileUploads();
			}
			/** Start queued upload Workers until the configured concurrency is occupied. */
			pumpFileUploads() {
				while (this.activeFileUploads < this.maxConcurrentFileUploads) {
					const task = this.fileUploadQueue.shift();
					if (task === void 0) return;
					this.activeFileUploads += 1;
					task.run().finally(() => {
						this.activeFileUploads -= 1;
						task.settle();
						this.pumpFileUploads();
					});
				}
			}
			/**
			* Resolve ordered input-state ids to runtime-owned draft attachments.
			* @param ids - draft attachment ids.
			* @returns descriptors that remain live, in requested order.
			*/
			resolveDraftAttachments(ids) {
				const attachments = [];
				for (const id of ids) {
					const attachment = this.draftAttachments.get(id);
					if (attachment !== void 0) attachments.push(attachment);
				}
				return attachments;
			}
			/**
			* Serialize ordered draft attachments to command-submit wire payloads without
			* sending or releasing them. Images are encoded even when an upload already
			* stored them, because commands accept only file receipts; generic files cite
			* receipts from their completed background uploads and never reread browser bytes.
			* @param attachmentIds - ordered draft-local attachment ids.
			* @returns wire payloads in id order.
			*/
			async serializeDraftAttachments(attachmentIds, preferReceipts=false) {
				const attachments = this.resolveDraftAttachments(attachmentIds);
				if (attachments.length !== attachmentIds.length) throw new Error("conversation.serializeDraftAttachments: one or more draft attachments are no longer available");
				const uploads = this.fileUploads.getSnapshot();
				return { attachments: await Promise.all(attachments.map(async (attachment) => {
                    if(preferReceipts && uploads[attachment.id]?.status === 'ready')return {type:'file',receiptId:uploads[attachment.id].receiptId};
					if (attachment.kind === "image") return {
						type: "image",
						...await this.encodeImage(attachment.file)
					};
					const upload = uploads[attachment.id];
					if (upload === void 0 || upload.status !== "ready") throw new Error("conversation.serializeDraftAttachments: one or more files have not finished uploading");
					return {
						type: "file",
						receiptId: upload.receiptId
					};
				})) };
			}
			/**
			* Release one browser-owned draft attachment, aborting its active upload.
			* @param id - draft attachment id.
			*/
			releaseDraftAttachment(id) {
				const attachment = this.draftAttachments.get(id);
				if (attachment === void 0) return;
				this.draftAttachments.delete(id);
				if (attachment.kind === "image") revokePreview(attachment.previewUrl);
				this.dropUpload(id);
			}
			/** Abort one draft's active upload and drop its upload state. */
			dropUpload(id) {
				const operation = this.fileUploadOperations.get(id);
				this.fileUploadOperations.delete(id);
				operation?.controller.abort();
				this.forgetUpload(id);
			}
			/** Drop one draft's upload state. */
			forgetUpload(id) {
				const uploads = this.fileUploads.getSnapshot();
				if (!(id in uploads)) return;
				this.fileUploads.set(Object.fromEntries(Object.entries(uploads).filter(([key]) => key !== id)));
			}
			/**
			* Release a set of browser-owned draft attachments.
			* @param attachments - descriptors to release.
			*/
			releaseDraftAttachments(attachments) {
				for (const attachment of attachments) this.releaseDraftAttachment(attachment.id);
			}
			/** Apply one operation to a pending queue occurrence. */
			async updateQueue(itemId, action) {
				const result = await this.scopedSession("updateQueue").updateQueue(itemId, action);
				if (!result.ok) {
					if (action.kind === "steer" && (result.error.code === "session/steer-unavailable" || result.error.code === "session/queue-item-not-found")) return;
					throw new Error(`conversation.updateQueue failed: ${result.error.code}: ${result.error.message}`);
				}
			}
			/** Cancel the scoped session's in-flight turn while preserving Queue (failures land in promptError and reject, as in send). */
			async cancel() {
				const transport = this.composerTransports.get(this.scopeId("cancel"));
                if(transport)return transport.cancel();
                const result = await this.scopedSession("cancel").cancel();
				if (!result.ok) throw new Error(`conversation.cancel failed: ${result.error.code}: ${result.error.message}`);
			}
			/** Pull one older history page for the scoped Session. */
			async loadOlder() {
				await this.scopedSession("loadOlder").loadOlder();
			}
			/** Resolve the caller scope's session face or throw on root contexts. */
			scopedSession(op) {
				const id = this.scopeId(op);
				const binding = this.requireSessions().binding(id);
				if (binding === void 0) throw new Error(`conversation.${op}: session "${id}" resolved no binding`);
				return binding.session;
			}
			/** Read the caller's session scope tag via the sessions service; root contexts fail loud. */
			scopeId(op) {
				const id = this.requireSessions().scopeOf(this.ctx);
				if (id === void 0) throw new Error(`conversation.${op} requires a session scope — address one via ctx.sessions.scope(id).conversation`);
				return id;
			}
			requireSessions() {
				const sessions = this.ctx.get("sessions");
				if (sessions === void 0) throw new Error("conversation: sessions service unavailable");
				return sessions;
			}
			/**
			* Settle one submission's draft attachments when its echo is observed: each
			* file is released, and each image leaves the registry, handing its preview
			* URL to the durable image cache (seeded under the admitted reference so the
			* transcript node renders immediately while the cache reads canonical
			* bytes) or revoking it when the cache already holds that reference.
			*/
			settleSubmittedAttachments(sessionId, attachments, retirement) {
				const uiConversation = this.ctx.get("uiConversation");
				let observedIndex = 0;
				for (const attachment of attachments) {
					const live = this.draftAttachments.get(attachment.id);
					const ref = retirement.attachments[observedIndex++];
					if (live === void 0) continue;
					if (attachment.kind === "file") {
						this.releaseDraftAttachment(attachment.id);
						continue;
					}
					this.draftAttachments.delete(attachment.id);
					this.forgetUpload(attachment.id);
					if (ref !== void 0 && "mediaType" in ref && uiConversation?.seedImageUrl(sessionId, ref, attachment.previewUrl) === true) continue;
					revokePreview(attachment.previewUrl);
				}
			}
			/** Canonical base64 wire form of one browser image file. */
			async encodeImage(file) {
				return {
					mediaType: imageMediaType(file.type),
					data: await base64ImageOf(file),
					...file.name === "" ? {} : { name: file.name }
				};
			}
		};
		function imageMediaType(value) {
			switch (value) {
				case "image/png":
				case "image/jpeg":
				case "image/webp":
				case "image/gif": return value;
				default: throw new UnsupportedImageMediaTypeError(value);
			}
		}
		/**
		* Whether a browser-declared MIME selects the image draft path (all other files upload verbatim).
		* @param value - the browser's declared MIME type.
		* @returns whether the file is an accepted raster image.
		*/
		function isImageMediaType(value) {
			return value === "image/png" || value === "image/jpeg" || value === "image/webp" || value === "image/gif";
		}
		function revokePreview(url) {
			if (url.startsWith("blob:")) URL.revokeObjectURL(url);
		}
		//#endregion
		//#region lib/types/client/input/blocks.js
		/**
		* Composer blocks: the one way another plugin stops a session's input.
		*
		* The composer cannot read the plugins that would know — the dependency runs
		* ui-model-selection → ui-conversation, never back — so a blocker pushes here and the
		* bar reads its own session's store. A block carries the localized reason it
		* exists, because the plugin that raised it owns that copy; the composer only
		* knows how to render an inert textarea with a placeholder, exactly as it
		* already does for a session with no workspace.
		*
		* This is an affordance, not enforcement: the Host refuses a prompt it cannot
		* route regardless of what any client disables.
		*/
		/** The per-session composer-block registry (one instance per plugin fiber). */
		var ComposerBlockRegistry = class {
			stores = /* @__PURE__ */ new Map();
			/** @inheritdoc */
			set(sessionId, block) {
				const store = this.storeFor(sessionId);
				if (store.getSnapshot()?.reason === block?.reason) return;
				store.set(block);
			}
			/** @inheritdoc */
			storeFor(sessionId) {
				const existing = this.stores.get(sessionId);
				if (existing !== void 0) return existing;
				const created = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(void 0);
				this.stores.set(sessionId, created);
				return created;
			}
			/** @inheritdoc */
			forget(sessionId) {
				this.stores.delete(sessionId);
			}
		};
		//#endregion
		//#region lib/types/client/input/prompt.js
		/** Serialize semantic draft spans without turning quoted references into gestures. */
		const QUOTE_SEPARATOR = "\n\n";
		function pushText(tokens, text) {
			if (text === "") return;
			const last = tokens.at(-1);
			if (last?.kind === "text") last.text += text;
			else tokens.push({
				kind: "text",
				text
			});
		}
		function normalizeQuoteBoundaries(tokens) {
			const normalized = [];
			for (const token of tokens) {
				if (token.kind === "text") {
					pushText(normalized, token.text);
					continue;
				}
				const previous = normalized.at(-1);
				if (previous?.kind === "text") {
					previous.text = previous.text.trimEnd();
					if (previous.text !== "") previous.text += QUOTE_SEPARATOR;
					else normalized.pop();
				}
				if (normalized.at(-1)?.kind === "quote") normalized.push({
					kind: "text",
					text: QUOTE_SEPARATOR
				});
				normalized.push(token);
			}
			for (let index = 0; index < normalized.length; index++) {
				if (normalized[index]?.kind !== "quote") continue;
				const next = normalized[index + 1];
				if (next?.kind !== "text") continue;
				if (next.text === QUOTE_SEPARATOR && normalized[index + 2]?.kind === "quote") continue;
				next.text = next.text.trimStart();
				if (next.text !== "") next.text = `${QUOTE_SEPARATOR}${next.text}`;
			}
			return normalized.filter((token) => token.kind === "quote" || token.text !== "");
		}
		/**
		* Serialize the captured draft through reference codecs, formatting quotes as Markdown.
		* @param draft - one semantic draft revision.
		* @param serializeReference - owner-routed reference serializer.
		* @returns synchronous content without references, otherwise the resolving promise.
		*/
		function serializeDraftPrompt(draft, serializeReference) {
			const build = (references) => {
				const spans = [...references, ...(draft.quotes ?? []).map((quote) => ({
					offset: quote.offset,
					length: quote.length,
					token: {
						kind: "quote",
						text: quote.text
					}
				}))].sort((a, b) => a.offset - b.offset);
				const tokens = [];
				let cursor = 0;
				for (const span of spans) {
					pushText(tokens, draft.text.slice(cursor, span.offset));
					if (span.token.kind === "text") pushText(tokens, span.token.text);
					else tokens.push(span.token);
					cursor = span.offset + span.length;
				}
				pushText(tokens, draft.text.slice(cursor));
				const first = tokens[0];
				if (first?.kind === "text") first.text = first.text.trimStart();
				const last = tokens.at(-1);
				if (last?.kind === "text") last.text = last.text.trimEnd();
				return normalizeQuoteBoundaries(tokens).map((token) => token.kind === "quote" ? (0, _deepseek_ai_dsh_client_ui_primitives.formatQuoteText)(token.text) : token.text).join("");
			};
			if (draft.references.length === 0) return build([]);
			return Promise.all(draft.references.map(async (reference) => ({
				offset: reference.offset,
				length: reference.length,
				token: {
					kind: "text",
					text: await serializeReference(reference.source, reference.ref)
				}
			}))).then(build);
		}
		//#endregion
		//#region lib/types/client/input/machine.js
		/** Exhaustiveness backstop for the closed InputEvent union. */
		function unreachable(value) {
			throw new Error(`unreachable input event: ${JSON.stringify(value)}`);
		}
		/** Strip a claimed command token from its submit-time draft. */
		function argsAfter(draft, token) {
			const s = draft.trimStart();
			if (s.startsWith(token)) return s.slice(token.length);
			const base = token.trimEnd();
			if (s.startsWith(base)) {
				const rest = s.slice(base.length);
				return /^\s/.test(rest) ? rest.slice(1) : rest;
			}
			return "";
		}
		/** Pure phase, claim, and attempt owner for one Session input. */
		var SubmitMachine = class {
			phase = "plain";
			claim;
			seq = 0;
			inflight;
			/** Read-only snapshot of the submit-plane state. */
			get state() {
				const c = this.claim;
				return {
					phase: this.phase,
					...c ? { claim: {
						name: c.name,
						token: c.token,
						...c.hint !== void 0 ? { hint: c.hint } : {},
						...c.attachments === true ? { attachments: true } : {}
					} } : {}
				};
			}
			/** The attempt of the message being sent; undefined outside the sending phase. */
			get sendingAttempt() {
				return this.phase === "sending" ? this.inflight?.attempt : void 0;
			}
			/**
			* Feed one event through the machine.
			* @param ev - submit-plane event.
			* @returns effects for the SessionInput shell, in execution order.
			*/
			dispatch(ev) {
				switch (ev.type) {
					case "draft-changed": return this.followCommand(ev.command);
					case "claim": return this.followCommand(ev.claim);
					case "enter": return this.onEnter(ev);
					case "adjudicated": return this.onAdjudicated(ev.attempt, ev.outcome);
					case "adjudication-failed": return this.onAdjudicationFailed(ev.attempt, ev.message);
					case "submit-settled": return this.onSubmitSettled(ev);
					case "sink-settled": return this.onSinkSettled(ev);
					case "release": return this.onRelease();
					default: return unreachable(ev);
				}
			}
			/**
			* Outside a transaction the claim follows the document's leading command
			* chip: deleting or displacing the chip releases it, and a history restore
			* of the chip re-enters claimed. The claim event applies the same rule to a
			* chip the editor just inserted, before its update commits; busy phases
			* refuse both.
			*/
			followCommand(command) {
				if (this.phase !== "plain" && this.phase !== "claimed") return [];
				this.claim = command;
				this.phase = command === void 0 ? "plain" : "claimed";
				return [];
			}
			/** Occupy the frozen slot with the draft, references, quotes, and attachments the user sent. */
			beginAttempt(mode, draft, occurrences, quotes, attachmentIds, submission) {
				const controller = new AbortController();
				this.seq += 1;
				const attempt = {
					seq: this.seq,
					signal: controller.signal,
					draftSnapshot: draft,
					occurrences,
					quotes,
					attachmentIds,
					mode,
					...submission === void 0 ? {} : { submission }
				};
				this.inflight = {
					attempt,
					controller
				};
				return attempt;
			}
			/** Send the frozen message; the editor stays read-only until the Host accepts it. */
			send(attempt) {
				this.claim = void 0;
				this.phase = "sending";
				return [{
					type: "default-sink",
					attempt,
					draft: attempt.draftSnapshot,
					mode: attempt.mode
				}];
			}
			onEnter(ev) {
				if (this.phase === "adjudicating" || this.phase === "submitting" || this.phase === "sending") return [];
				const { mode, draft, occurrences, quotes, attachmentIds, submission } = ev;
				if (this.phase === "claimed" && this.claim !== void 0) {
					const attempt = this.beginAttempt(mode, draft, occurrences, quotes, attachmentIds, submission);
					this.phase = "submitting";
					return [{
						type: "begin-submit",
						attempt,
						claim: this.claim,
						args: argsAfter(draft, this.claim.token)
					}];
				}
				const trimmed = draft.trim();
				if (trimmed === "" && attachmentIds.length === 0) return [];
				const attempt = this.beginAttempt(mode, draft, occurrences, quotes, attachmentIds, submission);
				if (trimmed.startsWith("/")) {
					this.phase = "adjudicating";
					return [{
						type: "adjudicate",
						attempt,
						draft
					}];
				}
				return this.send(attempt);
			}
			onAdjudicated(attempt, outcome) {
				const flight = this.inflight;
				if (this.phase !== "adjudicating" || flight === void 0 || flight.attempt.seq !== attempt.seq) return [];
				if (outcome !== void 0 && outcome !== "handled" && "claim" in outcome) {
					this.claim = outcome.claim;
					this.phase = "submitting";
					return [{
						type: "begin-submit",
						attempt,
						claim: outcome.claim,
						args: argsAfter(attempt.draftSnapshot, outcome.claim.token)
					}];
				}
				if (outcome === void 0) return this.send(attempt);
				this.inflight = void 0;
				this.phase = "plain";
				return [];
			}
			onAdjudicationFailed(attempt, message) {
				if (this.phase !== "adjudicating" || this.inflight?.attempt.seq !== attempt.seq) return [];
				this.inflight = void 0;
				this.phase = "plain";
				return [{
					type: "notice",
					level: "error",
					text: message
				}];
			}
			/** Claimed command settlement; after a failure the claim follows the leading command chip again. */
			onSubmitSettled(ev) {
				const flight = this.inflight;
				if (this.phase !== "submitting" || flight === void 0 || flight.attempt.seq !== ev.attempt.seq) return [];
				this.inflight = void 0;
				if (ev.ok) {
					this.phase = "plain";
					this.claim = void 0;
					const effects = [{
						type: "commit-draft",
						retainSuffixOf: flight.attempt.draftSnapshot
					}];
					if (ev.outcome?.text !== void 0) effects.push({
						type: "notice",
						level: ev.outcome.kind === "error" ? "error" : "info",
						text: ev.outcome.text
					});
					return effects;
				}
				const text = ev.message ?? ev.outcome?.text;
				this.claim = ev.command;
				this.phase = ev.command === void 0 ? "plain" : "claimed";
				return text === void 0 ? [] : [{
					type: "notice",
					level: "error",
					text
				}];
			}
			/** An accepted message clears the editor; a refused or failed one returns to editing unchanged. */
			onSinkSettled(ev) {
				const flight = this.inflight;
				if (this.phase !== "sending" || flight === void 0 || flight.attempt.seq !== ev.attempt.seq) return [];
				this.inflight = void 0;
				this.phase = "plain";
				const effects = ev.ok ? [{
					type: "commit-draft",
					retainSuffixOf: null
				}] : [];
				const text = ev.message ?? ev.outcome?.text;
				if (text !== void 0) effects.push({
					type: "notice",
					level: ev.ok && ev.outcome?.kind !== "error" ? "info" : "error",
					text
				});
				return effects;
			}
			onRelease() {
				if (this.inflight !== void 0) {
					this.inflight.controller.abort();
					this.inflight = void 0;
				}
				this.phase = "plain";
				this.claim = void 0;
				return [];
			}
		};
		//#endregion
		//#region ../../../node_modules/.pnpm/lexical@0.49.0_patch_hash=54c4413db208cf234cb68c6a837f2523d3b319aa17911f1da385af08362e1356_typescript@6.0.3/node_modules/lexical/dist/Lexical.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		function t(t, ...e) {
			const n = new URL("https://lexical.dev/docs/error"), o = new URLSearchParams();
			o.append("code", t);
			for (const t of e) o.append("v", t);
			throw n.search = o.toString(), Error(`Minified Lexical error #${t}; visit ${n.toString()} for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`);
		}
		function e(t, ...e) {
			const n = new URL("https://lexical.dev/docs/error"), o = new URLSearchParams();
			o.append("code", t);
			for (const t of e) o.append("v", t);
			n.search = o.toString(), console.warn(`Minified Lexical warning #${t}; visit ${n.toString()} for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`);
		}
		const n = "undefined" != typeof window && void 0 !== window.document && void 0 !== window.document.createElement, o = n && "documentMode" in document ? document.documentMode : null, r$1 = n && /Mac|iPod|iPhone|iPad/.test(navigator.platform), i = n && /^(?!.*Seamonkey)(?=.*Firefox).*/i.test(navigator.userAgent), s = !(!n || !("InputEvent" in window) || o) && "getTargetRanges" in new window.InputEvent("input"), l = n && /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream, c = n && /Android/.test(navigator.userAgent), a = n && /Version\/[\d.]+.*Safari/.test(navigator.userAgent) && !c, u = n && /^(?=.*Chrome).*/i.test(navigator.userAgent), f = n && c && u, d$1 = n && /AppleWebKit\/[\d.]+/.test(navigator.userAgent) && r$1 && !u, h = 0, g = 1, _ = 2, b = 1, N = 2, E$1 = 3, w = 4, O$3 = 5, M$2 = 6, A = a || l || d$1 ? "\xA0" : "​", D$1 = "\n\n", F = i ? "\xA0" : A, z$1 = {
			bold: 1,
			capitalize: 1024,
			code: 16,
			highlight: 128,
			italic: 2,
			lowercase: 256,
			strikethrough: 4,
			subscript: 32,
			superscript: 64,
			underline: 8,
			uppercase: 512
		}, B = {
			directionless: 1,
			unmergeable: 2
		}, R$1 = {
			center: 2,
			end: 6,
			justify: 4,
			left: 1,
			right: 3,
			start: 5
		}, W = {
			[N]: "center",
			[M$2]: "end",
			[w]: "justify",
			[b]: "left",
			[E$1]: "right",
			[O$3]: "start"
		}, $ = {
			normal: 0,
			segmented: 2,
			token: 1
		}, U = {
			[h]: "normal",
			[_]: "segmented",
			[g]: "token"
		}, j = "$config";
		function J() {
			return vc()._blockCursorElement;
		}
		function V(t) {
			return null !== t && 1 === t.nodeType && t.hasAttribute("data-lexical-slot");
		}
		var q = class q {
			element;
			before;
			after;
			constructor(t, e, n) {
				this.element = t, this.before = e || null, this.after = n || null;
			}
			withBefore(t) {
				return new q(this.element, t, this.after);
			}
			withAfter(t) {
				return new q(this.element, this.before, t);
			}
			withElement(t) {
				return this.element === t ? this : new q(t, this.before, this.after);
			}
			insertChild(e) {
				const n = this.getInsertionAnchor();
				return null !== n && n.parentElement !== this.element && t(357), this.element.insertBefore(e, n), this;
			}
			removeChild(e) {
				return e.parentElement !== this.element && t(358), this.element.removeChild(e), this;
			}
			replaceChild(e, n) {
				return n.parentElement !== this.element && t(359), this.element.replaceChild(e, n), this;
			}
			getFirstChild() {
				const t = this.getFirstChildAnchor(), e = t ? t.nextSibling : this.element.firstChild;
				return e === this.getInsertionAnchor() ? null : e;
			}
			getFirstChildAnchor() {
				return this.after;
			}
			resolveLeafPosition(t, e, n) {
				if (this.element === t) return e === t && 0 === n ? "before" : "after";
				const o = Y(t, this.element);
				if (null === o) return "after";
				const r = Array.prototype.indexOf.call(t.childNodes, o);
				if (r < 0) return "after";
				if (e === t) return n <= r ? "before" : "after";
				const i = Y(t, e);
				if (null === i) return "after";
				const s = Array.prototype.indexOf.call(t.childNodes, i);
				return s >= 0 && s <= r ? "before" : "after";
			}
			getInsertionAnchor() {
				return this.before;
			}
		};
		function Y(t, e) {
			let n = e;
			for (; null !== n && n.parentNode !== t;) n = n.parentNode;
			return n;
		}
		var G = class G extends q {
			withBefore(t) {
				return new G(this.element, t, this.after);
			}
			withAfter(t) {
				return new G(this.element, this.before, t);
			}
			withElement(t) {
				return this.element === t ? this : new G(t, this.before, this.after);
			}
			getInsertionAnchor() {
				return super.getInsertionAnchor() || this.getManagedLineBreak();
			}
			getFirstChildAnchor() {
				let t = super.getFirstChildAnchor(), e = t ? t.nextSibling : this.element.firstChild;
				for (; V(e);) t = e, e = e.nextSibling;
				const n = t ? t.nextSibling : this.element.firstChild;
				return null !== n && n === J() ? n : t;
			}
			getManagedLineBreak() {
				return this.element.__lexicalLineBreak || null;
			}
			setManagedLineBreak(t) {
				if (this.element.__lexicalLastChildKind = t, null === t) this.removeManagedLineBreak();
				else {
					const e = "decorator" === t && (d$1 || l || a);
					this.insertManagedLineBreak(e);
				}
			}
			removeManagedLineBreak() {
				const t = this.getManagedLineBreak();
				if (t) {
					const e = this.element, n = "IMG" === t.nodeName ? t.nextSibling : null;
					n && e.removeChild(n), e.removeChild(t), e.__lexicalLineBreak = void 0;
				}
			}
			insertManagedLineBreak(t) {
				const e = this.getManagedLineBreak();
				if (e) {
					if (t === ("IMG" === e.nodeName)) return;
					this.removeManagedLineBreak();
				}
				const n = this.element, o = this.before, r = Zl().createElement("br");
				if (r.setAttribute("data-lexical-managed-linebreak", "true"), n.insertBefore(r, o), t) {
					const t = Zl().createElement("img");
					t.setAttribute("data-lexical-managed-linebreak", "true"), t.style.setProperty("display", "inline", "important"), t.style.setProperty("border", "0px", "important"), t.style.setProperty("margin", "0px", "important"), t.alt = "", n.insertBefore(t, r), n.__lexicalLineBreak = t;
				} else n.__lexicalLineBreak = r;
			}
			getFirstChildOffset() {
				const t = this.getFirstChild(), e = this.getInsertionAnchor();
				let n = 0;
				for (let o = this.element.firstChild; null !== o && o !== t && o !== e; o = o.nextSibling) n++;
				return n;
			}
			resolveChildIndex(t, e, n, o) {
				if (n === this.element) {
					const e = this.getFirstChildOffset(), n = J(), r = this.element.childNodes, i = Math.min(o, r.length);
					let s = 0;
					for (let t = e; t < i; t++) r[t] !== n && s++;
					return [t, Math.min(s, t.getChildrenSize())];
				}
				const r = X(e, n);
				r.push(o);
				const i = X(e, this.element);
				let s = t.getIndexWithinParent();
				for (let t = 0; t < i.length; t++) {
					const e = r[t], n = i[t];
					if (void 0 === e || e < n) break;
					if (e > n) {
						s += 1;
						break;
					}
				}
				return [t.getParentOrThrow(), s];
			}
		};
		function X(e, n) {
			const o = [];
			let r = n;
			for (; r !== e && null !== r; r = r.parentNode) {
				let t = 0;
				for (let e = r.previousSibling; null !== e; e = e.previousSibling) t++;
				o.push(t);
			}
			return r !== e && t(225), o.reverse();
		}
		let Q;
		try {
			Q = "0.49.0+prod.esm";
		} catch (t) {}
		const Z$1 = Q ?? "\"<unknown>+source\"";
		var tt = class {
			_front = /* @__PURE__ */ new Set();
			_back = /* @__PURE__ */ new Set();
			_cache;
			get size() {
				return this._front.size + this._back.size;
			}
			addBack(t) {
				return delete this._cache, this._front.has(t) || this._back.add(t), this;
			}
			addFront(t) {
				return delete this._cache, this._back.has(t) || this._front.add(t), this;
			}
			delete(t) {
				return delete this._cache, this._front.delete(t) || this._back.delete(t);
			}
			toArray() {
				const t = Array.from(this._front).reverse();
				for (const e of this._back) t.push(e);
				return t;
			}
			toReadonlyArray() {
				return this._cache = this._cache || this.toArray(), this._cache;
			}
			[Symbol.iterator]() {
				return this.toReadonlyArray()[Symbol.iterator]();
			}
		};
		const et$1 = null;
		function nt$2(t, e = 1e3) {
			return t instanceof ot$1 ? t.clone() : t.size < e ? new Map(t) : new ot$1().init(new Map(t), void 0, t.size);
		}
		var ot$1 = class ot$1 {
			_mutable = !1;
			_old = void 0;
			_nursery = void 0;
			_size = 0;
			clone() {
				return this._mutable = !1, new ot$1().init(this._old, this._nursery, this._size);
			}
			init(t, e, n) {
				return this._old = t, this._nursery = e, this._size = n, this;
			}
			get size() {
				return this._size;
			}
			has(t) {
				return void 0 !== this.get(t);
			}
			getWithTombstone(t) {
				const e = this._nursery && this._nursery.get(t);
				return void 0 !== e ? e : this._old && this._old.get(t);
			}
			get(t) {
				const e = this.getWithTombstone(t);
				return e === et$1 ? void 0 : e;
			}
			shouldCompact() {
				return void 0 !== this._nursery && 2 * this._nursery.size > this._size;
			}
			getNursery() {
				return this._mutable && this._nursery || (this.compact(), this._nursery = new Map(this._nursery), this._mutable = !0), this._nursery;
			}
			compact(t = !1) {
				if (this._nursery && this._nursery.size > 0 && (t || this.shouldCompact())) {
					const t = new Map(this._old);
					for (const [e, n] of this._nursery) n !== et$1 ? t.set(e, n) : t.delete(e);
					this._old = t, this._nursery = void 0;
				}
				return this._mutable = !1, this;
			}
			set(t, e) {
				const n = this.getWithTombstone(t);
				if (n === e) return this;
				const o = this.getNursery();
				return n !== et$1 && void 0 !== n || (this._size++, n === et$1 && o.delete(t)), o.set(t, e), this;
			}
			delete(t) {
				const e = this.has(t);
				return e && (this.getNursery().set(t, et$1), this._size--), e;
			}
			getOrInsert(t, e) {
				const n = this.get(t);
				return void 0 !== n ? n : (this.set(t, e), e);
			}
			getOrInsertComputed(t, e) {
				const n = this.get(t);
				if (void 0 !== n) return n;
				const o = e(t);
				return this.set(t, o), o;
			}
			clear() {
				this._mutable = !1, this._old = void 0, this._nursery = void 0, this._size = 0;
			}
			*keys() {
				for (const t of this.entries()) yield t[0];
			}
			*values() {
				for (const t of this.entries()) yield t[1];
			}
			*entries() {
				const t = this._nursery, e = this._old;
				if (e) for (const n of e) {
					const e = n[0], o = t ? t.get(e) : void 0;
					o !== et$1 && (void 0 !== o && (n[1] = o), yield n);
				}
				if (t) for (const n of t) n[1] === et$1 || e && e.has(n[0]) || (yield n);
			}
			forEach(t, e) {
				void 0 !== e && (t = t.bind(e));
				for (const [e, n] of this.entries()) t(n, e, this);
			}
			get [Symbol.toStringTag]() {
				return "GenMap";
			}
			[Symbol.iterator]() {
				return this.entries();
			}
		};
		function rt$1(t, e, n, o, r, i) {
			if (Pi(t)) {
				let s = t.getFirstChild();
				for (; null !== s;) {
					const t = s.__key;
					s.__parent === e && ((Pi(s) || Qc(s) && null !== s.__slots) && rt$1(s, t, n, o, r, i), n.has(t) || i.delete(t), r.push(t)), s = s.getNextSibling();
				}
			}
			for (const s of Qc(t) && null !== t.__slots ? t.__slots.values() : []) {
				const t = o.get(s);
				void 0 !== t && Zc(t) && t.__slotHost === e && ((Pi(t) || Qc(t) && null !== t.__slots) && rt$1(t, s, n, o, r, i), n.has(s) || i.delete(s), r.push(s));
			}
		}
		let it$1 = !1, st$1 = 0;
		function lt$1(t) {
			st$1 = t.timeStamp;
		}
		function ct$1(t, e, n) {
			const o = "BR" === t.nodeName, r = e.__lexicalLineBreak;
			return r && (t === r || o && t.previousSibling === r) || o && void 0 !== Qs(t, n);
		}
		function at(t, e, n) {
			const o = Jl(Il(n)), r = o && nc(o, n._rootElement);
			let i = null, s = null;
			null !== r && r.anchorNode === t && (i = r.anchorOffset, s = r.focusOffset);
			const l = t.nodeValue;
			null !== l && fl(e, l, i, s, !1);
		}
		function ut$1(t, e, n) {
			if (ur(t)) {
				const e = t.anchor.getNode();
				if (e.is(n) && t.format !== e.getFormat()) return !1;
			}
			return zs(e) && n.isAttached();
		}
		function ft$1(t, e, n) {
			for (let o = t; o && !zc(o); o = wl(o)) {
				const t = Qs(o, e);
				if (void 0 !== t) {
					const e = Ys(t, n);
					if (e) return Ki(e) || !gc(o) ? void 0 : [o, e];
				}
			}
		}
		function dt$1(t, e, n) {
			it$1 = !0;
			const o = performance.now() - st$1 > 100;
			try {
				Ai(t, () => {
					const r = Kr() || function(t) {
						return t.read("latest", () => {
							const t = Kr();
							return null !== t ? t.clone() : null;
						});
					}(t), s = /* @__PURE__ */ new Map(), l = t._editorState, c = t._blockCursorElement;
					let a = !1, u = "";
					for (let n = 0; n < e.length; n++) {
						const f = e[n], d = f.type, h = f.target, g = ft$1(h, t, l);
						if (!g) continue;
						const [_, p] = g;
						if ("characterData" === d) o && Xo(p) && zs(h) && ut$1(r, h, p) && at(h, p, t);
						else if ("childList" === d) {
							a = !0;
							const e = f.addedNodes;
							for (let n = 0; n < e.length; n++) {
								const o = e[n], r = Gs(o), s = o.parentNode;
								if (!(null == s || o === c || null !== r || ct$1(o, s, t) || t._slotsUsed && gc(o) && o.hasAttribute("data-lexical-slot") || zc(o))) {
									if (i) {
										const t = (gc(o) ? o.innerText : null) || o.nodeValue;
										t && (u += t);
									}
									s.removeChild(o);
								}
							}
							const n = f.removedNodes, o = n.length;
							if (o > 0) {
								let e = 0;
								for (let r = 0; r < o; r++) {
									const o = n[r];
									(ct$1(o, h, t) || c === o) && (h.appendChild(o), e++);
								}
								o !== e && s.set(_, p);
							}
						}
					}
					if (s.size > 0) for (const [e, n] of s) n.reconcileObservedMutation(e, t);
					const f = n.takeRecords();
					if (f.length > 0) {
						for (let e = 0; e < f.length; e++) {
							const n = f[e], o = n.addedNodes, r = n.target;
							for (let e = 0; e < o.length; e++) {
								const n = o[e], i = n.parentNode;
								null == i || "BR" !== n.nodeName || ct$1(n, r, t) || i.removeChild(n);
							}
						}
						n.takeRecords();
					}
					null !== r && (a && ol(r), i && bl(t) && r.insertRawText(u));
				});
			} finally {
				it$1 = !1;
			}
		}
		function ht$2(t) {
			const e = t._observer;
			if (null !== e) dt$1(t, e.takeRecords(), e);
		}
		function gt$1(t) {
			(function(t) {
				0 === st$1 && Il(t).addEventListener("textInput", lt$1, !0);
			})(t), t._observer = new MutationObserver((e, n) => {
				dt$1(t, e, n);
			});
		}
		var yt$2 = class {
			key;
			parse;
			unparse;
			isEqual;
			defaultValue;
			resetOnCopyNode;
			constructor(t, e) {
				this.key = t, this.parse = e.parse.bind(e), this.unparse = (e.unparse || wt).bind(e), this.isEqual = (e.isEqual || Object.is).bind(e), this.defaultValue = this.parse(void 0), this.resetOnCopyNode = e.resetOnCopyNode || !1;
			}
		};
		function mt$2(t, e) {
			return new yt$2(t, e);
		}
		function vt$1(t) {
			const e = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Set();
			for (const { ownNodeConfig: o } of jc("function" == typeof t ? t : t.replace)) if (o && o.stateConfigs) for (const t of o.stateConfigs) {
				let o;
				"stateConfig" in t ? (o = t.stateConfig, t.flat && n.add(o.key)) : o = t, e.set(o.key, o);
			}
			return {
				flatKeys: n,
				sharedConfigMap: e
			};
		}
		const Tt$2 = new Set([
			"__proto__",
			"constructor",
			"prototype"
		]);
		var kt$1 = class kt$1 {
			node;
			knownState;
			unknownState;
			sharedNodeState;
			size;
			constructor(t, e, n = void 0, o = /* @__PURE__ */ new Map(), r = void 0) {
				this.node = t, this.sharedNodeState = e, this.unknownState = n, this.knownState = o;
				const { sharedConfigMap: i } = this.sharedNodeState, s = void 0 !== r ? r : function(t, e, n) {
					let o = n.size;
					if (e) for (const r in e) {
						const e = t.get(r);
						e && n.has(e) || o++;
					}
					return o;
				}(i, n, o);
				this.size = s;
			}
			getValue(t) {
				const e = this.knownState.get(t);
				if (void 0 !== e) return e;
				this.sharedNodeState.sharedConfigMap.set(t.key, t);
				let n = t.defaultValue;
				if (this.unknownState && t.key in this.unknownState) {
					const e = this.unknownState[t.key];
					void 0 !== e && (n = t.parse(e)), this.updateFromKnown(t, n);
				}
				return n;
			}
			getInternalState() {
				return [this.unknownState, this.knownState];
			}
			toJSON() {
				const t = { ...this.unknownState }, e = {};
				for (const [e, n] of this.knownState) e.isEqual(n, e.defaultValue) ? delete t[e.key] : t[e.key] = e.unparse(n);
				for (const n of this.sharedNodeState.flatKeys) n in t && (e[n] = t[n], delete t[n]);
				return Et$1(t) && (e.$ = t), e;
			}
			getWritable(t) {
				if (this.node === t) return this;
				const { sharedNodeState: e, unknownState: n } = this, o = new Map(this.knownState);
				return new kt$1(t, e, function(t, e, n) {
					let o;
					if (n) for (const [r, i] of Object.entries(n)) {
						if (Tt$2.has(r)) continue;
						const n = t.get(r);
						n ? e.has(n) || e.set(n, n.parse(i)) : (o = o || {}, o[r] = i);
					}
					return o;
				}(e.sharedConfigMap, o, n), o, this.size);
			}
			resetOnCopyNode() {
				for (const t of this.knownState.keys()) t.resetOnCopyNode && this.knownState.set(t, t.defaultValue);
				return this;
			}
			updateFromKnown(t, e) {
				const n = t.key;
				this.sharedNodeState.sharedConfigMap.set(n, t);
				const { knownState: o, unknownState: r } = this;
				o.has(t) || r && n in r || (r && (delete r[n], this.unknownState = Et$1(r)), this.size++), o.set(t, e);
			}
			updateFromUnknown(t, e) {
				if (Tt$2.has(t)) return;
				const n = this.sharedNodeState.sharedConfigMap.get(t);
				n ? this.updateFromKnown(n, n.parse(e)) : (this.unknownState = this.unknownState || {}, t in this.unknownState || this.size++, this.unknownState[t] = e);
			}
			updateFromJSON(t) {
				const { knownState: e } = this;
				for (const t of e.keys()) e.set(t, t.defaultValue);
				if (this.size = e.size, this.unknownState = void 0, t) for (const [e, n] of Object.entries(t)) this.updateFromUnknown(e, n);
			}
		};
		function bt$2(t) {
			const e = t.getWritable(), n = e.__state ? e.__state.getWritable(e) : new kt$1(e, Nt$1(e));
			return e.__state = n, n;
		}
		function Nt$1(t) {
			return t.__state ? t.__state.sharedNodeState : Ns(vc(), t.getType()).sharedNodeState;
		}
		function Et$1(t) {
			if (t) for (const e in t) return t;
		}
		function wt(t) {
			return t;
		}
		function Ot$1(t, e, n) {
			for (const [o, r] of e.knownState) {
				if (t.has(o.key)) continue;
				t.add(o.key);
				const e = n ? n.getValue(o) : o.defaultValue;
				if (e !== r && !o.isEqual(e, r)) return !0;
			}
			return !1;
		}
		function Mt$1(t, e, n) {
			const { unknownState: o } = e, r = n ? n.unknownState : void 0;
			if (o) for (const [e, n] of Object.entries(o)) {
				if (t.has(e)) continue;
				t.add(e);
				if (n !== (r ? r[e] : void 0)) return !0;
			}
			return !1;
		}
		function At(t, e) {
			const n = t.__state;
			return n && n.node === t ? n.getWritable(e) : n;
		}
		function Dt$1(t, e) {
			const n = t.__mode, o = t.__format, r = t.__style, i = e.__mode, s = e.__format, l = e.__style, c = t.__state, a = e.__state;
			return (null === n || n === i) && (null === o || o === s) && (null === r || r === l) && (null === t.__state || c === a || function(t, e) {
				if (t === e) return !0;
				const n = /* @__PURE__ */ new Set();
				return !(t && Ot$1(n, t, e) || e && Ot$1(n, e, t) || t && Mt$1(n, t, e) || e && Mt$1(n, e, t));
			}(c, a));
		}
		function Ft$1(t, e) {
			const n = t.mergeWithSibling(e), o = _i()._normalizedNodes;
			return o.add(t.__key), o.add(e.__key), n;
		}
		function Pt$1(t) {
			let e, n, o = t;
			if ("" !== o.__text || !o.isSimpleText() || o.isUnmergeable()) {
				for (; null !== (e = o.getPreviousSibling()) && Xo(e) && e.isSimpleText() && !e.isUnmergeable();) {
					if ("" !== e.__text) {
						if (Dt$1(e, o)) {
							o = Ft$1(e, o);
							break;
						}
						break;
					}
					e.remove();
				}
				for (; null !== (n = o.getNextSibling()) && Xo(n) && n.isSimpleText() && !n.isUnmergeable();) {
					if ("" !== n.__text) {
						if (Dt$1(o, n)) {
							o = Ft$1(o, n);
							break;
						}
						break;
					}
					n.remove();
				}
			} else o.remove();
		}
		function It(t) {
			return Lt$1(t.anchor), Lt$1(t.focus), t;
		}
		function Lt$1(t) {
			for (; "element" === t.type;) {
				const e = t.getNode(), n = t.offset;
				let o, r;
				if (n === e.getChildrenSize() ? (o = e.getChildAtIndex(n - 1), r = !0) : (o = e.getChildAtIndex(n), r = !1), Xo(o)) {
					t.set(o.__key, r ? o.getTextContentSize() : 0, "text", !0);
					break;
				}
				if (!Pi(o)) break;
				t.set(o.__key, r ? o.getChildrenSize() : 0, "element", !0);
			}
		}
		const Kt$2 = Symbol.for("@lexical/CachedTextSize");
		function zt$2(e, n) {
			return ee$3.read(() => {
				let o = 0, r = e;
				for (let e = 0; e < n && null !== r; e++) {
					const i = te$3.get(r);
					if (void 0 === i && t(345, r), Pi(i)) {
						const s = ne$3.get(r);
						if (void 0 !== s && Pi(s) && s.__parent !== i.__parent) o += i.getTextContentSize();
						else {
							const e = oe$3.get(r), n = e && e.__lexicalTextContent;
							"string" != typeof n && t(346, i.getType()), o += n.length;
						}
						e < n - 1 && !i.isInline() && (o += 2);
					} else {
						const e = i[Kt$2];
						void 0 === e && t(347, i.getType(), r), o += e;
					}
					r = i.__next;
				}
				return o;
			}, { editor: $t$2 });
		}
		function Bt$3(t) {
			Pi(t) || void 0 === t[Kt$2] && (t[Kt$2] = Xo(t) ? t.__text.length : t.getTextContentSize());
		}
		const Rt$1 = 4;
		let Wt$2, $t$2, Ut$2, Ht$2 = "", jt$2 = null, Jt$2 = null, Vt$2 = null;
		function qt$2() {
			return {
				firstTextKey: Vt$2,
				format: jt$2,
				style: Jt$2
			};
		}
		function Yt$2(t) {
			null !== t.firstTextKey && (jt$2 = t.format, Jt$2 = t.style, Vt$2 = t.firstTextKey);
		}
		function Gt$2(e) {
			if (null !== Vt$2) return;
			const n = e.__lexicalFirstTextKey;
			if (void 0 === n && t(348), null === n) return;
			const o = ne$3.get(n);
			Xo(o) && (jt$2 = o.getFormat(), Jt$2 = o.getStyle(), Vt$2 = n);
		}
		let Xt$2, Qt$2, Zt$2, te$3, ee$3, ne$3, oe$3, re$2, ie$2, se$2, le$2 = !1, ce$2 = !1;
		function ae$2(t, e) {
			const n = te$3.get(t), o = ne$3.has(t);
			if (null !== e) {
				const n = Fe$2(t);
				n.parentNode === e && e.removeChild(n);
			}
			if (!o) {
				if ($t$2._keyToDOMMap.delete(t), Pi(n)) {
					const t = Yc(n, te$3);
					ue$1(t, 0, t.length - 1, null);
				}
				if (void 0 !== n) {
					for (const t of xe$1(n).values()) {
						const e = Se$1(t);
						ae$2(t, null), null !== e && e.remove();
					}
					Sl(ie$2, Ut$2, Xt$2, n, "destroyed");
				}
			}
		}
		function ue$1(t, e, n, o) {
			for (let r = e; r <= n; ++r) {
				const e = t[r];
				void 0 !== e && ae$2(e, o);
			}
		}
		function fe$1(t, e) {
			t.setProperty("text-align", e);
		}
		const de$2 = "40px";
		function he(t, e) {
			const n = Wt$2.theme.indent;
			if ("string" == typeof n) {
				const o = t.classList.contains(n);
				e > 0 && !o ? t.classList.add(n) : e < 1 && o && t.classList.remove(n);
			}
			t.style.setProperty("padding-inline-start", 0 === e ? "" : `calc(${e} * var(--lexical-indent-base-value, ${de$2}))`);
		}
		function ge$1(t, e) {
			const n = t.style;
			0 === e ? fe$1(n, "") : 1 === e ? fe$1(n, "left") : 2 === e ? fe$1(n, "center") : 3 === e ? fe$1(n, "right") : 4 === e ? fe$1(n, "justify") : 5 === e ? fe$1(n, "start") : 6 === e && fe$1(n, "end");
		}
		function _e$2(t, e) {
			const n = function(t) {
				const e = t.__dir;
				if (null !== e) return e;
				if (Bi(t)) return null;
				const n = t.getParent();
				return null === n || Bl(n) && null === n.__dir ? "auto" : null;
			}(e);
			null !== n ? t.dir = n : t.removeAttribute("dir");
		}
		function pe$1(t) {
			const e = Zl().createElement("div");
			return e.setAttribute("data-lexical-slot", t), e.style.display = "none", e;
		}
		function ye$1(t, e, n) {
			e || "false" === t.contentEditable ? Bc(n, $t$2) : n.removeAttribute("contenteditable");
		}
		function me$2(t, e, n) {
			const o = Ht$2, r = qt$2();
			Ht$2 = "";
			let i = "";
			const s = Ki(t);
			for (const [o, r] of n) {
				const n = pe$1(o);
				ye$1(e, s, n), e.appendChild(n), Ht$2 = "";
				const l = qt$2();
				Te$2(r, kc(t, n, $t$2)), Yt$2(l), Ce$2(t, o, e, n), i += Ht$2;
			}
			return Yt$2(r), Ht$2 = o, i;
		}
		function xe$1(t) {
			return Qc(t) && null !== t.__slots ? t.__slots : Xc;
		}
		function Ce$2(t, e, n, o) {
			const r = se$2.$getSlotTargetElement(t, e, n, $t$2);
			null !== r && (o.parentElement !== r && r.appendChild(o), o.style.display = "");
		}
		function Se$1(t) {
			const e = oe$3.get(t);
			return void 0 !== e ? e.parentElement : null;
		}
		function ve$2(t, e, n) {
			const o = xe$1(t), r = xe$1(e);
			for (const [t, e] of o) if (!r.has(t)) {
				const t = Se$1(e);
				ae$2(e, null), null !== t && t.remove();
			}
			const i = Ht$2, s = qt$2();
			let l = "", c = null;
			const a = Ki(e);
			for (const [t, i] of r) {
				const r = o.get(t);
				let s = void 0 !== r ? Se$1(r) : null;
				Ht$2 = "";
				const u = qt$2();
				if (null === s) {
					s = pe$1(t);
					let o = null;
					for (const t of n.children) if (!t.hasAttribute("data-lexical-slot")) {
						o = t;
						break;
					}
					n.insertBefore(s, o), Te$2(i, kc(e, s, $t$2));
				} else r === i ? we$1(i, s) : (void 0 !== r && ae$2(r, s), Te$2(i, kc(e, s, $t$2)));
				if (Yt$2(u), ye$1(n, a, s), Ce$2(e, t, n, s), l += Ht$2, s.parentElement === n) {
					const t = null === c ? n.firstChild : c.nextSibling;
					t !== s && n.insertBefore(s, t), c = s;
				}
			}
			return Yt$2(s), Ht$2 = i, l;
		}
		function Te$2(e, n) {
			const o = ne$3.get(e);
			if (void 0 === o && t(60), null !== n) {
				const t = te$3.get(e);
				if (void 0 !== t) {
					const r = oe$3.get(e);
					if (void 0 !== r) {
						const i = Zc(t) ? t.__slotHost : null, s = Zc(o) ? o.__slotHost : null, l = t.__parent !== o.__parent || i !== s, c = null !== s && r.parentElement !== n.element;
						if (l || c) return n.insertChild(r), we$1(e, n.element);
					}
				}
			}
			const r = se$2.$createDOM(o, $t$2);
			if (function(t, e, n) {
				const o = n._keyToDOMMap;
				Xs(e, n, t), o.set(t, e);
			}(e, r, $t$2), Xo(o) ? r.setAttribute("data-lexical-text", "true") : Ki(o) && (r.setAttribute("data-lexical-decorator", "true"), Kc(r, { captureSelection: !0 })), Pi(o)) {
				const t = o.__indent, e = o.__size;
				_e$2(r, o), 0 !== t && he(r, t);
				const n = xe$1(o), i = n.size > 0 ? me$2(o, r, n) : "";
				if (0 === e) r.__lexicalTextContent = i, r.__lexicalFirstTextKey = null, Ht$2 += i, n.size > 0 && (r.__lexicalSlotTextLength = i.length);
				else {
					const t = Ht$2, s = e - 1;
					if (ke$2(Yc(o, ne$3), o, 0, s, kc(o, r, $t$2)), "" !== i) {
						const e = r.__lexicalTextContent || "";
						r.__lexicalTextContent = i + e, Ht$2 = t + i + e;
					}
					n.size > 0 && (r.__lexicalSlotTextLength = i.length);
				}
				const s = o.__format;
				0 !== s && ge$1(r, s), o.isInline() || be$1(null, o, r);
			} else {
				const t = o.getTextContent();
				if (Ki(o)) {
					const t = o.decorate($t$2, Wt$2);
					null !== t && Oe$1(e, t), r.contentEditable = "false";
					const n = xe$1(o);
					n.size > 0 && me$2(o, r, n);
				}
				Ht$2 += t;
			}
			return null !== n && n.insertChild(r), se$2.$decorateDOM(o, null, r, $t$2), Bt$3(o), Sl(ie$2, Ut$2, Xt$2, o, "created"), r;
		}
		function ke$2(e, n, o, r, i) {
			const s = Ht$2, l = qt$2();
			Ht$2 = "", jt$2 = null, Jt$2 = null, Vt$2 = null;
			let c = o;
			for (; c <= r; ++c) {
				const t = qt$2();
				Te$2(e[c], i);
				const n = ne$3.get(e[c]);
				null !== n && Xo(n) ? null === jt$2 && (jt$2 = n.getFormat(), Jt$2 = n.getStyle(), Vt$2 = n.__key) : Pi(n) && c < r && !n.isInline() && (Ht$2 += D$1), Yt$2(t);
			}
			const a = $t$2._keyToDOMMap.get(n.__key);
			void 0 === a && t(349, n.__key), a.__lexicalTextContent = Ht$2, a.__lexicalFirstTextKey = Vt$2, Ht$2 = s + Ht$2, Yt$2(l);
		}
		function be$1(t, e, n) {
			const o = kc(e, n, $t$2), r = o.element.__lexicalLastChildKind ?? null, i = function(t, e) {
				if (t) {
					const n = t.__last;
					if (n) {
						const t = e.get(n);
						if (t) return Yi(t) ? "line-break" : Ki(t) && t.isInline() ? "decorator" : null;
					}
					return xe$1(t).size > 0 ? null : "empty";
				}
				return null;
			}(e, ne$3);
			r !== i && o.setManagedLineBreak(i);
		}
		function Ne$1(e, n, o) {
			var r;
			jt$2 = null, Jt$2 = null, Vt$2 = null, function(e, n, o) {
				const r = Ht$2, i = e.__size, s = n.__size;
				Ht$2 = "";
				const l = o.element, c = $t$2._keyToDOMMap.get(n.__key);
				void 0 === c && t(351, n.__key);
				const a = s - i;
				if (!le$2 && Math.abs(a) <= 1 && i >= Rt$1 && e.__first === n.__first && (0 !== a || !$t$2._cloneNotNeeded.has(e.__key))) {
					const i = c.__lexicalTextContent, u = re$2.get(e.__key);
					if (!le$2 && "string" == typeof i && void 0 !== u) {
						const s = function(t, e) {
							const n = e.size;
							if (0 === n || n >= t.__size) return null;
							let o = t.__last, r = null, i = 0;
							for (; null !== o && i < n;) {
								if (!e.has(o)) return null;
								r = o;
								const t = ne$3.get(o);
								if (void 0 === t) return null;
								o = t.__prev, i++;
							}
							if (i !== n) return null;
							if (null !== o && e.has(o)) return null;
							return r;
						}(n, u);
						if (null !== s) {
							const f = u.size;
							if (0 === a) {
								const e = zt$2(s, f);
								let o = s, a = 0;
								for (; null !== o && a < f;) {
									const t = ne$3.get(o);
									if (void 0 === t) break;
									const e = qt$2();
									we$1(o, l), Xo(t) && null === jt$2 && (jt$2 = t.getFormat(), Jt$2 = t.getStyle(), Vt$2 = t.__key), Yt$2(e), o = t.__next, a++;
								}
								let d = "";
								for (o = s, a = 0; null !== o && a < f;) {
									const e = ne$3.get(o);
									if (void 0 === e) break;
									let n;
									if (Pi(e)) {
										const r = $t$2._keyToDOMMap.get(o), i = r && r.__lexicalTextContent;
										"string" != typeof i && t(352, e.getType()), n = i;
									} else n = e.getTextContent();
									d += n, a < f - 1 && Pi(e) && !e.isInline() && (d += D$1), o = e.__next, a++;
								}
								const h = c.__lexicalSlotTextLength || 0, g = h > 0 ? i.slice(h) : i, _ = g.slice(0, g.length - e) + d;
								c.__lexicalTextContent = _, Ht$2 = r + _, Ee$1(n, c, u);
								return;
							}
							if (function(e, n, o, r, i, s, l, c) {
								if (1 !== c && -1 !== c) return !1;
								if (l !== (1 === c ? 2 : 1)) return !1;
								const u = l - c;
								let f = e.__last;
								for (let t = 0; t < u - 1; t++) {
									if (null === f) return !1;
									const t = te$3.get(f);
									if (void 0 === t) return !1;
									f = t.__prev;
								}
								if (null === f) return !1;
								const d = ne$3.get(s), h = te$3.get(f);
								if (void 0 === d || void 0 === h) return !1;
								if (d.__prev !== h.__prev) return !1;
								const g = [];
								let _ = s;
								for (let t = 0; t < l; t++) {
									if (null === _) return !1;
									g.push(_);
									const t = ne$3.get(_);
									_ = t ? t.__next : null;
								}
								const p = [];
								_ = f;
								for (let t = 0; t < u; t++) {
									if (null === _) return !1;
									p.push(_);
									const t = te$3.get(_);
									_ = t ? t.__next : null;
								}
								const y = new Set(p), m = new Set(g), x = [];
								let C = 0, S = 0;
								for (; C < u && S < l;) if (g[S] === p[C]) x.push({
									key: g[S],
									kind: "reconcile"
								}), C++, S++;
								else if (m.has(p[C])) {
									if (y.has(g[S])) return !1;
									x.push({
										key: g[S],
										kind: "create",
										nextIndex: S
									}), S++;
								} else x.push({
									key: p[C],
									kind: "destroy"
								}), C++;
								for (; C < u;) x.push({
									key: p[C++],
									kind: "destroy"
								});
								for (; S < l;) x.push({
									key: g[S],
									kind: "create",
									nextIndex: S
								}), S++;
								const v = zt$2(f, u);
								for (const t of x) {
									const e = qt$2();
									if ("reconcile" === t.kind) we$1(t.key, o.element);
									else if ("destroy" === t.kind) ae$2(t.key, o.element);
									else {
										let e = null;
										for (let n = t.nextIndex + 1; n < l; n++) {
											const t = $t$2._keyToDOMMap.get(g[n]);
											if (void 0 !== t) {
												e = t;
												break;
											}
										}
										Te$2(t.key, o.withBefore(e ?? o.before));
									}
									if ("destroy" !== t.kind) {
										const e = ne$3.get(t.key);
										e && Xo(e) && null === jt$2 && (jt$2 = e.getFormat(), Jt$2 = e.getStyle(), Vt$2 = e.__key);
									}
									Yt$2(e);
								}
								let T = "";
								for (let e = 0; e < l; e++) {
									const n = ne$3.get(g[e]);
									if (void 0 === n) return !1;
									let o;
									if (Pi(n)) {
										const r = $t$2._keyToDOMMap.get(g[e]), i = r && r.__lexicalTextContent;
										"string" != typeof i && t(350, n.getType()), o = i;
									} else o = n.getTextContent();
									T += o, e < l - 1 && Pi(n) && !n.isInline() && (T += D$1);
								}
								const k = r.__lexicalSlotTextLength || 0, b = k > 0 ? i.slice(k) : i;
								return r.__lexicalTextContent = b.slice(0, b.length - v) + T, !0;
							}(e, 0, o, c, i, s, f, a)) {
								const e = c.__lexicalTextContent;
								"string" != typeof e && t(353), Ht$2 = r + e, Ee$1(n, c, u);
								return;
							}
						}
					}
					if (0 === a) {
						let n = e.__first, o = 0;
						for (; null !== n;) {
							const e = ne$3.get(n);
							if (void 0 === e) break;
							const r = le$2 || Zt$2.has(n) || Qt$2.has(n), i = qt$2();
							if (r) we$1(n, l);
							else {
								let o, r;
								if (Pi(e)) {
									r = oe$3.get(n);
									const i = r && r.__lexicalTextContent;
									"string" != typeof i && t(354, e.getType()), o = i;
								} else o = e.getTextContent();
								Ht$2 += o, void 0 !== r && Gt$2(r);
							}
							Xo(e) ? null === jt$2 && (jt$2 = e.getFormat(), Jt$2 = e.getStyle(), Vt$2 = e.__key) : Pi(e) && o < s - 1 && !e.isInline() && (Ht$2 += D$1), Yt$2(i), n = e.__next, o++;
						}
						c.__lexicalTextContent = Ht$2, c.__lexicalFirstTextKey = Vt$2, Ht$2 = r + Ht$2;
						return;
					}
				}
				if (1 === i && 1 === s) {
					const t = e.__first, r = n.__first;
					if (t === r) we$1(t, l);
					else {
						const e = Fe$2(t), n = Te$2(r, null);
						try {
							e.parentNode === l ? l.replaceChild(n, e) : o.insertChild(n);
						} catch (o) {
							if ("object" == typeof o && null != o) {
								const i = `${o.toString()} Parent: ${l.tagName}, new child: {tag: ${n.tagName} key: ${r}}, old child: {tag: ${e.tagName}, key: ${t}}.`;
								throw new Error(i);
							}
							throw o;
						}
						ae$2(t, null);
					}
					const i = ne$3.get(r);
					Xo(i) && null === jt$2 && (jt$2 = i.getFormat(), Jt$2 = i.getStyle(), Vt$2 = i.__key);
				} else {
					const r = Yc(e, te$3), c = Yc(n, ne$3);
					if (r.length !== i && t(227), c.length !== s && t(228), 0 === i) 0 !== s && ke$2(c, n, 0, s - 1, o);
					else if (0 === s) {
						if (0 !== i) {
							const t = null == o.after && null == o.before && 0 === xe$1(n).size && null == o.element.__lexicalLineBreak;
							ue$1(r, 0, i - 1, t ? null : l), t && (l.textContent = "");
						}
					} else (function(t, e, n, o, r, i) {
						const s = o - 1, l = r - 1;
						let c, a, u = i.getFirstChild(), f = 0, d = 0;
						for (; f <= s && d <= l;) {
							const t = e[f], o = n[d], r = qt$2();
							if (t === o) u = Me$2(we$1(o, i.element)), f++, d++;
							else {
								if (void 0 === a && (a = Ae$2(n, d)), void 0 === c) c = Ae$2(e, f);
								else if (!c.has(t)) {
									f++, Yt$2(r);
									continue;
								}
								if (!a.has(t)) {
									u = Me$2(Fe$2(t)), ae$2(t, i.element), f++, c.delete(t), Yt$2(r);
									continue;
								}
								if (c.has(o)) {
									const t = El($t$2, o);
									t !== u && i.withBefore(u ?? i.before).insertChild(t), u = Me$2(we$1(o, i.element)), f++, d++;
								} else Te$2(o, i.withBefore(u ?? i.before)), d++;
							}
							const s = ne$3.get(o);
							null !== s && Xo(s) ? null === jt$2 && (jt$2 = s.getFormat(), Jt$2 = s.getStyle(), Vt$2 = s.__key) : Pi(s) && d <= l && !s.isInline() && (Ht$2 += D$1), Yt$2(r);
						}
						const h = f > s, g = d > l;
						if (h && !g) {
							const e = n[l + 1], o = void 0 === e ? null : $t$2.getElementByKey(e);
							ke$2(n, t, d, l, i.withBefore(o ?? i.before));
						} else g && !h && ue$1(e, f, s, i.element);
					})(n, r, c, i, s, o);
				}
				c.__lexicalTextContent = Ht$2, c.__lexicalFirstTextKey = Vt$2, Ht$2 = r + Ht$2;
			}(e, n, kc(n, o, $t$2)), Bl(n) || (r = n, null == jt$2 || jt$2 === r.__textFormat || ce$2 || r.setTextFormat(jt$2), function(t) {
				null == Jt$2 || Jt$2 === t.__textStyle || ce$2 || t.setTextStyle(Jt$2);
			}(n));
		}
		function Ee$1(t, e, n) {
			const o = e.__lexicalFirstTextKey;
			if (null != o) {
				const e = t.__key;
				let r = o;
				for (; null !== r;) {
					const t = ne$3.get(r);
					if (void 0 === t) {
						r = null;
						break;
					}
					if (t.__parent === e) break;
					r = t.__parent;
				}
				if (null !== r && !n.has(r)) {
					const t = ne$3.get(o);
					if (Xo(t)) return jt$2 = t.getFormat(), void (Jt$2 = t.getStyle());
				}
			}
			e.__lexicalFirstTextKey = Vt$2;
		}
		function we$1(e, n) {
			const o = te$3.get(e);
			let r = ne$3.get(e);
			void 0 !== o && void 0 !== r || t(61);
			const i = le$2 || Zt$2.has(e) || Qt$2.has(e), s = El($t$2, e);
			if (o === r && !i) {
				let e;
				if (Pi(o)) {
					const n = s.__lexicalTextContent;
					"string" != typeof n && t(355, o.getType()), e = n, Gt$2(s);
				} else e = o.getTextContent();
				return Ht$2 += e, s;
			}
			if (o !== r && i && Sl(ie$2, Ut$2, Xt$2, r, "updated"), se$2.$updateDOM(r, o, s, $t$2)) {
				const o = Te$2(e, null);
				return null === n && t(62), n.replaceChild(o, s), ae$2(e, null), o;
			}
			if (Pi(o)) {
				Pi(r) || t(334, e);
				const n = r.__indent;
				(le$2 || n !== o.__indent) && he(s, n);
				const l = r.__format;
				(le$2 || l !== o.__format) && ge$1(s, l);
				const c = i && (xe$1(r).size > 0 || xe$1(o).size > 0) ? ve$2(o, r, s) : "";
				if (i) {
					const t = Ht$2;
					if (Ne$1(o, r, s), Bi(r) || r.isInline() || be$1(0, r, s), "" !== c) {
						const e = s.__lexicalTextContent || "";
						s.__lexicalTextContent = c + e, Ht$2 = t + c + e, s.__lexicalSlotTextLength = c.length;
					} else (xe$1(r).size > 0 || xe$1(o).size > 0) && (s.__lexicalSlotTextLength = 0);
				} else {
					const e = s.__lexicalTextContent;
					"string" != typeof e && t(356, o.getType()), Ht$2 += e, Gt$2(s);
				}
				if ((le$2 || r.__dir !== o.__dir || r.__parent !== o.__parent) && (_e$2(s, r), Bi(r) && !le$2)) {
					for (const t of r.getChildren()) if (Pi(t)) _e$2(El($t$2, t.getKey()), t);
				}
			} else {
				const t = r.getTextContent();
				if (Ki(r)) {
					const t = r.decorate($t$2, Wt$2);
					null !== t && Oe$1(e, t), i && (xe$1(r).size > 0 || xe$1(o).size > 0) && ve$2(o, r, s);
				}
				Ht$2 += t;
			}
			if (!ce$2 && Bi(r)) {
				const t = r.getLatest();
				if (t.__cachedText !== Ht$2) {
					const e = t.getWritable();
					e.__cachedText = Ht$2, r = e;
				}
			}
			return se$2.$decorateDOM(r, o, s, $t$2), Bt$3(r), s;
		}
		function Oe$1(t, e) {
			let n = $t$2._pendingDecorators;
			const o = $t$2._decorators;
			if (null === n) {
				if (o[t] === e) return;
				n = tl($t$2);
			}
			n[t] = e;
		}
		function Me$2(t) {
			let e = t.nextSibling;
			return null !== e && e === $t$2._blockCursorElement && (e = e.nextSibling), e;
		}
		function Ae$2(t, e) {
			const n = /* @__PURE__ */ new Set();
			for (let o = e; o < t.length; o++) n.add(t[o]);
			return n;
		}
		function De$2(t, e, n, o, r, i) {
			Ht$2 = "", jt$2 = null, Jt$2 = null, Vt$2 = null, le$2 = 2 === o, $t$2 = n, Wt$2 = n._config, se$2 = n._config.dom || ps, Ut$2 = n._nodes, Xt$2 = $t$2._listeners.mutation, Qt$2 = r, Zt$2 = i, te$3 = t._nodeMap, ee$3 = t, ne$3 = e._nodeMap, ce$2 = e._readOnly, oe$3 = nt$2(n._keyToDOMMap), re$2 = function() {
				const t = /* @__PURE__ */ new Map(), e = (e) => {
					for (const n of e) {
						const e = ne$3.get(n);
						if (void 0 === e) continue;
						const o = e.__parent;
						if (null === o) continue;
						let r = t.get(o);
						void 0 === r && (r = /* @__PURE__ */ new Set(), t.set(o, r)), r.add(n);
					}
				};
				return e(Qt$2.keys()), e(Zt$2), t;
			}();
			const s = /* @__PURE__ */ new Map();
			return ie$2 = s, we$1("root", null), $t$2 = void 0, Ut$2 = void 0, Qt$2 = void 0, Zt$2 = void 0, te$3 = void 0, ee$3 = void 0, ne$3 = void 0, Wt$2 = void 0, oe$3 = void 0, re$2 = void 0, ie$2 = void 0, se$2 = ps, s;
		}
		function Fe$2(e) {
			const n = oe$3.get(e);
			return void 0 === n && t(75, e), n;
		}
		function Pe$2(t) {
			return { type: t };
		}
		const Ie$2 = /* @__PURE__ */ Pe$2("SELECTION_CHANGE_COMMAND"), Ke$2 = /* @__PURE__ */ Pe$2("CLICK_COMMAND"), ze$2 = /* @__PURE__ */ Pe$2("BEFORE_INPUT_COMMAND"), Be$2 = /* @__PURE__ */ Pe$2("INPUT_COMMAND"), Re = /* @__PURE__ */ Pe$2("COMPOSITION_START_COMMAND"), We$2 = /* @__PURE__ */ Pe$2("COMPOSITION_END_COMMAND"), $e$2 = /* @__PURE__ */ Pe$2("DELETE_CHARACTER_COMMAND"), Ue$2 = /* @__PURE__ */ Pe$2("INSERT_LINE_BREAK_COMMAND"), He$2 = /* @__PURE__ */ Pe$2("INSERT_PARAGRAPH_COMMAND"), je$2 = /* @__PURE__ */ Pe$2("CONTROLLED_TEXT_INSERTION_COMMAND"), Je$2 = /* @__PURE__ */ Pe$2("PASTE_COMMAND"), Ve$2 = /* @__PURE__ */ Pe$2("REMOVE_TEXT_COMMAND"), qe$2 = /* @__PURE__ */ Pe$2("DELETE_WORD_COMMAND"), Ye$1 = /* @__PURE__ */ Pe$2("DELETE_LINE_COMMAND"), Ge$2 = /* @__PURE__ */ Pe$2("FORMAT_TEXT_COMMAND"), Qe$2 = /* @__PURE__ */ Pe$2("UNDO_COMMAND"), Ze$2 = /* @__PURE__ */ Pe$2("REDO_COMMAND"), tn$2 = /* @__PURE__ */ Pe$2("KEYDOWN_COMMAND"), en$3 = /* @__PURE__ */ Pe$2("KEY_ARROW_RIGHT_COMMAND"), nn$2 = /* @__PURE__ */ Pe$2("MOVE_TO_END"), on$1 = /* @__PURE__ */ Pe$2("KEY_ARROW_LEFT_COMMAND"), rn$1 = /* @__PURE__ */ Pe$2("MOVE_TO_START"), sn$2 = /* @__PURE__ */ Pe$2("KEY_ARROW_UP_COMMAND"), ln$2 = /* @__PURE__ */ Pe$2("KEY_ARROW_DOWN_COMMAND"), cn$1 = /* @__PURE__ */ Pe$2("KEY_ENTER_COMMAND"), an$1 = /* @__PURE__ */ Pe$2("KEY_SPACE_COMMAND"), un$2 = /* @__PURE__ */ Pe$2("KEY_BACKSPACE_COMMAND"), fn$1 = /* @__PURE__ */ Pe$2("KEY_ESCAPE_COMMAND"), dn$1 = /* @__PURE__ */ Pe$2("KEY_DELETE_COMMAND"), hn$2 = /* @__PURE__ */ Pe$2("KEY_TAB_COMMAND"), yn$1 = /* @__PURE__ */ Pe$2("DROP_COMMAND"), xn$1 = /* @__PURE__ */ Pe$2("DRAGSTART_COMMAND"), Cn$1 = /* @__PURE__ */ Pe$2("DRAGOVER_COMMAND"), Sn$2 = /* @__PURE__ */ Pe$2("DRAGEND_COMMAND"), vn$2 = /* @__PURE__ */ Pe$2("COPY_COMMAND"), Tn = /* @__PURE__ */ Pe$2("CUT_COMMAND"), kn = /* @__PURE__ */ Pe$2("SELECT_ALL_COMMAND"), bn$2 = /* @__PURE__ */ Pe$2("CLEAR_EDITOR_COMMAND"), Nn$1 = /* @__PURE__ */ Pe$2("CLEAR_HISTORY_COMMAND"), En = /* @__PURE__ */ Pe$2("CAN_REDO_COMMAND"), wn$1 = /* @__PURE__ */ Pe$2("CAN_UNDO_COMMAND"), On$1 = /* @__PURE__ */ Pe$2("FOCUS_COMMAND"), Mn$1 = /* @__PURE__ */ Pe$2("BLUR_COMMAND"), An = /* @__PURE__ */ Pe$2("KEY_MODIFIER_COMMAND");
		function Dn$1(t) {
			const e = /* @__PURE__ */ new Map();
			return {
				dispose() {
					for (const t of e.values()) t.dispose();
					e.clear();
				},
				register(n, o) {
					let r = e.get(n);
					void 0 === r && (r = {
						dispose: t(n, o),
						holders: /* @__PURE__ */ new Set()
					}, e.set(n, r));
					const i = () => {
						const t = e.get(n);
						t && t.holders.delete(i) && 0 === t.holders.size && (e.delete(n), t.dispose());
					};
					return r.holders.add(i), i;
				}
			};
		}
		function Fn(t, e, n, o) {
			return t.addEventListener(e, n, o), t.removeEventListener.bind(t, e, n, o);
		}
		const Pn = Object.freeze({}), In = [
			["keydown", function(t, e) {
				const n = e._inputState;
				n.lastKeyDownTimeStamp = t.timeStamp, n.lastKeyCode = t.key, "Backspace" !== t.key && Jn(n);
				if (e.isComposing()) return;
				Nl(e, tn$2, t);
			}],
			["pointerdown", function(t, e) {
				const n = ac(t), o = t.pointerType;
				_c(n) && "touch" !== o && "pen" !== o && 0 === t.button && Ai(e, () => {
					Rc(n, e) || (e._inputState.isSelectionChangeFromMouseDown = !0);
				});
			}],
			["compositionstart", function(t, e) {
				Nl(e, Re, t);
			}],
			["compositionend", function(t, e) {
				const n = e._inputState;
				i ? n.compositionPhase = "ending-firefox" : l || !a && !d$1 ? Nl(e, We$2, t) : (n.compositionPhase = "ending-safari", n.compositionEndData = t.data);
			}],
			["input", function(t, e) {
				t.stopPropagation();
				const n = e._inputState;
				Jn(n), Ai(e, () => {
					qn(t, e) || e.dispatchCommand(Be$2, t);
				}, { event: t }), n.unprocessedBeforeInputData = null;
			}],
			["click", function(t, e) {
				Ai(e, () => {
					const n = Kr(), o = Jl(Il(e)), r = zr();
					if (o) {
						if (ur(n)) {
							const t = n.anchor, e = t.getNode();
							"element" === t.type && 0 === t.offset && n.isCollapsed() && !Bi(e) && 1 === nl().getChildrenSize() && e.getTopLevelElementOrThrow().isEmpty() && null !== r && n.is(r) && (o.removeAllRanges(), n.dirty = !0);
						} else if ("touch" === t.pointerType || "pen" === t.pointerType) {
							const n = nc(o, e._rootElement).anchorNode;
							if (gc(n) || zs(n)) ol(Lr(r, o, e, t));
						}
					}
					if (i && null !== o && 0 === o.rangeCount) {
						const n = e._rootElement;
						if (null !== n && t.target === n) {
							const i = t.clientY;
							let s = n.childNodes.length;
							for (let t = 0; t < n.childNodes.length; t++) {
								const e = n.childNodes[t];
								if (gc(e)) {
									const n = e.getBoundingClientRect();
									if (i <= (n.top + n.bottom) / 2) {
										s = t;
										break;
									}
								}
							}
							o.setBaseAndExtent(n, s, n, s);
							const l = Lr(r, o, e, t);
							null !== l ? ol(l) : o.removeAllRanges();
						}
					}
					Nl(e, Ke$2, t);
				});
			}],
			["cut", Pn],
			["copy", Pn],
			["dragstart", Pn],
			["dragover", Pn],
			["dragend", Pn],
			["paste", Pn],
			["focus", Pn],
			["blur", Pn],
			["drop", Pn]
		];
		s && In.push(["beforeinput", (t, e) => function(t, e) {
			const n = t.inputType;
			if ("deleteCompositionText" === n || i && bl(e)) return;
			if ("insertCompositionText" === n) return;
			Ai(e, () => {
				qn(t, e) || Nl(e, ze$2, t);
			}, { event: t });
		}(t, e)]);
		const Ln = /* @__PURE__ */ new WeakMap(), Kn = /* @__PURE__ */ new WeakMap(), zn = Dn$1((t) => (t.addEventListener("selectionchange", ro), () => t.removeEventListener("selectionchange", ro)));
		function Bn(t, e, n, o, r, i) {
			const l = t.anchor, c = t.focus, a = l.getNode(), u = _i();
			let f;
			if (void 0 !== i) f = i;
			else {
				const t = Jl(Il(u));
				f = null !== t ? nc(t, u._rootElement) : null;
			}
			const d = null !== f ? f.anchorNode : null, h = l.key, g = u.getElementByKey(h), _ = n.length;
			return h !== c.key || !Xo(a) || (!r && (!s || u._inputState.lastBeforeInputInsertTextTimeStamp < o + 50) || a.isDirty() && _ < 2 || sl(n)) && l.offset !== c.offset && !a.isComposing() || Ks(a) || a.isDirty() && _ > 1 || (r || !s) && null !== g && !a.isComposing() && d !== wc(a, g, u) || null !== f && null !== e && (!e.collapsed || e.startContainer !== f.anchorNode || e.startOffset !== f.anchorOffset) || !a.isComposing() && (a.getFormat() !== t.format || a.getStyle() !== t.style) || function(t, e) {
				if (e.isSegmented()) return !0;
				if (!t.isCollapsed()) return !1;
				const n = t.anchor.offset, o = e.getParentOrThrow(), r = Ls(e);
				return 0 === n ? !e.canInsertTextBefore() || !o.canInsertTextBefore() && !e.isComposing() || r || function(t) {
					const e = t.getPreviousSibling();
					return (Xo(e) || Pi(e) && e.isInline()) && !e.canInsertTextAfter();
				}(e) : n === e.getTextContentSize() && (!e.canInsertTextAfter() || !o.canInsertTextAfter() && !e.isComposing() || r);
			}(t, a);
		}
		function Rn(t, e) {
			return zs(t) && null !== t.nodeValue && 0 !== e && e !== t.nodeValue.length;
		}
		function Wn(e, n, o) {
			const { anchorNode: r, anchorOffset: i, focusNode: s, focusOffset: l } = nc(e, n._rootElement), c = n._inputState;
			c.isSelectionChangeFromDOMUpdate && (c.isSelectionChangeFromDOMUpdate = !1, Rn(r, i) && Rn(s, l) && !c.postDeleteSelectionToRestore) || Ai(n, () => {
				if (!o) return void ol(null);
				if (!As(n, r, s)) return;
				let a = Kr();
				if (c.postDeleteSelectionToRestore && ur(a) && a.isCollapsed()) {
					const t = a.anchor, e = c.postDeleteSelectionToRestore.anchor;
					(t.key === e.key && t.offset === e.offset + 1 || 1 === t.offset && e.getNode().is(t.getNode().getPreviousSibling())) && (a = c.postDeleteSelectionToRestore.clone(), ol(a));
				}
				if (c.postDeleteSelectionToRestore = null, ur(a)) {
					const o = a.anchor, u = o.getNode();
					if (a.isCollapsed()) {
						"Range" === e.type && r === s && (a.dirty = !0);
						const i = Il(n).event, l = i ? i.timeStamp : performance.now(), { format: f, style: d, offset: h, key: g, timeStamp: _ } = c.collapsedSelectionFormat, p = nl(), y = !1 === n.isComposing() && "" === p.getTextContent();
						if (l < _ + 200 && o.offset === h && o.key === g) $n$1(a, f, d);
						else if ("text" === o.type) Xo(u) || t(141), Un(a, u);
						else if ("element" === o.type && !y) {
							Pi(u) || t(259);
							const e = o.getNode();
							e.isEmpty() ? function(t, e) {
								$n$1(t, e.getTextFormat(), e.getTextStyle());
							}(a, e) : $n$1(a, a.format, "");
						}
					} else {
						const t = o.key, e = a.focus.key, n = a.getNodes(), r = n.length, s = a.isBackward(), c = s ? l : i, u = s ? i : l, f = s ? e : t, d = s ? t : e;
						let h = 2047, g = !1;
						for (let t = 0; t < r; t++) {
							const e = n[t], o = e.getTextContentSize();
							if (Xo(e) && 0 !== o && !(0 === t && e.__key === f && c === o || t === r - 1 && e.__key === d && 0 === u) && (g = !0, h &= e.getFormat(), 0 === h)) break;
						}
						a.format = g ? h : 0;
					}
				}
				Nl(n, Ie$2);
			});
		}
		function $n$1(t, e, n) {
			t.format === e && t.style === n || (t.format = e, t.style = n, t.dirty = !0);
		}
		function Un(t, e) {
			$n$1(t, e.getFormat(), e.getStyle());
		}
		function Hn(t) {
			if (!t.getTargetRanges) return null;
			const e = t.getTargetRanges();
			return 0 === e.length ? null : e[0];
		}
		function jn(t) {
			const { lastKeyCode: e } = _i()._inputState;
			if (null == t || t.length <= 1 || null == e) return;
			const n = 1 === e.length ? e : "Enter" === e ? "\n" : "Tab" === e ? "	" : null;
			if (!n) return;
			const o = Kr();
			if (!ur(o) || !o.isCollapsed()) return;
			const r = o.anchor.getNode();
			if (!Xo(r)) return;
			const { offset: i } = o.anchor;
			if (r.getTextContentSize() === i) {
				const t = r.getNextSibling();
				if ("\n" === n) {
					if (Yi(t)) t.selectEnd();
					else if (!t) {
						const t = qc(r, Ar), e = t && t.getNextSibling();
						Pi(e) && e.selectStart();
					}
				} else "	" === n ? er(t) && t.selectEnd() : Xo(t) && t.getTextContent()[0] === n && t.select(1, 1);
			} else r.getTextContent()[i] === n && r.select(i + 1, i + 1);
		}
		function Jn(t) {
			t.isInsertTextAfterHandledSelectionCommand = !1, null !== t.handledSelectionCommandTimeoutId && (clearTimeout(t.handledSelectionCommandTimeoutId), t.handledSelectionCommandTimeoutId = null);
		}
		function Vn(t) {
			Jn(t), t.isInsertTextAfterHandledSelectionCommand = !0, t.handledSelectionCommandTimeoutId = setTimeout(() => Jn(t), 0);
		}
		function qn(t, e) {
			const n = ac(t);
			if (gc(n) && Rc(n, e)) return !0;
			const o = e.getRootElement();
			if (null === o) return !1;
			const r = cc(o.ownerDocument);
			return null !== r && o.contains(r) && Rc(r, e);
		}
		function Yn(e) {
			const n = e.inputType, o = Hn(e), r = _i(), i = r._inputState, s = Kr();
			if ("insertText" === n && e.data && i.isInsertTextAfterHandledSelectionCommand) {
				if (Jn(i), e.preventDefault(), ur(s) && !s.isCollapsed()) {
					const t = s.isBackward() ? s.anchor : s.focus;
					s.anchor.set(t.key, t.offset, t.type), s.focus.set(t.key, t.offset, t.type);
				}
				return !0;
			}
			if ("deleteContentBackward" === n) {
				if (null === s) {
					const t = zr();
					if (!ur(t)) return !0;
					ol(t.clone());
				}
				if (ur(s)) {
					const n = s.anchor.key === s.focus.key;
					if (function(t, e) {
						return "MediaLast" === t.lastKeyCode && e < t.lastKeyDownTimeStamp + 30;
					}(i, e.timeStamp) && r.isComposing() && n) {
						if (Vs(null), i.lastKeyDownTimeStamp = 0, setTimeout(() => {
							Ai(r, () => {
								Vs(null);
							});
						}, 30), ur(s)) {
							const e = s.anchor.getNode();
							e.markDirty(), Xo(e) || t(142), Un(s, e);
						}
					} else {
						if (Vs(null), l && null !== o && !o.collapsed && (s.applyDOMRange(o), !s.isCollapsed())) return e.preventDefault(), s.removeText(), !0;
						e.preventDefault();
						const t = s.anchor.getNode(), c = t.getTextContent(), a = t.canInsertTextAfter(), u = 0 === s.anchor.offset && s.focus.offset === c.length;
						let d = f && n && !u && a;
						if (d && s.isCollapsed() && (d = !Ki(kl(s.anchor, !0))), !d) {
							Nl(r, $e$2, !0);
							const t = Kr();
							f && ur(t) && t.isCollapsed() && (i.postDeleteSelectionToRestore = t, setTimeout(() => i.postDeleteSelectionToRestore = null));
						}
					}
					return !0;
				}
			}
			if (!ur(s)) return !0;
			const c = e.data;
			null !== i.unprocessedBeforeInputData && ul(!1, r, i.unprocessedBeforeInputData), s.dirty && null === i.unprocessedBeforeInputData || !s.isCollapsed() || Bi(s.anchor.getNode()) || null === o || s.applyDOMRange(o), i.unprocessedBeforeInputData = null;
			const a = s.anchor, u = s.focus, d = a.getNode(), h = u.getNode();
			if ("insertText" === n || "insertTranspose" === n) {
				if ("\n" === c) e.preventDefault(), Nl(r, Ue$2, !1);
				else if (c === D$1) e.preventDefault(), Nl(r, He$2);
				else if (null == c && e.dataTransfer) {
					const t = e.dataTransfer.getData("text/plain");
					e.preventDefault(), s.insertRawText(t);
				} else null != c && Bn(s, o, c, e.timeStamp, !0) ? (e.preventDefault(), Nl(r, je$2, c), jn(c)) : i.unprocessedBeforeInputData = c;
				return i.lastBeforeInputInsertTextTimeStamp = e.timeStamp, !0;
			}
			switch (e.preventDefault(), n) {
				case "insertFromYank":
				case "insertFromDrop":
				case "insertReplacementText":
					Nl(r, je$2, e);
					jn((e.dataTransfer ? e.dataTransfer.getData("text/plain") : null) ?? e.data);
					break;
				case "insertFromComposition": {
					const t = i.hadOrphanedCompositionEvents;
					i.hadOrphanedCompositionEvents = !1;
					const n = r._compositionKey;
					Vs(null), t || Nl(r, je$2, e), Zn(n);
					break;
				}
				case "insertLineBreak":
					Vs(null), Nl(r, Ue$2, !1);
					break;
				case "insertParagraph":
					Vs(null), i.isInsertLineBreak && !l ? (i.isInsertLineBreak = !1, Nl(r, Ue$2, !1)) : Nl(r, He$2);
					break;
				case "insertFromPaste":
				case "insertFromPasteAsQuotation":
					Nl(r, Je$2, e);
					break;
				case "deleteByComposition":
					(function(t, e) {
						return t !== e || Pi(t) || Pi(e) || !Ls(t) || !Ls(e);
					})(d, h) && Nl(r, Ve$2, e);
					break;
				case "deleteByDrag":
					Al(No), Nl(r, Ve$2, e);
					break;
				case "deleteByCut":
					Nl(r, Ve$2, e);
					break;
				case "deleteContent":
					Nl(r, $e$2, !1);
					break;
				case "deleteWordBackward":
					Nl(r, qe$2, !0);
					break;
				case "deleteWordForward":
					Nl(r, qe$2, !1);
					break;
				case "deleteHardLineBackward":
				case "deleteSoftLineBackward":
					Nl(r, Ye$1, !0);
					break;
				case "deleteContentForward":
				case "deleteHardLineForward":
				case "deleteSoftLineForward":
					Nl(r, Ye$1, !1);
					break;
				case "formatStrikeThrough":
					Nl(r, Ge$2, "strikethrough");
					break;
				case "formatBold":
					Nl(r, Ge$2, "bold");
					break;
				case "formatItalic":
					Nl(r, Ge$2, "italic");
					break;
				case "formatUnderline":
					Nl(r, Ge$2, "underline");
					break;
				case "historyUndo":
					Nl(r, Qe$2);
					break;
				case "historyRedo": Nl(r, Ze$2);
			}
			return !0;
		}
		function Gn(t) {
			const e = _i(), n = e._inputState, o = Kr(), r = t.data, l = Hn(t);
			let c = !1;
			if (null != r && ur(o)) {
				const a = Jl(Il(e)), u = null !== a ? nc(a, e._rootElement) : null, d = "insertCompositionText" === t.inputType && "ending-firefox" !== n.compositionPhase && !e.isComposing();
				d && (n.hadOrphanedCompositionEvents = !0);
				const h = o.anchor.getNode(), g = "insertCompositionText" === t.inputType && "ending-firefox" !== n.compositionPhase && e.isComposing() && Xo(h) && Ks(h);
				if (!d && !g && Bn(o, l, r, t.timeStamp, !1, u)) {
					if (c = !0, "ending-firefox" === n.compositionPhase) {
						const t = to(e, r);
						if (n.compositionPhase = "idle", t) return Al(wo), rl(), !0;
					}
					const l = o.anchor.getNode();
					if (null === a || null === u) return !0;
					const d = o.isBackward(), h = d ? o.anchor.offset : o.focus.offset, g = d ? o.focus.offset : o.anchor.offset;
					s && !o.isCollapsed() && Xo(l) && null !== u.anchorNode && l.getTextContent().slice(0, h) + r + l.getTextContent().slice(h + g) === al(u.anchorNode) || Nl(e, je$2, r);
					const _ = r.length;
					i && _ > 1 && "insertCompositionText" === t.inputType && !e.isComposing() && (o.anchor.offset -= _, o._cachedNodes = null, o._cachedIsBackward = null), f && e.isComposing() && (n.lastKeyDownTimeStamp = 0, Vs(null));
				}
			}
			if (!c) ul(!1, e, null !== r ? r : void 0), "ending-firefox" === n.compositionPhase && (to(e, r || void 0), Al("composition-end"), n.compositionPhase = "idle");
			return rl(), !0;
		}
		function Xn(t) {
			const e = _i(), n = e._inputState, o = Kr();
			if (ur(o) && !e.isComposing()) {
				n.compositionPhase = "composing", n.hadOrphanedCompositionEvents = !1;
				const r = o.anchor, i = o.anchor.getNode();
				if (Vs(r.key), Al("composition-start"), t.timeStamp < n.lastKeyDownTimeStamp + 30 || "element" === r.type || !o.isCollapsed() || !f && (i.getFormat() !== o.format || Xo(i) && i.getStyle() !== o.style) || Xo(i) && (Ks(i) || 0 === r.offset && !i.canInsertTextBefore() || r.offset === i.getTextContentSize() && !i.canInsertTextAfter())) {
					Nl(e, je$2, F);
					const t = Kr();
					ur(t) && Vs(t.anchor.key);
				}
			}
			return !0;
		}
		function Qn(t) {
			const e = _i();
			return e._inputState.compositionPhase = "idle", to(e, t.data), Al(wo), !0;
		}
		function Zn(t) {
			if (null === t) return;
			const e = Ys(t);
			if (!Xo(e) || "text" === e.getType() || Ks(e) || !e.isAttached()) return;
			const n = Kr(), o = ur(n) && n.anchor.key === t ? n.anchor.offset : null, r = Go(e.getTextContent());
			if (r.setFormat(e.getFormat()), r.setStyle(e.getStyle()), e.replace(r), null !== o) {
				const t = Math.min(o, r.getTextContentSize());
				r.select(t, t);
			}
		}
		function to(t, e) {
			const n = t._compositionKey;
			if (Vs(null), null !== n && null != e) {
				if ("" === e) {
					const e = Ys(n), o = t.getElementByKey(n), r = null !== o && Xo(e) ? wc(e, o, t) : null;
					if (null !== r && null !== r.nodeValue && Xo(e)) {
						const n = Jl(Il(t)), o = n && nc(n, t._rootElement);
						let i = null, s = null;
						null !== o && o.anchorNode === r && (i = o.anchorOffset, s = o.focusOffset), fl(e, r.nodeValue, i, s, !0);
					}
					return Zn(n), !1;
				}
				if ("\n" === e[e.length - 1]) {
					const e = Kr();
					if (ur(e) || dr(e)) {
						if (ur(e)) {
							const t = e.focus;
							e.anchor.set(t.key, t.offset, t.type);
						}
						return Nl(t, cn$1, null), Zn(n), !1;
					}
				}
				const o = Ys(n);
				if (null !== o && Xo(o) && Ks(o)) {
					o.markDirty();
					const t = Kr(), r = o.getTextContentSize(), i = ur(t) && t.anchor.key === n ? t.anchor.offset : r;
					return o.select(i, i).insertText(e), !0;
				}
			}
			return ul(!0, t, e), Zn(n), !1;
		}
		function eo(t) {
			const e = _i(), n = e._inputState;
			if (null == t.key) return !0;
			if ("ending-safari" === n.compositionPhase) {
				const o = ml(t);
				if (o && Ai(e, () => {
					to(e, n.compositionEndData);
				}), n.compositionPhase = "idle", n.compositionEndData = "", o) return !0;
			}
			if (function(t) {
				return _l(t, "ArrowRight", { shiftKey: "any" });
			}(t)) Nl(e, en$3, t);
			else if (function(t) {
				return _l(t, "ArrowRight", {
					...pl,
					shiftKey: "any"
				});
			}(t)) Nl(e, nn$2, t);
			else if (function(t) {
				return _l(t, "ArrowLeft", { shiftKey: "any" });
			}(t)) Nl(e, on$1, t);
			else if (function(t) {
				return _l(t, "ArrowLeft", {
					...pl,
					shiftKey: "any"
				});
			}(t)) Nl(e, rn$1, t);
			else if (function(t) {
				return _l(t, "ArrowUp", {
					altKey: "any",
					shiftKey: "any"
				});
			}(t)) Nl(e, sn$2, t);
			else if (function(t) {
				return _l(t, "ArrowDown", {
					altKey: "any",
					shiftKey: "any"
				});
			}(t)) Nl(e, ln$2, t);
			else if (function(t) {
				return _l(t, "Enter", {
					altKey: "any",
					ctrlKey: "any",
					metaKey: "any",
					shiftKey: !0
				});
			}(t)) n.isInsertLineBreak = !0, Nl(e, cn$1, t);
			else if (function(t) {
				return " " === t.key;
			}(t)) Nl(e, an$1, t);
			else if (function(t) {
				return r$1 && _l(t, "o", { ctrlKey: !0 });
			}(t)) t.preventDefault(), n.isInsertLineBreak = !0, Nl(e, Ue$2, !0);
			else if (function(t) {
				return _l(t, "Enter", {
					altKey: "any",
					ctrlKey: "any",
					metaKey: "any"
				});
			}(t)) n.isInsertLineBreak = !1, Nl(e, cn$1, t);
			else if (function(t) {
				return _l(t, "Backspace", { shiftKey: "any" }) || r$1 && _l(t, "h", { ctrlKey: !0 });
			}(t)) ml(t) ? Nl(e, un$2, t) && Vn(n) : (t.preventDefault(), Nl(e, $e$2, !0));
			else if (function(t) {
				return "Escape" === t.key;
			}(t)) Nl(e, fn$1, t);
			else if (function(t) {
				return _l(t, "Delete", {}) || r$1 && _l(t, "d", { ctrlKey: !0 });
			}(t)) !function(t) {
				return "Delete" === t.key;
			}(t) ? (t.preventDefault(), Nl(e, $e$2, !1)) : Nl(e, dn$1, t);
			else if (function(t) {
				return _l(t, "Backspace", yl);
			}(t)) t.preventDefault(), Nl(e, qe$2, !0);
			else if (function(t) {
				return _l(t, "Delete", yl);
			}(t)) t.preventDefault(), Nl(e, qe$2, !1);
			else if (function(t) {
				return r$1 && _l(t, "Backspace", { metaKey: !0 });
			}(t)) t.preventDefault(), Nl(e, Ye$1, !0);
			else if (function(t) {
				return r$1 && (_l(t, "Delete", { metaKey: !0 }) || _l(t, "k", { ctrlKey: !0 }));
			}(t)) t.preventDefault(), Nl(e, Ye$1, !1);
			else if (function(t) {
				return _l(t, "b", pl);
			}(t)) t.preventDefault(), Nl(e, Ge$2, "bold");
			else if (function(t) {
				return _l(t, "u", pl);
			}(t)) t.preventDefault(), Nl(e, Ge$2, "underline");
			else if (function(t) {
				return _l(t, "i", pl);
			}(t)) t.preventDefault(), Nl(e, Ge$2, "italic");
			else if (function(t) {
				return _l(t, "Tab", { shiftKey: "any" });
			}(t)) Nl(e, hn$2, t);
			else if (function(t) {
				return _l(t, "z", pl);
			}(t)) t.preventDefault(), Nl(e, Qe$2);
			else if (function(t) {
				if (r$1) return _l(t, "z", {
					metaKey: !0,
					shiftKey: !0
				});
				return _l(t, "y", { ctrlKey: !0 }) || _l(t, "z", {
					ctrlKey: !0,
					shiftKey: !0
				});
			}(t)) t.preventDefault(), Nl(e, Ze$2);
			else {
				const o = e._editorState._selection;
				!function(t) {
					return _l(t, "a", pl);
				}(t) ? null === o || ur(o) || (!function(t) {
					return _l(t, "c", pl);
				}(t) ? function(t) {
					return _l(t, "x", pl);
				}(t) && (t.preventDefault(), Nl(e, Tn, t)) : (t.preventDefault(), Nl(e, vn$2, t))) : (t.preventDefault(), Nl(e, kn, t) && Vn(n));
			}
			return function(t) {
				return t.ctrlKey || t.shiftKey || t.altKey || t.metaKey;
			}(t) && e.dispatchCommand(An, t), !0;
		}
		function no(t) {
			let e = t.__lexicalEventHandles;
			return void 0 === e && (e = [], t.__lexicalEventHandles = e), e;
		}
		const oo = /* @__PURE__ */ new Map();
		function ro(t) {
			const e = Vl(t.target);
			if (null === e) return;
			const n = Ol(t.target);
			let o = null, r = null;
			const i = null !== n ? Kn.get(n) : void 0;
			if (null !== n) {
				if (void 0 !== i) {
					const t = i.editors;
					let n = i.hasShadowEditor;
					if (void 0 === n) {
						n = !1;
						for (const e of t) if (null !== e._rootElement && ql(e._rootElement.getRootNode())) {
							n = !0;
							break;
						}
						i.hasShadowEditor = n;
					}
					if (n) {
						let n = null, i = null;
						for (const s of t) {
							const t = s._rootElement;
							if (null === t) continue;
							const l = nc(e, t).anchorNode;
							if (null !== l && Fs(l) === s) {
								if (ql(t.getRootNode())) {
									o = s, r = l;
									break;
								}
								null === n && (n = s, i = l);
							}
						}
						null === o && null !== n && (o = n, r = i);
					} else {
						const t = e.anchorNode;
						null === t || gc(t) && null !== t.shadowRoot || (o = Fs(t), null !== o && (r = t));
					}
				}
				if (null === o) {
					const t = cc(n);
					o = null !== t ? Fs(t) : null;
				}
			}
			if (null === o) return;
			if (o._inputState.isSelectionChangeFromMouseDown) {
				if (void 0 !== i) for (const t of i.editors) t._inputState.isSelectionChangeFromMouseDown = !1;
				Ai(o, () => {
					const n = zr(), i = r ?? nc(e, o._rootElement).anchorNode;
					if (gc(i) || zs(i)) ol(Lr(n, e, o, t));
				});
			}
			const s = ll(o), l = s[s.length - 1], c = l._key, a = oo.get(c), u = a || l;
			u !== o && Wn(e, u, !1), Wn(e, o, !0), o !== l ? oo.set(c, o) : a && oo.delete(c);
		}
		function io(t) {
			t._lexicalHandled = !0;
		}
		function so(t) {
			return !0 === t._lexicalHandled;
		}
		function co(e) {
			const n = Ln.get(e);
			if (void 0 === n) return void 0;
			const o = Kn.get(n);
			if (void 0 === o) return void 0;
			Ln.delete(e);
			const r = Ps(e);
			Ds(r) ? (function(t) {
				if (null !== t._parentEditor) {
					const e = ll(t), n = e[e.length - 1]._key;
					oo.get(n) === t && oo.delete(n);
				} else oo.delete(t._key);
			}(r), o.editors.delete(r), o.hasShadowEditor = void 0, e.__lexicalEditor = null) : r && t(198);
			const i = no(e);
			for (let t = 0; t < i.length; t++) i[t]();
			e.__lexicalEventHandles = [];
		}
		function ao(e, n, o) {
			fi();
			const r = e.__key, i = e.getParent();
			if (null === i) return void (null !== ta(e) && t(367, r, String(ta(e))));
			const s = function(t) {
				const e = Kr();
				if (!ur(e) || !Pi(t)) return e;
				const { anchor: n, focus: o } = e, r = n.getNode(), i = o.getNode();
				Fl(r, t) && n.set(t.__key, 0, "element");
				Fl(i, t) && o.set(t.__key, 0, "element");
				return e;
			}(e);
			let l = !1;
			if (ur(s) && n) {
				const t = s.anchor, n = s.focus;
				t.key === r && (Wr(t, e, i, e.getPreviousSibling(), e.getNextSibling()), l = !0), n.key === r && (Wr(n, e, i, e.getPreviousSibling(), e.getNextSibling()), l = !0);
			} else dr(s) && n && e.isSelected() && e.selectPrevious();
			if (ur(s) && n && !l) {
				const t = e.getIndexWithinParent();
				Hs(e), Br(s, i, t, -1);
			} else Hs(e);
			o || Bl(i) || i.canBeEmpty() || !i.isEmpty() || ao(i, n), n && s && Bi(i) && i.isEmpty() && i.selectEnd();
		}
		const fo = Symbol.for("ephemeral");
		function ho(t) {
			return t[fo] || !1;
		}
		const go = {
			configurable: !0,
			enumerable: !1,
			value: void 0,
			writable: !0
		};
		var _o = class {
			__type;
			__key;
			__parent;
			__prev;
			__next;
			__state;
			[Kt$2];
			static getType() {
				const { ownNodeType: e } = Hc(this);
				return void 0 === e && t(64, this.name), e;
			}
			static clone(e) {
				t(65, this.name);
			}
			$config() {
				return {};
			}
			config(t, e) {
				const n = e.extends || Gc(this.constructor);
				return Object.assign(e, { extends: n }), "string" == typeof t && Object.assign(e, { type: t }), { [t]: e };
			}
			afterCloneFrom(t) {
				this.__key === t.__key ? (this.__parent = t.__parent, this.__next = t.__next, this.__prev = t.__prev, this.__state = t.__state) : t.__state && (this.__state = t.__state.getWritable(this));
			}
			resetOnCopyNodeFrom(t) {
				this.__state && (this.__state = this.__state.getWritable(this).resetOnCopyNode());
			}
			static importDOM;
			constructor(t) {
				this.__type = this.constructor.getType(), this.__parent = null, this.__prev = null, this.__next = null, Object.defineProperty(this, "__state", go), Object.defineProperty(this, Kt$2, go), Us(this, t);
			}
			getType() {
				return this.__type;
			}
			isInline() {
				t(137, this.constructor.name);
			}
			isAttached() {
				let t = this.__key;
				for (; null !== t;) {
					if ("root" === t) return !0;
					const e = Ys(t);
					if (null === e) break;
					t = null !== e.__parent ? e.__parent : ta(e);
				}
				return !1;
			}
			isSelected(t) {
				const e = t || Kr();
				if (null == e) return !1;
				const n = e.getNodes().some((t) => t.__key === this.__key);
				if (Xo(this)) return n;
				if (ur(e) && "element" === e.anchor.type && "element" === e.focus.type) {
					if (e.isCollapsed()) return !1;
					const t = this.getParent();
					if (Ki(this) && this.isInline() && t) {
						const n = e.isBackward() ? e.focus : e.anchor;
						if (t.is(n.getNode()) && n.offset === t.getChildrenSize() && this.is(t.getLastChild())) return !1;
					}
				}
				return n;
			}
			getKey() {
				return this.__key;
			}
			getIndexWithinParent() {
				const t = this.getParent();
				if (null === t) return -1;
				let e = t.getFirstChild(), n = 0;
				for (; null !== e;) {
					if (this.is(e)) return n;
					n++, e = e.getNextSibling();
				}
				return -1;
			}
			getParent() {
				const t = this.getLatest().__parent;
				return null === t ? null : Ys(t);
			}
			getParentOrThrow() {
				const e = this.getParent();
				return null === e && t(66, this.__key), e;
			}
			getTopLevelElement() {
				let e = this;
				for (; null !== e;) {
					const n = e.getParent();
					if (Bl(n) || null !== ta(e)) return Pi(e) || e === this && Ki(e) || t(194), e;
					e = n;
				}
				return null;
			}
			getTopLevelElementOrThrow() {
				const e = this.getTopLevelElement();
				return null === e && t(67, this.__key), e;
			}
			getParents() {
				const t = [];
				let e = this.getParent();
				for (; null !== e;) t.push(e), e = e.getParent();
				return t;
			}
			getParentKeys() {
				const t = [];
				let e = this.getParent();
				for (; null !== e;) t.push(e.__key), e = e.getParent();
				return t;
			}
			getPreviousSibling() {
				const t = this.getLatest().__prev;
				return null === t ? null : Ys(t);
			}
			getPreviousSiblings() {
				const t = [], e = this.getParent();
				if (null === e) return t;
				let n = e.getFirstChild();
				for (; null !== n && !n.is(this);) t.push(n), n = n.getNextSibling();
				return t;
			}
			getNextSibling() {
				const t = this.getLatest().__next;
				return null === t ? null : Ys(t);
			}
			getNextSiblings() {
				const t = [];
				let e = this.getNextSibling();
				for (; null !== e;) t.push(e), e = e.getNextSibling();
				return t;
			}
			getCommonAncestor(t) {
				const e = Pi(this) ? this : this.getParent(), n = Pi(t) ? t : t.getParent(), o = e && n ? Za(e, n) : null;
				return o ? o.commonAncestor : null;
			}
			is(t) {
				return null != t && this.__key === t.__key;
			}
			isBefore(e) {
				const n = Za(this, e);
				return null !== n && ("descendant" === n.type || ("branch" === n.type ? -1 === Ga(n) : ("same" !== n.type && "ancestor" !== n.type && t(279), !1)));
			}
			isParentOf(t) {
				return Fl(t, this);
			}
			getNodesBetween(e) {
				const n = this.isBefore(e), o = [], r = /* @__PURE__ */ new Set();
				let i = this;
				for (; null !== i;) {
					const s = i.__key;
					if (r.has(s) || (r.add(s), o.push(i)), i === e) break;
					const l = Pi(i) ? n ? i.getFirstChild() : i.getLastChild() : null;
					if (null !== l) {
						i = l;
						continue;
					}
					const c = n ? i.getNextSibling() : i.getPreviousSibling();
					if (null !== c) {
						i = c;
						continue;
					}
					const a = i.getParentOrThrow();
					if (r.has(a.__key) || o.push(a), a === e) break;
					let u = null, f = a;
					do {
						if (null === f && t(68), u = n ? f.getNextSibling() : f.getPreviousSibling(), f = f.getParent(), null === f) break;
						null !== u || r.has(f.__key) || o.push(f);
					} while (null === u);
					i = u;
				}
				return n || o.reverse(), o;
			}
			isDirty() {
				const t = _i()._dirtyLeaves;
				return null !== t && t.has(this.__key);
			}
			getLatest() {
				if (ho(this)) return this;
				const e = Ys(this.__key);
				return null === e && t(113), e;
			}
			getWritable() {
				if (ho(this)) return this;
				fi();
				const t = hi(), e = _i(), n = t._nodeMap, o = this.__key, r = this.getLatest(), i = e._cloneNotNeeded, s = Kr();
				if (null !== s && s.setCachedNodes(null), i.has(o)) return Js(r), r;
				const l = Dc(r);
				return i.add(o), Js(l), n.set(o, l), l;
			}
			getTextContent() {
				return ha(this);
			}
			getTextContentSize() {
				return this.getTextContent().length;
			}
			createDOM(e, n) {
				t(70);
			}
			updateDOM(e, n, o) {
				t(71);
			}
			getDOMSlot(t) {
				return new q(t);
			}
			exportDOM(t) {
				return { element: this.createDOM(t._config, t) };
			}
			exportJSON() {
				const t = this.__state ? this.__state.toJSON() : void 0;
				return {
					type: this.__type,
					version: 1,
					...t
				};
			}
			static importJSON(e) {
				t(18, this.name);
			}
			updateFromJSON(t) {
				return function(t, e) {
					const n = t.getWritable(), o = e.$;
					let r = o;
					for (const t of Nt$1(n).flatKeys) t in e && (void 0 !== r && r !== o || (r = { ...o }), r[t] = e[t]);
					return (n.__state || r) && bt$2(t).updateFromJSON(r), n;
				}(this, t);
			}
			static transform() {
				return null;
			}
			remove(t) {
				ao(this, !0, t);
			}
			replace(e, n) {
				fi();
				let o = Kr();
				null !== o && (o = o.clone()), $l(this, e);
				const r = this.getLatest(), i = this.__key, s = e.__key, l = e.getWritable(), c = this.getParentOrThrow().getWritable(), a = c.__size, u = l.getParent(), f = null !== u ? l.getIndexWithinParent() : -1;
				Hs(l), null !== u && ur(o) && Br(o, u, f, -1);
				const d = r.getPreviousSibling(), h = r.getNextSibling(), g = r.__prev, _ = r.__next, p = r.__parent;
				if (ao(r, !1, !0), null === d) c.__first = s;
				else d.getWritable().__next = s;
				if (l.__prev = g, null === h) c.__last = s;
				else h.getWritable().__prev = s;
				l.__next = _, l.__parent = p, c.__size = a;
				let y = 0;
				n && (Pi(this) && Pi(l) || t(139), y = l.getChildrenSize(), l.splice(y, 0, this.getChildren()));
				const m = ia(this);
				if (m.length > 0) {
					Qc(this) && Qc(l) || t(368, this.__key, l.__key);
					for (const t of m) {
						const e = sa(this, t);
						null !== e && (ya(this, t), pa(l, t, e));
					}
				}
				if (ur(o)) {
					ol(o);
					const t = o.anchor, e = o.focus;
					t.key === i && (n && "element" === t.type ? t.set(l.__key, y + t.offset, "element") : ir(t, l)), e.key === i && (n && "element" === e.type ? e.set(l.__key, y + e.offset, "element") : ir(e, l));
				}
				return qs() === i && Vs(s), l;
			}
			insertAfter(t, e = !0) {
				fi(), $l(this, t);
				const n = this.getWritable(), o = t.getWritable();
				this.getParentOrThrow();
				const r = o.getParent(), i = Kr();
				let s = !1, l = !1;
				if (null !== r) {
					const n = t.getIndexWithinParent();
					if (ur(i)) {
						const t = r.__key, e = i.anchor, o = i.focus;
						s = "element" === e.type && e.key === t && e.offset === n + 1, l = "element" === o.type && o.key === t && o.offset === n + 1;
					}
					Hs(o), e && ur(i) && Br(i, r, n, -1);
				} else Hs(o);
				const c = this.getNextSibling(), a = this.getParentOrThrow().getWritable(), u = o.__key, f = n.__next;
				if (null === c) a.__last = u;
				else c.getWritable().__prev = u;
				if (a.__size++, n.__next = u, o.__next = f, o.__prev = n.__key, o.__parent = n.__parent, e && ur(i)) {
					const t = this.getIndexWithinParent();
					Br(i, a, t + 1);
					const e = a.__key;
					s && i.anchor.set(e, t + 2, "element"), l && i.focus.set(e, t + 2, "element");
				}
				return t;
			}
			insertBefore(t, e = !0) {
				fi(), $l(this, t);
				const n = this.getWritable(), o = t.getWritable();
				this.getParentOrThrow();
				const r = o.__key, i = Kr(), s = o.getParent(), l = null !== s ? o.getIndexWithinParent() : -1;
				Hs(o), null !== s && e && ur(i) && Br(i, s, l, -1);
				const c = this.getPreviousSibling(), a = this.getParentOrThrow().getWritable(), u = n.__prev, f = this.getIndexWithinParent();
				if (null === c) a.__first = r;
				else c.getWritable().__next = r;
				if (a.__size++, n.__prev = r, o.__prev = u, o.__next = n.__key, o.__parent = n.__parent, e && ur(i)) Br(i, this.getParentOrThrow(), f);
				return t;
			}
			isParentRequired() {
				return !1;
			}
			createParentElementNode() {
				return es$1();
			}
			selectStart() {
				return this.selectPrevious();
			}
			selectEnd() {
				return this.selectNext(0, 0);
			}
			selectPrevious(t, e) {
				fi();
				const n = ea(this);
				if (null !== n) return n.selectPrevious(t, e);
				const o = this.getPreviousSibling(), r = this.getParentOrThrow();
				if (null === o) return r.select(0, 0);
				if (Pi(o)) return o.select();
				if (!Xo(o)) {
					const t = o.getIndexWithinParent() + 1;
					return r.select(t, t);
				}
				return o.select(t, e);
			}
			selectNext(t, e) {
				fi();
				const n = ea(this);
				if (null !== n) return n.selectNext(t, e);
				const o = this.getNextSibling(), r = this.getParentOrThrow();
				if (null === o) return r.select();
				if (Pi(o)) return o.select(0, 0);
				if (!Xo(o)) {
					const t = o.getIndexWithinParent();
					return r.select(t, t);
				}
				return o.select(t, e);
			}
			markDirty() {
				this.getWritable();
			}
			reconcileObservedMutation(t, e) {
				this.markDirty();
			}
		};
		function po(t) {
			return t instanceof _o;
		}
		const mo = "history-push", xo = "history-merge", Co = "paste", ko = "skip-scroll-into-view", bo = "skip-dom-selection", No = "skip-selection-focus", wo = "composition-end", Oo = "!important";
		function Mo(t) {
			const e = {};
			if (!t) return e;
			let n = "", o = "", r = null, i = !1, s = !1, l = !1, c = 0;
			const a = t.length;
			let u = -1;
			for (let f = 0; f < a; f++) {
				const a = t[f];
				if (i) "*" === a && "/" === t[f + 1] && (i = !1, f++);
				else if (s) -1 === u && (u = f), s = !1;
				else if (null === r) if ("/" !== a || "*" !== t[f + 1]) if ("\"" !== a && "'" !== a) if ("(" !== a) if (")" !== a) if (l || ":" !== a || 0 !== c) {
					if (";" === a && 0 === c) {
						-1 !== u && (l ? o += t.slice(u, f) : n += t.slice(u, f), u = -1);
						const r = n.trim(), i = o.trim();
						"" !== r && "" !== i && (e[r] = i), n = "", o = "", l = !1;
						continue;
					}
					-1 === u && (u = f);
				} else -1 !== u && (n += t.slice(u, f), u = -1), l = !0;
				else -1 === u && (u = f), c = Math.max(0, c - 1);
				else -1 === u && (u = f), c++;
				else -1 === u && (u = f), r = a;
				else -1 !== u && (l ? o += t.slice(u, f) : n += t.slice(u, f), u = -1), i = !0, f++;
				else -1 === u && (u = f), "\\" === a ? s = !0 : a === r && (r = null);
			}
			-1 !== u && (l ? o += t.slice(u, a) : n += t.slice(u, a));
			const f = n.trim(), d = o.trim();
			return "" !== f && "" !== d && (e[f] = d), e;
		}
		function Ao(t, e, n) {
			const o = n.trimEnd(), r = o.length - 10;
			r >= 0 && o.slice(r).toLowerCase() === Oo ? t.setProperty(e, o.slice(0, r).trim(), "important") : t.setProperty(e, n, "");
		}
		function Fo(t, e, n = "") {
			if (e === n) return;
			const o = Mo(n), r = Mo(e);
			for (const e in r) delete o[e], Ao(t, e, r[e]);
			for (const e in o) t.removeProperty(e);
		}
		function Po(t, e) {
			return 16 & e ? "code" : e & 128 ? "mark" : 32 & e ? "sub" : 64 & e ? "sup" : null;
		}
		function Io(t, e) {
			return 1 & e ? "strong" : 2 & e ? "em" : "span";
		}
		function Lo(t, e, n, o, r) {
			const i = o.classList;
			let s = Cl(r, "base");
			void 0 !== s && i.add(...s), s = Cl(r, "underlineStrikethrough");
			let l = !1;
			const c = 8 & e && 4 & e;
			void 0 !== s && (8 & n && 4 & n ? (l = !0, c || i.add(...s)) : c && i.remove(...s));
			for (const t in z$1) {
				const o = z$1[t];
				if (s = Cl(r, t), void 0 !== s) if (n & o) {
					if (l && ("underline" === t || "strikethrough" === t)) {
						e & o && i.remove(...s);
						continue;
					}
					(0 === (e & o) || c && "underline" === t || "strikethrough" === t) && i.add(...s);
				} else e & o && i.remove(...s);
			}
		}
		function Ko(t, e, n) {
			const o = n.isComposing(), r = t + (o ? A : ""), s = vc(), l = Tc(s).$getDOMSlot(n, e, s), c = l.getFirstChild();
			if (null === c || c.nodeType !== Node.TEXT_NODE) return void l.insertChild(Zl().createTextNode(r));
			const a = c, u = a.nodeValue;
			if (u !== r) if (o || i) {
				const [t, e, n] = function(t, e) {
					const n = t.length, o = e.length;
					let r = 0, i = 0;
					for (; r < n && r < o && t[r] === e[r];) r++;
					for (; i + r < n && i + r < o && t[n - i - 1] === e[o - i - 1];) i++;
					return [
						r,
						n - r - i,
						e.slice(r, o - i)
					];
				}(u, r);
				0 !== e && a.deleteData(t, e), a.insertData(t, n);
			} else a.nodeValue = r;
		}
		function zo(t, e, n, o, r, i) {
			Ko(r, t, e);
			const s = i.theme.text;
			void 0 !== s && Lo(0, 0, o, t, s);
		}
		function Bo(t, e) {
			const n = Zl().createElement(e);
			return n.appendChild(t), n;
		}
		function Ro(t) {
			return null != t && !0 === t.__isInlineFormattable;
		}
		var Wo = class extends _o {
			__text;
			__format;
			__style;
			__mode;
			__detail;
			get __isInlineFormattable() {
				return !0;
			}
			$config() {
				return this.config("text", { importDOM: {
					"#text": () => ({
						conversion: Jo,
						priority: 0
					}),
					b: () => ({
						conversion: Uo,
						priority: 0
					}),
					code: () => ({
						conversion: Yo,
						priority: 0
					}),
					em: () => ({
						conversion: Yo,
						priority: 0
					}),
					i: () => ({
						conversion: Yo,
						priority: 0
					}),
					mark: () => ({
						conversion: Yo,
						priority: 0
					}),
					s: () => ({
						conversion: Yo,
						priority: 0
					}),
					span: () => ({
						conversion: $o,
						priority: 0
					}),
					strong: () => ({
						conversion: Yo,
						priority: 0
					}),
					sub: () => ({
						conversion: Yo,
						priority: 0
					}),
					sup: () => ({
						conversion: Yo,
						priority: 0
					}),
					u: () => ({
						conversion: Yo,
						priority: 0
					})
				} });
			}
			afterCloneFrom(t) {
				super.afterCloneFrom(t), this.__text = t.__text, this.__format = t.__format, this.__style = t.__style, this.__mode = t.__mode, this.__detail = t.__detail;
			}
			constructor(t = "", e) {
				super(e), this.__text = t, this.__format = 0, this.__style = "", this.__mode = 0, this.__detail = 0;
			}
			getFormat() {
				return this.getLatest().__format;
			}
			getDetail() {
				return this.getLatest().__detail;
			}
			getMode() {
				return U[this.getLatest().__mode];
			}
			getStyle() {
				return this.getLatest().__style;
			}
			isToken() {
				return 1 === this.getLatest().__mode;
			}
			isComposing() {
				return this.__key === qs();
			}
			isSegmented() {
				return 2 === this.getLatest().__mode;
			}
			isDirectionless() {
				return !!(1 & this.getLatest().__detail);
			}
			isUnmergeable() {
				return !!(2 & this.getLatest().__detail);
			}
			hasFormat(t) {
				const e = z$1[t];
				return 0 !== (this.getFormat() & e);
			}
			isSimpleText() {
				return "text" === this.__type && 0 === this.__mode;
			}
			getTextContent() {
				return this.getLatest().__text;
			}
			getFormatFlags(t, e) {
				return Ws(this.getLatest().__format, t, e);
			}
			canHaveFormat() {
				return !0;
			}
			isInline() {
				return !0;
			}
			createDOM(t, e) {
				const n = this.__format, o = Po(0, n), r = Io(0, n), i = null === o ? r : o, s = Zl().createElement(i);
				let l = s;
				this.hasFormat("code") && s.setAttribute("spellcheck", "false"), null !== o && (l = Zl().createElement(r), s.appendChild(l));
				zo(l, this, 0, n, this.__text, t);
				const c = this.__style;
				return "" !== c && Fo(s.style, c), s;
			}
			updateDOM(e, n, o) {
				const r = this.__text, i = e.__format, s = this.__format, l = Po(0, i), c = Po(0, s), a = Io(0, i), u = Io(0, s);
				if ((null === l ? a : l) !== (null === c ? u : c)) return !0;
				if (l === c && a !== u) {
					const e = n.firstChild;
					e ?? t(48);
					const i = Zl().createElement(u);
					return zo(i, this, 0, s, r, o), n.replaceChild(i, e), !1;
				}
				let f = n;
				null !== c && null !== l && (f = n.firstChild, f ?? t(49)), Ko(r, f, this);
				const d = o.theme.text;
				void 0 !== d && i !== s && Lo(0, i, s, f, d);
				const h = e.__style, g = this.__style;
				return h !== g && Fo(n.style, g, h), !1;
			}
			updateFromJSON(t) {
				return super.updateFromJSON(t).setTextContent(t.text).setFormat(t.format).setDetail(t.detail).setMode(t.mode).setStyle(t.style);
			}
			exportDOM(e) {
				let { element: n } = super.exportDOM(e);
				return gc(n) || t(132), n.style.whiteSpace = "pre-wrap", this.hasFormat("lowercase") ? n.style.textTransform = "lowercase" : this.hasFormat("uppercase") ? n.style.textTransform = "uppercase" : this.hasFormat("capitalize") && (n.style.textTransform = "capitalize"), this.hasFormat("bold") && (n = Bo(n, "b")), this.hasFormat("italic") && (n = Bo(n, "i")), this.hasFormat("strikethrough") && (n = Bo(n, "s")), this.hasFormat("underline") && (n = Bo(n, "u")), { element: n };
			}
			exportJSON() {
				return {
					detail: this.getDetail(),
					format: this.getFormat(),
					mode: this.getMode(),
					style: this.getStyle(),
					text: this.getTextContent(),
					...super.exportJSON()
				};
			}
			selectionTransform(t, e) {}
			setFormat(t) {
				const e = this.getWritable();
				return e.__format = "string" == typeof t ? z$1[t] : t, e;
			}
			setDetail(t) {
				const e = this.getWritable();
				return e.__detail = "string" == typeof t ? B[t] : t, e;
			}
			setStyle(t) {
				const e = this.getWritable();
				return e.__style = t, e;
			}
			toggleFormat(t) {
				const e = Ws(this.getFormat(), t, null);
				return this.setFormat(e);
			}
			toggleDirectionless() {
				const t = this.getWritable();
				return t.__detail ^= 1, t;
			}
			toggleUnmergeable() {
				const t = this.getWritable();
				return t.__detail ^= 2, t;
			}
			setMode(t) {
				const e = $[t];
				if (this.__mode === e) return this;
				const n = this.getWritable();
				return n.__mode = e, n;
			}
			setTextContent(t) {
				if (this.__text === t) return this;
				const e = this.getWritable();
				return e.__text = t, e;
			}
			select(t, e) {
				fi();
				let n = t, o = e;
				const r = Kr(), i = this.getTextContent(), s = this.__key;
				if ("string" == typeof i) {
					const t = i.length;
					void 0 === n && (n = t), void 0 === o && (o = t);
				} else n = 0, o = 0;
				if (!ur(r)) return Dr(s, n, s, o, "text", "text");
				{
					const t = qs();
					t !== r.anchor.key && t !== r.focus.key || Vs(s), r.setTextNodeRange(this, n, this, o);
				}
				return r;
			}
			selectStart() {
				return this.select(0, 0);
			}
			selectEnd() {
				const t = this.getTextContentSize();
				return this.select(t, t);
			}
			spliceText(t, e, n, o) {
				const r = this.getWritable(), i = r.__text, s = n.length;
				let l = t;
				l < 0 && (l = s + l, l < 0 && (l = 0));
				const c = Kr();
				if (o && ur(c)) {
					const e = t + s;
					c.setTextNodeRange(r, e, r, e);
				}
				return r.__text = i.slice(0, l) + n + i.slice(l + e), r;
			}
			canInsertTextBefore() {
				return !0;
			}
			canInsertTextAfter() {
				return !0;
			}
			splitText(...t) {
				fi();
				const e = this.getLatest(), n = e.getTextContent();
				if ("" === n) return [];
				const o = e.__key, r = qs(), i = n.length;
				t.sort((t, e) => t - e), t.push(i);
				const s = [], l = t.length;
				for (let e = 0, o = 0; e < i && o <= l; o++) {
					const r = t[o];
					r > e && (s.push(n.slice(e, r)), e = r);
				}
				const c = s.length;
				if (1 === c) return [e];
				const a = s[0], u = e.getParent();
				let f;
				const d = e.getFormat(), h = e.getStyle(), g = e.__detail;
				let _ = !1, p = null, y = null;
				const m = Kr();
				if (ur(m)) {
					const [t, e] = m.isBackward() ? [m.focus, m.anchor] : [m.anchor, m.focus];
					"text" === t.type && t.key === o && (p = t), "text" === e.type && e.key === o && (y = e);
				}
				e.isSegmented() ? (f = Go(a), f.__format = d, f.__style = h, f.__detail = g, f.__state = At(e, f), _ = !0) : f = e.setTextContent(a);
				const x = [f];
				for (let t = 1; t < c; t++) {
					const n = Go(s[t]);
					n.__format = d, n.__style = h, n.__detail = g, n.__state = At(e, n);
					const i = n.__key;
					r === o && Vs(i), x.push(n);
				}
				const C = p ? p.offset : null, S = y ? y.offset : null;
				let v = 0;
				for (const t of x) {
					if (!p && !y) break;
					const e = v + t.getTextContentSize();
					if (null !== p && null !== C && C <= e && C >= v && (p.set(t.getKey(), C - v, "text"), C < e && (p = null)), null !== y && null !== S && S <= e && S >= v) {
						y.set(t.getKey(), S - v, "text");
						break;
					}
					v = e;
				}
				if (null !== u) {
					(function(t) {
						const e = t.getPreviousSibling(), n = t.getNextSibling();
						null !== e && Js(e);
						null !== n && Js(n);
					})(this);
					const t = u.getWritable(), e = this.getIndexWithinParent();
					_ ? (t.splice(e, 0, x), this.remove()) : t.splice(e, 1, x), ur(m) && Br(m, u, e, c - 1);
				}
				return x;
			}
			mergeWithSibling(e) {
				const n = e === this.getPreviousSibling();
				n || e === this.getNextSibling() || t(50);
				const o = this.__key, r = e.__key, i = this.__text, s = i.length;
				qs() === r && Vs(o);
				const l = Kr();
				if (ur(l)) {
					const t = l.anchor, i = l.focus;
					null !== t && t.key === r && $r(t, n, o, e, s), null !== i && i.key === r && $r(i, n, o, e, s);
				}
				const c = e.__text, a = n ? c + i : i + c;
				this.setTextContent(a);
				const u = this.getWritable();
				return e.remove(), u;
			}
			isTextEntity() {
				return !1;
			}
		};
		function $o(t) {
			return {
				forChild: Qo(t.style),
				node: null
			};
		}
		function Uo(t) {
			const e = t, n = "normal" === e.style.fontWeight;
			return {
				forChild: Qo(e.style, n ? void 0 : "bold"),
				node: null
			};
		}
		const Ho = /* @__PURE__ */ new WeakMap();
		function jo(t) {
			if (!gc(t)) return !1;
			if ("PRE" === t.nodeName) return !0;
			const e = t.style.whiteSpace;
			return "string" == typeof e && e.startsWith("pre");
		}
		function Jo(e) {
			const n = e;
			null === e.parentElement && t(129);
			let o = n.textContent || "";
			if (null !== function(t) {
				let e, n = t.parentNode;
				const o = [t];
				for (; null !== n && void 0 === (e = Ho.get(n)) && !jo(n);) o.push(n), n = n.parentNode;
				const r = void 0 === e ? n : e;
				for (let t = 0; t < o.length; t++) Ho.set(o[t], r);
				return r;
			}(n)) return { node: qr(o) };
			if (o = o.replace(/\r/g, "").replace(/[ \t\n]+/g, " "), "" === o) return { node: null };
			if (" " === o[0]) {
				let t = n, e = !0;
				for (; null !== t && null !== (t = Vo(t, !1));) {
					const n = t.textContent || "";
					if (n.length > 0) {
						/[ \t\n]$/.test(n) && (o = o.slice(1)), e = !1;
						break;
					}
				}
				e && (o = o.slice(1));
			}
			if (" " === o[o.length - 1]) {
				let t = n, e = !0;
				for (; null !== t && null !== (t = Vo(t, !0));) if ((t.textContent || "").replace(/^( |\t|\r?\n)+/, "").length > 0) {
					e = !1;
					break;
				}
				e && (o = o.slice(0, o.length - 1));
			}
			return "" === o ? { node: null } : { node: Go(o) };
		}
		function Vo(t, e) {
			let n = t;
			for (;;) {
				let t;
				for (; null === (t = e ? n.nextSibling : n.previousSibling);) {
					const t = n.parentElement;
					if (null === t) return null;
					n = t;
				}
				if (n = t, gc(n)) {
					const t = n.style.display;
					if ("" === t && !mc(n) || "" !== t && !t.startsWith("inline")) return null;
				}
				let o = n;
				for (; null !== (o = e ? n.firstChild : n.lastChild);) n = o;
				if (zs(n)) return n;
				if ("BR" === n.nodeName) return null;
			}
		}
		const qo = {
			code: "code",
			em: "italic",
			i: "italic",
			mark: "highlight",
			s: "strikethrough",
			strong: "bold",
			sub: "subscript",
			sup: "superscript",
			u: "underline"
		};
		function Yo(t) {
			const e = qo[t.nodeName.toLowerCase()];
			return void 0 === e ? { node: null } : {
				forChild: Qo(t.style, e),
				node: null
			};
		}
		function Go(t = "") {
			return Wl(new Wo(t));
		}
		function Xo(t) {
			return t instanceof Wo;
		}
		function Qo(t, e) {
			const n = t.fontWeight, o = t.textDecoration.split(" "), r = "700" === n || "bold" === n, i = o.includes("line-through"), s = "italic" === t.fontStyle, l = o.includes("underline"), c = t.verticalAlign;
			return (t) => Xo(t) || Ro(t) ? (r && !t.hasFormat("bold") && t.toggleFormat("bold"), i && !t.hasFormat("strikethrough") && t.toggleFormat("strikethrough"), s && !t.hasFormat("italic") && t.toggleFormat("italic"), l && !t.hasFormat("underline") && t.toggleFormat("underline"), "sub" !== c || t.hasFormat("subscript") || t.toggleFormat("subscript"), "super" !== c || t.hasFormat("superscript") || t.toggleFormat("superscript"), e && !t.hasFormat(e) && t.toggleFormat(e), t) : t;
		}
		var Zo = class extends Wo {
			$config() {
				return this.config("tab", { extends: Wo });
			}
			constructor(t = void 0) {
				super("	", t), this.__detail = 2;
			}
			createDOM(t) {
				const e = super.createDOM(t), n = Cl(t.theme, "tab");
				if (void 0 !== n) e.classList.add(...n);
				return e;
			}
			setTextContent(t) {
				return super.setTextContent("	");
			}
			spliceText(e, n, o, r) {
				return "" === o && 0 === n || "	" === o && 1 === n || t(286), this;
			}
			setDetail(e) {
				return 2 !== e && t(127), this;
			}
			setMode(e) {
				return "normal" !== e && t(128), this;
			}
			canInsertTextBefore() {
				return !1;
			}
			canInsertTextAfter() {
				return !1;
			}
		};
		function tr() {
			return Wl(new Zo());
		}
		function er(t) {
			return t instanceof Zo;
		}
		var nr = class {
			key;
			offset;
			type;
			_selection;
			constructor(t, e, n) {
				this._selection = null, this.key = t, this.offset = e, this.type = n;
			}
			is(t) {
				return this.key === t.key && this.offset === t.offset && this.type === t.type;
			}
			isBefore(t) {
				if (this.key === t.key) return this.offset < t.offset;
				return Ya(au(tu(this, "next")), au(tu(t, "next"))) < 0;
			}
			getNode() {
				const e = Ys(this.key);
				return null === e && t(20), e;
			}
			set(t, e, n, o) {
				const r = this._selection, i = this.key;
				o && this.key === t && this.offset === e && this.type === n || (this.key = t, this.offset = e, this.type = n, ui() || (qs() === i && Vs(t), null !== r && (r.setCachedNodes(null), ur(r) && (r._cachedIsBackward = null), r.dirty = !0)));
			}
		};
		function or(t, e, n) {
			return new nr(t, e, n);
		}
		function rr(t, e) {
			let n = e.__key, o = t.offset, r = "element";
			if (Xo(e)) {
				r = "text";
				const t = e.getTextContentSize();
				o > t && (o = t);
			} else if (!Pi(e)) {
				const t = e.getNextSibling();
				if (Xo(t)) n = t.__key, o = 0, r = "text";
				else {
					const t = e.getParent();
					t && (n = t.__key, o = e.getIndexWithinParent() + 1);
				}
			}
			t.set(n, o, r);
		}
		function ir(t, e) {
			if (Pi(e)) {
				const n = e.getLastDescendant();
				Pi(n) || Xo(n) ? rr(t, n) : rr(t, e);
			} else rr(t, e);
		}
		function sr(t, e, n, o) {
			const r = t.getNode(), i = r.getChildAtIndex(t.offset), s = Go();
			if (s.setFormat(n), s.setStyle(o), ns(i)) i.splice(0, 0, [s]);
			else if (null !== i) {
				const t = Bl(r) ? es$1().append(s) : s;
				i.insertBefore(t);
			} else if (Bl(r)) {
				const t = r.getLastChild();
				Pi(t) && !t.isInline() && t.isEmpty() ? t.append(s) : r.append(es$1().append(s));
			} else r.append(s);
			t.is(e) && e.set(s.__key, 0, "text"), t.set(s.__key, 0, "text");
		}
		function lr(e, n, o, r) {
			const i = e.anchor.getNode();
			Xo(i) || t(398);
			const s = e.anchor.offset, l = Go(n);
			l.setFormat(o), l.setStyle(r);
			const c = i.getParentOrThrow();
			if (0 === s) c.isInline() && !i.__prev ? c.insertBefore(l) : i.insertBefore(l, !1);
			else if (s === i.getTextContentSize()) c.isInline() && !i.__next ? c.insertAfter(l) : i.insertAfter(l, !1);
			else {
				const [t] = i.splitText(s);
				t.insertAfter(l, !1);
			}
			"" === i.getTextContent() && i.isAttached() && i.remove(), l.selectEnd(), l.isComposing() && "text" === e.anchor.type && e.anchor.set(e.anchor.key, e.anchor.offset - n.length, e.anchor.type);
		}
		var cr = class cr {
			_nodes;
			_cachedNodes;
			dirty;
			constructor(t) {
				this._cachedNodes = null, this._nodes = t, this.dirty = !1;
			}
			getCachedNodes() {
				return this._cachedNodes;
			}
			setCachedNodes(t) {
				this._cachedNodes = t;
			}
			is(t) {
				if (!dr(t)) return !1;
				const e = this._nodes, n = t._nodes;
				return e.size === n.size && Array.from(e).every((t) => n.has(t));
			}
			isCollapsed() {
				return !1;
			}
			isBackward() {
				return !1;
			}
			getStartEndPoints() {
				return null;
			}
			add(t) {
				this.dirty = !0, this._nodes.add(t), this._cachedNodes = null;
			}
			delete(t) {
				this.dirty = !0, this._nodes.delete(t), this._cachedNodes = null;
			}
			clear() {
				this.dirty = !0, this._nodes.clear(), this._cachedNodes = null;
			}
			has(t) {
				return this._nodes.has(t);
			}
			clone() {
				return new cr(new Set(this._nodes));
			}
			extract() {
				return this.getNodes();
			}
			insertRawText(t) {}
			insertText() {}
			insertNodes(t) {
				const e = this.getNodes().filter((t) => null === ta(t)), n = e.length;
				if (0 === n) return;
				const o = e[n - 1];
				let r;
				if (Xo(o)) r = o.select();
				else {
					const t = o.getIndexWithinParent() + 1;
					r = o.getParentOrThrow().select(t, t);
				}
				r.insertNodes(t);
				for (let t = 0; t < n; t++) e[t].remove();
			}
			getNodes() {
				const t = this._cachedNodes;
				if (null !== t) return t;
				const e = this._nodes, n = [];
				for (const t of e) {
					const e = Ys(t);
					null !== e && n.push(e);
				}
				return ui() || (this._cachedNodes = n), n;
			}
			getTextContent() {
				const t = this.getNodes();
				let e = "";
				for (let n = 0; n < t.length; n++) e += t[n].getTextContent();
				return e;
			}
			deleteNodes() {
				const t = this.getNodes().filter((t) => null === ta(t));
				if ((Kr() || zr()) === this && t[0]) {
					const e = Ia(t[0], "next");
					nu(Va(e, e));
				}
				for (const e of t) e.remove();
				ar();
			}
		};
		function ar() {
			const t = nl();
			if (t.isEmpty()) {
				const e = es$1();
				t.append(e), e.select();
			}
		}
		function ur(t) {
			return t instanceof fr$1;
		}
		var fr$1 = class fr$1 {
			format;
			style;
			anchor;
			focus;
			_cachedNodes;
			_cachedIsBackward;
			dirty;
			constructor(t, e, n, o) {
				this.anchor = t, this.focus = e, t._selection = this, e._selection = this, this._cachedNodes = null, this._cachedIsBackward = null, this.format = n, this.style = o, this.dirty = !1;
			}
			getCachedNodes() {
				return this._cachedNodes;
			}
			setCachedNodes(t) {
				this._cachedNodes = t;
			}
			is(t) {
				return !!ur(t) && this.anchor.is(t.anchor) && this.focus.is(t.focus) && this.format === t.format && this.style === t.style;
			}
			isCollapsed() {
				return this.anchor.is(this.focus);
			}
			getNodes() {
				const t = this._cachedNodes;
				if (null !== t) return t;
				const e = function(t) {
					const e = [], [n, o] = t.getTextSlices();
					n && e.push(n.caret.origin);
					const r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set();
					for (const n of t) if (Aa(n)) {
						const { origin: t } = n;
						0 === e.length ? r.add(t) : (i.add(t), e.push(t));
					} else {
						const { origin: t } = n;
						Pi(t) && i.has(t) || e.push(t);
					}
					o && e.push(o.caret.origin);
					if (Ma(t.focus) && Pi(t.focus.origin) && null === t.focus.getNodeAtCaret()) for (let n = Ba(t.focus.origin, "previous"); Aa(n) && r.has(n.origin) && !n.origin.isEmpty() && n.origin.is(e[e.length - 1]); n = Wa(n)) r.delete(n.origin), e.pop();
					for (; e.length > 1;) {
						const t = e[e.length - 1];
						if (!Pi(t) || i.has(t) || t.isEmpty() || r.has(t)) break;
						e.pop();
					}
					if (0 === e.length && t.isCollapsed()) {
						const n = au(t.anchor), o = au(t.anchor.getFlipped()), r = (t) => wa(t) ? t.origin : t.getNodeAtCaret(), i = r(n) || r(o) || (t.anchor.getNodeAtCaret() ? n.origin : o.origin);
						e.push(i);
					}
					return e;
				}(du(ru$1(this), "next"));
				return ui() || (this._cachedNodes = e), e;
			}
			setTextNodeRange(t, e, n, o) {
				return this.anchor.set(t.__key, e, "text"), this.focus.set(n.__key, o, "text"), this;
			}
			getTextContent() {
				const t = this.getNodes();
				if (0 === t.length) return "";
				const e = t[0], n = t[t.length - 1], o = this.anchor, r = this.focus, i = o.isBefore(r), [s, l] = yr(this);
				let c = "", a = !0;
				for (let u = 0; u < t.length; u++) {
					const f = t[u];
					if (Pi(f) && !f.isInline()) {
						a || (c += "\n");
						let t = "";
						for (const e of ia(f)) {
							const n = sa(f, e);
							null !== n && (t += n.getTextContent());
						}
						"" !== t ? (c += t, a = !1) : a = !f.isEmpty();
					} else if (a = !1, Xo(f)) {
						let t = f.getTextContent();
						f === e ? f === n ? "element" === o.type && "element" === r.type && r.offset !== o.offset || (t = s < l ? t.slice(s, l) : t.slice(l, s)) : t = i ? t.slice(s) : t.slice(l) : f === n && (t = i ? t.slice(0, l) : t.slice(0, s)), c += t;
					} else !Ki(f) && !Yi(f) || f === n && this.isCollapsed() || (c += f.getTextContent());
				}
				return c;
			}
			applyDOMRange(t) {
				const e = _i(), n = e.getEditorState()._selection, o = Mr(t.startContainer, t.startOffset, t.endContainer, t.endOffset, e, n);
				if (null === o) return;
				const [r, i, s] = o;
				this.anchor.set(r.key, r.offset, r.type, !0), this.focus.set(i.key, i.offset, i.type, !0), s && (this.dirty = !0), It(this);
			}
			clone() {
				const t = this.anchor, e = this.focus;
				return new fr$1(or(t.key, t.offset, t.type), or(e.key, e.offset, e.type), this.format, this.style);
			}
			toggleFormat(t) {
				this.format = Ws(this.format, t, null), this.dirty = !0;
			}
			setFormat(t) {
				this.format = t, this.dirty = !0;
			}
			setStyle(t) {
				this.style = t, this.dirty = !0;
			}
			hasFormat(t) {
				const e = z$1[t];
				return 0 !== (this.format & e);
			}
			insertRawText(t) {
				this.insertNodes(qr(t));
			}
			insertText(e) {
				let n = this.format, o = this.style;
				if (!this.isCollapsed()) {
					const t = (this.focus.isBefore(this.anchor) ? this.focus : this.anchor).getNode();
					if (Xo(t) && (n = t.getFormat(), o = t.getStyle()), this.removeText(), this.format = n, this.style = o, "" === e) return;
					if (null === qs()) return "element" === this.anchor.type && sr(this.anchor, this.focus, n, o), void lr(this, e, n, o);
				}
				"element" === this.anchor.type && sr(this.anchor, this.focus, n, o);
				const r = this.anchor.getNode();
				Xo(r) || t(398);
				const i = this.anchor.offset, s = r.getParentOrThrow(), l = r.getTextContentSize();
				if (Ks(r) || 0 === i && (!r.canInsertTextBefore() || !s.canInsertTextBefore() && !r.__prev) || i === l && (!r.canInsertTextAfter() || !s.canInsertTextAfter() && !r.__next)) {
					if (r.isSegmented() && 0 !== i && i !== l) {
						if (null !== qs()) r.setMode("normal").setFormat(n).setStyle(o);
						else {
							const t = Go(r.getTextContent());
							t.setFormat(n), t.setStyle(o), r.replace(t), t.select(i, i);
						}
						"" !== e && this.insertText(e);
						return;
					}
					if ("" === e) return;
					if (0 === i) {
						const t = r.getPreviousSibling();
						if (Xo(t) && t.canInsertTextAfter() && !Ks(t)) t.select();
						else {
							const t = Go();
							t.setFormat(n), t.setStyle(o), s.canInsertTextBefore() ? r.insertBefore(t) : s.insertBefore(t), t.select();
						}
						this.insertText(e);
						return;
					}
					if (i === l) {
						const t = r.getNextSibling();
						if (Xo(t) && t.canInsertTextBefore() && !Ks(t)) t.select(0, 0);
						else {
							const t = Go();
							t.setFormat(n), t.setStyle(o), s.canInsertTextAfter() ? r.insertAfter(t) : s.insertAfter(t), t.select(0, 0);
						}
						this.insertText(e);
						return;
					}
					const t = Go(e);
					t.setFormat(n), t.setStyle(o), r.replace(t), t.select();
					return;
				}
				if ("" === e) return;
				const c = s.isInline() && 0 === i && !r.__prev, a = s.isInline() && i === l && !r.__next, u = r.getFormat() !== n || r.getStyle() !== o;
				if (c || a || u) {
					if ("" !== r.getTextContent() || c || a) return void lr(this, e, n, o);
					r.setFormat(n), r.setStyle(o);
				}
				r.spliceText(i, 0, e, !0), r.isComposing() && "text" === this.anchor.type && this.anchor.set(this.anchor.key, this.anchor.offset - e.length, this.anchor.type);
			}
			removeText() {
				const t = Kr() === this;
				ou(this, cu(ru$1(this))), t && Kr() !== this && ol(this);
			}
			formatText(t, e = null) {
				_r(this, t, e);
			}
			insertNodes(e) {
				if (0 === e.length) return;
				this.isCollapsed() || this.removeText();
				const n = this.anchor.getNode();
				if ("element" === this.anchor.type && Pi(n) && null !== ta(n)) {
					let o = n.isShadowRoot() ? n.getFirstChild() ?? n.append(es$1()).getFirstChild() : n.getFirstChild();
					if (n.isShadowRoot() && null !== o && !Pi(o)) {
						const t = es$1();
						o.insertBefore(t), o = t;
					}
					if (null !== o) {
						o.selectStart();
						const n = Kr();
						return ur(n) || t(369), n.insertNodes(e);
					}
				}
				if ("element" === this.anchor.type && Bl(n)) {
					const t = ti(e), o = t.getLastDescendant();
					n.splice(this.anchor.offset, 0, t.getChildren()), null !== o && o.selectEnd();
					return;
				}
				let o = (this.isBackward() ? this.focus : this.anchor).getNode(), r = qc(o, Sc);
				const i = e[e.length - 1];
				if (Pi(r) && "__language" in r) {
					if ("__language" in e[0]) this.insertText(e[0].getTextContent());
					else {
						const t = Xr(this);
						r.splice(t, 0, e), i.selectEnd();
					}
					return;
				}
				if (!e.some((t) => (Pi(t) || Ki(t)) && !t.isInline())) {
					Pi(r) || t(211, o.constructor.name, o.getType());
					const n = Xr(this);
					r.splice(n, 0, e), i.selectEnd();
					return;
				}
				if (Pi(r) && null !== ta(r)) {
					const t = Xr(this), n = Gr(e);
					r.splice(t, 0, n);
					const o = n[n.length - 1];
					void 0 !== o ? o.selectEnd() : r.select(t, t);
					return;
				}
				if (null === r) {
					const t = ti(e), n = t.getLastDescendant();
					let o = tu(this.anchor, "next");
					for (const e of t.getChildren()) o = mu(e, o);
					null !== n && n.selectEnd();
					return;
				}
				if (Pi(r) && !r.isParentRequired() && !Bl(r.getParentOrThrow())) {
					const t = Xr(this), n = Gr(e);
					r.splice(t, 0, n);
					const o = n[n.length - 1];
					void 0 !== o ? o.selectEnd() : r.select(t, t);
					return;
				}
				const s = ti(e), l = s.getLastDescendant(), c = s.getChildren(), a = !Pi(r) || !r.isEmpty() ? this.insertParagraph() : null;
				a && !r.isAttached() && (o = this.anchor.getNode(), r = qc(o, Sc));
				const u = c[c.length - 1];
				let f = c[0];
				var d;
				Pi(d = f) && Sc(d) && !d.isEmpty() && Pi(r) && (!r.isEmpty() || r.canMergeWhenEmpty()) && (Pi(r) || t(211, o.constructor.name, o.getType()), r.append(...f.getChildren()), f = c[1]), f && (null === r && t(212, o.constructor.name, o.getType()), function(e, n) {
					const o = n.getParentOrThrow().getLastChild();
					let r = n;
					const i = [n];
					for (; r !== o;) r.getNextSibling() || t(140), r = r.getNextSibling(), i.push(r);
					let s = e;
					for (const t of i) s = s.insertAfter(t);
				}(r, f));
				const h = qc(l, Sc);
				a && Pi(h) && (a.canMergeWhenEmpty() || Sc(u)) && (h.append(...a.getChildren()), a.remove()), Pi(r) && r.isEmpty() && r.remove(), l.selectEnd();
				const g = Pi(r) ? r.getLastChild() : null;
				Yi(g) && h !== r && g.remove();
			}
			insertParagraph() {
				const e = this.anchor.getNode();
				if ("element" === this.anchor.type && Bl(e)) {
					const t = es$1();
					return e.splice(this.anchor.offset, 0, [t]), t.select(), t;
				}
				const n = Xr(this), o = qc(this.anchor.getNode(), Sc);
				if (null !== o && null !== ta(o)) return null;
				Pi(o) || t(213);
				const r = o.getChildAtIndex(n), i = r ? [r, ...r.getNextSiblings()] : [], s = o.insertNewAfter(this, !1);
				return s ? (s.append(...i), s.selectStart(), s) : null;
			}
			insertLineBreak(t) {
				const e = qi();
				if (this.insertNodes([e]), t) {
					const t = e.getParentOrThrow(), n = e.getIndexWithinParent();
					t.select(n, n);
				}
			}
			extract() {
				const t = [...this.getNodes()], e = t.length;
				let n = t[0], o = t[e - 1];
				const [r, i] = yr(this), s = this.isBackward(), [l, c] = s ? [this.focus, this.anchor] : [this.anchor, this.focus], [a, u] = s ? [i, r] : [r, i];
				if (0 === e) return [];
				if (1 === e) {
					if (Xo(n) && !this.isCollapsed()) {
						const t = n.splitText(a, u), e = 0 === a ? t[0] : t[1];
						return e ? (l.set(e.getKey(), 0, "text"), c.set(e.getKey(), e.getTextContentSize(), "text"), [e]) : [];
					}
					return [n];
				}
				if (Xo(n) && (a === n.getTextContentSize() ? t.shift() : 0 !== a && ([, n] = n.splitText(a), t[0] = n, l.set(n.getKey(), 0, "text"))), Xo(o)) {
					const e = o.getTextContent().length;
					0 === u ? t.pop() : u !== e && ([o] = o.splitText(u), t[t.length - 1] = o, c.set(o.getKey(), o.getTextContentSize(), "text"));
				}
				return t;
			}
			modify(t, e, n) {
				if (ei(this, t, e, n)) return;
				const o = "move" === t, r = _i(), i = Jl(Il(r));
				if (!i) return;
				const s = r._blockCursorElement, l = r._rootElement, c = this.focus.getNode();
				null === l || null === s || !Pi(c) || c.isInline() || c.canBeEmpty() || jl(s, r, l);
				const a = El(r, this.focus.key);
				let u = a;
				if ("text" === this.focus.type && (u = Xo(c) ? wc(c, a, r) : null), this.dirty) {
					const t = El(r, this.anchor.key);
					let e = t;
					if ("text" === this.anchor.type) {
						const n = this.anchor.getNode();
						e = Xo(n) ? wc(n, t, r) : null;
					}
					e && u && Ur(i, e, this.anchor.offset, u, this.focus.offset);
				}
				if ("character" === n && Xo(c) && c.isUnmergeable()) {
					if (e ? 0 === this.focus.offset : this.focus.offset === c.getTextContentSize()) {
						const t = Ia(c, e ? "previous" : "next").getNodeAtCaret();
						if (Xo(t)) {
							if (!o) {
								const n = t.getTextContentSize();
								e ? this.focus.set(t.__key, n - 1, "text") : this.focus.set(t.__key, 1, "text"), this.dirty = !0;
								return;
							}
							{
								const n = r.getElementByKey(t.getKey()), o = n ? wc(t, n, r) : null;
								if (o) {
									const t = e ? o.length : 0;
									Ur(i, o, t, o, t);
								}
							}
						}
					}
				}
				if (Cr(i, t, e ? "backward" : "forward", n), i.rangeCount > 0) {
					const t = tc(i, r._rootElement), n = t || i.getRangeAt(0), s = this.anchor.getNode(), l = Bi(s) ? s : Kl(s);
					if (this.applyDOMRange(n), this.dirty = !0, !o) {
						Sr(this, e, l);
						(t ? "backward" !== i.direction : i.anchorNode === n.startContainer && i.anchorOffset === n.startOffset) || xr(this);
					}
				}
				"lineboundary" === n && ei(this, t, e, n, "decorators");
			}
			forwardDeletion(t, e, n) {
				if (!n && ("element" === t.type && Pi(e) && t.offset === e.getChildrenSize() || "text" === t.type && t.offset === e.getTextContentSize())) {
					const t = e.getParent(), n = e.getNextSibling() || (null === t ? null : t.getNextSibling());
					if (Pi(n) && n.isShadowRoot()) return !0;
				}
				return !1;
			}
			deleteCharacter(t) {
				const e = this.isCollapsed();
				if (this.isCollapsed()) {
					const e = this.anchor;
					let n = e.getNode();
					if (this.forwardDeletion(e, n, t)) return;
					const o = ja$1(tu(e, t ? "previous" : "next"));
					if (o.getTextSlices().every((t) => null === t || 0 === t.distance)) {
						let t = { type: "initial" };
						for (const e of o.iterNodeCarets("shadowRoot")) if (Aa(e)) if (e.origin.isInline());
						else {
							if (e.origin.isShadowRoot()) {
								if ("merge-block" === t.type) break;
								if (Pi(o.anchor.origin) && o.anchor.origin.isEmpty()) {
									const t = au(e);
									ou(this, Va(t, t)), o.anchor.origin.remove();
								}
								return;
							}
							"merge-next-block" !== t.type && "merge-block" !== t.type || (t = {
								block: t.block,
								caret: e,
								type: "merge-block"
							});
						}
						else {
							if ("merge-block" === t.type) break;
							if (Ma(e)) {
								if (Pi(e.origin)) {
									if (e.origin.isInline()) {
										if (!e.origin.isParentOf(o.anchor.origin)) break;
									} else t = {
										block: e.origin,
										type: "merge-next-block"
									};
									continue;
								}
								if (Ki(e.origin)) {
									if (e.origin.isIsolated());
									else if (ia(e.origin).length > 0) {
										if (Pi(o.anchor.origin) && o.anchor.origin.isEmpty()) {
											o.anchor.origin.remove();
											const t = Pr();
											t.add(e.origin.getKey()), ol(t);
										}
									} else if ("merge-next-block" === t.type && (e.origin.isKeyboardSelectable() || !e.origin.isInline()) && Pi(o.anchor.origin) && o.anchor.origin.isEmpty()) {
										o.anchor.origin.remove();
										const t = Pr();
										t.add(e.origin.getKey()), ol(t);
									} else e.origin.remove();
									return;
								}
								break;
							}
						}
						if ("merge-block" === t.type) {
							const { caret: e, block: n } = t;
							if (ia(n).length > 0) return;
							return e.origin.isEmpty() && !n.isEmpty() && e.origin.getParent() === n.getParent() ? void e.origin.remove(!0) : (ou(this, Va(!e.origin.isEmpty() && n.isEmpty() ? iu(Ia(n, e.direction)) : o.anchor, e)), this.removeText());
						}
						for (let t = e.getNode(); null !== t;) {
							if (null !== ta(t)) return;
							if (Pi(t) && t.isShadowRoot()) break;
							t = t.getParent();
						}
					}
					const r = this.focus;
					if (vr(this, t, "character"), this.isCollapsed()) {
						if (t && 0 === e.offset && mr(this, e.getNode())) return;
					} else {
						const o = "text" === r.type ? r.getNode() : null;
						if (n = "text" === e.type ? e.getNode() : null, null !== o && o.isSegmented()) {
							const e = r.offset, i = o.getTextContentSize();
							if (o.is(n) || t && e !== i || !t && 0 !== e) return void kr(o, t, e);
						} else if (null !== n && n.isSegmented()) {
							const r = e.offset, i = n.getTextContentSize();
							if (n.is(o) || t && 0 !== r || !t && r !== i) return void kr(n, t, r);
						}
						(function(t, e) {
							const n = t.anchor, o = t.focus, r = n.getNode();
							if (r === o.getNode() && "text" === n.type && "text" === o.type) {
								const t = n.offset, i = o.offset, s = t < i, l = s ? t : i, c = s ? i : t, a = c - 1;
								if (l !== a) (function(t) {
									return !(sl(t) || Tr(t));
								})(r.getTextContent().slice(l, c)) && (e ? o.set(o.key, a, o.type) : n.set(n.key, a, n.type));
							}
						})(this, t);
					}
				}
				if (this.removeText(), t && !e && this.isCollapsed() && "element" === this.anchor.type && 0 === this.anchor.offset) {
					const t = this.anchor.getNode();
					t.isEmpty() && Bi(t.getParent()) && null === t.getPreviousSibling() && mr(this, t), ar();
				}
			}
			deleteLine(t) {
				const e = Er(this.anchor);
				if (null !== e && Ki(ea(e))) return this.isCollapsed() || this.focus.set(this.anchor.key, this.anchor.offset, this.anchor.type), void this.deleteCharacter(t);
				if (this.isCollapsed() && vr(this, t, "lineboundary"), this.isCollapsed()) this.deleteCharacter(t);
				else qc(this.anchor.getNode(), Sc) !== qc(this.focus.getNode(), Sc) ? (this.focus.set(this.anchor.key, this.anchor.offset, this.anchor.type), this.deleteCharacter(t)) : this.removeText();
			}
			deleteWord(t) {
				if (this.isCollapsed()) {
					const e = this.anchor, n = e.getNode();
					if (this.forwardDeletion(e, n, t)) return;
					vr(this, t, "word");
				}
				this.isCollapsed() ? this.deleteCharacter(t) : this.removeText();
			}
			isBackward() {
				const t = this._cachedIsBackward;
				if (null !== t) return t;
				const e = this.focus.isBefore(this.anchor);
				return ui() || (this._cachedIsBackward = e), e;
			}
			getStartEndPoints() {
				return [this.anchor, this.focus];
			}
		};
		function dr(t) {
			return t instanceof cr;
		}
		function hr(t, e) {
			if (dr(t)) {
				for (const n of t.getNodes()) Ro(n) && n.setFormat(e(n.getFormat()));
				return;
			}
			if (t.isCollapsed()) return t.setFormat(e(t.format)), void Vs(null);
			const n = [];
			for (const o of t.getNodes()) Xo(o) ? n.push(o) : Pi(o) ? o.setTextFormat(e(o.getTextFormat())) : Ro(o) && o.setFormat(e(o.getFormat()));
			const o = n.length;
			if (0 === o) return t.setFormat(e(t.format)), void Vs(null);
			const r = t.anchor, i = t.focus, s = t.isBackward(), l = s ? i : r, c = s ? r : i;
			let a = 0, u = n[0], f = "element" === l.type ? 0 : l.offset;
			if ("text" === l.type && f === u.getTextContentSize() && (a = 1, u = n[1], f = 0), null == u) return;
			const d = o - 1;
			let h = n[d];
			const g = "text" === c.type ? c.offset : h.getTextContentSize();
			if (u.is(h)) {
				if (f === g) return;
				const n = e(u.getFormat());
				if (Ks(u) || 0 === f && g === u.getTextContentSize()) u.setFormat(n);
				else {
					const t = u.splitText(f, g), e = 0 === f ? t[0] : t[1];
					e.setFormat(n), "text" === l.type && l.set(e.__key, 0, "text"), "text" === c.type && c.set(e.__key, g - f, "text");
				}
				t.format = n;
				return;
			}
			0 === f || Ks(u) || ([, u] = u.splitText(f), f = 0);
			const _ = e(u.getFormat());
			u.setFormat(_);
			const p = e(h.getFormat());
			g > 0 && (g === h.getTextContentSize() || Ks(h) || ([h] = h.splitText(g)), h.setFormat(p));
			for (let t = a + 1; t < d; t++) {
				const o = n[t];
				o.setFormat(e(o.getFormat()));
			}
			"text" === l.type && l.set(u.__key, f, "text"), "text" === c.type && c.set(h.__key, g, "text"), t.format = _ | p;
		}
		function _r(t, e, n = null) {
			const o = null === n && ur(t) ? Ws(t.format, e, null) : n;
			hr(t, (t) => Ws(t, e, o));
		}
		function pr(t) {
			const e = t.offset;
			if ("text" === t.type) return e;
			const n = t.getNode();
			return e === n.getChildrenSize() ? n.getTextContent().length : 0;
		}
		function yr(t) {
			const e = t.getStartEndPoints();
			if (null === e) return [0, 0];
			const [n, o] = e;
			return "element" === n.type && "element" === o.type && n.key === o.key && n.offset === o.offset ? [0, 0] : [pr(n), pr(o)];
		}
		function mr(t, e) {
			for (let n = e; n; n = n.getParent()) {
				if (Pi(n)) {
					if (n.collapseAtStart(t)) return !0;
					if (Bl(n)) break;
				}
				if (n.getPreviousSibling()) break;
			}
			return !1;
		}
		function xr(t) {
			const e = t.focus, n = t.anchor, o = n.key, r = n.offset, i = n.type;
			n.set(e.key, e.offset, e.type, !0), e.set(o, r, i, !0);
		}
		function Cr(t, e, n, o) {
			t.modify(e, n, o);
		}
		function Sr(t, e, n) {
			const o = t.getNodes(), r = o.filter((t) => Fl(t, n));
			if (0 === r.length || r.length === o.length) return !1;
			const i = e ? r[0] : r[r.length - 1], s = Pi(i) ? i : i.getParentOrThrow();
			return e ? s.selectStart() : s.selectEnd(), !0;
		}
		function vr(t, e, n) {
			if (ei(t, "extend", e, n)) return;
			const o = _i(), r = Jl(Il(o));
			if (!r || "function" != typeof r.modify) return;
			const i = o._blockCursorElement, s = o._rootElement, l = t.anchor, c = t.focus.getNode();
			null === s || null === i || !Pi(c) || c.isInline() || c.canBeEmpty() || jl(i, o, s);
			const a = (t) => {
				const e = t.getNode(), n = o.getElementByKey(t.key);
				return null !== n && "text" === t.type && Xo(e) ? wc(e, n, o) : n;
			}, u = l.getNode(), f = a(l);
			if (null === f) return;
			const d = l.offset, h = t.isCollapsed(), g = t.focus, _ = h ? f : a(g);
			if (null === _) return;
			const p = g.offset;
			if (Ur(r, _, p, _, p), Cr(r, "move", e ? "backward" : "forward", n), 0 === r.rangeCount) return;
			const y = tc(r, s) || r.getRangeAt(0), m = y.startContainer, x = y.startOffset;
			if (h && "character" === n && "text" === l.type && Xo(u) && u.isUnmergeable()) {
				if (d === (e ? 0 : u.getTextContentSize())) {
					const n = Ia(u, e ? "previous" : "next").getNodeAtCaret();
					if (Xo(n)) {
						const o = e ? n.getTextContentSize() - 1 : 1;
						t.focus.set(n.__key, o, "text"), t.dirty = !0;
						return;
					}
				}
			}
			if (h && "character" === n && "text" === l.type) {
				const n = e ? 0 : u.getTextContentSize(), o = m === f ? x : d !== n ? n : -1;
				if (o >= 0) return void (o !== d && (t.focus.set(l.key, o, "text"), t.dirty = !0));
			}
			const [C, S, v, T] = e ? [
				m,
				x,
				f,
				d
			] : [
				f,
				d,
				m,
				x
			], k = Bi(u) ? u : Kl(u);
			t.applyDOMRange({
				collapsed: !1,
				endContainer: v,
				endOffset: T,
				startContainer: C,
				startOffset: S
			}), t.dirty = !0, !Sr(t, e, k) && e && xr(t), "lineboundary" === n && ei(t, "extend", e, n, "decorators");
		}
		const Tr = (() => {
			try {
				const t = /* @__PURE__ */ new RegExp("\\p{Emoji}", "u"), e = t.test.bind(t);
				if (e("❤️") && e("#️⃣") && e("👍")) return e;
			} catch (t) {}
			return () => !1;
		})();
		function kr(t, e, n) {
			const o = t, r = o.getTextContent().split(/(?=\s)/g), i = r.length;
			let s = 0, l = 0;
			for (let t = 0; t < i; t++) {
				const o = t === i - 1;
				if (l = s, s += r[t].length, e && s === n || s > n || o) {
					r.splice(t, 1), o && (l = void 0);
					break;
				}
			}
			const c = r.join("").trim();
			"" === c ? o.remove() : (o.setTextContent(c), o.select(l, l));
		}
		function br(e, n, o, r) {
			let i, s = n, l = !1;
			if (gc(e)) {
				let c = !1;
				const a = e.childNodes, u = a.length, f = r._blockCursorElement;
				s === u && u > 0 && (c = !0, s = u - 1), void 0 !== Qs(e, r) || Rc(e, r) || (l = !0);
				let d = a[s], h = !1;
				if (d === f) d = a[s + 1], h = !0;
				else if (null !== f) {
					const t = f.parentNode;
					if (e === t) n > Array.prototype.indexOf.call(t.children, f) && s--;
				}
				if (i = il(d), Xo(i)) s = Ka(i, c ? "next" : "previous");
				else {
					let a = il(e);
					if (null === a) return null;
					if (Pi(a)) {
						const l = r.getElementByKey(a.getKey());
						null === l && t(214);
						const u = kc(a, l, r);
						[a, s] = u.resolveChildIndex(a, l, e, n), Pi(a) || t(215), c && s >= a.getChildrenSize() && (s = Math.max(0, a.getChildrenSize() - 1));
						let f = a.getChildAtIndex(s);
						if (Pi(f) && function(t, e, n) {
							const o = t.getParent();
							return null === n || null === o || !o.canBeEmpty() || o !== n.getNode();
						}(f, 0, o)) {
							const t = c ? f.getLastDescendant() : f.getFirstDescendant();
							null === t ? a = f : (f = t, a = Pi(f) ? f : f.getParentOrThrow()), s = 0;
						}
						Xo(f) ? (i = f, a = null, s = Ka(f, c ? "next" : "previous")) : f !== a && c && !h && (Pi(a) || t(216), s = Math.min(a.getChildrenSize(), s + 1));
					} else {
						const t = ea(a), o = null !== t ? t : a, i = o.getIndexWithinParent(), l = r.getElementByKey(a.getKey());
						let c = "after";
						if (null !== l && il(e) === a) {
							const t = kc(a, l, r);
							t.element !== l ? c = t.resolveLeafPosition(l, e, n) : 0 === n && Ki(a) && (c = "before");
						}
						s = "before" === c ? i : i + 1, a = o.getParentOrThrow();
					}
					if (Pi(a)) return [or(a.__key, s, "element"), l];
				}
			} else i = il(e);
			return Xo(i) ? [or(i.__key, Ka(i, s, "clamp"), "text"), l] : null;
		}
		function Nr(t, e, n) {
			const o = t.offset, r = t.getNode();
			if (0 === o) {
				const o = r.getPreviousSibling(), i = r.getParent();
				if (e) {
					if ((n || !e) && null === o && Pi(i) && i.isInline()) {
						const e = i.getPreviousSibling();
						Xo(e) && t.set(e.__key, e.getTextContent().length, "text");
					}
				} else Pi(o) && !n && o.isInline() ? t.set(o.__key, o.getChildrenSize(), "element") : Xo(o) && !r.isUnmergeable() && t.set(o.__key, o.getTextContent().length, "text");
			} else if (o === r.getTextContent().length) {
				const o = r.getNextSibling(), i = r.getParent();
				if (e && Pi(o) && o.isInline()) t.set(o.__key, 0, "element");
				else if ((n || e) && null === o && Pi(i) && i.isInline() && !i.canInsertTextAfter() && i.getTextContentSize() > 1) {
					const e = i.getNextSibling();
					Xo(e) && t.set(e.__key, 0, "text");
				}
			}
		}
		function Er(t) {
			const e = Ys(t.key);
			return null === e ? null : oa(e);
		}
		function wr(t, e, n) {
			const o = Er(t), r = Er(e);
			if (o === r || null !== o && null !== r && o.is(r)) return !1;
			const i = n(o, r);
			if (null !== o) return Pi(o) ? e.set(o.getKey(), i ? o.getChildrenSize() : 0, "element") : e.set(o.getKey(), i ? o.getTextContentSize() : 0, "text"), !0;
			const s = ea(r);
			if (null === s) return !1;
			const l = s.getParent();
			if (null === l) return !1;
			const c = s.getIndexWithinParent();
			return e.set(l.getKey(), i ? c + 1 : c, "element"), !0;
		}
		function Or(t) {
			const e = wr(t.anchor, t.focus, (e, n) => function(t, e, n, o) {
				if (null !== n && null !== o) {
					const t = ea(n), e = ea(o);
					if (null !== t && t.is(e)) {
						for (const e of ra(t).values()) {
							if (e === n.getKey()) return !0;
							if (e === o.getKey()) return !1;
						}
						return !0;
					}
					return null === t || null === e || t.isBefore(e);
				}
				if (null !== n) {
					const t = ea(n), o = Ys(e.key);
					return null === t || null === o || !(!t.is(o) && !t.isParentOf(o)) || t.isBefore(o);
				}
				const r = ea(o), i = Ys(t.key);
				return null !== r && null !== i && !r.is(i) && !r.isParentOf(i) && i.isBefore(r);
			}(t.anchor, t.focus, e, n));
			return e && (t.dirty = !0), e;
		}
		function Mr(t, e, n, o, r, i) {
			if (null === t || null === n || !As(r, t, n)) return null;
			const s = br(t, e, ur(i) ? i.anchor : null, r);
			if (null === s) return null;
			const l = br(n, o, ur(i) ? i.focus : null, r);
			if (null === l) return null;
			const [c, a] = s, [u, f] = l;
			if ("element" === c.type && "element" === u.type) {
				const e = il(t), o = il(n);
				if (Ki(e) && Ki(o)) return null;
			}
			const d = r._slotsUsed && wr(c, u, () => 0 !== (t.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING));
			return function(t, e) {
				if ("text" === t.type && "text" === e.type) {
					const n = t.isBefore(e), o = t.is(e);
					Nr(t, n, o), Nr(e, !n, o), o && e.set(t.key, t.offset, t.type);
				}
			}(c, u), [
				c,
				u,
				a || f || d
			];
		}
		function Ar(t) {
			return Pi(t) && !t.isInline();
		}
		function Dr(t, e, n, o, r, i) {
			const s = hi(), l = new fr$1(or(t, e, r), or(n, o, i), 0, "");
			return l.dirty = !0, s._selection = l, l;
		}
		function Fr() {
			return new fr$1(or("root", 0, "element"), or("root", 0, "element"), 0, "");
		}
		function Pr() {
			return new cr(/* @__PURE__ */ new Set());
		}
		function Lr(t, e, n, o) {
			const r = n._window;
			if (null === r) return null;
			const i = o || r.event, s = i ? i.type : void 0, l = "selectionchange" === s, c = !it$1 && (l || "beforeinput" === s || "compositionstart" === s || "compositionend" === s || "click" === s && i && 3 === i.detail || "drop" === s || void 0 === s);
			let a, u, f, d;
			if (ur(t) && !c) return t.clone();
			{
				if (null === e) return null;
				const o = nc(e, n._rootElement);
				if (a = o.anchorNode, u = o.focusNode, f = o.anchorOffset, d = o.focusOffset, (l || void 0 === s) && ur(t) && !As(n, a, u)) return t.clone();
			}
			const h = Mr(a, f, u, d, n, t);
			if (null === h) return null;
			const [g, _, p] = h;
			let y = 0, m = "";
			if (ur(t)) {
				const e = t.anchor;
				if (g.key === e.key) y = t.format, m = t.style;
				else {
					const t = g.getNode();
					Xo(t) ? (y = t.getFormat(), m = t.getStyle()) : Pi(t) && (y = t.getTextFormat(), m = t.getTextStyle());
				}
			}
			const x = new fr$1(g, _, y, m);
			return p && (x.dirty = !0), x;
		}
		function Kr() {
			return hi()._selection;
		}
		function zr() {
			return _i()._editorState._selection;
		}
		function Br(t, e, n, o = 1) {
			const r = t.anchor, i = t.focus, s = r.getNode(), l = i.getNode();
			if (!e.is(s) && !e.is(l)) return;
			const c = e.__key;
			if (t.isCollapsed()) {
				const e = r.offset;
				if (n <= e && o > 0 || n < e && o < 0) {
					const n = Math.max(0, e + o);
					r.set(c, n, "element"), i.set(c, n, "element"), Rr(t);
				}
			} else {
				const s = t.isBackward(), l = s ? i : r, a = l.getNode(), u = s ? r : i, f = u.getNode();
				if (e.is(a)) {
					const t = l.offset;
					(n <= t && o > 0 || n < t && o < 0) && l.set(c, Math.max(0, t + o), "element");
				}
				if (e.is(f)) {
					const t = u.offset;
					(n <= t && o > 0 || n < t && o < 0) && u.set(c, Math.max(0, t + o), "element");
				}
			}
			Rr(t);
		}
		function Rr(t) {
			const e = t.anchor, n = e.offset, o = t.focus, r = o.offset, i = e.getNode(), s = o.getNode();
			if (t.isCollapsed()) {
				if (!Pi(i)) return;
				const t = i.getChildrenSize(), r = n >= t, s = r ? i.getChildAtIndex(t - 1) : i.getChildAtIndex(n);
				if (Xo(s)) {
					let t = 0;
					r && (t = s.getTextContentSize()), e.set(s.__key, t, "text"), o.set(s.__key, t, "text");
				}
				return;
			}
			if (Pi(i)) {
				const t = i.getChildrenSize(), o = n >= t, r = o ? i.getChildAtIndex(t - 1) : i.getChildAtIndex(n);
				if (Xo(r)) {
					let t = 0;
					o && (t = r.getTextContentSize()), e.set(r.__key, t, "text");
				}
			}
			if (Pi(s)) {
				const t = s.getChildrenSize(), e = r >= t, n = e ? s.getChildAtIndex(t - 1) : s.getChildAtIndex(r);
				if (Xo(n)) {
					let t = 0;
					e && (t = n.getTextContentSize()), o.set(n.__key, t, "text");
				}
			}
		}
		function Wr(t, e, n, o, r) {
			let i = null, s = 0, l = null;
			null !== o ? (i = o.__key, Xo(o) ? (s = o.getTextContentSize(), l = "text") : Pi(o) && (s = o.getChildrenSize(), l = "element")) : null !== r && (i = r.__key, Xo(r) ? l = "text" : Pi(r) && (l = "element")), null !== i && null !== l ? t.set(i, s, l) : (s = e.getIndexWithinParent(), -1 === s && (s = n.getChildrenSize()), t.set(n.__key, s, "element"));
		}
		function $r(t, e, n, o, r) {
			"text" === t.type ? t.set(n, t.offset + (e ? 0 : r), "text") : t.offset > o.getIndexWithinParent() && t.set(t.key, t.offset - 1, "element");
		}
		function Ur(t, e, n, o, r) {
			try {
				t.setBaseAndExtent(e, n, o, r);
			} catch (t) {}
		}
		function Hr(t, e, n) {
			const o = El(t, e.getKey());
			if (Pi(e)) {
				const r = kc(e, o, t);
				return [r.element, n + r.getFirstChildOffset()];
			}
			return [o, n];
		}
		function jr(t, e, n, o, r, s) {
			const l = s.getRootNode(), c = Bs(l) || ql(l) ? cc(l) : null;
			if (r.has("collaboration") && c !== s || null !== c && Os(c, c)) return;
			const a = nc(o, s);
			let u;
			if (!ur(e)) return void (null !== t && As(n, a.anchorNode, a.focusNode) && o.removeAllRanges());
			const f = e.anchor, d = e.focus, h = f.getNode(), g = d.getNode(), [_, p] = Hr(n, h, f.offset), [y, m] = Hr(n, g, d.offset), x = e.format, C = e.style, S = e.isCollapsed();
			let v = _, T = y, k = !1;
			if ("text" === f.type ? (v = Xo(h) ? wc(h, _, n) : null, k = h.getFormat() !== x || h.getStyle() !== C) : ur(t) && "text" === t.anchor.type && (k = !0), "text" === d.type && (T = Xo(g) ? wc(g, y, n) : null), null !== v && null !== T) {
				if (S && (null === t || k || ur(t) && (t.format !== x || t.style !== C)) && function(t, e, n, o, r, i) {
					t._inputState.collapsedSelectionFormat = {
						format: e,
						key: r,
						offset: o,
						style: n,
						timeStamp: i
					};
				}(n, x, C, p, f.key, performance.now()), ("Range" !== o.type || !S) && a.anchorOffset === p && a.focusOffset === m && a.anchorNode === v && a.focusNode === T) {
					if (null === c || !s.contains(c)) {
						const t = null !== c ? Fs(c) : null;
						null !== t && t !== n || r.has("skip-selection-focus") || s.focus({ preventScroll: !0 });
					}
					if ("element" !== f.type) return;
				}
				if (Ur(o, v, p, T, m), i && e.isCollapsed() && null !== s && !r.has("skip-selection-focus")) {
					const t = lc(s);
					if (null === t || !s.contains(t)) {
						const t = cc(s.ownerDocument), e = null !== t ? Fs(t) : null;
						null !== e && e !== n || s.focus({ preventScroll: !0 });
					}
				}
				if (!r.has("skip-scroll-into-view") && e.isCollapsed() && null !== s && s === lc(s)) {
					const t = ur(e) && "element" === e.anchor.type ? v.childNodes[p] || null : (void 0 === u && (u = ec(o, s)), u);
					if (null !== t) {
						let e;
						if (zs(t)) {
							const n = t.ownerDocument.createRange();
							n.selectNode(t), e = n.getBoundingClientRect();
						} else e = t.getBoundingClientRect();
						(function(t, e, n) {
							const o = Ol(n), r = Pl(o);
							if (null === o || null === r) return;
							const i = n.getBoundingClientRect();
							if (e.bottom < i.top) return;
							let { top: s, bottom: l } = e, c = 0, a = 0, u = n;
							for (; null !== u;) {
								const e = u === o.body;
								if (e) {
									const e = r.visualViewport;
									if (e) {
										const t = e.pageTop - r.scrollY;
										c = t, a = t + e.height;
									} else c = 0, a = Il(t).innerHeight;
									const n = r.getComputedStyle(o.documentElement), i = parseFloat(n.scrollPaddingTop), s = parseFloat(n.scrollPaddingBottom);
									isFinite(i) && (c += i), isFinite(s) && (a -= s);
								} else {
									const t = u === n ? i : u.getBoundingClientRect();
									c = t.top, a = t.bottom;
								}
								let f = 0;
								if (s < c ? f = -(c - s) : l > a && (f = l - a), 0 !== f) if (e) r.scrollBy(0, f);
								else {
									const t = u.scrollTop;
									u.scrollTop += f;
									const e = u.scrollTop - t;
									s -= e, l -= e;
								}
								if (e) break;
								u = wl(u);
							}
						})(n, e, s);
					}
				}
				(function(t) {
					t._inputState.isSelectionChangeFromDOMUpdate = !0;
				})(n);
			}
		}
		function Vr(t, e) {
			for (const n of t.split(/(\r?\n|\t)/)) "\n" === n || "\r\n" === n ? e.linebreak() : "	" === n ? e.tab() : "" !== n && e.text(n);
		}
		function qr(t) {
			const e = [];
			return Vr(t, {
				linebreak: () => e.push(qi()),
				tab: () => e.push(tr()),
				text: (t) => e.push(Go(t))
			}), e;
		}
		function Gr(t) {
			const e = [];
			for (const n of t) Yi(n) || (!Pi(n) && !Ki(n) || n.isInline() ? e.push(n) : Pi(n) && e.push(...Gr(n.getChildren())));
			return e;
		}
		function Xr(e) {
			let n = e;
			e.isCollapsed() || n.removeText();
			const o = Kr();
			ur(o) && (n = o), ur(n) || t(161);
			const r = n.anchor;
			let i = r.getNode(), s = r.offset;
			for (; !Sc(i) && null === ta(i);) {
				const t = i;
				if ([i, s] = Qr(i, s), t.is(i)) break;
			}
			return s;
		}
		function Qr(t, e) {
			const n = t.getParent();
			if (!n) {
				const t = es$1();
				return nl().append(t), t.select(), [nl(), 0];
			}
			if (Xo(t)) {
				const o = t.splitText(e);
				if (0 === o.length) return [n, t.getIndexWithinParent()];
				const r = 0 === e ? 0 : 1;
				return [n, o[0].getIndexWithinParent() + r];
			}
			if (!Pi(t) || 0 === e) return [n, t.getIndexWithinParent()];
			const o = t.getChildAtIndex(e);
			if (o) {
				const n = new fr$1(or(t.__key, e, "element"), or(t.__key, e, "element"), 0, ""), r = t.insertNewAfter(n);
				r && r.append(o, ...o.getNextSiblings());
			}
			return [n, t.getIndexWithinParent() + 1];
		}
		function Zr(t) {
			return Yi(t) || Ll(t) || Xo(t) || t.isParentRequired();
		}
		function ti(t) {
			const e = es$1();
			let n = null;
			for (let o = 0; o < t.length; o++) {
				const r = t[o];
				if (Zr(r)) {
					if (null === n) {
						n = r.createParentElementNode(), e.append(n);
						const i = t[o + 1];
						if (Yi(r) && (void 0 === i || !Zr(i))) continue;
					}
					n.append(r);
				} else e.append(r), n = null;
			}
			return e;
		}
		function ei(t, e, n, o, r = "decorators-and-blocks") {
			if ("move" === e && "character" === o && !t.isCollapsed()) {
				const [e, o] = n === t.isBackward() ? [t.focus, t.anchor] : [t.anchor, t.focus];
				return o.set(e.key, e.offset, e.type), !0;
			}
			const i = tu(t.focus, n ? "previous" : "next"), s = "lineboundary" === o, l = "move" === e;
			let c = i, a = "decorators-and-blocks" === r;
			if (!uu(c)) {
				for (const t of c) {
					a = !1;
					const { origin: e } = t;
					if (!Ki(e) || e.isIsolated() || (c = t, !s || !e.isInline())) break;
				}
				if (a) for (const t of ja$1(i).iterNodeCarets("extend" === e ? "shadowRoot" : "root")) {
					if (Aa(t)) t.origin.isInline() || (c = t);
					else {
						if (Pi(t.origin)) continue;
						Ki(t.origin) && !t.origin.isInline() && (c = t);
					}
					break;
				}
			}
			if (c === i) return !1;
			if (l && !s && Ki(c.origin) && c.origin.isKeyboardSelectable()) {
				const t = Pr();
				return t.add(c.origin.getKey()), ol(t), !0;
			}
			return c = au(c), l && eu(t.anchor, c), eu(t.focus, c), a || !s;
		}
		let ni = null, oi = null, ri = !1, ii = !1, si = !1;
		const li = /* @__PURE__ */ new Set();
		let ci = 0;
		const ai = {
			characterData: !0,
			childList: !0,
			subtree: !0
		};
		function ui() {
			return ri || null !== ni && ni._readOnly;
		}
		function fi() {
			ri && t(13);
		}
		function di() {
			ci > 99 && t(14);
		}
		function hi() {
			return null === ni && t(195, yi()), ni;
		}
		function gi(t) {
			null !== hi() && null === oi && (oi = t), oi !== t && e(378);
		}
		function _i() {
			return null === oi && t(337, yi()), oi;
		}
		function pi() {
			_i()._dirtyType = 2;
		}
		function yi() {
			let t = 0;
			const e = /* @__PURE__ */ new Set(), n = Cs.version;
			if ("undefined" != typeof window) for (const o of Xl(document)) {
				const r = Ps(o);
				if (Ds(r)) t++;
				else if (r) {
					let t = String(r.constructor.version || "<0.17.1");
					t === n && (t += " (separately built, likely a bundler configuration issue)"), e.add(t);
				}
			}
			let o = ` Detected on the page: ${t} compatible editor(s) with version ${n}`;
			return e.size && (o += ` and incompatible editors with versions ${Array.from(e).join(", ")}`), o;
		}
		function mi() {
			return oi;
		}
		function xi(t, e, n) {
			const o = e.__type, r = Ns(t, o);
			let i = n.get(o);
			void 0 === i && (i = Array.from(r.transforms), n.set(o, i));
			const s = i.length;
			for (let t = 0; t < s && (i[t](e), e.isAttached()); t++);
		}
		function Ci(t, e) {
			return void 0 !== t && t.__key !== e && t.isAttached();
		}
		function Si(t, e) {
			if (!e) return;
			const n = t._updateTags;
			let o = e;
			Array.isArray(e) || (o = [e]);
			for (const t of o) n.add(t);
		}
		function Ti(e, n) {
			const o = e.type, r = n.get(o);
			void 0 === r && t(17, o);
			const i = r.klass;
			e.type !== i.getType() && t(18, i.name);
			const s = i.importJSON(e), l = e.children;
			if (Pi(s) && Array.isArray(l)) for (let t = 0; t < l.length; t++) {
				const e = Ti(l[t], n);
				s.append(e);
			}
			const c = e.$slots;
			if (c) {
				Qc(s) || t(379, i.name);
				for (const t in c) pa(s, t, Ti(c[t], n));
			}
			return s;
		}
		function ki(t, e, n) {
			const o = ni, r = ri, i = oi;
			ni = e, ri = !0, oi = t;
			try {
				return n();
			} finally {
				ni = o, ri = r, oi = i;
			}
		}
		function bi(t, e) {
			const n = si;
			si = !0;
			try {
				(function(t, e) {
					const n = t._pendingEditorState, o = t._rootElement, r = t._headless || null === o;
					if (null === n) return void (!t._updating && t._deferred.length > 0 && wi(t, t._deferred));
					const i = t._editorState, s = i._selection, l = n._selection, c = 0 !== t._dirtyType, a = ni, u = ri, f = oi, d = t._updating, h = t._observer;
					let g = null;
					if (t._pendingEditorState = null, t._editorState = n, !r && c && null !== h) {
						oi = t, ni = n, ri = !1, t._updating = !0;
						try {
							const e = t._dirtyType, o = t._dirtyElements, r = t._dirtyLeaves;
							h.disconnect(), g = De$2(i, n, t, e, o, r);
						} catch (e) {
							if (e instanceof Error && t._onError(e), ii) throw e;
							gs(t, null, o, n), gt$1(t), t._dirtyType = 2, ii = !0, bi(t, i), ii = !1;
							return;
						} finally {
							h.observe(o, ai), t._updating = d, ni = a, ri = u, oi = f;
						}
					}
					n._readOnly || (n._readOnly = !0);
					const _ = t._dirtyLeaves, p = t._dirtyElements, y = t._normalizedNodes, m = t._updateTags;
					c && (t._dirtyType = 0, t._cloneNotNeeded.clear(), t._dirtyLeaves = /* @__PURE__ */ new Set(), t._dirtyElements = /* @__PURE__ */ new Map(), t._normalizedNodes = /* @__PURE__ */ new Set());
					t._updateTags = /* @__PURE__ */ new Set(), function(t, e) {
						const n = t._decorators;
						let o = t._pendingDecorators || n;
						const r = e._nodeMap;
						let i;
						for (i in o) r.has(i) || (o === n && (o = tl(t)), delete o[i]);
					}(t, n);
					const x = r ? null : Jl(Il(t));
					if (t._editable && null !== x && (c || null === l || l.dirty || !l.is(s)) && null !== o && !m.has("skip-dom-selection")) {
						oi = t, ni = n;
						try {
							if (null !== h && h.disconnect(), c || null === l || l.dirty) {
								const e = t._blockCursorElement;
								null !== e && jl(e, t, o), jr(s, l, t, x, m, o);
							}
							(function(t, e, n) {
								let o = t._blockCursorElement;
								if (ur(n) && n.isCollapsed() && "element" === n.anchor.type && e.contains(lc(e))) {
									const r = n.anchor, i = r.getNode(), s = r.offset;
									let l = !1, c = null;
									if (s === i.getChildrenSize()) Hl(i.getChildAtIndex(s - 1)) && (l = !0);
									else {
										const e = i.getChildAtIndex(s);
										if (null !== e && Hl(e)) {
											const n = e.getPreviousSibling();
											(null === n || Hl(n)) && (l = !0, c = t.getElementByKey(e.__key));
										}
									}
									if (l) {
										const n = kc(i, t.getElementByKey(i.__key), t).element;
										null === o && (t._blockCursorElement = o = function(t) {
											const e = t.theme, n = Zl().createElement("div");
											n.contentEditable = "false", n.setAttribute("data-lexical-cursor", "true");
											let o = e.blockCursor;
											if (void 0 !== o) {
												if ("string" == typeof o) o = e.blockCursor = ku(o);
												void 0 !== o && n.classList.add(...o);
											}
											return n;
										}(t._config)), e.style.caretColor = "transparent", null === c ? n.appendChild(o) : n.insertBefore(o, c);
										return;
									}
								}
								null !== o && jl(o, t, e);
							})(t, o, l);
						} finally {
							null !== h && h.observe(o, ai), oi = f, ni = a;
						}
					}
					null !== g && function(t, e, n, o, r) {
						const i = Array.from(t._listeners.mutation), s = i.length;
						for (let t = 0; t < s; t++) {
							const [s, l] = i[t];
							for (const t of l) {
								const i = e.get(t);
								void 0 !== i && s(i, {
									dirtyLeaves: o,
									prevEditorState: r,
									updateTags: n
								});
							}
						}
					}(t, g, m, _, i);
					ur(l) || null === l || null !== s && s.is(l) || t.dispatchCommand(Ie$2);
					const C = t._pendingDecorators;
					null !== C && (t._decorators = C, t._pendingDecorators = null, Ni("decorator", t, !0, C));
					if (function(t, e, n) {
						const o = el(e), r = el(n);
						o !== r && Ni("textcontent", t, !0, r);
					}(t, e || i, n), Ni("update", t, !0, {
						dirtyElements: p,
						dirtyLeaves: _,
						editorState: n,
						mutatedNodes: g,
						normalizedNodes: y,
						prevEditorState: e || i,
						tags: m
					}), !d) wi(t, t._deferred);
					(function(t) {
						const e = t._updates;
						if (0 === e.length) return void (t._cascadeCount = 0);
						if (function(t) {
							if (li.has(t)) return;
							li.add(t), setTimeout(() => {
								li.delete(t), t._cascadeCount = 0;
							}, 0);
						}(t), t._cascadeCount++ > 99) return t._updates = [], t._cascadeCount = 0, void t._onWarn(/* @__PURE__ */ new Error(`One or more update listeners are endlessly enqueueing more updates. May have encountered infinite recursion caused by update listeners that trigger additional updates without a stop condition. Editor namespace: ${t._config.namespace}`));
						const n = e.shift();
						if (n) {
							const [e, o] = n;
							Mi(t, e, o);
						}
					})(t);
				})(t, e);
			} finally {
				si = n;
			}
		}
		function Ni(t, e, n, ...o) {
			const r = e._updating;
			e._updating = n;
			try {
				const n = e._listeners[t], r = Array.from(n);
				for (const [t, e] of r) {
					e && e();
					const r = t(...o);
					n.has(t) ? n.set(t, r) : r && r();
				}
			} finally {
				e._updating = r;
			}
		}
		function Ei(t, e, n, o) {
			const r = ll(t);
			let i;
			if (!si) for (let t = 0; t < r.length; t++) r[t]._updating || (r[t]._cascadeCount = 0);
			for (let t = 4; t >= 0; t--) for (let s = 0; s < r.length; s++) {
				const l = r[s];
				if (s > 0 && l._updating) {
					i = l;
					break;
				}
				const c = l._commands.get(e);
				if (void 0 !== c) {
					const e = c[t];
					if (e.size > 0) {
						let t = !1;
						if (Ai(l, () => {
							for (const r of e) if (r(n, o)) return void (t = !0);
						}), t) return t;
					}
				}
			}
			return i && i.update(() => {
				Ei(i, e, n, o);
			}), !1;
		}
		function wi(t, e) {
			if (t._deferred = [], 0 !== e.length) {
				const n = t._updating;
				t._updating = !0;
				try {
					for (let t = 0; t < e.length; t++) e[t]();
				} finally {
					t._updating = n;
				}
			}
		}
		function Oi(e, n) {
			const o = e._updates;
			let r = n || !1;
			for (; 0 !== o.length;) {
				const n = o.shift();
				if (n) {
					const [o, i] = n, s = e._pendingEditorState;
					let l;
					void 0 !== i && (l = i.onUpdate, i.skipTransforms && (r = !0), i.discrete && (null === s && t(191), s._flushSync = !0), l && e._deferred.push(l), Si(e, i.tag)), null == s ? Mi(e, o, i) : o();
				}
			}
			return r;
		}
		function Mi(e, n, o) {
			const r = e._updateTags;
			let i, s = !1, l = !1;
			void 0 !== o && (i = o.onUpdate, Si(e, o.tag), s = o.skipTransforms || !1, l = o.discrete || !1), i && e._deferred.push(i);
			const c = e._editorState;
			let a = e._pendingEditorState, u = !1;
			(null === a || a._readOnly) && (a = e._pendingEditorState = Ri(a || c), u = !0), a._flushSync = l;
			const f = ni, d = ri, h = oi, g = e._updating;
			ni = a, ri = !1, e._updating = !0, oi = e;
			const _ = e._headless || null === e.getRootElement();
			vs(null);
			try {
				u && (_ ? null !== c._selection && (a._selection = c._selection.clone()) : a._selection = function(t, e) {
					const n = t.getEditorState()._selection, o = Jl(Il(t));
					return ur(n) || null == n ? Lr(n, o, t, e) : n.clone();
				}(e, o && o.event || null));
				const r = e._compositionKey;
				n(), s = Oi(e, s), function(t, e) {
					const n = e.getEditorState()._selection, o = t._selection;
					if (ur(o)) {
						const t = o.anchor, e = o.focus;
						let r;
						if ("text" === t.type && (r = t.getNode(), r.selectionTransform(n, o)), "text" === e.type) {
							const t = e.getNode();
							r !== t && t.selectionTransform(n, o);
						}
					}
				}(a, e), 0 !== e._dirtyType && (s ? function(t, e) {
					const n = e._dirtyLeaves, o = t._nodeMap;
					for (const t of n) {
						const e = o.get(t);
						Xo(e) && e.isAttached() && e.isSimpleText() && !e.isUnmergeable() && Pt$1(e);
					}
				}(a, e) : function(t, e) {
					const n = e._dirtyLeaves, o = e._dirtyElements, r = t._nodeMap, i = qs(), s = /* @__PURE__ */ new Map();
					let l = n, c = l.size, a = o, u = a.size;
					for (; c > 0 || u > 0;) {
						if (c > 0) {
							e._dirtyLeaves = /* @__PURE__ */ new Set();
							for (const t of l) {
								const o = r.get(t);
								Xo(o) && o.isAttached() && o.isSimpleText() && !o.isUnmergeable() && Pt$1(o), void 0 !== o && Ci(o, i) && xi(e, o, s), n.add(t);
							}
							if (l = e._dirtyLeaves, c = l.size, c > 0) {
								ci++;
								continue;
							}
						}
						e._dirtyLeaves = /* @__PURE__ */ new Set(), e._dirtyElements = /* @__PURE__ */ new Map(), a.delete("root") && a.set("root", !0);
						for (const t of a) {
							const n = t[0], l = t[1];
							if (o.set(n, l), !l) continue;
							const c = r.get(n);
							void 0 !== c && Ci(c, i) && xi(e, c, s);
						}
						l = e._dirtyLeaves, c = l.size, a = e._dirtyElements, u = a.size, ci++;
					}
					e._dirtyLeaves = n, e._dirtyElements = o;
				}(a, e), Oi(e), function(t, e, n, o) {
					const r = t._nodeMap, i = e._nodeMap, s = [];
					for (const [t] of o) {
						const e = i.get(t);
						void 0 !== e && (e.isAttached() || (Pi(e) && rt$1(e, t, r, i, s, o), r.has(t) || o.delete(t), s.push(t)));
					}
					for (const t of n) {
						const e = i.get(t);
						void 0 === e || e.isAttached() || (Qc(e) && null !== e.__slots && rt$1(e, t, r, i, s, n), r.has(t) || n.delete(t), s.push(t));
					}
					for (const t of s) i.delete(t);
					const l = _i(), c = l._compositionKey;
					null === c || i.has(c) || (l._compositionKey = null);
				}(c, a, e._dirtyLeaves, e._dirtyElements));
				r !== e._compositionKey && (a._flushSync = !0);
				const i = a._selection;
				if (ur(i)) {
					e._slotsUsed && Or(i);
					const n = a._nodeMap, o = i.anchor.key, r = i.focus.key;
					void 0 !== n.get(o) && void 0 !== n.get(r) || t(19);
				} else dr(i) && 0 === i._nodes.size && (a._selection = null);
			} catch (t) {
				t instanceof Error && e._onError(t), e._pendingEditorState = c, e._dirtyType = 2, e._cloneNotNeeded.clear(), e._dirtyLeaves = /* @__PURE__ */ new Set(), e._dirtyElements.clear(), bi(e);
				return;
			} finally {
				ni = f, ri = d, oi = h, e._updating = g, ci = 0;
			}
			0 !== e._dirtyType || e._deferred.length > 0 || function(t, e) {
				const n = e.getEditorState()._selection, o = t._selection;
				if (null !== o) {
					if (o.dirty || !o.is(n)) return !0;
				} else if (null !== n) return !0;
				return !1;
			}(a, e) ? a._flushSync ? (a._flushSync = !1, bi(e)) : u && ws(() => {
				bi(e);
			}) : (a._flushSync = !1, u && (r.clear(), e._deferred = [], e._pendingEditorState = null));
		}
		function Ai(t, e, n) {
			oi === t && void 0 === n ? ui() ? Mi(t, e, n) : e() : Mi(t, e, n);
		}
		function Di(t) {
			if (Bl(t)) {
				let e = null;
				for (const n of t.getChildren()) e = n.isInline() ? (e || n.replace(n.createParentElementNode())).append(n) : null;
			}
		}
		var Fi = class extends _o {
			__first;
			__last;
			__size;
			__format;
			__style;
			__indent;
			__dir;
			__textFormat;
			__textStyle;
			__slotHost;
			__slots;
			$config() {
				return this.config(Symbol.for("ElementNode"), {
					$transform: Di,
					extends: _o
				});
			}
			constructor(t) {
				super(t), this.__first = null, this.__last = null, this.__size = 0, this.__format = 0, this.__style = "", this.__indent = 0, this.__dir = null, this.__textFormat = 0, this.__textStyle = "", this.__slotHost = null, this.__slots = null;
			}
			afterCloneFrom(e) {
				super.afterCloneFrom(e), this.__key === e.__key && (this.__first = e.__first, this.__last = e.__last, this.__size = e.__size, this.__slotHost = e.__slotHost, null !== this.__slotHost && null !== this.__parent && t(384, this.__key, String(this.__slotHost), String(this.__parent)), this.__slots = e.__slots), this.__indent = e.__indent, this.__format = e.__format, this.__style = e.__style, this.__dir = e.__dir, this.__textFormat = e.__textFormat, this.__textStyle = e.__textStyle;
			}
			getFormat() {
				return this.getLatest().__format;
			}
			getFormatType() {
				return W[this.getFormat()] || "";
			}
			getStyle() {
				return this.getLatest().__style;
			}
			getIndent() {
				return this.getLatest().__indent;
			}
			getChildren() {
				const t = [];
				let e = this.getFirstChild();
				for (; null !== e;) t.push(e), e = e.getNextSibling();
				return t;
			}
			getChildrenKeys() {
				const t = [];
				let e = this.getFirstChild();
				for (; null !== e;) t.push(e.__key), e = e.getNextSibling();
				return t;
			}
			getChildrenSize() {
				return this.getLatest().__size;
			}
			isEmpty() {
				return 0 === this.getChildrenSize() && 0 === ia(this).length;
			}
			isDirty() {
				const t = _i()._dirtyElements;
				return null !== t && t.has(this.__key);
			}
			isLastChild() {
				const t = this.getLatest(), e = this.getParentOrThrow().getLastChild();
				return null !== e && e.is(t);
			}
			getAllTextNodes() {
				const t = [];
				for (const e of ia(this)) {
					const n = sa(this, e);
					Pi(n) && t.push(...n.getAllTextNodes());
				}
				let e = this.getFirstChild();
				for (; null !== e;) {
					if (Xo(e) && t.push(e), Pi(e)) {
						const n = e.getAllTextNodes();
						t.push(...n);
					}
					e = e.getNextSibling();
				}
				return t;
			}
			getFirstDescendant() {
				let t = this.getFirstChild();
				for (; Pi(t);) {
					const e = t.getFirstChild();
					if (null === e) break;
					t = e;
				}
				return t;
			}
			getLastDescendant() {
				let t = this.getLastChild();
				for (; Pi(t);) {
					const e = t.getLastChild();
					if (null === e) break;
					t = e;
				}
				return t;
			}
			getDescendantByIndex(t) {
				const e = this.getChildren(), n = e.length;
				if (t >= n) {
					const t = e[n - 1];
					return Pi(t) && t.getLastDescendant() || t || null;
				}
				const o = e[t];
				return Pi(o) && o.getFirstDescendant() || o || null;
			}
			getFirstChild() {
				const t = this.getLatest().__first;
				return null === t ? null : Ys(t);
			}
			getFirstChildOrThrow() {
				const e = this.getFirstChild();
				return null === e && t(45, this.__key), e;
			}
			getLastChild() {
				const t = this.getLatest().__last;
				return null === t ? null : Ys(t);
			}
			getLastChildOrThrow() {
				const e = this.getLastChild();
				return null === e && t(96, this.__key), e;
			}
			getChildAtIndex(t) {
				const e = this.getChildrenSize();
				let n, o;
				if (t < e / 2) {
					for (n = this.getFirstChild(), o = 0; null !== n && o <= t;) {
						if (o === t) return n;
						n = n.getNextSibling(), o++;
					}
					return null;
				}
				for (n = this.getLastChild(), o = e - 1; null !== n && o >= t;) {
					if (o === t) return n;
					n = n.getPreviousSibling(), o--;
				}
				return null;
			}
			getTextContent() {
				let t = ha(this);
				const e = this.getChildren(), n = e.length;
				for (let o = 0; o < n; o++) {
					const r = e[o];
					t += r.getTextContent(), Pi(r) && o !== n - 1 && !r.isInline() && (t += D$1);
				}
				return t;
			}
			getTextContentSize() {
				let t = function(t) {
					let e = 0;
					for (const n of ia(t)) {
						const o = sa(t, n);
						null !== o && (e += o.getTextContentSize());
					}
					return e;
				}(this);
				const e = this.getChildren(), n = e.length;
				for (let o = 0; o < n; o++) {
					const r = e[o];
					t += r.getTextContentSize(), Pi(r) && o !== n - 1 && !r.isInline() && (t += 2);
				}
				return t;
			}
			getDirection() {
				return this.getLatest().__dir;
			}
			getTextFormat() {
				return this.getLatest().__textFormat;
			}
			hasFormat(t) {
				if ("" !== t) {
					const e = R$1[t];
					return 0 !== (this.getFormat() & e);
				}
				return !1;
			}
			hasTextFormat(t) {
				const e = z$1[t];
				return 0 !== (this.getTextFormat() & e);
			}
			getFormatFlags(t, e) {
				return Ws(this.getLatest().__textFormat, t, e);
			}
			getTextStyle() {
				return this.getLatest().__textStyle;
			}
			select(t, e) {
				fi();
				const n = Kr();
				let o = t, r = e;
				const i = this.getChildrenSize();
				if (!this.canBeEmpty()) {
					if (0 === t && 0 === e) {
						const t = this.getFirstChild();
						if (Xo(t) || Pi(t)) return t.select(0, 0);
					} else if (!(void 0 !== t && t !== i || void 0 !== e && e !== i)) {
						const t = this.getLastChild();
						if (Xo(t) || Pi(t)) return t.select();
					}
				}
				void 0 === o && (o = i), void 0 === r && (r = i);
				const s = this.__key;
				return ur(n) ? (n.anchor.set(s, o, "element"), n.focus.set(s, r, "element"), n.dirty = !0, n) : Dr(s, o, s, r, "element", "element");
			}
			selectStart() {
				const t = this.getFirstDescendant();
				return t ? t.selectStart() : this.select();
			}
			selectEnd() {
				const t = this.getLastDescendant();
				return t ? t.selectEnd() : this.select();
			}
			clear() {
				const t = this.getWritable();
				return this.getChildren().forEach((t) => t.remove()), t;
			}
			append(...t) {
				return this.splice(this.getChildrenSize(), 0, t);
			}
			setDirection(t) {
				const e = this.getWritable();
				return e.__dir = t, e;
			}
			setFormat(t) {
				return this.getWritable().__format = "" !== t && R$1[t] || 0, this;
			}
			setStyle(t) {
				return this.getWritable().__style = t || "", this;
			}
			setTextFormat(t) {
				const e = this.getWritable();
				return e.__textFormat = t, e;
			}
			setTextStyle(t) {
				const e = this.getWritable();
				return e.__textStyle = t, e;
			}
			setIndent(t) {
				return this.getWritable().__indent = t, this;
			}
			splice(e, n, o) {
				ho(this) && t(324, this.__key, this.__type);
				const r = this.getChildrenSize(), i = this.getWritable();
				e + n <= r || t(226, String(e), String(n), String(r));
				for (const t of o);
				const s = i.__key, l = [], c = [], a = this.getChildAtIndex(e + n);
				let u = null, f = r - n + o.length;
				if (0 !== e) if (e === r) u = this.getLastChild();
				else {
					const t = this.getChildAtIndex(e);
					null !== t && (u = t.getPreviousSibling());
				}
				if (n > 0) {
					let e = null === u ? this.getFirstChild() : u.getNextSibling();
					for (let o = 0; o < n; o++) {
						null === e && t(100);
						const n = e.getNextSibling(), o = e.__key;
						Hs(e.getWritable()), c.push(o), e = n;
					}
				}
				let d = u;
				for (const e of o) {
					null !== d && e.is(d) && (u = d = d.getPreviousSibling());
					const n = e.getWritable();
					n.__parent === s && f--, Hs(n);
					const o = e.__key;
					if (null === d) i.__first = o, n.__prev = null;
					else {
						const t = d.getWritable();
						t.__next = o, n.__prev = t.__key;
					}
					e.__key === s && t(76), n.__parent = s, l.push(o), d = e;
				}
				if (e + n === r) {
					if (null !== d) d.getWritable().__next = null, i.__last = d.__key;
				} else if (null !== a) {
					const t = a.getWritable();
					if (null !== d) {
						const e = d.getWritable();
						t.__prev = d.__key, e.__next = a.__key;
					} else t.__prev = null;
				}
				if (i.__size = f, c.length) {
					const t = Kr();
					if (ur(t)) {
						const e = new Set(c), n = new Set(l), { anchor: o, focus: r } = t;
						Ii(o, e, n) && Wr(o, o.getNode(), this, u, a), Ii(r, e, n) && Wr(r, r.getNode(), this, u, a), 0 !== f || this.canBeEmpty() || Bl(this) || this.remove();
					}
				}
				return i;
			}
			getDOMSlot(t) {
				return new G(t);
			}
			exportDOM(t) {
				const { element: e } = super.exportDOM(t);
				if (gc(e)) {
					const t = this.getIndent();
					t > 0 && (e.style.paddingInlineStart = 40 * t + "px", e.setAttribute("data-lexical-indent", String(t)));
					const n = this.getDirection();
					n && (e.dir = n);
				}
				return { element: e };
			}
			exportJSON() {
				const t = {
					children: [],
					direction: this.getDirection(),
					format: this.getFormatType(),
					indent: this.getIndent(),
					...super.exportJSON()
				}, e = this.getTextFormat(), n = this.getTextStyle();
				return 0 === e && "" === n || Bl(this) || this.getChildren().some(Xo) || (0 !== e && (t.textFormat = e), "" !== n && (t.textStyle = n)), t;
			}
			updateFromJSON(t) {
				return super.updateFromJSON(t).setFormat(t.format).setIndent(t.indent).setDirection(t.direction).setTextFormat(t.textFormat || 0).setTextStyle(t.textStyle || "");
			}
			insertNewAfter(t, e) {
				return null;
			}
			canIndent() {
				return !0;
			}
			collapseAtStart(t) {
				return !1;
			}
			excludeFromCopy(t) {
				return !1;
			}
			canReplaceWith(t) {
				return !0;
			}
			canInsertAfter(t) {
				return !0;
			}
			canBeEmpty() {
				return !0;
			}
			canInsertTextBefore() {
				return !0;
			}
			canInsertTextAfter() {
				return !0;
			}
			isInline() {
				return !1;
			}
			isShadowRoot() {
				return !1;
			}
			canMergeWith(t) {
				return !1;
			}
			extractWithChild(t, e, n) {
				return !1;
			}
			canMergeWhenEmpty() {
				return !1;
			}
			reconcileObservedMutation(t, e) {
				const n = kc(this, t, e);
				let o = n.getFirstChild();
				for (let t = this.getFirstChild(); t; t = t.getNextSibling()) {
					const r = e.getElementByKey(t.getKey());
					null !== r && (null == o ? (n.insertChild(r), o = r) : o !== r && n.replaceChild(r, o), o = o.nextSibling);
				}
			}
		};
		function Pi(t) {
			return t instanceof Fi;
		}
		function Ii(t, e, n) {
			let o = t.getNode();
			for (; o;) {
				const t = o.__key;
				if (e.has(t) && !n.has(t)) return !0;
				o = o.getParent();
			}
			return !1;
		}
		var Li = class extends _o {
			__slotHost;
			__slots;
			constructor(t) {
				super(t), this.__slotHost = null, this.__slots = null;
			}
			afterCloneFrom(e) {
				super.afterCloneFrom(e), this.__key === e.__key && (this.__slotHost = e.__slotHost, null !== this.__slotHost && null !== this.__parent && t(383, this.__key, String(this.__slotHost), String(this.__parent)), this.__slots = e.__slots);
			}
			decorate(t, e) {
				return null;
			}
			isIsolated() {
				return !1;
			}
			isInline() {
				return !0;
			}
			isKeyboardSelectable() {
				return !0;
			}
		};
		function Ki(t) {
			return t instanceof Li;
		}
		var zi = class extends Fi {
			__cachedText;
			$config() {
				return this.config("root", { extends: Fi });
			}
			constructor() {
				super("root"), this.__cachedText = null;
			}
			getTopLevelElementOrThrow() {
				t(51);
			}
			getTextContent() {
				const t = this.__cachedText;
				return null === t || !ui() && 0 !== _i()._dirtyType ? super.getTextContent() : t;
			}
			remove() {
				t(52);
			}
			replace(e) {
				t(53);
			}
			insertBefore(e) {
				t(54);
			}
			insertAfter(e) {
				t(55);
			}
			updateDOM(t, e) {
				return !1;
			}
			splice(e, n, o) {
				for (const e of o) Pi(e) || Ki(e) || t(282);
				return super.splice(e, n, o);
			}
			static importJSON(t) {
				return nl().updateFromJSON(t);
			}
			collapseAtStart() {
				return !0;
			}
		};
		function Bi(t) {
			return t instanceof zi;
		}
		function Ri(t) {
			return new Hi(nt$2(t._nodeMap), null, t._slotsUsed);
		}
		function Wi() {
			return new Hi(new Map([["root", new zi()]]), null, !1);
		}
		function $i(e) {
			const n = e.exportJSON(), o = e.constructor;
			if (n.type !== o.getType() && t(130, o.name), Pi(e)) {
				const r = n.children;
				Array.isArray(r) || t(59, o.name);
				const i = e.getChildren();
				for (let t = 0; t < i.length; t++) {
					const e = $i(i[t]);
					r.push(e);
				}
			}
			const r = ia(e);
			if (r.length > 0) {
				const i = {};
				for (const n of r) {
					const r = sa(e, n);
					null === r && t(366, o.name, n), i[n] = $i(r);
				}
				n.$slots = i;
			}
			return n;
		}
		function Ui(t) {
			return t instanceof Hi;
		}
		var Hi = class Hi {
			_nodeMap;
			_selection;
			_flushSync;
			_readOnly;
			_parsed;
			_slotsUsed;
			constructor(t, e = null, n = !1) {
				this._nodeMap = t, this._selection = e || null, this._flushSync = !1, this._readOnly = !1, this._parsed = !1, this._slotsUsed = n;
			}
			isEmpty() {
				return 1 === this._nodeMap.size && null === this._selection;
			}
			read(t, e) {
				return ki(e && e.editor || null, this, t);
			}
			clone(t) {
				const e = new Hi(this._nodeMap, void 0 === t ? this._selection : t, this._slotsUsed);
				return e._readOnly = !0, e;
			}
			toJSON() {
				return ki(null, this, () => ({ root: $i(nl()) }));
			}
		};
		var ji = class extends Fi {
			$config() {
				return this.config("artificial", { extends: Fi });
			}
			createDOM(t) {
				return Zl().createElement("div");
			}
		};
		var Ji = class extends _o {
			$config() {
				return this.config("linebreak", { importDOM: { br: (t) => Gi(t) || Xi(t) ? null : {
					conversion: Vi,
					priority: 0
				} } });
			}
			getTextContent() {
				return "\n";
			}
			createDOM() {
				return Zl().createElement("br");
			}
			updateDOM() {
				return !1;
			}
			isInline() {
				return !0;
			}
		};
		function Vi(t) {
			return { node: qi() };
		}
		function qi() {
			return Wl(new Ji());
		}
		function Yi(t) {
			return t instanceof Ji;
		}
		function Gi(t) {
			const e = t.parentElement;
			if (null !== e && Cc(e)) {
				const n = e.firstChild;
				if (n === t || n.nextSibling === t && Qi(n)) {
					const n = e.lastChild;
					if (n === t || n.previousSibling === t && Qi(n)) return !0;
				}
			}
			return !1;
		}
		function Xi(t) {
			const e = t.parentElement;
			if (null !== e && Cc(e)) {
				const n = e.firstChild;
				if (n === t || n.nextSibling === t && Qi(n)) return !1;
				const o = e.lastChild;
				if (o === t || o.previousSibling === t && Qi(o)) return !0;
			}
			return !1;
		}
		function Qi(t) {
			return zs(t) && /^( |\t|\r?\n)+$/.test(t.textContent || "");
		}
		var Zi = class extends Fi {
			$config() {
				return this.config("paragraph", {
					extends: Fi,
					importDOM: { p: () => ({
						conversion: ts,
						priority: 0
					}) }
				});
			}
			createDOM(t) {
				const e = Zl().createElement("p"), n = Cl(t.theme, "paragraph");
				if (void 0 !== n) e.classList.add(...n);
				return e;
			}
			updateDOM(t, e, n) {
				return !1;
			}
			exportDOM(t) {
				const { element: e } = super.exportDOM(t);
				if (gc(e)) {
					this.isEmpty() && e.append(Zl().createElement("br"));
					const t = this.getFormatType();
					t && (e.style.textAlign = t);
				}
				return { element: e };
			}
			exportJSON() {
				const t = super.exportJSON();
				if (void 0 === t.textFormat || void 0 === t.textStyle) {
					const e = this.getChildren().find(Xo);
					e ? (t.textFormat = e.getFormat(), t.textStyle = e.getStyle()) : (t.textFormat = this.getTextFormat(), t.textStyle = this.getTextStyle());
				}
				return t;
			}
			insertNewAfter(t, e) {
				const n = es$1();
				n.setTextFormat(t.format), n.setTextStyle(t.style);
				const o = this.getDirection();
				return n.setDirection(o), n.setFormat(this.getFormatType()), n.setStyle(this.getStyle()), this.insertAfter(n, e), n;
			}
			collapseAtStart() {
				const t = this.getChildren();
				if (0 === t.length || Xo(t[0]) && "" === t[0].getTextContent().trim()) {
					if (null !== this.getNextSibling()) return this.selectNext(), this.remove(), !0;
					if (null !== this.getPreviousSibling()) return this.selectPrevious(), this.remove(), !0;
				}
				return !1;
			}
		};
		function ts(t) {
			const e = es$1();
			if (Lc(e, t), Pc(t, e), "" === e.getFormatType()) {
				const n = t.getAttribute("align");
				n && n && n in R$1 && e.setFormat(n);
			}
			return Ic(e, t), { node: e };
		}
		function es$1() {
			return Wl(new Zi());
		}
		function ns(t) {
			return t instanceof Zi;
		}
		function os(t) {
			console.warn(t);
		}
		function gs(t, e, n, o, r) {
			const i = t._keyToDOMMap;
			i.clear(), t._editorState = Wi(), t._pendingEditorState = o, t._compositionKey = null, t._dirtyType = 0, t._cloneNotNeeded.clear(), t._dirtyLeaves = /* @__PURE__ */ new Set(), t._dirtyElements.clear(), t._normalizedNodes = /* @__PURE__ */ new Set(), r && r.preserveUpdateQueue || (t._updateTags = /* @__PURE__ */ new Set(), t._updates = [], t._cascadeCount = 0), t._blockCursorElement = null, null !== t._inputState.handledSelectionCommandTimeoutId && clearTimeout(t._inputState.handledSelectionCommandTimeoutId), t._inputState = {
				collapsedSelectionFormat: {
					format: 0,
					key: "root",
					offset: 0,
					style: "",
					timeStamp: 0
				},
				compositionEndData: "",
				compositionPhase: "idle",
				hadOrphanedCompositionEvents: !1,
				handledSelectionCommandTimeoutId: null,
				isInsertLineBreak: !1,
				isInsertTextAfterHandledSelectionCommand: !1,
				isSelectionChangeFromDOMUpdate: !1,
				isSelectionChangeFromMouseDown: !1,
				lastBeforeInputInsertTextTimeStamp: 0,
				lastKeyCode: null,
				lastKeyDownTimeStamp: 0,
				postDeleteSelectionToRestore: null,
				unprocessedBeforeInputData: null
			};
			const s = t._observer;
			null !== s && (s.disconnect(), t._observer = null), null !== e && (e.textContent = "", function(t, e) {
				const n = `__lexicalKey_${e._key}`;
				delete t[n];
			}(e, t)), null !== n && (n.textContent = "", i.set("root", n), Xs(n, t, "root"));
		}
		function _s(t) {
			const e = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
			for (const { klass: o, ownNodeConfig: r } of jc(t)) {
				const t = o.transform;
				if (!n.has(t)) {
					n.add(t);
					const r = o.transform();
					r && e.add(r);
				}
				if (r) {
					const t = r.$transform;
					t && e.add(t);
				}
			}
			return e;
		}
		const ps = {
			$createDOM: (t, e) => t.createDOM(e._config, e),
			$decorateDOM: (t, e, n, o) => {},
			$exportDOM: (t, e) => {
				const n = Es(e, t.getType());
				return n && void 0 !== n.exportDOM ? n.exportDOM(e, t) : t.exportDOM(e);
			},
			$extractWithChild: (t, e, n, o, r) => Pi(t) && t.extractWithChild(e, n, o),
			$getDOMSlot: (t, e, n) => t.getDOMSlot(e),
			$getSlotTargetElement: (t, e, n, o) => null,
			$shouldExclude: (t, e, n) => Pi(t) && t.excludeFromCopy("html"),
			$shouldInclude: (t, e, n) => !e || t.isSelected(e),
			$updateDOM: (t, e, n, o) => t.updateDOM(e, n, o._config)
		};
		function ys(e) {
			const n = e || {}, o = mi(), r = n.theme || {}, i = void 0 === e ? o : n.parentEditor || null, s = n.disableEvents || !1, l = Wi(), c = n.namespace || (null !== i ? i._config.namespace : cl()), a = n.editorState, u = [
				zi,
				Wo,
				Ji,
				Zo,
				Zi,
				ji,
				...n.nodes || []
			], { onError: f, onWarn: d, html: h } = n, g = void 0 === n.editable || n.editable;
			let _;
			if (void 0 === e && null !== o) _ = o._nodes;
			else {
				_ = /* @__PURE__ */ new Map();
				for (let e = 0; e < u.length; e++) {
					let o = u[e], r = null, i = null;
					if (o && "object" == typeof o) {
						const t = o;
						o = t.replace, r = t.with, i = t.withKlass || null;
					}
					if ("function" != typeof o || !o.prototype || !(o === _o || o.prototype instanceof _o)) {
						let r = "<unknown>";
						try {
							r = JSON.parse(Z$1);
						} catch (t) {}
						t(365, String(e - u.length + (n.nodes ? n.nodes.length : 0)), "function" == typeof o ? `${o.name}${"function" == typeof o.getType ? ` (type ${String(o.getType())})` : ""}` : String(o), String(r));
					}
					Hc(o);
					const s = o.getType(), l = _s(o);
					_.set(s, {
						exportDOM: h && h.export ? h.export.get(o) : void 0,
						klass: o,
						replace: r,
						replaceWithKlass: i,
						sharedNodeState: vt$1(u[e]),
						transforms: l
					});
				}
			}
			const p = new Cs(l, i, _, {
				disableEvents: s,
				dom: {
					...ps,
					...e && e.dom
				},
				namespace: c,
				theme: r
			}, f || console.error, d || os, function(t, e) {
				const n = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set(), r = (t) => {
					Object.keys(t).forEach((e) => {
						let o = n.get(e);
						void 0 === o && (o = [], n.set(e, o)), o.push(t[e]);
					});
				};
				return t.forEach((t) => {
					const e = t.klass.importDOM;
					if (null == e || o.has(e)) return;
					o.add(e);
					const n = e.call(t.klass);
					null !== n && r(n);
				}), e && r(e), n;
			}(_, h ? h.import : void 0), g, e);
			return void 0 !== a && (p._pendingEditorState = a, p._dirtyType = 2), function(t) {
				t.registerCommand(ze$2, Yn, 0), t.registerCommand(Be$2, Gn, 0), t.registerCommand(Re, Xn, 0), t.registerCommand(We$2, Qn, 0), t.registerCommand(tn$2, eo, 0);
			}(p), p;
		}
		function ms(t, e) {
			const n = t.get(e);
			t.delete(e), n && n();
		}
		function xs(t, e, n) {
			return t.set(e, n), ms.bind(null, t, e);
		}
		var Cs = class {
			static version;
			_headless;
			_parentEditor;
			_rootElement;
			_editorState;
			_pendingEditorState;
			_compositionKey;
			_deferred;
			_keyToDOMMap;
			_updates;
			_updating;
			_cascadeCount;
			_listeners;
			_commands;
			_nodes;
			_decorators;
			_pendingDecorators;
			_config;
			_dirtyType;
			_cloneNotNeeded;
			_dirtyLeaves;
			_dirtyElements;
			_normalizedNodes;
			_updateTags;
			_observer;
			_key;
			_onError;
			_onWarn;
			_htmlConversions;
			_window;
			_editable;
			_blockCursorElement;
			_slotsUsed;
			_inputState;
			_createEditorArgs;
			constructor(t, e, n, o, r, i, s, l, c) {
				this._createEditorArgs = c, this._parentEditor = e, this._rootElement = null, this._editorState = t, this._pendingEditorState = null, this._compositionKey = null, this._deferred = [], this._keyToDOMMap = new ot$1(), this._updates = [], this._updating = !1, this._cascadeCount = 0, this._listeners = {
					decorator: /* @__PURE__ */ new Map(),
					editable: /* @__PURE__ */ new Map(),
					mutation: /* @__PURE__ */ new Map(),
					root: /* @__PURE__ */ new Map(),
					textcontent: /* @__PURE__ */ new Map(),
					update: /* @__PURE__ */ new Map()
				}, this._commands = /* @__PURE__ */ new Map(), this._config = o, this._nodes = n, this._decorators = {}, this._pendingDecorators = null, this._dirtyType = 0, this._cloneNotNeeded = /* @__PURE__ */ new Set(), this._dirtyLeaves = /* @__PURE__ */ new Set(), this._dirtyElements = /* @__PURE__ */ new Map(), this._normalizedNodes = /* @__PURE__ */ new Set(), this._updateTags = /* @__PURE__ */ new Set(), this._observer = null, this._key = cl(), this._onError = r, this._onWarn = i, this._htmlConversions = s, this._editable = l, this._headless = null !== e && e._headless, this._window = null, this._blockCursorElement = null, this._slotsUsed = !1, this._inputState = {
					collapsedSelectionFormat: {
						format: 0,
						key: "root",
						offset: 0,
						style: "",
						timeStamp: 0
					},
					compositionEndData: "",
					compositionPhase: "idle",
					hadOrphanedCompositionEvents: !1,
					handledSelectionCommandTimeoutId: null,
					isInsertLineBreak: !1,
					isInsertTextAfterHandledSelectionCommand: !1,
					isSelectionChangeFromDOMUpdate: !1,
					isSelectionChangeFromMouseDown: !1,
					lastBeforeInputInsertTextTimeStamp: 0,
					lastKeyCode: null,
					lastKeyDownTimeStamp: 0,
					postDeleteSelectionToRestore: null,
					unprocessedBeforeInputData: null
				};
			}
			isComposing() {
				return null != this._compositionKey;
			}
			registerUpdateListener(t) {
				return xs(this._listeners.update, t);
			}
			registerEditableListener(t) {
				return xs(this._listeners.editable, t);
			}
			registerDecoratorListener(t) {
				return xs(this._listeners.decorator, t);
			}
			registerTextContentListener(t) {
				return xs(this._listeners.textcontent, t);
			}
			registerRootListener(t) {
				const e = this._listeners.root;
				return Eu(xs(e, t, t(this._rootElement, null) || void 0), () => function(t, e, n) {
					const o = t.get(e);
					o && o(), t.set(e, e(...n) || void 0);
				}(e, t, [null, this._rootElement]));
			}
			registerCommand(e, n, o) {
				void 0 === o && t(35);
				const r = this._commands;
				r.has(e) || r.set(e, [
					new tt(),
					new tt(),
					new tt(),
					new tt(),
					new tt()
				]);
				const i = r.get(e);
				void 0 === i && t(36, String(e));
				const s = function(t) {
					return 7 & t;
				}(o), l = i[s];
				return s !== o ? l.addFront(n) : l.addBack(n), () => {
					l.delete(n), i.every((t) => 0 === t.size) && r.delete(e);
				};
			}
			registerMutationListener(t, e, n) {
				const o = this.resolveRegisteredNodeAfterReplacements(this.getRegisteredNode(t)).klass, r = this._listeners.mutation;
				let i = r.get(e);
				void 0 === i && (i = /* @__PURE__ */ new Set(), r.set(e, i)), i.add(o);
				const s = n && n.skipInitialization;
				return void 0 !== s && s || this.initializeMutationListener(e, o), () => {
					i.delete(o), 0 === i.size && r.delete(e);
				};
			}
			getRegisteredNode(e) {
				const n = this._nodes.get(e.getType());
				return void 0 === n && t(37, e.name), n;
			}
			resolveRegisteredNodeAfterReplacements(t) {
				for (; t.replaceWithKlass;) t = this.getRegisteredNode(t.replaceWithKlass);
				return t;
			}
			initializeMutationListener(t, e) {
				const n = this._editorState, o = Ac(n).get(e.getType());
				if (!o) return;
				const r = /* @__PURE__ */ new Map();
				for (const t of o.keys()) r.set(t, "created");
				r.size > 0 && t(r, {
					dirtyLeaves: /* @__PURE__ */ new Set(),
					prevEditorState: n,
					updateTags: new Set(["registerMutationListener"])
				});
			}
			registerNodeTransformToKlass(t, e) {
				const n = this.getRegisteredNode(t);
				return n.transforms.add(e), n;
			}
			registerNodeTransform(t, e) {
				const n = this.registerNodeTransformToKlass(t, e), o = [n], r = n.replaceWithKlass;
				if (null != r) {
					const t = this.registerNodeTransformToKlass(r, e);
					o.push(t);
				}
				return function(t, e) {
					const n = Ac(t.getEditorState()), o = [];
					for (const t of e) {
						const e = n.get(t);
						e && o.push(e);
					}
					if (0 === o.length) return;
					t.update(() => {
						for (const t of o) for (const e of t.keys()) {
							const t = Ys(e);
							t && t.markDirty();
						}
					}, null === t._pendingEditorState ? { tag: xo } : void 0);
				}(this, o.map((t) => t.klass.getType())), () => {
					o.forEach((t) => t.transforms.delete(e));
				};
			}
			hasNode(t) {
				return this._nodes.has(t.getType());
			}
			hasNodes(t) {
				return t.every(this.hasNode.bind(this));
			}
			dispatchCommand(t, ...e) {
				return Nl(this, t, ...e);
			}
			getDecorators() {
				return this._decorators;
			}
			getRootElement() {
				return this._rootElement;
			}
			getKey() {
				return this._key;
			}
			setRootElement(t) {
				const e = this._rootElement;
				if (t !== e) {
					const n = Cl(this._config.theme, "root"), o = this._pendingEditorState || this._editorState;
					if (this._rootElement = t, gs(this, e, t, o, { preserveUpdateQueue: !0 }), null !== e && (this._config.disableEvents || co(e), null != n && e.classList.remove(...n)), null !== t) {
						const e = Pl(t), o = t.style;
						o.userSelect = "text", o.whiteSpace = "pre-wrap", o.wordBreak = "break-word", t.setAttribute("data-lexical-editor", "true"), this._window = e, this._dirtyType = 2, gt$1(this), this._updateTags.add(xo), bi(this), this._config.disableEvents || function(t, e) {
							const n = t.ownerDocument;
							Ln.set(t, n);
							let o = Kn.get(n);
							void 0 === o && (o = {
								editors: /* @__PURE__ */ new Set(),
								hasShadowEditor: void 0
							}, Kn.set(n, o)), o.editors.add(e), o.hasShadowEditor = void 0, t.__lexicalEditor = e;
							const r = no(t);
							r.push(zn.register(n));
							for (let n = 0; n < In.length; n++) {
								const [o, i] = In[n], s = "function" == typeof i ? (t) => {
									so(t) || (io(t), (e.isEditable() || "click" === o) && i(t, e));
								} : (t) => {
									if (so(t)) return;
									io(t);
									const n = e.isEditable();
									switch (o) {
										case "cut": return n && Nl(e, Tn, t);
										case "copy": return Nl(e, vn$2, t);
										case "paste": return n && Nl(e, Je$2, t);
										case "dragstart": return n && Nl(e, xn$1, t);
										case "dragover": return n && Nl(e, Cn$1, t);
										case "dragend": return n && Nl(e, Sn$2, t);
										case "focus": return n && Nl(e, On$1, t);
										case "blur": return n && Nl(e, Mn$1, t);
										case "drop": return n && Nl(e, yn$1, t);
									}
								};
								r.push(Fn(t, o, s));
							}
						}(t, this), null != n && t.classList.add(...n);
					} else this._window = null, this._updateTags.add(xo), bi(this);
					Ni("root", this, !1, t, e);
				}
			}
			getElementByKey(t) {
				return this._keyToDOMMap.get(t) || null;
			}
			getEditorState() {
				return this._editorState;
			}
			setEditorState(e, n) {
				e.isEmpty() && t(38);
				let o = e;
				o._readOnly && (o = Ri(e), o._selection = e._selection ? e._selection.clone() : null), ht$2(this);
				const r = this._pendingEditorState, i = void 0 !== n ? n.tag : null;
				null === r || r.isEmpty() || (null != i && this._updateTags.add(i), bi(this)), this._pendingEditorState = o, this._dirtyType = 2, this._dirtyElements.set("root", !1), this._compositionKey = null, this._slotsUsed = this._slotsUsed || e._slotsUsed, Ai(this, () => {
					if (i && this._updateTags.add(i), e._parsed) for (const [t, e] of o._nodeMap.entries()) Pi(e) ? this._dirtyElements.set(t, !0) : this._dirtyLeaves.add(t);
				}, { discrete: !this._updating || void 0 });
			}
			parseEditorState(t, e) {
				return function(t, e, n) {
					const o = Wi(), r = ni, i = ri, s = oi, l = e._dirtyElements, c = e._dirtyLeaves, a = e._cloneNotNeeded, u = e._dirtyType;
					e._dirtyElements = /* @__PURE__ */ new Map(), e._dirtyLeaves = /* @__PURE__ */ new Set(), e._cloneNotNeeded = /* @__PURE__ */ new Set(), e._dirtyType = 0, ni = o, ri = !1, oi = e, vs(null);
					try {
						const r = e._nodes;
						Ti(t.root, r), n && n(), o._readOnly = !0, o._parsed = !0;
					} catch (t) {
						t instanceof Error && e._onError(t);
					} finally {
						e._dirtyElements = l, e._dirtyLeaves = c, e._cloneNotNeeded = a, e._dirtyType = u, ni = r, ri = i, oi = s;
					}
					return o;
				}("string" == typeof t ? JSON.parse(t) : t, this, e);
			}
			read(...t) {
				const [e, n] = 1 === t.length ? ["force-commit", t[0]] : t;
				"force-commit" === e && bi(this);
				return ("pending" === e ? this._pendingEditorState || this._editorState : this.getEditorState()).read(n, { editor: this });
			}
			update(t, e) {
				(function(t, e, n) {
					t._updating ? t._updates.push([e, n]) : Mi(t, e, n);
				})(this, t, e);
			}
			focus(t, e = {}) {
				const n = this._rootElement;
				null !== n && (n.setAttribute("autocapitalize", "off"), Ai(this, () => {
					const o = Kr(), r = nl();
					null !== o ? o.dirty || ol(o.clone()) : 0 !== r.getChildrenSize() && ("rootStart" === e.defaultSelection ? r.selectStart() : r.selectEnd()), Al("focus"), Dl(() => {
						n.removeAttribute("autocapitalize"), t && t();
					});
				}), null === this._pendingEditorState && n.removeAttribute("autocapitalize"));
			}
			blur() {
				const t = this._rootElement;
				null !== t && t.blur();
				const e = Jl(this._window);
				null !== e && e.removeAllRanges();
			}
			isEditable() {
				return this._editable;
			}
			setEditable(t) {
				this._editable !== t && (this._editable = t, Ni("editable", this, !0, t), this._slotsUsed && this.update(() => pi()));
			}
			toJSON() {
				return { editorState: this._editorState.toJSON() };
			}
		};
		Cs.version = Z$1;
		let Ss = null;
		function vs(t) {
			Ss = t;
		}
		const Ts = Symbol("INTERNAL_SKIP_AFTER_CLONE_FROM");
		let ks = 1;
		function Ns(e, n) {
			const o = Es(e, n);
			return void 0 === o && t(30, n), o;
		}
		function Es(t, e) {
			return t._nodes.get(e);
		}
		const ws = "function" == typeof queueMicrotask ? queueMicrotask : (t) => {
			Promise.resolve().then(t);
		};
		function Os(t, e) {
			const n = void 0 !== e ? e : (() => {
				const e = t.getRootNode();
				return Bs(e) || ql(e) ? cc(e) : null;
			})();
			if (!gc(n)) return !1;
			if (n.hasAttribute("data-lexical-slot")) return !1;
			const o = Zs(n), r = n.nodeName;
			return po(o) && ("INPUT" === r || "TEXTAREA" === r || "true" === n.contentEditable && null == Ps(n));
		}
		function As(t, e, n) {
			const o = t.getRootElement();
			if (!o) return !1;
			try {
				if (!e || !o.contains(e) || !o.contains(n)) return !1;
			} catch (t) {
				return !1;
			}
			return Fs(e) === t && t.read("latest", () => !Os(e));
		}
		function Ds(t) {
			return t instanceof Cs;
		}
		function Fs(t) {
			let e = t;
			for (; null != e;) {
				const t = Ps(e);
				if (Ds(t)) return t;
				e = wl(e);
			}
			return null;
		}
		function Ps(t) {
			return t ? t.__lexicalEditor : null;
		}
		function Ls(t) {
			return er(t) || t.isToken();
		}
		function Ks(t) {
			return Ls(t) || t.isSegmented();
		}
		function zs(t) {
			return _c(t) && 3 === t.nodeType;
		}
		function Bs(t) {
			return _c(t) && 9 === t.nodeType;
		}
		function Rs(t) {
			let e = t;
			for (; null != e;) {
				if (zs(e)) return e;
				e = e.firstChild;
			}
			return null;
		}
		function Ws(t, e, n) {
			const o = z$1[e];
			if (null !== n && (t & o) === (n & o)) return t;
			let r = t ^ o;
			return "subscript" === e ? r &= ~z$1.superscript : "superscript" === e ? r &= ~z$1.subscript : "lowercase" === e ? (r &= ~z$1.uppercase, r &= ~z$1.capitalize) : "uppercase" === e ? (r &= ~z$1.lowercase, r &= ~z$1.capitalize) : "capitalize" === e && (r &= ~z$1.lowercase, r &= ~z$1.uppercase), r;
		}
		function Us(t, e) {
			const n = function() {
				const t = Ss;
				return Ss = null, t;
			}();
			if (null != (e = e || n && n.__key)) return void (t.__key = e);
			fi(), di();
			const o = _i(), r = hi(), i = "" + ks++;
			r._nodeMap.set(i, t), Pi(t) ? o._dirtyElements.set(i, !0) : o._dirtyLeaves.add(i), o._cloneNotNeeded.add(i), 0 === o._dirtyType && (o._dirtyType = 1), t.__key = i;
		}
		function Hs(e) {
			null !== ta(e) && t(380, e.__key, String(ta(e)));
			const n = e.getParent();
			if (null !== n) {
				const t = e.getWritable(), o = n.getWritable(), r = e.getPreviousSibling(), i = e.getNextSibling(), s = null !== i ? i.__key : null, l = null !== r ? r.__key : null, c = null !== r ? r.getWritable() : null, a = null !== i ? i.getWritable() : null;
				null === r && (o.__first = s), null === i && (o.__last = l), null !== c && (c.__next = s), null !== a && (a.__prev = l), t.__prev = null, t.__next = null, t.__parent = null, o.__size--;
			}
		}
		function Js(e) {
			di(), ho(e) && t(323, e.__key, e.__type);
			const n = e.getLatest(), o = null !== n.__parent ? n.__parent : Zc(n) ? n.__slotHost : null, r = hi(), i = _i(), s = r._nodeMap, l = i._dirtyElements;
			null !== o && function(t, e, n) {
				let o = t;
				for (; null !== o;) {
					if (n.has(o)) return;
					const t = e.get(o);
					if (void 0 === t) break;
					n.set(o, !1), o = null !== t.__parent ? t.__parent : Zc(t) ? t.__slotHost : null;
				}
			}(o, s, l);
			const c = n.__key;
			0 === i._dirtyType && (i._dirtyType = 1), Pi(e) ? l.set(c, !0) : i._dirtyLeaves.add(c);
		}
		function Vs(t) {
			fi();
			const e = _i(), n = e._compositionKey;
			if (t !== n) {
				if (e._compositionKey = t, null !== n) {
					const t = Ys(n);
					null !== t && t.getWritable();
				}
				if (null !== t) {
					const e = Ys(t);
					null !== e && e.getWritable();
				}
			}
		}
		function qs() {
			if (ui()) return null;
			return _i()._compositionKey;
		}
		function Ys(t, e) {
			const n = (e || hi())._nodeMap.get(t);
			return void 0 === n ? null : n;
		}
		function Gs(t, e) {
			const n = Qs(t, _i());
			return void 0 !== n ? Ys(n, e) : null;
		}
		function Xs(t, e, n) {
			t[`__lexicalKey_${e._key}`] = n;
		}
		function Qs(t, e) {
			return t[`__lexicalKey_${e._key}`];
		}
		function Zs(t, e) {
			let n = t;
			for (; null != n;) {
				const t = Gs(n, e);
				if (null !== t) return t;
				n = wl(n);
			}
			return null;
		}
		function tl(t) {
			const e = t._decorators, n = Object.assign({}, e);
			return t._pendingDecorators = n, n;
		}
		function el(t) {
			return t.read(() => nl().getTextContent());
		}
		function nl() {
			return hi()._nodeMap.get("root");
		}
		function ol(t) {
			fi();
			const e = hi();
			null !== t && (t.dirty = !0, t.setCachedNodes(null), ur(t) && _i()._slotsUsed && Or(t)), e._selection = t;
		}
		function rl() {
			fi();
			ht$2(_i());
		}
		function il(t) {
			const e = function(t, e) {
				let n = t;
				for (; null != n;) {
					const t = Qs(n, e);
					if (void 0 !== t) return t;
					n = wl(n);
				}
				return null;
			}(t, _i());
			return null === e ? null : Ys(e);
		}
		function sl(t) {
			return /[\uD800-\uDBFF][\uDC00-\uDFFF]/g.test(t);
		}
		function ll(t) {
			const e = [];
			for (let n = t; null !== n; n = n._parentEditor) e.push(n);
			return e;
		}
		function cl() {
			return Math.random().toString(36).replace(/[^a-z]+/g, "").substring(0, 5);
		}
		function al(t) {
			return zs(t) ? t.nodeValue : null;
		}
		function ul(t, e, n) {
			const o = Jl(Il(e));
			if (null === o) return;
			const r = nc(o, e._rootElement), i = r.anchorNode;
			let { anchorOffset: s, focusOffset: l } = r;
			if (null !== i) {
				let e = al(i);
				const o = Zs(i);
				if (null !== e && Xo(o)) {
					if ((e === A || e === F) && n) {
						const t = n.length;
						e = n, s = t, l = t;
					}
					null !== e && fl(o, e, s, l, t);
				}
			}
		}
		function fl(t, e, n, o, r) {
			let i = t;
			if (i.isAttached() && (r || !i.isDirty())) {
				const s = i.isComposing();
				if (i.isToken() && s) return;
				let c = e;
				if ((s || r) && (e.endsWith(A) && (c = e.slice(0, -A.length)), r)) {
					const t = F;
					let e;
					for (; -1 !== (e = c.indexOf(t));) c = c.slice(0, e) + c.slice(e + t.length), null !== n && n > e && (n = Math.max(e, n - t.length)), null !== o && o > e && (o = Math.max(e, o - t.length));
				}
				const u = i.getTextContent();
				if (r || c !== u) {
					const e = Kr();
					if ("" === c) {
						if (Vs(null), a || l || d$1) i.remove();
						else {
							const t = _i();
							dl(i, "", e), setTimeout(() => {
								t.update(() => {
									i.isAttached() && "" === i.getTextContent() && i.remove();
								});
							}, 20);
						}
						return;
					}
					const r = i.getParent(), u = zr(), f = i.getTextContentSize(), h = qs(), g = i.getKey();
					if (i.isToken() && !s || null !== h && g === h && !s || ur(u) && (null !== r && !r.canInsertTextBefore() && 0 === u.anchor.offset || u.anchor.key === t.__key && 0 === u.anchor.offset && !i.canInsertTextBefore() && !s || u.focus.key === t.__key && u.focus.offset === f && !i.canInsertTextAfter() && !s)) return void i.markDirty();
					if (!ur(e) || null === n || null === o) return void dl(i, c, e);
					if (e.setTextNodeRange(i, n, i, o), i.isSegmented()) {
						const t = Go(i.getTextContent());
						i.replace(t), i = t;
					}
					dl(i, c, e);
				}
			}
		}
		function dl(t, e, n) {
			if (t.setTextContent(e), ur(n)) {
				const e = t.getKey();
				let o = !1;
				for (const r of ["anchor", "focus"]) {
					const i = n[r];
					"text" === i.type && i.key === e && (i.offset = Ka(t, i.offset, "clamp"), o = !0);
				}
				o && (n._cachedNodes = null, n._cachedIsBackward = null);
			}
		}
		function hl(t, e, n) {
			const o = e[n] || !1;
			return "any" === o || o === t[n];
		}
		function gl(t, e) {
			return hl(t, e, "altKey") && hl(t, e, "ctrlKey") && hl(t, e, "shiftKey") && hl(t, e, "metaKey");
		}
		function _l(t, e, n) {
			if (!gl(t, n)) return !1;
			if (t.key.toLowerCase() === e.toLowerCase()) return !0;
			if (e.length > 1) return !1;
			if (1 === t.key.length && t.key.charCodeAt(0) <= 127) return !1;
			if (t.code.startsWith("Digit") && /^\d$/.test(e)) return t.code === `Digit${e}`;
			const o = "Key" + e.toUpperCase();
			return t.code === o;
		}
		const pl = {
			ctrlKey: !r$1,
			metaKey: r$1
		}, yl = {
			altKey: r$1,
			ctrlKey: !r$1
		};
		function ml(t) {
			return "Backspace" === t.key;
		}
		function xl(t) {
			const e = nl();
			if (ur(t)) {
				const e = t.anchor, n = t.focus, o = e.getNode();
				if (Bi(o)) return e.set(o.getKey(), 0, "element"), n.set(o.getKey(), o.getChildrenSize(), "element"), It(t), t;
				const r = o.getTopLevelElementOrThrow(), i = r.getParent();
				if (null === i) return Pi(r) && (e.set(r.getKey(), 0, "element"), n.set(r.getKey(), r.getChildrenSize(), "element"), It(t)), t;
				const s = i;
				return e.set(s.getKey(), 0, "element"), n.set(s.getKey(), s.getChildrenSize(), "element"), It(t), t;
			}
			{
				const t = e.select(0, e.getChildrenSize());
				return ol(It(t)), t;
			}
		}
		function Cl(t, e) {
			void 0 === t.__lexicalClassNameCache && (t.__lexicalClassNameCache = {});
			const n = t.__lexicalClassNameCache, o = n[e];
			if (void 0 !== o) return o;
			const r = t[e];
			if ("string" == typeof r) {
				const t = ku(r);
				return n[e] = t, t;
			}
			return r;
		}
		function Sl(e, n, o, r, i) {
			if (0 === o.size) return;
			const s = r.__type, l = r.__key, c = n.get(s);
			void 0 === c && t(33, s);
			const a = c.klass;
			let u = e.get(a);
			void 0 === u && (u = /* @__PURE__ */ new Map(), e.set(a, u));
			const f = u.get(l), d = "destroyed" === f && "created" === i;
			(void 0 === f || d) && u.set(l, d ? "updated" : i);
		}
		function Tl(t, e, n) {
			const o = t.getParent();
			let r = n, i = t;
			return null !== o && (e && 0 === n ? (r = i.getIndexWithinParent(), i = o) : e || n !== i.getChildrenSize() || (r = i.getIndexWithinParent() + 1, i = o)), i.getChildAtIndex(e ? r - 1 : r);
		}
		function kl(t, e) {
			const n = t.offset;
			if ("element" === t.type) return Tl(t.getNode(), e, n);
			{
				const o = t.getNode();
				if (e && 0 === n || !e && n === o.getTextContentSize()) {
					const t = e ? o.getPreviousSibling() : o.getNextSibling();
					return null === t ? Tl(o.getParentOrThrow(), e, o.getIndexWithinParent() + (e ? 0 : 1)) : t;
				}
			}
			return null;
		}
		function bl(t) {
			const e = Il(t).event, n = e && e.inputType;
			return "insertFromPaste" === n || "insertFromPasteAsQuotation" === n;
		}
		function Nl(t, e, ...n) {
			return Ei(t, e, n[0], t);
		}
		function El(e, n) {
			const o = e._keyToDOMMap.get(n);
			return void 0 === o && t(75, n), o;
		}
		function wl(t) {
			const e = t.assignedSlot || t.parentElement;
			if (null !== e) return e;
			const n = t.parentNode;
			return ql(n) ? n.host : null;
		}
		function Ol(t) {
			return Bs(t) ? t : gc(t) ? t.ownerDocument : null;
		}
		function Al(t) {
			fi();
			_i()._updateTags.add(t);
		}
		function Dl(t) {
			fi();
			_i()._deferred.push(t);
		}
		function Fl(t, e) {
			let n = t.getParent();
			for (; null !== n;) {
				if (n.is(e)) return !0;
				n = n.getParent();
			}
			return !1;
		}
		function Pl(t) {
			const e = Ol(t);
			return e ? e.defaultView : null;
		}
		function Il(e) {
			const n = e._window;
			return null === n && t(78), n;
		}
		function Ll(t) {
			return Pi(t) && t.isInline() || Ki(t) && t.isInline();
		}
		function Kl(t) {
			let e = t.getLatest();
			for (; null !== e;) {
				if (null !== ta(e) && Pi(e)) return e;
				const t = e.getParentOrThrow();
				if (Bl(t)) return t;
				e = t;
			}
			return e;
		}
		function zl(t) {
			return Pi(t) && t.isShadowRoot();
		}
		function Bl(t) {
			return Bi(t) || zl(t);
		}
		function Rl(t, e = !1) {
			const n = t.constructor.clone(t, Ts);
			return Us(n, null), n.afterCloneFrom(t), e || n.resetOnCopyNodeFrom(t), n;
		}
		function Wl(e) {
			const n = _i(), o = e.getType(), r = Es(n, o);
			void 0 === r && t(200, e.constructor.name, o);
			const { replace: i, replaceWithKlass: s } = r;
			if (null !== i) {
				const n = i(e), r = n.constructor;
				return null !== s ? n instanceof s || t(201, s.name, s.getType(), r.name, r.getType(), e.constructor.name, o) : n instanceof e.constructor && r !== e.constructor || t(202, r.name, r.getType(), e.constructor.name, o), n.__key === e.__key && t(203, e.constructor.name, o, r.name, r.getType()), n;
			}
			return e;
		}
		function $l(e, n) {
			!Bi(e.getParent()) || Pi(n) || Ki(n) || t(99);
		}
		function Ul(e) {
			const n = Ys(e);
			return null === n && t(63, e), n;
		}
		function Hl(t) {
			if (!t || t.isInline()) return !1;
			if (Ki(t)) return !0;
			if (Pi(t)) {
				if (t.isShadowRoot()) {
					const e = t.getParent();
					return !(Pi(e) && e.isShadowRoot());
				}
				return !t.canBeEmpty();
			}
			return !1;
		}
		function jl(t, e, n) {
			n.style.removeProperty("caret-color"), e._blockCursorElement = null;
			const o = t.parentElement;
			null !== o && o.removeChild(t);
		}
		function Jl(t) {
			return n ? (t || window).getSelection() : null;
		}
		function Vl(t) {
			const e = Pl(t);
			return e ? e.getSelection() : null;
		}
		function ql(t) {
			return pc(t) && "host" in t;
		}
		const Yl = [];
		function Gl(t) {
			const e = t.getRootNode();
			if (e === t || !ql(e)) return Yl;
			const n = [e];
			let o = e.host;
			for (;;) {
				const t = o.getRootNode();
				if (t === o || !ql(t)) break;
				n.push(t), o = t.host;
			}
			return n;
		}
		function* Xl(t) {
			const e = [t];
			let n;
			for (; n = e.pop();) {
				yield* n.querySelectorAll("[data-lexical-editor=\"true\"]");
				const t = (Bs(n) ? n : n.ownerDocument).createTreeWalker(n, NodeFilter.SHOW_ELEMENT);
				let o;
				for (; o = t.nextNode();) o.shadowRoot && e.push(o.shadowRoot);
			}
		}
		function Ql(t) {
			return null !== t ? t.ownerDocument : document;
		}
		function Zl() {
			const t = mi();
			return Ql(null !== t ? t._rootElement : null);
		}
		function tc(t, e) {
			if (null === e || "function" != typeof t.getComposedRanges) return null;
			const n = Gl(e);
			if (0 === n.length) return null;
			const o = t.getComposedRanges;
			try {
				const e = o.call(t, { shadowRoots: n })[0];
				if (void 0 !== e) return e;
			} catch (t) {}
			try {
				const e = o.apply(t, n)[0];
				if (void 0 !== e) return e;
			} catch (t) {}
			return null;
		}
		function ec(t, e) {
			const n = tc(t, e);
			if (null !== n) {
				const t = rc(n);
				if (null !== t) return t;
			}
			return t.rangeCount > 0 ? t.getRangeAt(0) : null;
		}
		function nc(t, e) {
			const n = tc(t, e);
			return null === n ? t : ic(n, sc(t));
		}
		function rc(t) {
			const e = t.startContainer.ownerDocument;
			if (null === e) return null;
			const n = e.createRange();
			try {
				return n.setStart(t.startContainer, t.startOffset), n.setEnd(t.endContainer, t.endOffset), n;
			} catch (t) {
				return null;
			}
		}
		function ic(t, e) {
			const { startContainer: n, startOffset: o, endContainer: r, endOffset: i } = t;
			return "backward" === e ? {
				anchorNode: r,
				anchorOffset: i,
				direction: e,
				focusNode: n,
				focusOffset: o
			} : {
				anchorNode: n,
				anchorOffset: o,
				direction: e,
				focusNode: r,
				focusOffset: i
			};
		}
		function sc(t) {
			return t.direction;
		}
		function lc(t) {
			const e = t.getRootNode();
			return Bs(e) || ql(e) ? e.activeElement : null;
		}
		function cc(t) {
			let e = t.activeElement;
			for (; null !== e && null !== e.shadowRoot;) {
				const t = e.shadowRoot.activeElement;
				if (null === t) break;
				e = t;
			}
			return e;
		}
		function ac(t) {
			const e = t.target;
			if (null !== e && gc(e) && null !== e.shadowRoot && "function" == typeof t.composedPath) {
				const e = t.composedPath();
				if (e.length > 0) return e[0];
			}
			return e;
		}
		function gc(t) {
			return _c(t) && 1 === t.nodeType;
		}
		function _c(t) {
			return "object" == typeof t && null !== t && "nodeType" in t && "number" == typeof t.nodeType;
		}
		function pc(t) {
			return _c(t) && 11 === t.nodeType;
		}
		const yc = /^(a|abbr|acronym|b|cite|code|del|em|i|ins|kbd|label|mark|output|q|ruby|s|samp|span|strong|sub|sup|time|u|tt|var|#text)$/i;
		function mc(t) {
			return !(!gc(t) || !t.style.display.startsWith("inline")) || yc.test(t.nodeName);
		}
		const xc = /^(address|article|aside|blockquote|canvas|dd|div|dl|dt|fieldset|figcaption|figure|footer|form|h1|h2|h3|h4|h5|h6|header|hr|li|main|nav|noscript|ol|p|pre|section|table|td|tfoot|ul|video)$/i;
		function Cc(t) {
			return (!gc(t) || !t.style.display.startsWith("inline")) && xc.test(t.nodeName);
		}
		function Sc(t) {
			if (Ki(t) && !t.isInline()) return !0;
			if (!Pi(t) || Bl(t)) return !1;
			const e = t.getFirstChild(), n = null === e || Yi(e) || Xo(e) || e.isInline();
			return !t.isInline() && !1 !== t.canBeEmpty() && n;
		}
		function vc() {
			return _i();
		}
		function Tc(t = vc()) {
			return t._config.dom || ps;
		}
		function kc(e, n, o = vc()) {
			const r = Tc(o).$getDOMSlot(e, n, o);
			return Pi(e) && (Ec(r) || t(344, e.getKey(), e.getType())), r;
		}
		function Ec(t) {
			return t instanceof G;
		}
		function wc(t, e, n = vc()) {
			return Rs(kc(t, e, n).element);
		}
		const Oc = /* @__PURE__ */ new WeakMap(), Mc = /* @__PURE__ */ new Map();
		function Ac(e) {
			if (!e._readOnly && e.isEmpty()) return Mc;
			e._readOnly || t(192);
			let n = Oc.get(e);
			return n || (n = function(t) {
				const e = /* @__PURE__ */ new Map();
				for (const [n, o] of t._nodeMap) {
					const t = o.__type;
					let r = e.get(t);
					r || (r = /* @__PURE__ */ new Map(), e.set(t, r)), r.set(n, o);
				}
				return e;
			}(e), Oc.set(e, n)), n;
		}
		function Dc(t) {
			const e = t.constructor.clone(t, Ts);
			return e.afterCloneFrom(t), e;
		}
		function Fc(t) {
			return (e = Dc(t))[fo] = !0, e;
			var e;
		}
		function Pc(t, e) {
			const n = t.getAttribute("data-lexical-indent");
			if (null !== n) {
				const t = parseInt(n, 10);
				if (Number.isFinite(t) && t >= 0) return void e.setIndent(t);
			}
			const o = parseInt(t.style.paddingInlineStart, 10) || 0, r = Math.round(o / 40);
			e.setIndent(r);
		}
		function Ic(t, e) {
			const n = e.getAttribute("dir");
			return "ltr" === n || "rtl" === n ? t.setDirection(n) : t;
		}
		function Lc(t, e) {
			const n = e.style.textAlign;
			return n && n in R$1 ? t.setFormat(n) : t;
		}
		function Kc(t, e) {
			t.__lexicalUnmanaged = !0, e && void 0 !== e.captureSelection && (t.__lexicalCapturedSelection = e.captureSelection);
		}
		function zc(t) {
			return !0 === t.__lexicalUnmanaged;
		}
		function Bc(t, e = vc()) {
			const n = e.isEditable();
			t.contentEditable = n ? "true" : "false", n ? t.__lexicalEditor = e : delete t.__lexicalEditor;
		}
		function Rc(t, e) {
			let n = t;
			for (; null != n;) {
				if (!0 === n.__lexicalCapturedSelection) return !0;
				if (gc(n) && n.hasAttribute("data-lexical-slot")) return !1;
				if (void 0 !== Qs(n, e)) return !1;
				n = wl(n);
			}
			return !1;
		}
		function Wc(t, e) {
			return function(t, e) {
				return Object.prototype.hasOwnProperty.call(t, e);
			}(t, e) && t[e] !== _o[e];
		}
		const $c = /* @__PURE__ */ new WeakMap(), Uc = Symbol("lexical.synthesizedGetType");
		function Hc(e) {
			const n = $c.get(e);
			if (n) return n;
			const o = null != e.prototype && j in e.prototype ? e.prototype[j]() : void 0, r = function(e) {
				if (!(e === _o || e.prototype instanceof _o)) {
					let n = "<unknown>", o = "<unknown>";
					try {
						n = e.getType();
					} catch (t) {}
					try {
						Cs.version && (o = JSON.parse(Cs.version));
					} catch (t) {}
					t(290, e.name, n, o);
				}
				return e === Li || e === Fi || e === _o;
			}(e), i = !r && Wc(e, "getType") ? e.getType : void 0, s = i && !(Uc in i) ? i.call(e) : void 0;
			let l, c = s;
			if (o) if (s) l = o[s];
			else {
				for (const [t, e] of Object.entries(o)) c = t, l = e;
				if (!l) for (const t of Object.getOwnPropertySymbols(o)) {
					const e = o[t];
					if (e) {
						l = e;
						break;
					}
				}
			}
			if (!r && c) {
				if (!Wc(e, "getType")) {
					const t = e, n = function() {
						return this !== t ? _o.getType.call(this) : c;
					};
					n[Uc] = !0, e.getType = n;
				}
				if (Wc(e, "clone") || (e.clone = (t, n) => {
					vs(t);
					const o = new e();
					return n !== Ts && o.afterCloneFrom(t), o;
				}), Wc(e, "importJSON") || (e.importJSON = l && l.$importJSON || ((t) => new e().updateFromJSON(t))), !Wc(e, "importDOM") && l) {
					const { importDOM: t } = l;
					t && (e.importDOM = () => t);
				}
			}
			const a = {
				klass: e,
				ownNodeConfig: l,
				ownNodeType: c
			};
			return $c.set(e, a), a;
		}
		function* jc(t) {
			for (let e = t; e && (e === _o || po(e.prototype));) {
				const t = Hc(e);
				yield t, e = t.ownNodeConfig && t.ownNodeConfig.extends || Gc(e);
			}
		}
		function Vc(t) {
			const e = vc();
			fi();
			return new (e.resolveRegisteredNodeAfterReplacements(e.getRegisteredNode(t))).klass();
		}
		const qc = (t, e) => {
			let n = t;
			for (; null != n && !Bi(n);) {
				if (e(n)) return n;
				n = n.getParent();
			}
			return null;
		};
		function Yc(e, n) {
			const o = [];
			let r = e.__first;
			for (; null !== r;) {
				const e = null === n ? Ys(r) : n.get(r);
				e ?? t(174), o.push(r), r = e.__next;
			}
			return o;
		}
		function Gc(t) {
			const e = Object.getPrototypeOf(t);
			if ("function" == typeof e && e !== Function.prototype) return e;
			const n = t.prototype && Object.getPrototypeOf(t.prototype);
			return n ? n.constructor : null;
		}
		const Xc = /* @__PURE__ */ new Map();
		function Qc(t) {
			return Pi(t) || Ki(t);
		}
		function Zc(t) {
			return Pi(t) || Ki(t);
		}
		function ta(t) {
			const e = t.getLatest();
			return Zc(e) ? e.__slotHost : null;
		}
		function ea(e) {
			const n = ta(e);
			if (null === n) return null;
			const o = Ys(n);
			return Pi(o) || Ki(o) || t(370), o;
		}
		function na(t) {
			const e = ea(t);
			if (null === e) return null;
			const n = t.getLatest().__key;
			for (const [t, o] of ra(e)) if (o === n) return t;
			return null;
		}
		function oa(t) {
			let e = t.getLatest();
			for (; null !== e;) {
				if (null !== ta(e)) return e;
				e = e.getParent();
			}
			return null;
		}
		function ra(t) {
			const e = t.getLatest();
			return Qc(e) && null !== e.__slots ? e.__slots : Xc;
		}
		function ia(t) {
			return Array.from(ra(t).keys());
		}
		function sa(t, e) {
			const n = ra(t).get(e);
			return void 0 === n ? null : Ys(n);
		}
		const la = [
			"__proto__",
			"constructor",
			"prototype"
		], ca = Symbol("slotMapOwner");
		function aa(t) {
			let e = t.__slots;
			return null !== e && e[ca] === t || (e = new Map(e), e[ca] = t, t.__slots = e), e;
		}
		const ua = /* @__PURE__ */ new WeakMap(), fa = [];
		function da(t) {
			for (const { ownNodeConfig: e } of jc(t)) {
				const t = e && e.slots;
				if (t) return t;
			}
			return fa;
		}
		function ha(t) {
			let e = "";
			for (const n of ia(t)) {
				const o = sa(t, n);
				null !== o && (e += o.getTextContent());
			}
			return e;
		}
		function ga(t, e, n) {
			const o = n.get(t), r = n.get(e);
			return void 0 !== o ? void 0 !== r ? o - r : -1 : void 0 !== r ? 1 : t < e ? -1 : t > e ? 1 : 0;
		}
		function _a(e) {
			const n = e.__slots;
			if (null === n || n.size < 2) return;
			const o = function(e) {
				let n = ua.get(e);
				if (void 0 === n) {
					const o = da(e), r = /* @__PURE__ */ new Map();
					for (const n of o) la.includes(n) && t(371, e.name, n), r.has(n) && t(372, e.name, n), r.set(n, r.size);
					n = r, ua.set(e, n);
				}
				return n;
			}(e.constructor);
			let r = null, i = !0;
			for (const t of n.keys()) {
				if (null !== r && ga(r, t, o) > 0) {
					i = !1;
					break;
				}
				r = t;
			}
			if (i) return;
			const s = Array.from(n).sort(([t], [e]) => ga(t, e, o));
			n.clear();
			for (const [t, e] of s) n.set(t, e);
		}
		function pa(e, n, o) {
			"__proto__" !== n && "constructor" !== n && "prototype" !== n || t(373, n);
			const r = e.getLatest();
			if (null !== r.__slots && r.__slots.get(n) === o.getLatest().__key) return r;
			(!Pi(o) && !Ki(o) || o.isInline()) && t(374, o.__key);
			const i = e.getWritable(), s = aa(i), l = s.get(n);
			void 0 !== l && xa(l);
			const c = o.getWritable(), a = ea(c);
			if (null !== a) {
				const t = na(c);
				null !== t && aa(a.getWritable()).delete(t), c.__slotHost = null;
			}
			return Hs(c), c.__slotHost = i.__key, s.set(n, c.__key), _a(i), function() {
				const t = vc();
				t._slotsUsed = !0, t._pendingEditorState && (t._pendingEditorState._slotsUsed = !0);
			}(), i;
		}
		function ya(t, e) {
			const n = t.getWritable();
			if (null === n.__slots) return n;
			const o = n.__slots.get(e);
			return void 0 !== o && (xa(o), aa(n).delete(e)), n;
		}
		function xa(e) {
			const n = Ys(e);
			if (null === n) return;
			const o = n.getWritable();
			Zc(o) || t(377, e), o.__slotHost = null, o.remove();
		}
		const Ca = {
			next: "previous",
			previous: "next"
		};
		var Sa = class {
			origin;
			constructor(t) {
				this.origin = t;
			}
			[Symbol.iterator]() {
				return qa({
					hasNext: Ma,
					initial: this.getAdjacentCaret(),
					map: (t) => t,
					step: (t) => t.getAdjacentCaret()
				});
			}
			getAdjacentCaret() {
				return Ia(this.getNodeAtCaret(), this.direction);
			}
			getSiblingCaret() {
				return Ia(this.origin, this.direction);
			}
			remove() {
				const t = this.getNodeAtCaret();
				return t && t.remove(), this;
			}
			replaceOrInsert(t, e) {
				const n = this.getNodeAtCaret();
				return t.is(this.origin) || t.is(n) || (null === n ? this.insert(t) : n.replace(t, e)), this;
			}
			splice(e, n, o = "next") {
				const r = o === this.direction ? n : Array.from(n).reverse();
				let i = this;
				const s = this.getParentAtCaret(), l = /* @__PURE__ */ new Map();
				for (let t = i.getAdjacentCaret(); null !== t && l.size < e; t = t.getAdjacentCaret()) {
					const e = t.origin.getWritable();
					l.set(e.getKey(), e);
				}
				for (const e of r) {
					if (l.size > 0) {
						const n = i.getNodeAtCaret();
						if (n) if (l.delete(n.getKey()), l.delete(e.getKey()), n.is(e) || i.origin.is(e));
						else {
							const t = e.getParent();
							t && t.is(s) && e.remove(), n.replace(e);
						}
						else null === n && t(263, Array.from(l).join(" "));
					} else i.insert(e);
					i = Ia(e, this.direction);
				}
				for (const t of l.values()) t.remove();
				return this;
			}
		};
		var va = class va extends Sa {
			type = "child";
			getLatest() {
				const t = this.origin.getLatest();
				return t === this.origin ? this : Ba(t, this.direction);
			}
			getParentCaret(t = "root") {
				return Ia(ba(this.getParentAtCaret(), t), this.direction);
			}
			getFlipped() {
				const t = ka(this.direction);
				return Ia(this.getNodeAtCaret(), t) || Ba(this.origin, t);
			}
			getParentAtCaret() {
				return this.origin;
			}
			getChildCaret() {
				return this;
			}
			isSameNodeCaret(t) {
				return t instanceof va && this.direction === t.direction && this.origin.is(t.origin);
			}
			isSamePointCaret(t) {
				return this.isSameNodeCaret(t);
			}
		};
		const Ta = {
			root: Bi,
			shadowRoot: Bl
		};
		function ka(t) {
			return Ca[t];
		}
		function ba(t, e = "root") {
			return null === t || Ta[e](t) ? null : null === ta(t) ? t : null;
		}
		var Na = class Na extends Sa {
			type = "sibling";
			getLatest() {
				const t = this.origin.getLatest();
				return t === this.origin ? this : Ia(t, this.direction);
			}
			getSiblingCaret() {
				return this;
			}
			getParentAtCaret() {
				return this.origin.getParent();
			}
			getChildCaret() {
				return Pi(this.origin) ? Ba(this.origin, this.direction) : null;
			}
			getParentCaret(t = "root") {
				return Ia(ba(this.getParentAtCaret(), t), this.direction);
			}
			getFlipped() {
				const t = ka(this.direction);
				return Ia(this.getNodeAtCaret(), t) || Ba(this.origin.getParentOrThrow(), t);
			}
			isSamePointCaret(t) {
				return t instanceof Na && this.direction === t.direction && this.origin.is(t.origin);
			}
			isSameNodeCaret(t) {
				return (t instanceof Na || t instanceof Ea) && this.direction === t.direction && this.origin.is(t.origin);
			}
		};
		var Ea = class Ea extends Sa {
			type = "text";
			offset;
			constructor(t, e) {
				super(t), this.offset = e;
			}
			getLatest() {
				const t = this.origin.getLatest();
				return t === this.origin ? this : La(t, this.direction, this.offset);
			}
			getParentAtCaret() {
				return this.origin.getParent();
			}
			getChildCaret() {
				return null;
			}
			getParentCaret(t = "root") {
				return Ia(ba(this.getParentAtCaret(), t), this.direction);
			}
			getFlipped() {
				return La(this.origin, ka(this.direction), this.offset);
			}
			isSamePointCaret(t) {
				return t instanceof Ea && this.direction === t.direction && this.origin.is(t.origin) && this.offset === t.offset;
			}
			isSameNodeCaret(t) {
				return (t instanceof Na || t instanceof Ea) && this.direction === t.direction && this.origin.is(t.origin);
			}
			getSiblingCaret() {
				return Ia(this.origin, this.direction);
			}
		};
		function wa(t) {
			return t instanceof Ea;
		}
		function Ma(t) {
			return t instanceof Na;
		}
		function Aa(t) {
			return t instanceof va;
		}
		const Da = {
			next: class extends Ea {
				direction = "next";
				getNodeAtCaret() {
					return this.origin.getNextSibling();
				}
				insert(t) {
					return this.origin.insertAfter(t), this;
				}
			},
			previous: class extends Ea {
				direction = "previous";
				getNodeAtCaret() {
					return this.origin.getPreviousSibling();
				}
				insert(t) {
					return this.origin.insertBefore(t), this;
				}
			}
		}, Fa = {
			next: class extends Na {
				direction = "next";
				getNodeAtCaret() {
					return this.origin.getNextSibling();
				}
				insert(t) {
					return this.origin.insertAfter(t), this;
				}
			},
			previous: class extends Na {
				direction = "previous";
				getNodeAtCaret() {
					return this.origin.getPreviousSibling();
				}
				insert(t) {
					return this.origin.insertBefore(t), this;
				}
			}
		}, Pa = {
			next: class extends va {
				direction = "next";
				getNodeAtCaret() {
					return this.origin.getFirstChild();
				}
				insert(t) {
					return this.origin.splice(0, 0, [t]), this;
				}
			},
			previous: class extends va {
				direction = "previous";
				getNodeAtCaret() {
					return this.origin.getLastChild();
				}
				insert(t) {
					return this.origin.splice(this.origin.getChildrenSize(), 0, [t]), this;
				}
			}
		};
		function Ia(t, e) {
			return t ? new Fa[e](t) : null;
		}
		function La(t, e, n) {
			return t ? new Da[e](t, Ka(t, n)) : null;
		}
		function Ka(t, n, o = "error") {
			const r = t.getTextContentSize();
			let i = "next" === n ? r : "previous" === n ? 0 : n;
			return (i < 0 || i > r) && ("clamp" !== o && e(284, String(n), String(r), t.getKey()), i = i < 0 ? 0 : r), i;
		}
		function za(t, e) {
			return new Ua(t, e);
		}
		function Ba(t, e) {
			return Pi(t) ? new Pa[e](t) : null;
		}
		function Ra(t) {
			return t && t.getChildCaret() || t;
		}
		function Wa(t) {
			return t && Ra(t.getAdjacentCaret());
		}
		var $a = class $a {
			type = "node-caret-range";
			direction;
			anchor;
			focus;
			constructor(t, e, n) {
				this.anchor = t, this.focus = e, this.direction = n;
			}
			getLatest() {
				const t = this.anchor.getLatest(), e = this.focus.getLatest();
				return t === this.anchor && e === this.focus ? this : new $a(t, e, this.direction);
			}
			isCollapsed() {
				return this.anchor.isSamePointCaret(this.focus);
			}
			getTextSlices() {
				const t = (t) => {
					const e = this[t].getLatest();
					return wa(e) ? function(t, e) {
						const { direction: n, origin: o } = t;
						return za(t, Ka(o, "focus" === e ? ka(n) : n) - t.offset);
					}(e, t) : null;
				}, e = t("anchor"), n = t("focus");
				if (e && n) {
					const { caret: t } = e, { caret: o } = n;
					if (t.isSameNodeCaret(o)) return [za(t, o.offset - t.offset), null];
				}
				return [e, n];
			}
			iterNodeCarets(t = "root") {
				const e = wa(this.anchor) ? this.anchor.getSiblingCaret() : this.anchor.getLatest(), n = this.focus.getLatest(), o = wa(n), r = (e) => e.isSameNodeCaret(n) ? null : Wa(e) || e.getParentCaret(t);
				return qa({
					hasNext: (t) => null !== t && !(o && n.isSameNodeCaret(t)),
					initial: e.isSameNodeCaret(n) ? null : r(e),
					map: (t) => t,
					step: r
				});
			}
			[Symbol.iterator]() {
				return this.iterNodeCarets("root");
			}
		};
		var Ua = class {
			type = "slice";
			caret;
			distance;
			constructor(t, e) {
				this.caret = t, this.distance = e;
			}
			getSliceIndices() {
				const { distance: t, caret: { offset: e } } = this, n = e + t;
				return n < e ? [n, e] : [e, n];
			}
			getTextContent() {
				const [t, e] = this.getSliceIndices();
				return this.caret.origin.getTextContent().slice(t, e);
			}
			getTextContentSize() {
				return Math.abs(this.distance);
			}
			removeTextSlice() {
				const { caret: { origin: t, direction: e } } = this, [n, o] = this.getSliceIndices(), r = t.getTextContent();
				return La(t.setTextContent(r.slice(0, n) + r.slice(o)), e, n);
			}
		};
		function ja$1(t) {
			return Va(t, Ia(nl(), t.direction));
		}
		function Ja(t) {
			return Va(t, t);
		}
		function Va(e, n) {
			return e.direction !== n.direction && t(265), new $a(e, n, e.direction);
		}
		function qa(t) {
			const { initial: e, hasNext: n, step: o, map: r } = t;
			let i = e;
			return {
				[Symbol.iterator]() {
					return this;
				},
				next() {
					if (!n(i)) return {
						done: !0,
						value: void 0
					};
					const t = {
						done: !1,
						value: r(i)
					};
					return i = o(i), t;
				}
			};
		}
		function Ya(e, n) {
			const o = Za(e.origin, n.origin);
			switch (null === o && t(275, e.origin.getKey(), n.origin.getKey()), o.type) {
				case "same": {
					const t = "text" === e.type, o = "text" === n.type;
					return t && o ? function(t, e) {
						return Math.sign(t - e);
					}(e.offset, n.offset) : e.type === n.type ? 0 : t ? -1 : o ? 1 : "child" === e.type ? -1 : 1;
				}
				case "ancestor": return "child" === e.type ? -1 : 1;
				case "descendant": return "child" === n.type ? 1 : -1;
				case "branch": return Ga(o);
			}
		}
		function Ga(t) {
			const { a: e, b: n } = t, o = e.__key, r = n.__key;
			let i = e, s = n;
			for (; i && s; i = i.getNextSibling(), s = s.getNextSibling()) {
				if (i.__key === r) return -1;
				if (s.__key === o) return 1;
			}
			return null === i ? 1 : -1;
		}
		function Xa(t, e) {
			return e.is(t);
		}
		function Qa(t) {
			return Pi(t) ? [t.getLatest(), null] : [t.getParent(), t.getLatest()];
		}
		function Za(e, n) {
			if (e.is(n)) return {
				commonAncestor: e,
				type: "same"
			};
			const o = /* @__PURE__ */ new Map();
			for (let [t, n] = Qa(e); t; n = t, t = t.getParent()) o.set(t, n);
			for (let [r, i] = Qa(n); r; i = r, r = r.getParent()) {
				const s = o.get(r);
				if (void 0 !== s) return null === s ? (Xa(e, r) || t(276), {
					commonAncestor: r,
					type: "ancestor"
				}) : null === i ? (Xa(n, r) || t(277), {
					commonAncestor: r,
					type: "descendant"
				}) : ((Pi(s) || Xa(e, s)) && (Pi(i) || Xa(n, i)) && r.is(s.getParent()) && r.is(i.getParent()) || t(278), {
					a: s,
					b: i,
					commonAncestor: r,
					type: "branch"
				});
			}
			return null;
		}
		function tu(e, n) {
			const { type: o, key: r, offset: i } = e, s = Ul(e.key);
			return "text" === o ? (Xo(s) || t(266, s.getType(), r), La(s, n, i)) : (Pi(s) || t(267, s.getType(), r), hu(s, e.offset, n));
		}
		function eu(e, n) {
			const { origin: o, direction: r } = n, i = "next" === r;
			wa(n) ? e.set(o.getKey(), n.offset, "text") : Ma(n) ? Xo(o) ? e.set(o.getKey(), Ka(o, r), "text") : e.set(o.getParentOrThrow().getKey(), o.getIndexWithinParent() + (i ? 1 : 0), "element") : (Aa(n) && Pi(o) || t(268), e.set(o.getKey(), i ? 0 : o.getChildrenSize(), "element"));
		}
		function nu(t) {
			const e = Kr(), n = ur(e) ? e : Fr();
			return ou(n, t), ol(n), n;
		}
		function ou(t, e) {
			eu(t.anchor, e.anchor), eu(t.focus, e.focus);
		}
		function ru$1(t) {
			const { anchor: e, focus: n } = t, o = tu(e, "next"), r = tu(n, "next"), i = Ya(o, r) <= 0 ? "next" : "previous";
			return Va(fu(o, i), fu(r, i));
		}
		function iu(t) {
			const { direction: e, origin: n } = t, o = Ia(n, ka(e)).getNodeAtCaret();
			return o ? Ia(o, e) : Ba(n.getParentOrThrow(), e);
		}
		function su(t, e = "root") {
			const n = [t];
			for (let o = Aa(t) ? t.getParentCaret(e) : t.getSiblingCaret(); null !== o; o = o.getParentCaret(e)) n.push(iu(o));
			return n;
		}
		function lu(t) {
			return !!t && t.origin.isAttached();
		}
		function cu(e, n = "removeEmptySlices") {
			if (e.isCollapsed()) return e;
			const o = "root", r = "next";
			let i = n;
			const s = du(e, r), l = su(s.anchor, o), c = su(s.focus.getFlipped(), o), a = /* @__PURE__ */ new Set(), u = [];
			for (const t of s.iterNodeCarets(o)) if (Aa(t)) a.add(t.origin.getKey());
			else if (Ma(t)) {
				const { origin: e } = t;
				Pi(e) && !a.has(e.getKey()) || u.push(e);
			}
			const f = /* @__PURE__ */ new Set();
			for (const t of u) {
				const e = t.getParent();
				null === e || a.has(e.getKey()) || f.add(e), Hs(t);
			}
			for (const t of f) !t.canBeEmpty() && !Bl(t) && t.isEmpty() && t.isAttached() && t.remove();
			for (const t of s.getTextSlices()) {
				if (!t) continue;
				const { origin: e } = t.caret, n = e.getTextContentSize(), o = iu(Ia(e, r)), s = e.getMode();
				if (Math.abs(t.distance) === n && "removeEmptySlices" === i || "token" === s && 0 !== t.distance) o.remove();
				else if (0 !== t.distance) {
					i = "removeEmptySlices";
					let e = t.removeTextSlice();
					const n = t.caret.origin;
					if ("segmented" === s) {
						const t = e.origin, n = Go(t.getTextContent()).setStyle(t.getStyle()).setFormat(t.getFormat());
						o.replaceOrInsert(n), e = La(n, r, e.offset);
					}
					n.is(l[0].origin) && (l[0] = e), n.is(c[0].origin) && (c[0] = e.getFlipped());
				}
			}
			let d, h;
			for (const t of l) if (lu(t)) {
				d = au(t);
				break;
			}
			for (const t of c) if (lu(t)) {
				h = au(t);
				break;
			}
			const g = function(t, e, n) {
				if (!t || !e) return null;
				const o = t.getParentAtCaret(), r = e.getParentAtCaret();
				if (!o || !r) return null;
				const i = o.getParents().reverse();
				i.push(o);
				const s = r.getParents().reverse();
				s.push(r);
				const l = Math.min(i.length, s.length);
				let c;
				for (c = 0; c < l && i[c] === s[c]; c++);
				const a = (t, e) => {
					let n;
					for (let o = c; o < t.length; o++) {
						const r = t[o];
						if (Bl(r)) return;
						!n && e(r) && (n = r);
					}
					return n;
				}, u = a(i, Sc), f = u && a(s, (t) => n.has(t.getKey()) && Sc(t));
				if (f && ia(f).length > 0) return null;
				return u && f ? [u, f] : null;
			}(d, h, a);
			if (g) {
				const [t, e] = g;
				Ba(t, "previous").splice(0, e.getChildren());
				let n = e.getParent();
				for (e.remove(!0); n && n.isEmpty();) {
					const t = n;
					n = n.getParent(), t.remove(!0);
				}
			} else if (h) {
				const t = function(t) {
					if (Aa(t)) {
						const e = t.origin;
						if (Sc(e)) return e;
					} else {
						const e = t.getParentAtCaret();
						if (e && Sc(e)) return e;
					}
					return null;
				}(h), e = t && t.getParent(), n = t && t.getParents().findLast(zl);
				if (t && e && !Bi(e) && t.isEmpty() && a.has(t.getKey()) && 0 === ia(t).length && (!n || a.has(n.getKey()))) {
					t.remove(!0);
					let n = e;
					for (; n && !Bi(n) && n.isEmpty();) {
						const t = n.getParent();
						if (t && Bi(t) && t.getChildrenSize() <= 1) break;
						const e = n;
						n = t, e.remove(!0);
					}
				}
			}
			const _ = [
				d,
				h,
				...l,
				...c
			].find(lu);
			if (_) return Ja(fu(au(_), e.direction));
			t(269, JSON.stringify(l.map((t) => t.origin.__key)));
		}
		function au(t) {
			const e = function(t) {
				let e = t;
				for (; Aa(e);) {
					const t = Wa(e);
					if (!Aa(t)) break;
					e = t;
				}
				return e;
			}(t.getLatest()), { direction: n } = e;
			if (Xo(e.origin)) return wa(e) ? e : La(e.origin, n, n);
			const o = e.getAdjacentCaret();
			return Ma(o) && Xo(o.origin) ? La(o.origin, n, ka(n)) : e;
		}
		function uu(t) {
			return wa(t) && t.offset !== Ka(t.origin, t.direction);
		}
		function fu(t, e) {
			return t.direction === e ? t : t.getFlipped();
		}
		function du(t, e) {
			return t.direction === e ? t : Va(fu(t.focus, e), fu(t.anchor, e));
		}
		function hu(t, e, n) {
			let o = Ba(t, "next");
			for (let t = 0; t < e; t++) {
				const t = o.getAdjacentCaret();
				if (null === t) break;
				o = t;
			}
			return fu(o, n);
		}
		function _u(e) {
			const { origin: n, offset: o, direction: r } = e;
			if (o === Ka(n, r)) return e.getSiblingCaret();
			if (o === Ka(n, ka(r))) return iu(e.getSiblingCaret());
			const [i] = n.splitText(o);
			return Xo(i) || t(281), fu(Ia(i, "next"), r);
		}
		function pu(t, e) {
			return !0;
		}
		function yu(t, { $copyElementNode: e = Rl, $splitTextPointCaretNext: n = _u, rootMode: o = "shadowRoot", $shouldSplit: r = pu, removeEmptyDestination: i = !1 } = {}) {
			if (wa(t)) return n(t);
			const s = t.getParentCaret(o);
			if (s) {
				const { origin: n } = s;
				if (Aa(t)) {
					const t = iu(s);
					if (i && n.isEmpty()) return n.remove(), t;
					if (!n.canBeEmpty() || !r(n, "first")) return t;
				}
				const o = function(t) {
					const e = [];
					for (let n = t.getAdjacentCaret(); n; n = n.getAdjacentCaret()) e.push(n.origin);
					return e;
				}(t);
				(o.length > 0 || !i && n.canBeEmpty() && r(n, "last")) && s.insert(e(n).splice(0, 0, o));
			}
			return s;
		}
		function mu(e, n, o) {
			let r = fu(n, "next");
			wa(r) && (0 === r.offset ? r = Ia(r.origin, "previous").getFlipped() : r.offset === r.origin.getTextContentSize() && (r = Ia(r.origin, "next"))), r.origin.is(e) && (Ma(r) || t(342, e.getKey(), e.getType()), r = iu(r)), (e.is(r.getNodeAtCaret()) || e.is(r.getFlipped().getNodeAtCaret())) && e.remove(!0);
			for (let t = r; t; t = yu(t, o)) r = t;
			return wa(r) && t(283), r.insert(e.isInline() ? es$1().append(e) : e), fu(Ia(e.getLatest(), "next"), n.direction);
		}
		function xu(t) {
			return t;
		}
		function vu(t) {
			return t;
		}
		function Tu(t, e) {
			if (!e || t === e) return t;
			for (const n in e) if (t[n] !== e[n]) return {
				...t,
				...e
			};
			return t;
		}
		function ku(...t) {
			const e = [];
			for (const n of t) if (n && "string" == typeof n) for (const [t] of n.matchAll(/\S+/g)) e.push(t);
			return e;
		}
		function bu(t, ...e) {
			const n = ku(...e);
			n.length > 0 && t.classList.add(...n);
		}
		function Eu(...t) {
			return () => {
				for (let e = t.length - 1; e >= 0; e--) t[e]();
				t.length = 0;
			};
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/@lexical+selection@0.49.0_typescript@6.0.3/node_modules/@lexical/selection/dist/LexicalSelection.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		function R(e) {
			const t = vc().getElementByKey(e.getKey());
			if (null === t) return null;
			const o = t.ownerDocument.defaultView;
			return null === o ? null : o.getComputedStyle(t);
		}
		function O$2(e) {
			return R(Bi(e) ? e : e.getParentOrThrow());
		}
		function L(e, t, n = "self") {
			const o = e.getStartEndPoints();
			if (t.isSelected(e) && !Ks(t) && null !== o) {
				const [l, r] = o, i = e.isBackward(), s = l.getNode(), c = r.getNode(), g = t.is(s), a = t.is(c);
				if (g || a) {
					const [o, l] = yr(e), r = s.is(c), g = t.is(i ? c : s), a = t.is(i ? s : c);
					let d, p = 0;
					if (r) p = o > l ? l : o, d = o > l ? o : l;
					else if (g) p = i ? l : o, d = void 0;
					else if (a) p = 0, d = i ? o : l;
					const h = t.__text.slice(p, d);
					h !== t.__text && ("clone" === n && (t = Fc(t)), t.__text = h);
				}
			}
			return t;
		}
		function Z(e) {
			const t = ee$2(e);
			return null !== t && "vertical-rl" === t.writingMode;
		}
		function ee$2(e) {
			const t = e.anchor.getNode();
			return Pi(t) ? R(t) : O$2(t);
		}
		function te$2(e, n) {
			let o = Z(e) ? !n : n;
			oe$2(e) && (o = !o);
			const l = tu(e.focus, o ? "previous" : "next");
			if (uu(l)) return !1;
			if (wa(l) && !er(l.origin) && l.origin.isUnmergeable()) {
				const e = l.getNodeAtCaret();
				if (Xo(e) && !er(e)) return !0;
			}
			for (const e of ja$1(l)) {
				if (Aa(e)) return !e.origin.isInline();
				if (!Pi(e.origin)) {
					if (Ki(e.origin)) return !0;
					break;
				}
			}
			return !1;
		}
		function ne$2(e, t, n, o) {
			e.modify(t ? "extend" : "move", n, o);
		}
		function oe$2(e) {
			const t = ee$2(e);
			return null !== t && "rtl" === t.direction;
		}
		function le$1(e, t, n) {
			const o = oe$2(e);
			let l;
			l = Z(e) || o ? !n : n, ne$2(e, t, l, "character");
		}
		function Mt(t, e) {
			return null !== t && Object.getPrototypeOf(t).constructor.name === e.name;
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/@lexical+extension@0.49.0_typescript@6.0.3/node_modules/@lexical/extension/dist/LexicalExtension.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		const Kt$1 = Symbol.for("preact-signals");
		function $t$1() {
			if (Bt$1 > 1) return void Bt$1--;
			let t, e = !1;
			for (function() {
				let t = Wt$1;
				for (Wt$1 = void 0; void 0 !== t;) t.S.v === t.v && (t.S.i = t.i), t = t.o;
			}(); void 0 !== zt$1;) {
				let n = zt$1;
				for (zt$1 = void 0, Vt$1++; void 0 !== n;) {
					const i = n.u;
					if (n.u = void 0, n.f &= -3, !(8 & n.f) && qt$1(n)) try {
						n.c();
					} catch (n) {
						e || (t = n, e = !0);
					}
					n = i;
				}
			}
			if (Vt$1 = 0, Bt$1--, e) throw t;
		}
		let Tt$1, zt$1;
		function Ut$1(t) {
			const e = Tt$1;
			Tt$1 = void 0;
			try {
				return t();
			} finally {
				Tt$1 = e;
			}
		}
		let Wt$1, Bt$1 = 0, Vt$1 = 0, Zt$1 = 0, Ht$1 = 0;
		function Jt$1(t) {
			if (void 0 === Tt$1) return;
			let e = t.n;
			return void 0 === e || e.t !== Tt$1 ? (e = {
				i: 0,
				S: t,
				p: Tt$1.s,
				n: void 0,
				t: Tt$1,
				e: void 0,
				x: void 0,
				r: e
			}, void 0 !== Tt$1.s && (Tt$1.s.n = e), Tt$1.s = e, t.n = e, 32 & Tt$1.f && t.S(e), e) : -1 === e.i ? (e.i = 0, void 0 !== e.n && (e.n.p = e.p, void 0 !== e.p && (e.p.n = e.n), e.p = Tt$1.s, e.n = void 0, Tt$1.s.n = e, Tt$1.s = e), e) : void 0;
		}
		function Xt$1(t, e) {
			this.v = t, this.i = 0, this.n = void 0, this.t = void 0, this.l = 0, this.W = null == e ? void 0 : e.watched, this.Z = null == e ? void 0 : e.unwatched, this.name = null == e ? void 0 : e.name;
		}
		function qt$1(t) {
			for (let e = t.s; void 0 !== e; e = e.n) if (e.S.i !== e.i || !e.S.h() || e.S.i !== e.i) return !0;
			return !1;
		}
		function Qt$1(t) {
			for (let e = t.s; void 0 !== e; e = e.n) {
				const n = e.S.n;
				if (void 0 !== n && (e.r = n), e.S.n = e, e.i = -1, void 0 === e.n) {
					t.s = e;
					break;
				}
			}
		}
		function te$1(t) {
			let e, n = t.s;
			for (; void 0 !== n;) {
				const t = n.p;
				-1 === n.i ? (n.S.U(n), void 0 !== t && (t.n = n.n), void 0 !== n.n && (n.n.p = t)) : e = n, n.S.n = n.r, void 0 !== n.r && (n.r = void 0), n = t;
			}
			t.s = e;
		}
		function ee$1(t, e) {
			Xt$1.call(this, void 0), this.x = t, this.s = void 0, this.g = Ht$1 - 1, this.f = 4, this.W = null == e ? void 0 : e.watched, this.Z = null == e ? void 0 : e.unwatched, this.name = null == e ? void 0 : e.name;
		}
		function ie$1(t) {
			const e = t.m;
			if (t.m = void 0, "function" == typeof e) {
				Bt$1++;
				const n = Tt$1;
				Tt$1 = void 0;
				try {
					e();
				} catch (e) {
					throw t.f &= -2, t.f |= 8, oe$1(t), e;
				} finally {
					Tt$1 = n, $t$1();
				}
			}
		}
		function oe$1(t) {
			for (let e = t.s; void 0 !== e; e = e.n) e.S.U(e);
			t.x = void 0, t.s = void 0, ie$1(t);
		}
		function se$1(t) {
			if (Tt$1 !== this) throw new Error("Out-of-order effect");
			te$1(this), Tt$1 = t, this.f &= -2, 8 & this.f && oe$1(this), $t$1();
		}
		function re$1(t, e) {
			this.x = t, this.m = void 0, this.s = void 0, this.u = void 0, this.f = 32, this.name = null == e ? void 0 : e.name;
		}
		function ce$1(t, e) {
			const n = new re$1(t, e);
			try {
				n.c();
			} catch (t) {
				throw n.d(), t;
			}
			const i = n.d.bind(n);
			return i[Symbol.dispose] = i, i;
		}
		Xt$1.prototype.brand = Kt$1, Xt$1.prototype.h = function() {
			return !0;
		}, Xt$1.prototype.S = function(t) {
			const e = this.t;
			e !== t && void 0 === t.e && (t.x = e, this.t = t, void 0 !== e ? e.e = t : Ut$1(() => {
				var t;
				null == (t = this.W) || t.call(this);
			}));
		}, Xt$1.prototype.U = function(t) {
			if (void 0 !== this.t) {
				const e = t.e, n = t.x;
				void 0 !== e && (e.x = n, t.e = void 0), void 0 !== n && (n.e = e, t.x = void 0), t === this.t && (this.t = n, void 0 === n && Ut$1(() => {
					var t;
					null == (t = this.Z) || t.call(this);
				}));
			}
		}, Xt$1.prototype.subscribe = function(t) {
			return ce$1(() => {
				const e = this.value, n = Tt$1;
				Tt$1 = void 0;
				try {
					t(e);
				} finally {
					Tt$1 = n;
				}
			}, { name: "sub" });
		}, Xt$1.prototype.valueOf = function() {
			return this.value;
		}, Xt$1.prototype.toString = function() {
			return this.value + "";
		}, Xt$1.prototype.toJSON = function() {
			return this.value;
		}, Xt$1.prototype.peek = function() {
			const t = Tt$1;
			Tt$1 = void 0;
			try {
				return this.value;
			} finally {
				Tt$1 = t;
			}
		}, Object.defineProperty(Xt$1.prototype, "value", {
			get() {
				const t = Jt$1(this);
				return void 0 !== t && (t.i = this.i), this.v;
			},
			set(t) {
				if (t !== this.v) {
					if (Vt$1 > 100) throw new Error("Cycle detected");
					(function(t) {
						0 !== Bt$1 && 0 === Vt$1 && t.l !== Zt$1 && (t.l = Zt$1, Wt$1 = {
							S: t,
							v: t.v,
							i: t.i,
							o: Wt$1
						});
					})(this), this.v = t, this.i++, Ht$1++, Bt$1++;
					try {
						for (let t = this.t; void 0 !== t; t = t.x) t.t.N();
					} finally {
						$t$1();
					}
				}
			}
		}), ee$1.prototype = new Xt$1(), ee$1.prototype.h = function() {
			if (this.f &= -3, 1 & this.f) return !1;
			if (32 == (36 & this.f)) return !0;
			if (this.f &= -5, this.g === Ht$1) return !0;
			if (this.g = Ht$1, this.f |= 1, this.i > 0 && !qt$1(this)) return this.f &= -2, !0;
			const t = Tt$1;
			try {
				Qt$1(this), Tt$1 = this;
				const t = this.x();
				(16 & this.f || this.v !== t || 0 === this.i) && (this.v = t, this.f &= -17, this.i++);
			} catch (t) {
				this.v = t, this.f |= 16, this.i++;
			}
			return Tt$1 = t, te$1(this), this.f &= -2, !0;
		}, ee$1.prototype.S = function(t) {
			if (void 0 === this.t) {
				this.f |= 36;
				for (let t = this.s; void 0 !== t; t = t.n) t.S.S(t);
			}
			Xt$1.prototype.S.call(this, t);
		}, ee$1.prototype.U = function(t) {
			if (void 0 !== this.t && (Xt$1.prototype.U.call(this, t), void 0 === this.t)) {
				this.f &= -33;
				for (let t = this.s; void 0 !== t; t = t.n) t.S.U(t);
			}
		}, ee$1.prototype.N = function() {
			if (!(2 & this.f)) {
				this.f |= 6;
				for (let t = this.t; void 0 !== t; t = t.x) t.t.N();
			}
		}, Object.defineProperty(ee$1.prototype, "value", { get() {
			if (1 & this.f) throw new Error("Cycle detected");
			const t = Jt$1(this);
			if (this.h(), void 0 !== t && (t.i = this.i), 16 & this.f) throw this.v;
			return this.v;
		} }), re$1.prototype.c = function() {
			const t = this.S();
			try {
				if (8 & this.f) return;
				if (void 0 === this.x) return;
				const t = this.x();
				"function" == typeof t && (this.m = t);
			} finally {
				t();
			}
		}, re$1.prototype.S = function() {
			if (1 & this.f) throw new Error("Cycle detected");
			this.f |= 1, this.f &= -9, ie$1(this), Qt$1(this), Bt$1++;
			const t = Tt$1;
			return Tt$1 = this, se$1.bind(this, t);
		}, re$1.prototype.N = function() {
			2 & this.f || (this.f |= 2, this.u = zt$1, zt$1 = this);
		}, re$1.prototype.d = function() {
			this.f |= 8, 1 & this.f || oe$1(this);
		}, re$1.prototype.dispose = function() {
			this.d();
		};
		function ve$1(t) {
			return ("function" == typeof t.nodes ? t.nodes() : t.nodes) || [];
		}
		function Ie$1(t, ...e) {
			const n = new URL("https://lexical.dev/docs/error"), i = new URLSearchParams();
			i.append("code", t);
			for (const t of e) i.append("v", t);
			throw n.search = i.toString(), Error(`Minified Lexical error #${t}; visit ${n.toString()} for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`);
		}
		let Fe$1;
		try {
			Fe$1 = "0.49.0+prod.esm";
		} catch (t) {}
		const Me$1 = Fe$1 ?? "\"<unknown>+source\"", ke$1 = new Set([
			"__proto__",
			"constructor",
			"prototype"
		]);
		function _e$1(t, e) {
			if (t && e && !Array.isArray(e) && "object" == typeof t && "object" == typeof e) {
				const n = t, i = e;
				for (const t in i) !ke$1.has(t) && Object.prototype.hasOwnProperty.call(i, t) && (n[t] = _e$1(n[t], i[t]));
				return t;
			}
			return e;
		}
		const Ae$1 = 0, Pe$1 = 1, Le$1 = 2, Ke$1 = 3, $e$1 = 4, je$1 = 5, Te$1 = 6, ze$1 = 7;
		function Ue$1(t) {
			return t.id === Ae$1;
		}
		function We$1(t) {
			return t.id === Le$1;
		}
		function Be$1(t) {
			return function(t) {
				return t.id === Pe$1;
			}(t) || Ie$1(305, String(t.id), String(Pe$1)), Object.assign(t, { id: Le$1 });
		}
		const Ve$1 = /* @__PURE__ */ new Set();
		var Ge$1 = class {
			builder;
			configs;
			_dependency;
			_peerNameSet;
			extension;
			state;
			_signal;
			constructor(t, e) {
				this.builder = t, this.extension = e, this.configs = /* @__PURE__ */ new Set(), this.state = { id: Ae$1 };
			}
			mergeConfigs() {
				let t = this.extension.config || {};
				const e = this.extension.mergeConfig ? this.extension.mergeConfig.bind(this.extension) : Tu;
				for (const n of this.configs) t = e(t, n);
				return t;
			}
			init(t) {
				const e = this.state;
				We$1(e) || Ie$1(306, String(e.id));
				const n = {
					getDependency: this.getInitDependency.bind(this),
					getDirectDependentNames: this.getDirectDependentNames.bind(this),
					getPeer: this.getInitPeer.bind(this),
					getPeerNameSet: this.getPeerNameSet.bind(this)
				}, i = {
					...n,
					getDependency: this.getDependency.bind(this),
					getInitResult: this.getInitResult.bind(this),
					getPeer: this.getPeer.bind(this)
				}, o = function(t, e, n) {
					return Object.assign(t, {
						config: e,
						id: Ke$1,
						registerState: n
					});
				}(e, this.mergeConfigs(), n);
				let s;
				this.state = o, this.extension.init && (s = this.extension.init(t, o.config, n)), this.state = function(t, e, n) {
					return Object.assign(t, {
						id: $e$1,
						initResult: e,
						registerState: n
					});
				}(o, s, i);
			}
			build(t) {
				const e = this.state;
				let n;
				e.id !== $e$1 && Ie$1(307, String(e.id), String(je$1)), this.extension.build && (n = this.extension.build(t, e.config, e.registerState));
				const i = {
					...e.registerState,
					getOutput: () => n,
					getSignal: this.getSignal.bind(this)
				};
				this.state = function(t, e, n) {
					return Object.assign(t, {
						id: je$1,
						output: e,
						registerState: n
					});
				}(e, n, i);
			}
			register(t, e) {
				this._signal = e;
				const n = this.state;
				n.id !== je$1 && Ie$1(308, String(n.id), String(je$1));
				const i = this.extension.register && this.extension.register(t, n.config, n.registerState);
				return this.state = function(t) {
					return Object.assign(t, { id: Te$1 });
				}(n), () => {
					const t = this.state;
					t.id !== ze$1 && Ie$1(309, String(n.id), String(ze$1)), this.state = function(t) {
						return Object.assign(t, { id: je$1 });
					}(t), i && i();
				};
			}
			afterRegistration(t) {
				const e = this.state;
				let n;
				return e.id !== Te$1 && Ie$1(310, String(e.id), String(Te$1)), this.extension.afterRegistration && (n = this.extension.afterRegistration(t, e.config, e.registerState)), this.state = function(t) {
					return Object.assign(t, { id: ze$1 });
				}(e), n;
			}
			getSignal() {
				return void 0 === this._signal && Ie$1(311), this._signal;
			}
			getInitResult() {
				void 0 === this.extension.init && Ie$1(312, this.extension.name);
				const t = this.state;
				return function(t) {
					return t.id >= $e$1;
				}(t) || Ie$1(313, String(t.id), String($e$1)), t.initResult;
			}
			getInitPeer(t) {
				const e = this.builder.extensionNameMap.get(t);
				return e ? e.getExtensionInitDependency() : void 0;
			}
			getExtensionInitDependency() {
				const t = this.state;
				return function(t) {
					return t.id >= Ke$1;
				}(t) || Ie$1(314, String(t.id), String(Ke$1)), { config: t.config };
			}
			getPeer(t) {
				const e = this.builder.extensionNameMap.get(t);
				return e ? e.getExtensionDependency() : void 0;
			}
			getInitDependency(t) {
				const e = this.builder.getExtensionRep(t);
				return void 0 === e && Ie$1(315, this.extension.name, t.name), e.getExtensionInitDependency();
			}
			getDependency(t) {
				const e = this.builder.getExtensionRep(t);
				return void 0 === e && Ie$1(315, this.extension.name, t.name), e.getExtensionDependency();
			}
			getState() {
				const t = this.state;
				return function(t) {
					return t.id >= ze$1;
				}(t) || Ie$1(316, String(t.id), String(ze$1)), t;
			}
			getDirectDependentNames() {
				return this.builder.incomingEdges.get(this.extension.name) || Ve$1;
			}
			getPeerNameSet() {
				let t = this._peerNameSet;
				return t || (t = new Set((this.extension.peerDependencies || []).map(([t]) => t)), this._peerNameSet = t), t;
			}
			getExtensionDependency() {
				if (!this._dependency) {
					const t = this.state;
					(function(t) {
						return t.id >= je$1;
					})(t) || Ie$1(317, this.extension.name), this._dependency = {
						config: t.config,
						init: t.initResult,
						output: t.output
					};
				}
				return this._dependency;
			}
		};
		const Ze$1 = { tag: xo };
		function He$1() {
			const t = nl();
			t.isEmpty() && t.append(es$1());
		}
		const Je$1 = /* @__PURE__ */ xu({
			config: /* @__PURE__ */ vu({
				setOptions: Ze$1,
				updateOptions: Ze$1
			}),
			init: ({ $initialEditorState: t = He$1 }) => ({
				$initialEditorState: t,
				initialized: !1
			}),
			afterRegistration(t, { updateOptions: e, setOptions: n }, i) {
				const o = i.getInitResult();
				if (!o.initialized) {
					o.initialized = !0;
					const { $initialEditorState: i } = o;
					if (Ui(i)) t.setEditorState(i, n);
					else if ("function" == typeof i) t.update(() => {
						i(t);
					}, e);
					else if (i && ("string" == typeof i || "object" == typeof i)) {
						const e = t.parseEditorState(i);
						t.setEditorState(e, n);
					}
				}
				return () => {};
			},
			name: "@lexical/extension/InitialState",
			nodes: [
				zi,
				Wo,
				Ji,
				Zo,
				Zi
			]
		}), Xe$1 = Symbol.for("@lexical/extension/LexicalBuilder");
		function qe$1() {}
		function Qe$1(t) {
			throw t;
		}
		function tn$1(t) {
			return Array.isArray(t) ? t : [t];
		}
		const en$2 = Me$1;
		var nn$1 = class nn$1 {
			roots;
			extensionNameMap;
			outgoingConfigEdges;
			incomingEdges;
			conflicts;
			_sortedExtensionReps;
			PACKAGE_VERSION;
			constructor(t) {
				this.outgoingConfigEdges = /* @__PURE__ */ new Map(), this.incomingEdges = /* @__PURE__ */ new Map(), this.extensionNameMap = /* @__PURE__ */ new Map(), this.conflicts = /* @__PURE__ */ new Map(), this.PACKAGE_VERSION = en$2, this.roots = t;
				for (const e of t) this.addExtension(e);
			}
			static fromExtensions(t) {
				const e = [tn$1(Je$1)];
				for (const n of t) e.push(tn$1(n));
				return new nn$1(e);
			}
			static maybeFromEditor(t) {
				const e = t[Xe$1];
				return e && (e.PACKAGE_VERSION !== en$2 && Ie$1(292, e.PACKAGE_VERSION, en$2), e instanceof nn$1 || Ie$1(293)), e;
			}
			static fromEditor(t) {
				const e = nn$1.maybeFromEditor(t);
				return void 0 === e && Ie$1(294), e;
			}
			constructEditor() {
				const { $initialEditorState: t, onError: e, onWarn: n, ...i } = this.buildCreateEditorArgs(), o = Object.assign(ys({
					...i,
					...e ? { onError: (t) => {
						e(t, o);
					} } : {},
					...n ? { onWarn: (t) => {
						n(t, o);
					} } : {}
				}), { [Xe$1]: this });
				for (const t of this.sortedExtensionReps()) t.build(o);
				return o;
			}
			buildEditor() {
				let t = qe$1;
				function e() {
					try {
						t();
					} finally {
						t = qe$1;
					}
				}
				const n = Object.assign(this.constructEditor(), {
					dispose: e,
					[Symbol.dispose]: e
				});
				return t = Eu(this.registerEditor(n), () => n.setRootElement(null)), n;
			}
			hasExtensionByName(t) {
				return this.extensionNameMap.has(t);
			}
			getExtensionRep(t) {
				const e = this.extensionNameMap.get(t.name);
				if (e) return e.extension !== t && Ie$1(295, t.name), e;
			}
			addEdge(t, e, n) {
				const i = this.outgoingConfigEdges.get(t);
				i ? i.set(e, n) : this.outgoingConfigEdges.set(t, new Map([[e, n]]));
				const o = this.incomingEdges.get(e);
				o ? o.add(t) : this.incomingEdges.set(e, new Set([t]));
			}
			addExtension(t) {
				void 0 !== this._sortedExtensionReps && Ie$1(296);
				const [n] = tn$1(t);
				"string" != typeof n.name && Ie$1(297, typeof n.name);
				let i = this.extensionNameMap.get(n.name);
				if (void 0 !== i && i.extension !== n && Ie$1(298, n.name), !i) {
					i = new Ge$1(this, n), this.extensionNameMap.set(n.name, i);
					const t = this.conflicts.get(n.name);
					"string" == typeof t && Ie$1(299, n.name, t);
					for (const t of n.conflictsWith || []) this.extensionNameMap.has(t) && Ie$1(299, n.name, t), this.conflicts.set(t, n.name);
					for (const t of n.dependencies || []) {
						const e = tn$1(t);
						this.addEdge(n.name, e[0].name, e.slice(1)), this.addExtension(e);
					}
					for (const [t, e] of n.peerDependencies || []) this.addEdge(n.name, t, e ? [e] : []);
				}
			}
			sortedExtensionReps() {
				if (this._sortedExtensionReps) return this._sortedExtensionReps;
				const t = [], e = (n, i) => {
					let o = n.state;
					if (We$1(o)) return;
					const s = n.extension.name;
					var r;
					Ue$1(o) || Ie$1(300, s, i || "[unknown]"), Ue$1(r = o) || Ie$1(304, String(r.id), String(Ae$1)), o = Object.assign(r, { id: Pe$1 }), n.state = o;
					const c = this.outgoingConfigEdges.get(s);
					if (c) for (const t of c.keys()) {
						const n = this.extensionNameMap.get(t);
						n && e(n, s);
					}
					o = Be$1(o), n.state = o, t.push(n);
				};
				for (const t of this.extensionNameMap.values()) Ue$1(t.state) && e(t);
				for (const e of t) for (const [t, n] of this.outgoingConfigEdges.get(e.extension.name) || []) if (n.length > 0) {
					const e = this.extensionNameMap.get(t);
					if (e) for (const t of n) e.configs.add(t);
				}
				for (const [t, ...e] of this.roots) if (e.length > 0) {
					const n = this.extensionNameMap.get(t.name);
					void 0 === n && Ie$1(301, t.name);
					for (const t of e) n.configs.add(t);
				}
				return this._sortedExtensionReps = t, this._sortedExtensionReps;
			}
			registerEditor(t) {
				const e = this.sortedExtensionReps(), n = new AbortController(), i = [() => n.abort()], o = n.signal;
				for (const n of e) {
					const e = n.register(t, o);
					e && i.push(e);
				}
				for (const n of e) {
					const e = n.afterRegistration(t);
					e && i.push(e);
				}
				return Eu(...i);
			}
			buildCreateEditorArgs() {
				const t = {}, e = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), o = {}, s = {}, r = this.sortedExtensionReps();
				for (const c of r) {
					const { extension: r } = c;
					if (void 0 !== r.onError && (t.onError = r.onError), void 0 !== r.onWarn && (t.onWarn = r.onWarn), void 0 !== r.disableEvents && (t.disableEvents = r.disableEvents), void 0 !== r.parentEditor && (t.parentEditor = r.parentEditor), void 0 !== r.editable && (t.editable = r.editable), void 0 !== r.namespace && (t.namespace = r.namespace), void 0 !== r.$initialEditorState && (t.$initialEditorState = r.$initialEditorState), r.nodes) for (const t of ve$1(r)) {
						if ("function" != typeof t) {
							const e = n.get(t.replace);
							e && Ie$1(302, r.name, t.replace.name, e.extension.name), n.set(t.replace, c);
						}
						e.add(t);
					}
					if (r.html) {
						if (r.html.export) for (const [t, e] of r.html.export.entries()) i.set(t, e);
						r.html.import && Object.assign(o, r.html.import);
					}
					r.theme && _e$1(s, r.theme);
				}
				Object.keys(s).length > 0 && (t.theme = s), e.size && (t.nodes = [...e]);
				const c = Object.keys(o).length > 0, a = i.size > 0;
				(c || a) && (t.html = {}, c && (t.html.import = o), a && (t.html.export = i));
				for (const e of r) e.init(t);
				return t.onError || (t.onError = Qe$1), t;
			}
		};
		function sn$1(t, e) {
			const n = nn$1.maybeFromEditor(t);
			if (!n) return;
			const i = n.extensionNameMap.get(e);
			return i ? i.getExtensionDependency() : void 0;
		}
		var hn$1 = class extends Li {
			$config() {
				return this.config("horizontalrule", { importDOM: { hr: () => ({
					conversion: gn$1,
					priority: 0
				}) } });
			}
			exportDOM() {
				return { element: Zl().createElement("hr") };
			}
			createDOM(t) {
				const e = Zl().createElement("hr");
				return bu(e, t.theme.hr), e;
			}
			getTextContent() {
				return "\n";
			}
			isInline() {
				return !1;
			}
			updateDOM() {
				return !1;
			}
		};
		function gn$1() {
			return { node: pn$1() };
		}
		function pn$1() {
			return Vc(hn$1);
		}
		new Set([No, ko]);
		Date.now;
		//#endregion
		//#region ../../../node_modules/.pnpm/@lexical+html@0.49.0_typescript@6.0.3/node_modules/@lexical/html/dist/LexicalHtml.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		function nt$1(t, ...e) {
			const n = new URL("https://lexical.dev/docs/error"), o = new URLSearchParams();
			o.append("code", t);
			for (const t of e) o.append("v", t);
			throw n.search = o.toString(), Error(`Minified Lexical error #${t}; visit ${n.toString()} for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`);
		}
		let ot;
		function rt(t, e) {
			const { key: n } = e;
			return t && n in t ? t[n] : e.defaultValue;
		}
		function st(t) {
			return ot && ot.editor === t ? ot : void 0;
		}
		function it(t, e) {
			const n = st(e);
			return n && n[t];
		}
		function ct(t, e) {
			if ("cfg" in e) {
				const { cfg: n, updater: o } = e;
				return [n, o(rt(t, n))];
			}
			return e;
		}
		function lt(t, e) {
			let n = e;
			for (const o of t) {
				const [t, r] = ct(n, o), s = t.key;
				if (n === e && rt(n, t) === r) continue;
				const i = n === e || void 0 === n ? ut(e) : n;
				i[s] = r, n = i;
			}
			return n;
		}
		function ut(t) {
			return Object.create(t || null);
		}
		function ft(t, e) {
			return [t, e];
		}
		function dt(t, n, o, r = vc()) {
			const s = ot, i = st(r);
			try {
				return ot = {
					...i,
					editor: r,
					[t]: n
				}, o();
			} finally {
				ot = s;
			}
		}
		function pt$2(t, n = () => {}) {
			return (o, r = vc()) => (e) => {
				const s = st(r), i = s && s[t], c = lt(o, i || n(r));
				return c && c !== i ? dt(t, c, e, r) : e();
			};
		}
		function ht$1(t, e, o, r) {
			return Object.assign(mt$2(Symbol(e), {
				isEqual: r,
				parse: o
			}), { [t]: !0 });
		}
		const yt$1 = "@lexical/html/DOM", xt$1 = Symbol.for("@lexical/html/DOMExportContext"), St = "@lexical/html/DOMImport", $t = Symbol.for("@lexical/html/DOMImportContext");
		function Ct(t, e, n) {
			return ht$1(xt$1, t, e, n);
		}
		const kt = /* @__PURE__ */ Ct("isExport", Boolean);
		function Dt(t) {
			const e = sn$1(t, yt$1);
			return e ? e.output.defaults : void 0;
		}
		function Ot(t) {
			const e = sn$1(t, yt$1);
			return e ? e.output.runtime : void 0;
		}
		function Nt(t = vc()) {
			const n = Ot(t);
			return n ? n.getSessionConfig() : Tc(t);
		}
		const Et = pt$2(xt$1, Dt);
		new Map([[zi, () => {
			const t = Zl().createElement("div");
			return t.role = "textbox", { element: t };
		}]]);
		const re = Symbol.for("@lexical/html/SelectorImpl");
		function se(t, e) {
			const n = {
				kind: "element",
				predicate: (o = e, 0 === o.length ? gc : 1 === o.length ? o[0] : (t, e) => {
					for (const n of o) if (!n(t, e)) return !1;
					return !0;
				}),
				tags: t
			};
			var o;
			const s = (n) => se(t, [...e, n]);
			return {
				[re]: n,
				attr: (t, e, n) => s(le(t, e, n)),
				classAll: (...t) => s(ce(t)),
				classAny: (...t) => s(function(t) {
					const e = ie(t);
					if (0 === e.length) return () => !1;
					return (t) => {
						if (!gc(t)) return !1;
						const n = t.classList;
						for (const t of e) if (n.contains(t)) return !0;
						return !1;
					};
				}(t)),
				styleAny: (t, e, n) => s(function(t, e, n) {
					if ("string" == typeof e) return (n) => gc(n) && n.style.getPropertyValue(t) === e;
					if (e instanceof RegExp) {
						const o = n && n.capture, s = e;
						return (e, n) => {
							if (!gc(e)) return !1;
							const i = e.style.getPropertyValue(t);
							if (!i) return !1;
							const c = i.match(s);
							return null !== c && (void 0 !== o && (n[o] = c), !0);
						};
					}
					nt$1(362, JSON.stringify(t));
				}(t, e, n))
			};
		}
		function ie(t) {
			const e = [];
			for (const n of t) n && e.push(n);
			return e;
		}
		function ce(t) {
			const e = ie(t);
			return 0 === e.length ? () => !0 : (t) => {
				if (!gc(t)) return !1;
				const n = t.classList;
				for (const t of e) if (!n.contains(t)) return !1;
				return !0;
			};
		}
		function le(t, e, n) {
			if (!0 === e) return (e) => gc(e) && e.hasAttribute(t);
			if ("string" == typeof e) return (n) => gc(n) && n.getAttribute(t) === e;
			if (e instanceof RegExp) {
				const o = n && n.capture, s = e;
				return (e, n) => {
					if (!gc(e)) return !1;
					const i = e.getAttribute(t);
					if (null == i) return !1;
					const c = i.match(s);
					return null !== c && (void 0 !== o && (n[o] = c), !0);
				};
			}
			nt$1(361, JSON.stringify(t));
		}
		const ue = {
			kind: "text",
			predicate: zs,
			tags: /* @__PURE__ */ new Set()
		}, fe = { [re]: ue }, ae = {
			kind: "comment",
			predicate: (t) => 8 === t.nodeType,
			tags: /* @__PURE__ */ new Set()
		}, de$1 = { [re]: ae }, pe = {
			any: () => se(/* @__PURE__ */ new Set(), []),
			comment: () => de$1,
			tag(...t) {
				t.length > 0 || nt$1(363);
				const e = /* @__PURE__ */ new Set();
				for (const n of t) e.add(n.toUpperCase());
				return se(e, []);
			},
			text: () => fe
		};
		function Ne(t) {
			const e = sn$1(t, St);
			return e ? e.output.defaults : void 0;
		}
		function Ee(t, n = vc()) {
			return rt(function(t) {
				return it($t, t) || Ne(t);
			}(n), t);
		}
		const Ie = pt$2($t, Ne), Le = pe;
		new Set([
			"center",
			"end",
			"justify",
			"left",
			"right",
			"start"
		]);
		new Set([
			"font-weight",
			"font-style",
			"text-decoration",
			"vertical-align"
		]);
		Le.tag("b", "strong", "em", "i", "code", "mark", "s", "sub", "sup", "u", "span");
		Le.text();
		Le.tag("script", "style");
		Le.tag("br");
		Le.tag("p"), Le.tag("hr"), Le.any();
		function sn(t, e) {
			return zs(e) ? t.textIndices : 8 === e.nodeType ? t.commentIndices : gc(e) ? t.byTag.get(e.nodeName) || t.wildcardIndices : cn;
		}
		const cn = Object.freeze([]);
		const an = Object.freeze({});
		function dn(t, e) {
			return {
				$importChildren: (e, n) => function(t, e, n) {
					const o = n && n.rules ? n.rules.dispatch : void 0;
					o && t.overlays.push(o);
					try {
						const o = () => pn(t, e, n);
						return n && n.context ? Ie(n.context, t.editor)(o) : o();
					} finally {
						o && t.overlays.pop();
					}
				}(t, e, n),
				$importOne: (e, n) => hn(t, e, n),
				captures: e,
				get: (e) => Ee(e, t.editor),
				session: t.session
			};
		}
		function pn(t, e, n) {
			const o = n && n.$onChild, r = [];
			for (const n of Array.from(e.childNodes)) {
				const e = hn(t, n, void 0);
				for (const t of e) {
					const e = o ? o(t) : t;
					null != e && r.push(e);
				}
			}
			const s = n && n.$after ? n.$after(r) : r, i = n && n.schema;
			return i ? function(t, e, n, o) {
				const r = [];
				let s = null;
				const i = () => {
					if (null === s) return;
					const e = s;
					if (s = null, t.$packageRun) {
						const s = t.$packageRun(e, n, o);
						if (s.length > 0) {
							for (const t of s) r.push(t);
							return;
						}
					}
					if ("hoist" === t.onReject) for (const t of e) r.push(t);
				};
				for (const o of e) t.$accepts(o, n) ? (i(), r.push(o)) : (null === s && (s = []), s.push(o));
				return i(), t.$finalize ? t.$finalize(r, n) : r;
			}(i, s, null, e) : s;
		}
		function hn(t, e, n) {
			const o = () => function(t, e) {
				const n = function(t, e) {
					const n = [];
					for (let o = t.overlays.length - 1; o >= 0; o--) {
						const r = t.overlays[o], s = sn(r, e);
						s.length > 0 && n.push({
							dispatch: r,
							indices: s
						});
					}
					const o = sn(t.dispatch, e);
					o.length > 0 && n.push({
						dispatch: t.dispatch,
						indices: o
					});
					return n;
				}(t, e);
				if (0 === n.length) return gn(t, e);
				let o = 0, r = 0;
				const s = () => {
					for (; o < n.length;) {
						const { dispatch: i, indices: c } = n[o];
						for (; r < c.length;) {
							const n = c[r++], o = i.rules[n], l = {};
							if (o.predicate(e, l)) {
								const n = dn(t, 0 === Object.keys(l).length ? an : l);
								try {
									return o.$import(n, e, s);
								} catch (t) {
									throw t;
								}
							}
						}
						o++, r = 0;
					}
					return gn(t, e);
				};
				return s();
			}(t, e);
			return n && n.context ? Ie(n.context, t.editor)(o) : o();
		}
		function gn(t, e) {
			if (0 === e.childNodes.length) return [];
			const n = [];
			for (const o of Array.from(e.childNodes)) {
				const e = hn(t, o, void 0);
				for (const t of e) n.push(t);
			}
			return n;
		}
		pe.any();
		pe.any, pe.comment, pe.tag, pe.text;
		new Set(["STYLE", "SCRIPT"]);
		function Dn(t, n = null, o = vc()) {
			return Et([ft(kt, !0)], o)(() => {
				const e = nl(), r = Nt(o), s = ur(n) ? oa(n.anchor.getNode()) : null, i = t.append.bind(t);
				for (const t of (Pi(s) ? s : e).getChildren()) Mn(o, t, i, n, r);
				return t;
			});
		}
		function On(t, e = null) {
			return ("undefined" == typeof document || "undefined" == typeof window && void 0 === global.window) && nt$1(338), gi(t), Dn(Zl().createElement("div"), e, t).innerHTML;
		}
		function Mn(e, n, o, i = null, c = Tc(e)) {
			let l = c.$shouldInclude(n, i, e);
			const u = c.$shouldExclude(n, i, e);
			let f = n;
			null !== i && Xo(n) && (f = L(i, n, "clone"));
			const { element: d, after: p, append: g, $getChildNodes: m } = c.$exportDOM(f, e);
			if (!d) return !1;
			const y = Zl().createDocumentFragment(), S = m ? m() : Pi(f) ? f.getChildren() : [], $ = l && dr(i) && Pi(n) ? null : i, v = y.append.bind(y);
			for (const t of S) {
				const o = Mn(e, t, v, $, c);
				!l && o && c.$extractWithChild(n, t, i, "html", e) && (l = !0);
			}
			if (l && !u) {
				if ((gc(d) || pc(d)) && (g ? g(y) : d.append(y)), o(d), p) {
					const t = p.call(f, d);
					t && (pc(d) ? d.replaceChildren(t) : d.replaceWith(t));
				}
			} else o(y);
			return l;
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/@lexical+clipboard@0.49.0_typescript@6.0.3/node_modules/@lexical/clipboard/dist/LexicalClipboard.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		function et(r, i, l = null) {
			const c = Ql(l), s = l ? Gl(l) : [], u = null !== l && s.length > 0;
			if (u && "function" == typeof c.caretPositionFromPoint) {
				const t = c.caretPositionFromPoint(r, i, { shadowRoots: s });
				if (null !== t && function(t, e) {
					for (let n = t; null !== n;) {
						if (n === e) return !0;
						n = wl(n);
					}
					return !1;
				}(t.offsetNode, l)) return {
					node: t.offsetNode,
					offset: t.offset
				};
			}
			if (u) {
				const t = l.getRootNode();
				if (ql(t)) {
					const e = t.elementFromPoint(r, i);
					if (null !== e && l.contains(e)) {
						const t = function(t, e, n, o) {
							const r = o.createRange(), i = (t) => e < t.top ? t.top - e : e > t.bottom ? e - t.bottom : 0, l = (e) => t < e.left ? e.left - t : t > e.right ? t - e.right : 0, c = o.createTreeWalker(n, NodeFilter.SHOW_TEXT);
							let s = null, u = Infinity, a = Infinity;
							for (let t = c.nextNode(); t; t = c.nextNode()) {
								r.selectNodeContents(t);
								for (const e of r.getClientRects()) {
									const n = i(e), o = l(e);
									(n < u || n === u && o < a) && (u = n, a = o, s = t);
								}
							}
							if (null === s) return null;
							let f = 0, p = Infinity, d = Infinity;
							for (let e = 0; e <= s.length; e++) {
								r.setStart(s, e), r.collapse(!0);
								const n = r.getBoundingClientRect(), o = i(n), l = Math.abs(t - n.left);
								(o < p || o === p && l < d) && (p = o, d = l, f = e);
							}
							return {
								node: s,
								offset: f
							};
						}(r, i, e, c);
						if (null !== t) return t;
					}
				}
			}
			if ("function" == typeof c.caretRangeFromPoint) {
				const t = c.caretRangeFromPoint(r, i);
				return null === t ? null : {
					node: t.startContainer,
					offset: t.startOffset
				};
			}
			if ("function" == typeof c.caretPositionFromPoint) {
				const t = c.caretPositionFromPoint(r, i);
				return null === t ? null : {
					node: t.offsetNode,
					offset: t.offset
				};
			}
			return null;
		}
		function nt(t, ...e) {
			const n = new URL("https://lexical.dev/docs/error"), o = new URLSearchParams();
			o.append("code", t);
			for (const t of e) o.append("v", t);
			throw n.search = o.toString(), Error(`Minified Lexical error #${t}; visit ${n.toString()} for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`);
		}
		function pt$1(t, e = Kr()) {
			return e ?? nt(166), ur(e) && e.isCollapsed() || 0 === e.getNodes().length ? "" : On(t, e);
		}
		function mt(t, e) {
			const n = t.getData("text/plain") || t.getData("text/uri-list");
			null != n && e.insertRawText(n);
		}
		const yt = "application/x-lexical-drag";
		function xt(t, e) {
			const n = { editorKey: e.getKey() };
			t.setData(yt, JSON.stringify(n));
		}
		function ht(t, e, n) {
			const o = t.dataTransfer;
			if (null === o) return !1;
			const r = function(t) {
				const e = t.getData(yt);
				if (!e) return null;
				let n;
				try {
					n = JSON.parse(e);
				} catch (t) {
					return null;
				}
				return null !== (o = n) && "object" == typeof o && "editorKey" in o && "string" == typeof o.editorKey ? n : null;
				var o;
			}(o);
			if (null === r) return !1;
			const i = function(t, e) {
				const n = et(t.clientX, t.clientY, e.getRootElement());
				if (null === n) return null;
				const o = Zs(n.node);
				if (null === o) return null;
				if (Xo(o)) return La(o, "next", n.offset);
				if (Pi(o)) return hu(o, n.offset, "next");
				const r = o.getParent();
				return null === r ? null : hu(r, o.getIndexWithinParent() + 1, "next");
			}(t, e);
			if (null === i) return !1;
			const l = yu(i);
			if (null === l) return !1;
			const c = r.editorKey === e.getKey(), u = Kr();
			if (c) {
				if (!ur(u) || u.isCollapsed()) return !1;
				if (function(t, e) {
					const { anchor: n, focus: o } = du(ru$1(e), "next");
					return Ya(n, t) < 0 && Ya(t, o) < 0;
				}(i, u)) return t.preventDefault(), !0;
				u.removeText();
			}
			if (!l.origin.isAttached()) return t.preventDefault(), !0;
			if (n(o, nu(Ja(l)), e), !c) {
				const t = e.getRootElement(), n = t ? t.ownerDocument : null, o = n ? function(t, e) {
					for (const n of Xl(e)) {
						const e = Ps(n);
						if (Ds(e) && e.getKey() === t && gc(n)) return n;
					}
					return null;
				}(r.editorKey, n) : null;
				null !== o && o.dispatchEvent(new InputEvent("beforeinput", {
					bubbles: !0,
					cancelable: !0,
					inputType: "deleteByDrag"
				}));
			}
			return t.preventDefault(), !0;
		}
		function bt(t, e) {
			return ht(t, e, (t, e) => mt(t, e));
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/@lexical+plain-text@0.49.0_typescript@6.0.3/node_modules/@lexical/plain-text/dist/LexicalPlainText.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		function M$1(e, t) {
			t.update(() => {
				if (null !== e) {
					const r = Mt(e, KeyboardEvent) ? null : e.clipboardData, o = Kr();
					if (null !== o && !o.isCollapsed() && null != r) {
						e.preventDefault();
						const a = pt$1(t);
						null !== a && r.setData("text/html", a), r.setData("text/plain", o.getTextContent());
					}
				}
			});
		}
		function O$1(n) {
			return Eu(n.registerCommand($e$2, (e) => {
				const t = Kr();
				return !!ur(t) && (t.deleteCharacter(e), !0);
			}, 0), n.registerCommand(qe$2, (e) => {
				const t = Kr();
				return !!ur(t) && (t.deleteWord(e), !0);
			}, 0), n.registerCommand(Ye$1, (e) => {
				const t = Kr();
				return !!ur(t) && (t.deleteLine(e), !0);
			}, 0), n.registerCommand(je$2, (t) => {
				const r = Kr();
				if (!ur(r)) return !1;
				if ("string" == typeof t) r.insertText(t);
				else {
					const n = t.dataTransfer;
					if (null != n) mt(n, r);
					else {
						const e = t.data;
						e && r.insertText(e);
					}
				}
				return !0;
			}, 0), n.registerCommand(Ve$2, () => {
				const e = Kr();
				return !!ur(e) && (e.removeText(), !0);
			}, 0), n.registerCommand(Ue$2, (e) => {
				const t = Kr();
				return !!ur(t) && (t.insertLineBreak(e), !0);
			}, 0), n.registerCommand(He$2, () => {
				const e = Kr();
				return !!ur(e) && (e.insertLineBreak(), !0);
			}, 0), n.registerCommand(on$1, (e) => {
				const t = Kr();
				if (!ur(t)) return !1;
				const r = e, n = r.shiftKey;
				return !!te$2(t, !0) && (r.preventDefault(), le$1(t, n, !0), !0);
			}, 0), n.registerCommand(en$3, (e) => {
				const t = Kr();
				if (!ur(t)) return !1;
				const r = e, n = r.shiftKey;
				return !!te$2(t, !1) && (r.preventDefault(), le$1(t, n, !1), !0);
			}, 0), n.registerCommand(un$2, (e) => {
				return !!ur(Kr()) && (!l || !s) && (e.preventDefault(), n.dispatchCommand($e$2, !0));
			}, 0), n.registerCommand(dn$1, (e) => {
				return !!ur(Kr()) && (e.preventDefault(), n.dispatchCommand($e$2, !1));
			}, 0), n.registerCommand(cn$1, (e) => {
				if (!ur(Kr())) return !1;
				if (null !== e) {
					if ((l || a || d$1) && s) return !1;
					e.preventDefault();
				}
				return n.dispatchCommand(Ue$2, !1);
			}, 0), n.registerCommand(kn, () => {
				const e = Kr();
				return xl(ur(e) && null !== oa(e.anchor.getNode()) ? e : null), !0;
			}, 0), n.registerCommand(vn$2, (e) => {
				return !!ur(Kr()) && (M$1(e, n), !0);
			}, 0), n.registerCommand(Tn, (e) => {
				return !!ur(Kr()) && (function(e, t) {
					M$1(e, t), t.update(() => {
						const e = Kr();
						ur(e) && e.removeText();
					}, { tag: "cut" });
				}(e, n), !0);
			}, 0), n.registerCommand(Je$2, (t) => {
				return !!ur(Kr()) && (function(t, r) {
					t.preventDefault(), r.update(() => {
						const r = Kr(), n = Mt(t, ClipboardEvent) ? t.clipboardData : null;
						null != n && ur(r) && mt(n, r);
					}, { tag: "paste" });
				}(t, n), !0);
			}, 0), n.registerCommand(yn$1, (e) => bt(e, n), 0), n.registerCommand(xn$1, (e) => {
				const t = Kr();
				return !!ur(t) && (t.isCollapsed() || null === e.dataTransfer || xt(e.dataTransfer, n), !0);
			}, 0));
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/@lexical+history@0.49.0_typescript@6.0.3/node_modules/@lexical/history/dist/LexicalHistory.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		function E(t, e, n, o, r) {
			if (null === t || 0 === n.size && 0 === o.size && !r) return 0;
			const a = e._selection, i = t._selection;
			if (r) return 1;
			if (!(ur(a) && ur(i) && i.isCollapsed() && a.isCollapsed())) return 0;
			const l = function(t, e, n) {
				const o = t._nodeMap, r = [];
				for (const t of e) {
					const e = o.get(t);
					void 0 !== e && r.push(e);
				}
				for (const [t, e] of n) {
					if (!e) continue;
					const n = o.get(t);
					void 0 === n || Bi(n) || r.push(n);
				}
				return r;
			}(e, n, o);
			if (0 === l.length) return 0;
			if (l.length > 1) {
				const n = e._nodeMap, o = n.get(a.anchor.key), r = n.get(i.anchor.key);
				return o && r && !t._nodeMap.has(o.__key) && Xo(o) && 1 === o.__text.length && 1 === a.anchor.offset ? 2 : 0;
			}
			const s = l[0], u = t._nodeMap.get(s.__key);
			if (!Xo(u) || !Xo(s) || u.__mode !== s.__mode) return 0;
			const d = u.__text, c = s.__text;
			if (d === c) return 0;
			const p = a.anchor, f = i.anchor;
			if (p.key !== f.key || "text" !== p.type) return 0;
			const h = p.offset, m = f.offset, g = c.length - d.length;
			return 1 === g && m === h - 1 ? 2 : -1 === g && m === h + 1 ? 3 : -1 === g && m === h ? 4 : 0;
		}
		function D(t, e, n) {
			let o = n(), r = 0, a = o, i = 0, l = null;
			return (s, u, d, c, p, f) => {
				const h = n();
				if (f.has("composition-start") && (a = o, i = r, l = s), f.has("historic")) return r = 0, o = h, 2;
				f.has("composition-end") && l && (o = a, r = i, s = l);
				const m = f.has("paste") || f.has("cut") ? 0 : E(s, u, c, p, t.isComposing()), w = (() => {
					const n = null === d || d.editor === t, a = f.has(mo);
					if (!a && n && f.has("history-merge")) return 0;
					if (1 === m) return 2;
					if (null === s) return 1;
					const i = u._selection;
					if (!(c.size > 0 || p.size > 0)) return null !== i ? 0 : 2;
					const l = "number" == typeof e ? e : e.peek();
					if (!1 === a && 0 !== m && m === r && h < o + l && n) return 0;
					if (1 === c.size) {
						if (function(t, e, n) {
							const o = e._nodeMap.get(t), r = n._nodeMap.get(t), a = e._selection, i = n._selection;
							return !(ur(a) && ur(i) && "element" === a.anchor.type && "element" === a.focus.type && "text" === i.anchor.type && "text" === i.focus.type || !Xo(o) || !Xo(r) || o.__parent !== r.__parent) && JSON.stringify(e.read(() => o.exportJSON())) === JSON.stringify(n.read(() => r.exportJSON()));
						}(Array.from(c)[0], s, u)) return 0;
					}
					return 1;
				})();
				return o = h, r = m, w;
			};
		}
		function M(t, e) {
			t.undoStack = [], t.redoStack = [], t.current = null, e && e(t);
		}
		function O(t, e, n, o = Date.now, r, f = null) {
			const h = D(t, n, o), m = () => {
				r && r(e);
			};
			return m(), Eu(t.registerCommand(Qe$2, () => (function(t, e, n) {
				const o = e.redoStack, r = e.undoStack;
				if (0 !== r.length) {
					const a = e.current, i = r.pop();
					null !== a && (o.push(a), t.dispatchCommand(En, !0)), 0 === r.length && t.dispatchCommand(wn$1, !1), e.current = i || null, n && n(e), i && i.editor.setEditorState(i.editorState, { tag: "historic" });
				}
			}(t, e, r), !0), 0), t.registerCommand(Ze$2, () => (function(t, e, n) {
				const o = e.redoStack, r = e.undoStack;
				if (0 !== o.length) {
					const a = e.current;
					null !== a && (r.push(a), t.dispatchCommand(wn$1, !0));
					const i = o.pop();
					0 === o.length && t.dispatchCommand(En, !1), e.current = i || null, n && n(e), i && i.editor.setEditorState(i.editorState, { tag: "historic" });
				}
			}(t, e, r), !0), 0), t.registerCommand(bn$2, () => (M(e, r), !1), 0), t.registerCommand(Nn$1, () => (M(e, r), t.dispatchCommand(En, !1), t.dispatchCommand(wn$1, !1), !0), 0), t.registerUpdateListener(({ editorState: n, prevEditorState: o, dirtyLeaves: r, dirtyElements: a, tags: i }) => {
				const l = e.current, s = e.redoStack, u = e.undoStack, d = null === l ? null : l.editorState;
				if (null !== l && n === d) return;
				const g = h(o, n, l, r, a, i);
				if (1 === g) {
					if (0 !== s.length && (e.redoStack = [], t.dispatchCommand(En, !1)), null !== l) {
						u.push({ ...l });
						const e = "number" == typeof f || null === f ? f : f.peek();
						null !== e && u.length > e && u.splice(0, u.length - e), t.dispatchCommand(wn$1, !0);
					}
				} else if (2 === g) return;
				e.current = {
					editor: t,
					editorState: n
				}, m();
			}));
		}
		function z() {
			return {
				current: null,
				redoStack: [],
				undoStack: []
			};
		}
		Date.now;
		//#endregion
		//#region lib/types/client/input/editor/QuoteNode.js
		const EMPTY_LABELS = { remove: "" };
		/** Remove one quote occurrence by its Lexical identity. */
		const REMOVE_QUOTE_COMMAND = Pe$2("REMOVE_QUOTE_COMMAND");
		/** Pure React face of one quote node. */
		function QuoteNodeView({ editor, nodeKey, text, labels }) {
			return (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.QuotePreview, {
				text,
				removal: {
					label: labels.remove,
					onRemove: () => {
						editor.dispatchCommand(REMOVE_QUOTE_COMMAND, nodeKey);
					}
				}
			});
		}
		/** One selected transcript range represented as an atomic inline decorator. */
		var QuoteNode = class QuoteNode extends Li {
			__text;
			__labels;
			/** Lexical node registry type tag. */
			static getType() {
				return "quote";
			}
			/** @param node - node to clone. @returns a copy carrying the same NodeKey. */
			static clone(node) {
				return new QuoteNode(node.__text, node.__labels, node.__key);
			}
			/** @param json - serialized editor node. @returns a fresh node with default runtime labels. */
			static importJSON(json) {
				return new QuoteNode(json.text);
			}
			/**
			* @param text - selected text.
			* @param labels - runtime-only localized labels.
			* @param key - Lexical clone-path key; absent for fresh nodes.
			*/
			constructor(text, labels = EMPTY_LABELS, key) {
				super(key);
				this.__text = text;
				this.__labels = labels;
			}
			/** Serialize the quote data without its runtime presentation state. */
			exportJSON() {
				return {
					...super.exportJSON(),
					type: "quote",
					version: 1,
					text: this.__text
				};
			}
			/** Mount one non-editable inline host. */
			createDOM(_config) {
				const element = document.createElement("span");
				element.setAttribute("data-composer-quote", "");
				element.setAttribute("contenteditable", "false");
				return element;
			}
			/** Updates reuse the existing host element. */
			updateDOM() {
				return false;
			}
			/** Quotes flow with draft text and wrap at their own text boundary. */
			isInline() {
				return true;
			}
			/** Arrow movement crosses the quote without entering a NodeSelection. */
			isKeyboardSelectable() {
				return false;
			}
			/** Clipboard text is the exact model-visible Markdown blockquote. */
			getTextContent() {
				return (0, _deepseek_ai_dsh_client_ui_primitives.formatQuoteText)(this.__text);
			}
			/** Selected visible quote text. */
			getQuoteText() {
				return this.getLatest().__text;
			}
			/** Update the localized remove label without changing persisted quote data. */
			setLabels(labels) {
				if (this.getLatest().__labels.remove !== labels.remove) this.getWritable().__labels = labels;
			}
			/** Render the quote body and its independent close control. */
			decorate(editor) {
				return (0, react_jsx_runtime.jsx)(QuoteNodeView, {
					editor,
					nodeKey: this.__key,
					text: this.__text,
					labels: this.__labels
				});
			}
		};
		/** @param text - selected quote text. @param labels - runtime labels. @returns a fresh node. */
		function $createQuoteNode(text, labels) {
			return new QuoteNode(text, labels);
		}
		/** @param node - possible Lexical node. @returns whether it is a QuoteNode. */
		function $isQuoteNode(node) {
			return node instanceof QuoteNode;
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs
		function r(e) {
			var t, f, n = "";
			if ("string" == typeof e || "number" == typeof e) n += e;
			else if ("object" == typeof e) if (Array.isArray(e)) {
				var o = e.length;
				for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
			} else for (f in e) e[f] && (n && (n += " "), n += f);
			return n;
		}
		function clsx() {
			for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
			return n;
		}
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/input/editor/ReferenceChip.module.css.mjs
		const css$8 = ".yAWgPa_chip{max-width:240px;color:var(--dsw-alias-state-business-primary);user-select:none;align-items:baseline;gap:3px;display:inline-flex}.yAWgPa_marker{flex:none;font-weight:500}.yAWgPa_icon{flex:none;align-self:center}.yAWgPa_label{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.yAWgPa_invalid{color:var(--dsw-alias-state-error-primary);opacity:.7;text-decoration:line-through}";
		const tagId$8 = "@deepseek-ai/dsh-client-ui-conversation/ReferenceChip.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$8) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$8;
			tag.textContent = css$8;
			document.head.appendChild(tag);
		}
		var ReferenceChip_module_css_default = {
			"chip": "yAWgPa_chip",
			"icon": "yAWgPa_icon",
			"invalid": "yAWgPa_invalid",
			"label": "yAWgPa_label",
			"marker": "yAWgPa_marker"
		};
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/input/editor/composer-editor.module.css.mjs
		const css$7 = ".q44v1G_reference{border-radius:var(--dsw-radius-sm);line-height:inherit;vertical-align:baseline;color:var(--dsw-alias-state-business-primary);-webkit-box-decoration-break:clone;box-decoration-break:clone;background:0 0;padding:0 4px}@media (hover:hover){.q44v1G_reference:hover{background:var(--dsw-alias-state-business-tertiary)}}.q44v1G_openable{cursor:pointer}[data-composer-command][data-selected]>.q44v1G_reference{background:var(--dsw-alias-state-business-tertiary)}.q44v1G_textRef{max-width:100%;display:inline-block}";
		const tagId$7 = "@deepseek-ai/dsh-client-ui-conversation/composer-editor.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$7) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$7;
			tag.textContent = css$7;
			document.head.appendChild(tag);
		}
		var composer_editor_module_css_default = {
			"openable": "q44v1G_openable",
			"reference": "q44v1G_reference",
			"textRef": "q44v1G_textRef"
		};
		//#endregion
		//#region lib/types/client/input/editor/ReferenceChip.js
		/**
		* Visual body of one inline reference chip: the DecoratorNode's React
		* face. Pure display — identity, invalidation, and lifecycle live on the
		* ReferenceChipNode; this component renders whatever the node carries.
		*/
		/**
		* Render one inline reference chip.
		* @param props - label, optional domain glyph, and the invalid bit.
		* @returns the chip body (icon + truncating label).
		*/
		function ReferenceChip({ label, appearance, invalid }) {
			return (0, react_jsx_runtime.jsxs)("span", {
				className: clsx(composer_editor_module_css_default.reference, ReferenceChip_module_css_default.chip, appearance === "file" && !invalid && composer_editor_module_css_default.openable, invalid && ReferenceChip_module_css_default.invalid),
				title: label,
				children: [appearance === void 0 ? (0, react_jsx_runtime.jsx)("span", {
					className: ReferenceChip_module_css_default.marker,
					"aria-hidden": true,
					children: "@"
				}) : (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.ReferenceIconRegular, {
					kind: appearance,
					size: 14,
					className: ReferenceChip_module_css_default.icon
				}), (0, react_jsx_runtime.jsx)("span", {
					className: ReferenceChip_module_css_default.label,
					children: label
				})]
			});
		}
		//#endregion
		//#region lib/types/client/input/editor/chip-node.js
		/** One inline reference occurrence as an atomic decorator node. */
		var ReferenceChipNode = class ReferenceChipNode extends Li {
			/** Owning source name (serializer routing key). */
			__source;
			/** Owner-scoped reference id. */
			__ref;
			/** Inline display label (insert-time cache). */
			__label;
			/** Optional domain glyph (insert-time cache). */
			__appearance;
			/** Clipboard / persistence projection, e.g. `/name` (never the model form). */
			__clipboardText;
			/** Owner-resolution failure flag: chip renders invalid; serialization must fail. */
			__invalid;
			/** Lexical node registry type tag. */
			static getType() {
				return "reference-chip";
			}
			/**
			* Clone with identity (Lexical writable-copy contract).
			* @param node - node to clone.
			* @returns a copy carrying the same NodeKey.
			*/
			static clone(node) {
				return new ReferenceChipNode({
					source: node.__source,
					ref: node.__ref,
					label: node.__label,
					appearance: node.__appearance,
					clipboardText: node.__clipboardText
				}, node.__invalid, node.__key);
			}
			/**
			* Rebuild one chip from its JSON form.
			* @param json - serialized chip.
			* @returns a fresh node (new key).
			*/
			static importJSON(json) {
				return new ReferenceChipNode({
					source: json.source,
					ref: json.ref,
					label: json.label,
					appearance: json.appearance,
					clipboardText: json.clipboardText
				}, json.invalid);
			}
			/**
			* @param insert - the owner's reference insertion (display projections included).
			* @param invalid - owner-resolution failure bit (defaults valid).
			* @param key - Lexical clone-path key; absent for fresh nodes.
			*/
			constructor(insert, invalid = false, key) {
				super(key);
				this.__source = insert.source;
				this.__ref = insert.ref;
				this.__label = insert.label;
				this.__appearance = insert.appearance;
				this.__clipboardText = insert.clipboardText;
				this.__invalid = invalid;
			}
			/** Serialize to the JSON node form. */
			exportJSON() {
				return {
					...super.exportJSON(),
					type: "reference-chip",
					version: 1,
					source: this.__source,
					ref: this.__ref,
					label: this.__label,
					...this.__appearance === void 0 ? {} : { appearance: this.__appearance },
					clipboardText: this.__clipboardText,
					invalid: this.__invalid
				};
			}
			/**
			* Mount the chip's host element; the decorator portal renders into it.
			* @returns an inline, non-editable span carrying the test/e2e anchor.
			*/
			createDOM(_config) {
				const el = document.createElement("span");
				el.setAttribute("data-composer-chip", this.__source);
				el.setAttribute("contenteditable", "false");
				return el;
			}
			/** Host element never changes shape. */
			updateDOM() {
				return false;
			}
			/** Chips sit in the text line. */
			isInline() {
				return true;
			}
			/**
			* No keyboard-selected intermediate state: arrows step across the chip in
			* one move and Backspace/Delete remove it whole (the placeholder semantics
			* of the old textarea). `true` would put a NodeSelection between the
			* keystroke and the caret — a state the plain-text binding's handlers all
			* ignore, deadlocking arrows, typing, and deletion at the chip edge.
			*/
			isKeyboardSelectable() {
				return false;
			}
			/** Clipboard / persistence projection (native copy reads this). */
			getTextContent() {
				return this.__clipboardText;
			}
			/**
			* Flip the owner-resolution failure bit.
			* @param invalid - next bit; no-op writes are the caller's concern.
			*/
			setInvalid(invalid) {
				const writable = this.getWritable();
				writable.__invalid = invalid;
			}
			/** Owner-resolution failure bit. */
			isInvalid() {
				return this.getLatest().__invalid;
			}
			/** Owning source name. */
			getSource() {
				return this.getLatest().__source;
			}
			/** Owner-scoped reference id. */
			getReference() {
				return this.getLatest().__ref;
			}
			/** Inline display label. */
			getLabel() {
				return this.getLatest().__label;
			}
			/** Optional domain glyph. */
			getAppearance() {
				return this.getLatest().__appearance;
			}
			/** React face rendered into the host element by the decorator portal. */
			decorate() {
				return (0, react_jsx_runtime.jsx)(ReferenceChip, {
					label: this.__label,
					appearance: this.__appearance,
					invalid: this.__invalid
				});
			}
		};
		/**
		* Mint one chip node from a reference insertion.
		* @param insert - the owner's reference insertion.
		* @returns the fresh node.
		*/
		function $createReferenceChipNode(insert) {
			return new ReferenceChipNode(insert);
		}
		/**
		* Chip type guard.
		* @param node - any node or nullish.
		* @returns whether the node is a ReferenceChipNode.
		*/
		function $isReferenceChipNode(node) {
			return node instanceof ReferenceChipNode;
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/@lexical+text@0.49.0_typescript@6.0.3/node_modules/@lexical/text/dist/LexicalText.prod.mjs
		/**
		* Copyright (c) Meta Platforms, Inc. and affiliates.
		*
		* This source code is licensed under the MIT license found in the
		* LICENSE file in the root directory of this source tree.
		*
		*/
		function d(t, ...e) {
			const n = new URL("https://lexical.dev/docs/error"), r = new URLSearchParams();
			r.append("code", t);
			for (const t of e) r.append("v", t);
			throw n.search = r.toString(), Error(`Minified Lexical error #${t}; visit ${n.toString()} for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`);
		}
		function x(t, e, n, r) {
			const s = (t) => t instanceof n, f = (t) => {
				const e = Go(t.getTextContent());
				e.setFormat(t.getFormat()), t.replace(e);
			};
			return [t.registerNodeTransform(Wo, (t) => {
				if (!t.isSimpleText()) return;
				let n, o = t.getPreviousSibling(), l = t.getTextContent(), u = t;
				if (Xo(o)) {
					const n = o.getTextContent(), r = e(n + l);
					if (s(o)) {
						if (null === r || 0 !== ((t) => t.getLatest().__mode)(o)) return void f(o);
						{
							const e = r.end - n.length;
							if (e > 0) {
								const r = n + l.slice(0, e);
								if (o.select(), o.setTextContent(r), e === l.length) t.remove();
								else {
									const n = l.slice(e);
									t.setTextContent(n);
								}
								return;
							}
						}
					} else if (null === r || r.start < n.length) return;
				}
				let c = 0;
				for (;;) {
					n = e(l);
					let t, g = null === n ? "" : l.slice(n.end);
					if (l = g, "" === g) {
						const t = u.getNextSibling();
						if (Xo(t)) {
							g = u.getTextContent() + t.getTextContent();
							const n = e(g);
							if (null === n) return void (s(t) ? f(t) : t.markDirty());
							if (0 !== n.start) return;
						}
					}
					if (null === n) return;
					if (0 === n.start && Xo(o) && o.isTextEntity()) {
						c += n.end;
						continue;
					}
					0 === n.start ? [t, u] = u.splitText(n.end) : [, t, u] = u.splitText(n.start + c, n.end + c), void 0 === t && d(165, "nodeToReplace");
					const a = r(t);
					if (a.setFormat(t.getFormat()), t.replace(a), null == u) return;
					c = 0, o = a;
				}
			}), t.registerNodeTransform(n, (t) => {
				const n = t.getTextContent(), r = e(n);
				if (null === r || 0 !== r.start) return void f(t);
				if (n.length > r.end) return void t.splitText(r.end);
				const o = t.getPreviousSibling();
				Xo(o) && o.isTextEntity() && (f(o), f(t));
				const l = t.getNextSibling();
				Xo(l) && l.isTextEntity() && (f(l), s(t) && f(t));
			})];
		}
		//#endregion
		//#region lib/types/client/input/decorations.js
		/**
		* Plain-text reference scan (the plain-text-reference decision;
		* see .agents/notes/archived/architecture/2026-07-25-web-input-machine-and-slash-pipeline.md):
		* a `/name` or `@name` token whose name is on the trigger's lexicon, and
		* syntax-recognizable `@path` file and folder tokens. Pure derivation — the editor's
		* text-ref entity transform consumes these ranges; editing the text out of
		* match shape simply drops the range next scan.
		*/
		/** Token matcher: a trigger char at line start or after whitespace, then a word-ish name (never crosses \n). */
		const TEXT_REF_RE = /(^|\s)([/@])([\w-]+)/g;
		/** One `@` path token: a quoted path through its closing quote or line end, or an unquoted run. */
		const PATH_TOKEN_RE = /(^|\s)(@(?:"[^"\n]*"?|[^\s"]\S*))/g;
		/**
		* Punctuation that ends prose rather than a path: the characters the
		* sent-message file and folder rules in ui-reference strip from the end of an
		* unquoted token.
		*/
		const TRAILING_PUNCTUATION = /* @__PURE__ */ new Set(".,;:!?，。；：！？");
		/** An unquoted token names a path only with a separator or an extension; a bare `@name` stays plain until a lexicon claims it. */
		const PATH_LIKE_RE = /^@.*[/\\.]/u;
		/**
		* End of the whole `@path` file or folder token at `start`, so a path is never
		* cut at its directory prefix. A closed quote ends at its quote and an
		* unquoted token with a separator or extension drops trailing punctuation,
		* the spans the sent-message rules render. An open quote (a folder drill in
		* progress) ends at its last slash when only trailing punctuation and
		* whitespace or the draft end follow it.
		* @param draft - draft text.
		* @param start - offset of the token's `@`.
		* @param token - the path token at `start`.
		* @returns the token's end offset, or undefined when it names no path.
		*/
		function pathEnd(draft, start, token) {
			if (!token.startsWith("@\"")) {
				let length = token.length;
				while (TRAILING_PUNCTUATION.has(token.charAt(length - 1))) length -= 1;
				return PATH_LIKE_RE.test(token.slice(0, length)) ? start + length : void 0;
			}
			if (token.length > 3 && token.endsWith("\"")) return start + token.length;
			const slash = token.lastIndexOf("/");
			if (slash < 0) return void 0;
			let next = start + slash + 1;
			while (TRAILING_PUNCTUATION.has(draft.charAt(next))) next += 1;
			return next === draft.length || /\s/u.test(draft.charAt(next)) ? start + slash + 1 : void 0;
		}
		/**
		* What may follow a `/name` token: whitespace or the draft end, the boundary
		* the host skill gesture (`dsh-tool-skill`) requires, so `/nfs-hg/xxx`,
		* `/plan.md`, and `/plan。` are prose, never a reference.
		*/
		const SLASH_TOKEN_END_RE = /^(?:\s|$)/;
		/**
		* Scan the draft for plain-text reference tokens against the hot lexicons.
		* Word-boundary discipline: the trigger must sit at the draft
		* start or after whitespace ('x/name' never matches); the name must be an
		* exact lexicon member; a `/name` token must end at whitespace or the draft
		* end ('/name/x' is a path, '/name。' is prose).
		* @param draft - draft text.
		* @param lexicon - per-trigger name lists; missing catalogs match no named tokens.
		* @returns matched ranges in draft order.
		*/
		function scanTextRefs(draft, lexicon) {
			if (draft === "") return [];
			const out = [];
			TEXT_REF_RE.lastIndex = 0;
			let m;
			while ((m = TEXT_REF_RE.exec(draft)) !== null) {
				const trigger = m[2];
				const name = m[3] ?? "";
				if (trigger === "/" && !SLASH_TOKEN_END_RE.test(draft.slice(m.index + m[0].length))) continue;
				if (lexicon.get(trigger)?.includes(name)) {
					const start = m.index + (m[1]?.length ?? 0);
					out.push({
						start,
						end: start + 1 + name.length,
						trigger
					});
				}
			}
			PATH_TOKEN_RE.lastIndex = 0;
			let path;
			while ((path = PATH_TOKEN_RE.exec(draft)) !== null) {
				const start = path.index + (path[1]?.length ?? 0);
				const end = pathEnd(draft, start, path[2] ?? "");
				if (end !== void 0 && !out.some((range) => range.start < end && range.end > start)) out.push({
					start,
					end,
					trigger: "@"
				});
			}
			return out.sort((left, right) => left.start - right.start);
		}
		//#endregion
		//#region lib/types/client/input/editor/text-ref.js
		/** Editable reference tokens share chip hover styling while retaining ordinary text semantics. */
		/** One matched plain-text reference as a styled, fully editable text node. */
		var TextRefNode = class TextRefNode extends Wo {
			/** Lexical node registry type tag. */
			static getType() {
				return "composer-text-ref";
			}
			/**
			* Clone with identity (Lexical writable-copy contract).
			* @param node - node to clone.
			* @returns a copy carrying the same NodeKey.
			*/
			static clone(node) {
				return new TextRefNode(node.__text, node.__key);
			}
			/**
			* Rebuild one text-ref from its JSON form.
			* @param json - serialized node.
			* @returns a fresh node.
			*/
			static importJSON(json) {
				const node = new TextRefNode(json.text);
				node.setFormat(json.format);
				node.setDetail(json.detail);
				node.setMode(json.mode);
				node.setStyle(json.style);
				return node;
			}
			/** Serialize to the JSON node form. */
			exportJSON() {
				return {
					...super.exportJSON(),
					type: "composer-text-ref"
				};
			}
			/** Style the span the base TextNode mounts. */
			createDOM(config) {
				const el = super.createDOM(config);
				el.className = clsx(el.className, composer_editor_module_css_default.reference, composer_editor_module_css_default.textRef, this.getTextContent().startsWith("/") && composer_editor_module_css_default.openable);
				el.setAttribute("spellcheck", "false");
				el.setAttribute("data-composer-text-ref", "");
				return el;
			}
			/** Entity nodes never merge with plain siblings (the transform owns their bounds). */
			isTextEntity() {
				return true;
			}
			/** Editing continues inside; the transform re-evaluates match shape per edit. */
			canInsertTextBefore() {
				return true;
			}
		};
		/**
		* Register the plain-text reference entity transform.
		* @param editor - the shell-owned editor.
		* @param lexiconOf - live per-trigger name-roll accessor (the controller's aggregated store).
		* @returns the unregister disposer.
		*/
		function registerTextRefDecoration(editor, lexiconOf) {
			const getMatch = (text) => {
				const range = scanTextRefs(text, lexiconOf())[0];
				return range === void 0 ? null : {
					start: range.start,
					end: range.end
				};
			};
			return Eu(...x(editor, getMatch, TextRefNode, (node) => new TextRefNode(node.getTextContent())));
		}
		/**
		* Force a re-scan of the whole document (transforms only visit dirty nodes;
		* a lexicon roll change dirties nothing on its own). Queued, not discrete —
		* the caller may sit inside an update listener.
		* @param editor - the shell-owned editor.
		*/
		function rescanTextRefs(editor) {
			editor.update(() => {
				for (const node of nl().getAllTextNodes()) node.markDirty();
			}, { tag: xo });
		}
		//#endregion
		//#region lib/types/client/input/editor/reference-activation.js
		/** Route composer clicks through the live reference owner without editing the draft. */
		/**
		* Install preview activation for atomic chips and editable reference tokens.
		* @param editor - composer editor.
		* @param open - live source routing; false preserves ordinary editor handling.
		* @returns command disposer.
		*/
		function registerReferenceActivation(editor, open) {
			return editor.registerCommand(Ke$2, (event) => {
				if (event.target === null || event.button !== 0 || event.detail > 1) return false;
				const selection = Kr();
				if (ur(selection) && !selection.isCollapsed()) return false;
				const node = Zs(event.target);
				if ($isReferenceChipNode(node)) {
					if (node.isInvalid()) return false;
					const appearance = node.getAppearance();
					return open(node.getSource(), {
						ref: node.getReference(),
						...appearance === void 0 ? {} : { appearance }
					});
				}
				return node instanceof TextRefNode && open(void 0, { ref: node.getTextContent() });
			}, 1);
		}
		//#endregion
		//#region lib/types/client/input/editor/CommandChip.js
		/**
		* Visual body of the claimed command chip: the CommandChipNode's React face.
		* Pure display with the reference chip's treatment; the claim and its
		* lifecycle live on the node and the shell.
		*/
		/**
		* Render the claimed command chip.
		* @param props - the token to display.
		* @returns the chip body.
		*/
		function CommandChip({ token }) {
			return (0, react_jsx_runtime.jsx)("span", {
				className: clsx(composer_editor_module_css_default.reference, ReferenceChip_module_css_default.chip),
				children: (0, react_jsx_runtime.jsx)("span", {
					className: ReferenceChip_module_css_default.label,
					children: token
				})
			});
		}
		//#endregion
		//#region lib/types/client/input/editor/command-chip-node.js
		/** One claimed command as an atomic decorator node. */
		var CommandChipNode = class CommandChipNode extends Li {
			/** The claim this chip anchors; its submit closure has no JSON form. */
			__claim;
			/** Lexical node registry type tag. */
			static getType() {
				return "command-chip";
			}
			/**
			* Clone with identity (Lexical writable-copy contract).
			* @param node - node to clone.
			* @returns a copy carrying the same NodeKey and claim.
			*/
			static clone(node) {
				return new CommandChipNode(node.__claim, node.__key);
			}
			/**
			* Rebuild one chip from its JSON form. JSON cannot carry the claim's
			* submit closure, so an imported command is its literal token text.
			* @param json - serialized chip.
			* @returns a plain text node holding the token.
			*/
			static importJSON(json) {
				return Go(json.text);
			}
			/**
			* @param claim - the command claim the chip anchors.
			* @param key - Lexical clone-path key; absent for fresh nodes.
			*/
			constructor(claim, key) {
				super(key);
				this.__claim = claim;
			}
			/** Serialize to the JSON node form (the token text alone). */
			exportJSON() {
				return {
					...super.exportJSON(),
					type: "command-chip",
					version: 1,
					text: this.getTextContent()
				};
			}
			/**
			* Mount the chip's host element; the decorator portal renders into it.
			* @returns an inline, non-editable span carrying the test/e2e anchor.
			*/
			createDOM() {
				const el = document.createElement("span");
				el.setAttribute("data-composer-command", this.__claim.name);
				el.setAttribute("contenteditable", "false");
				return el;
			}
			/** Host element never changes shape. */
			updateDOM() {
				return false;
			}
			/** The chip sits in the text line. */
			isInline() {
				return true;
			}
			/**
			* Arrows step across the chip and the default character deletion removes
			* it whole, for the reason documented on ReferenceChipNode.isKeyboardSelectable;
			* registerCommandChipSelection inserts the selecting step before that deletion.
			*/
			isKeyboardSelectable() {
				return false;
			}
			/** Clipboard / persistence projection: the token without its separator. */
			getTextContent() {
				return this.__claim.token.trimEnd();
			}
			/** The claim this chip anchors. */
			getClaim() {
				return this.getLatest().__claim;
			}
			/** React face rendered into the host element by the decorator portal. */
			decorate() {
				return (0, react_jsx_runtime.jsx)(CommandChip, { token: this.getTextContent() });
			}
		};
		/**
		* Mint one chip node for a claim.
		* @param claim - the command claim.
		* @returns the fresh node.
		*/
		function $createCommandChipNode(claim) {
			return new CommandChipNode(claim);
		}
		/**
		* Command chip type guard.
		* @param node - any node or nullish.
		* @returns whether the node is a CommandChipNode.
		*/
		function $isCommandChipNode(node) {
			return node instanceof CommandChipNode;
		}
		/** Replace a displaced chip with its literal token. */
		function $releaseChip(chip) {
			chip.replace(Go(chip.getTextContent()));
		}
		/**
		* Keep command chips on the leading seat. A chip anywhere but the first
		* child of the first block (text, a line break, or a block inserted before
		* it) becomes its literal token, which releases the claim. Inserting a
		* sibling before the chip or moving it to another block marks the chip dirty;
		* a block inserted before the chip's block marks only that block dirty.
		* @param editor - the shell-owned editor.
		* @returns the unregister disposer.
		*/
		function registerCommandChipSeat(editor) {
			return Eu(editor.registerNodeTransform(CommandChipNode, (chip) => {
				if (chip.getPreviousSibling() !== null || chip.getParentOrThrow().getPreviousSibling() !== null) $releaseChip(chip);
			}), editor.registerNodeTransform(Zi, (block) => {
				const first = block.getFirstChild();
				if ($isCommandChipNode(first) && block.getPreviousSibling() !== null) $releaseChip(first);
			}));
		}
		//#endregion
		//#region lib/types/client/input/editor/command-chip-selection.js
		/**
		* Keys that never clear a selected chip by themselves: bare modifiers, and
		* IME or virtual-keyboard keys whose deletion arrives later as an input event.
		*/
		const PASSIVE_KEYS = new Set([
			"Shift",
			"Control",
			"Alt",
			"Meta",
			"Unidentified",
			"Process"
		]);
		/** The chip a collapsed caret deletes next in one direction, or null. */
		function $commandChipBesideCaret(isBackward) {
			const selection = Kr();
			if (!ur(selection) || !selection.isCollapsed()) return null;
			const node = kl(selection.focus, isBackward);
			return $isCommandChipNode(node) ? node : null;
		}
		/** Deletion direction of an input event type; null for other input. */
		function deletionDirection(inputType) {
			if (inputType === "deleteContentBackward") return true;
			if (inputType === "deleteContentForward") return false;
			return null;
		}
		/**
		* Register two-step deletion for the command chip.
		* @param editor - the shell-owned editor.
		* @returns the unregister disposer, which also clears a selected chip.
		*/
		function registerCommandChipSelection(editor) {
			let selected = null;
			/** A keydown with a selected chip whose dispatch has produced no character deletion yet. */
			let keyWithoutDeletion = false;
			const paint = (next) => {
				if (selected !== null && selected.key !== next?.key) editor.getElementByKey(selected.key)?.removeAttribute("data-selected");
				selected = next;
				if (next !== null) editor.getElementByKey(next.key)?.setAttribute("data-selected", "");
				editor.getRootElement()?.toggleAttribute("data-composer-chip-selected", next !== null);
			};
			const clear = () => {
				if (selected !== null) paint(null);
				return false;
			};
			/**
			* Decide one character deletion.
			* @param isBackward - deletion direction.
			* @param clearOnPass - whether letting the deletion run clears the selection here;
			* an input event leaves it for the deletion that follows.
			* @returns true when the deletion only selected the chip and must be consumed.
			*/
			const $decide = (isBackward, clearOnPass) => {
				keyWithoutDeletion = false;
				const chip = $commandChipBesideCaret(isBackward);
				if (chip === null) return clear();
				if (selected?.key === chip.getKey() && selected.isBackward === isBackward) return clearOnPass ? clear() : false;
				paint({
					key: chip.getKey(),
					isBackward
				});
				return true;
			};
			return Eu(editor.registerCommand(ze$2, (event) => {
				const isBackward = deletionDirection(event.inputType);
				if (isBackward === null || !$decide(isBackward, false)) return false;
				event.preventDefault();
				return true;
			}, 3), editor.registerCommand($e$2, (isBackward) => $decide(isBackward, true), 3), editor.registerCommand(tn$2, (event) => {
				if (selected === null || PASSIVE_KEYS.has(event.key)) return false;
				keyWithoutDeletion = true;
				queueMicrotask(() => {
					if (!keyWithoutDeletion) return;
					keyWithoutDeletion = false;
					clear();
				});
				return false;
			}, 4), editor.registerCommand(Ke$2, clear, 4), editor.registerCommand(Mn$1, clear, 4), editor.registerUpdateListener(({ editorState }) => {
				const current = selected;
				if (current === null) return;
				paint(editorState.read(() => $commandChipBesideCaret(current.isBackward)?.getKey() === current.key) ? current : null);
			}), () => {
				paint(null);
			});
		}
		/**
		* Walk the composer document once, producing every projection segment in
		* document order. Blocks (paragraphs) contribute a one-newline gap between
		* one another in both text projections.
		* @returns the layout for this EditorState.
		*/
		function $composerLayout() {
			const segments = [];
			const byKey = /* @__PURE__ */ new Map();
			const children = /* @__PURE__ */ new Map();
			const bounds = /* @__PURE__ */ new Map();
			let detect = "";
			let clipboard = "";
			const pushLeaf = (kind, node, detectPiece, clipboardPiece) => {
				const segment = {
					kind,
					node,
					detectStart: detect.length,
					detectLength: detectPiece.length,
					clipboardStart: clipboard.length,
					clipboardLength: clipboardPiece.length
				};
				segments.push(segment);
				byKey.set(node.getKey(), segment);
				detect += detectPiece;
				clipboard += clipboardPiece;
			};
			const walkElement = (element) => {
				const start = detect.length;
				const kids = element.getChildren();
				children.set(element.getKey(), kids.map((kid) => kid.getKey()));
				for (const kid of kids) if ($isReferenceChipNode(kid) || $isCommandChipNode(kid) || $isQuoteNode(kid)) pushLeaf("chip", kid, "￼", kid.getTextContent());
				else if (Xo(kid)) {
					const text = kid.getTextContent();
					pushLeaf("text", kid, text, text);
				} else if (Yi(kid)) pushLeaf("linebreak", kid, "\n", "\n");
				else if (Pi(kid))
 /* v8 ignore next 4 -- plain-text composition nests no block elements today; the walk stays total for imported states. */
				walkElement(kid);
				bounds.set(element.getKey(), {
					start,
					end: detect.length
				});
			};
			const root = nl();
			const blocks = root.getChildren();
			children.set(root.getKey(), blocks.map((block) => block.getKey()));
			const rootStart = detect.length;
			blocks.forEach((block, index) => {
				const previous = blocks[index - 1];
				if (index > 0 && previous !== void 0) {
					segments.push({
						kind: "gap",
						node: null,
						detectStart: detect.length,
						detectLength: 1,
						clipboardStart: clipboard.length,
						clipboardLength: 1,
						gapBetween: {
							before: previous.getKey(),
							after: block.getKey()
						}
					});
					detect += "\n";
					clipboard += "\n";
				}
				if (Pi(block)) walkElement(block);
			});
			bounds.set(root.getKey(), {
				start: rootStart,
				end: detect.length
			});
			return {
				segments,
				detectLength: detect.length,
				detectText: detect,
				clipboardText: clipboard,
				byKey,
				children,
				bounds
			};
		}
		/**
		* Fold one clipboard-projection offset to its detect-projection twin.
		* Offsets inside a chip's clipboard expansion snap to the chip's trailing
		* edge; callers only pass boundaries that were once a document end (submit
		* snapshots), which never split a chip.
		* @param layout - the current walk product.
		* @param clipboardOffset - offset into the clipboard projection.
		* @returns the detect offset covering the same document position.
		*/
		function detectOffsetOfClipboardOffset(layout, clipboardOffset) {
			for (const segment of layout.segments) {
				const end = segment.clipboardStart + segment.clipboardLength;
				if (clipboardOffset > end) continue;
				if (clipboardOffset === end) return segment.detectStart + segment.detectLength;
				if (segment.kind === "chip") return segment.detectStart + segment.detectLength;
				return segment.detectStart + (clipboardOffset - segment.clipboardStart);
			}
			return layout.detectLength;
		}
		/**
		* Fold one selection point to a detect offset.
		* @param layout - the current walk product.
		* @param point - selection anchor/focus point.
		* @returns detect offset, or null when the point references an unknown node.
		*/
		function $detectOffsetOfPoint(layout, point) {
			if (point.type === "text") {
				const segment = layout.byKey.get(point.key);
				return segment === void 0 ? null : segment.detectStart + Math.min(point.offset, segment.detectLength);
			}
			const kids = layout.children.get(point.key);
			const elementBounds = layout.bounds.get(point.key);
			if (kids === void 0 || elementBounds === void 0) return null;
			if (point.offset >= kids.length) return elementBounds.end;
			const childKey = kids[point.offset];
			if (childKey === void 0) return elementBounds.end;
			const childSegment = layout.byKey.get(childKey);
			if (childSegment !== void 0) return childSegment.detectStart;
			const childBounds = layout.bounds.get(childKey);
			return childBounds === void 0 ? null : childBounds.start;
		}
		/**
		* Project the composer document and its caret.
		* @param idOf - stable occurrence-id assignment per chip NodeKey (the shell
		* owns the map so ids survive across projections of the same node).
		* @returns the three-view projection product.
		*/
		function $projectComposer(idOf) {
			const layout = $composerLayout();
			const occurrences = [];
			const quotes = [];
			for (const segment of layout.segments) {
				if (segment.kind !== "chip") continue;
				if ($isQuoteNode(segment.node)) {
					quotes.push({
						offset: segment.clipboardStart,
						length: segment.clipboardLength,
						text: segment.node.getQuoteText()
					});
					continue;
				}
				if (!$isReferenceChipNode(segment.node)) continue;
				const chip = segment.node;
				occurrences.push({
					occurrenceId: idOf(chip.getKey()),
					source: chip.getSource(),
					ref: chip.getReference(),
					offset: segment.clipboardStart,
					length: segment.clipboardLength,
					label: chip.getLabel(),
					...chip.getAppearance() === void 0 ? {} : { appearance: chip.getAppearance() },
					clipboardText: chip.getTextContent(),
					...chip.isInvalid() ? { invalid: true } : {}
				});
			}
			const lead = layout.segments[0]?.node;
			const selection = Kr();
			let range = null;
			if (ur(selection)) {
				const anchor = $detectOffsetOfPoint(layout, selection.anchor);
				const focus = $detectOffsetOfPoint(layout, selection.focus);
				if (anchor !== null && focus !== null) range = {
					start: Math.min(anchor, focus),
					end: Math.max(anchor, focus)
				};
			}
			return {
				detectText: layout.detectText,
				clipboardText: layout.clipboardText,
				occurrences,
				quotes,
				selection: range,
				caret: range !== null && range.start === range.end ? range.start : null,
				command: $isCommandChipNode(lead) ? lead.getClaim() : void 0
			};
		}
		//#endregion
		//#region lib/types/client/input/editor/span-map.js
		/**
		* Resolve one detect offset to a selection point. Ownership rule: the first
		* segment whose half-open [start, end) contains the offset resolves it; the
		* document end falls to the last block. Atomic segments (chip, linebreak)
		* resolve to element points beside them, so a span can only ever address a
		* chip as a whole; a gap offset is the end of the block before it.
		* @param layout - current walk product.
		* @param offset - detect offset in [0, detectLength].
		* @returns the point, or null when the offset is out of bounds.
		*/
		function resolvePoint(layout, offset) {
			if (offset < 0 || offset > layout.detectLength) return null;
			for (const segment of layout.segments) {
				if (offset >= segment.detectStart + segment.detectLength) continue;
				if (segment.kind === "text" && segment.node !== null) return {
					key: segment.node.getKey(),
					offset: offset - segment.detectStart,
					type: "text"
				};
				if (segment.kind === "gap" && segment.gapBetween !== void 0) {
					const before = segment.gapBetween.before;
					return {
						key: before,
						offset: layout.children.get(before)?.length ?? 0,
						type: "element"
					};
				}
				/* v8 ignore next -- non-gap segments always carry their node. */
				if (segment.node === null) return null;
				const element = segment.node.getParent();
				/* v8 ignore next -- a walked leaf always has a parent element. */
				if (element === null) return null;
				return {
					key: element.getKey(),
					offset: segment.node.getIndexWithinParent(),
					type: "element"
				};
			}
			const blocks = nl().getChildren();
			const last = blocks[blocks.length - 1];
			if (last === void 0) return {
				key: nl().getKey(),
				offset: 0,
				type: "element"
			};
			return {
				key: last.getKey(),
				offset: layout.children.get(last.getKey())?.length ?? 0,
				type: "element"
			};
		}
		/**
		* Build and apply a live RangeSelection over one detect span.
		* @param layout - current walk product.
		* @param span - detect span.
		* @returns the applied selection, or null when either endpoint fails to map.
		*/
		function selectSpan(layout, span) {
			if (span.start < 0 || span.start > span.end || span.end > layout.detectLength) return null;
			const anchor = resolvePoint(layout, span.start);
			const focus = resolvePoint(layout, span.end);
			/* v8 ignore next -- bounds were checked above; resolvePoint only fails out of bounds. */
			if (anchor === null || focus === null) return null;
			const selection = Fr();
			selection.anchor.set(anchor.key, anchor.offset, anchor.type);
			selection.focus.set(focus.key, focus.offset, focus.type);
			ol(selection);
			return selection;
		}
		/**
		* Replace one detect span with plain text (empty text deletes the span).
		* The caret lands after the insertion.
		* @param span - detect span to replace.
		* @param text - replacement text.
		* @returns whether the span mapped and the edit applied.
		*/
		function $replaceDetectSpanWithText(span, text) {
			const selection = selectSpan($composerLayout(), span);
			if (selection === null) return false;
			if (text === "" && !selection.isCollapsed()) selection.removeText();
			else selection.insertText(text);
			return true;
		}
		/**
		* Replace one detect span with nodes (chip insertion path). The caret lands
		* after the last inserted node.
		* @param span - detect span to replace.
		* @param nodes - replacement nodes in order.
		* @returns whether the span mapped and the edit applied.
		*/
		function $replaceDetectSpanWithNodes(span, nodes) {
			const selection = selectSpan($composerLayout(), span);
			if (selection === null) return false;
			selection.insertNodes([...nodes]);
			return true;
		}
		//#endregion
		//#region lib/types/client/input/editor/runtime.js
		/**
		* Detect-projection and legacy reference placeholders stripped from every
		* external text entering the document (paste, persisted-draft seed): a chip
		* is the only legitimate source of U+FFFC in the detect projection, so a
		* literal one in text would forge chip positions.
		*/
		const REFERENCE_PLACEHOLDER_RE = /[\uE100-\uE11D\uFFFC]/gu;
		/**
		* Append one paragraph per line of `text` to the editor root and move the caret
		* to the end. Must run inside an editor update.
		* @param text - sanitized plain text.
		*/
		function $appendParagraphs(text) {
			const root = nl();
			for (const line of text.split("\n")) {
				const paragraph = es$1();
				if (line !== "") paragraph.append(Go(line));
				root.append(paragraph);
			}
			root.selectEnd();
		}
		/** Undo merge window for contiguous typing, in ms (the old machine's mergeWindowMs). */
		const HISTORY_MERGE_DELAY_MS = 1e3;
		/** Editor update that removes submitted content while retaining any newer draft suffix. */
		const DRAFT_SUBMITTED_TAG = "dsh-draft-submitted";
		/** One model-owned editor; registration and disposal remain with its model. */
		var DraftEditorRuntime = class {
			deps;
			/** The editor bound by the Composer's contenteditable host. */
			editor;
			projected = {
				detectText: "",
				clipboardText: "",
				occurrences: [],
				quotes: [],
				selection: null,
				caret: null,
				command: void 0
			};
			/** Stable occurrence ids per chip NodeKey (undo restores keys, so ids survive it too). */
			occurrenceIds = /* @__PURE__ */ new Map();
			occurrenceSeq = 0;
			/** Live lexicon subscription disposer; undefined until the controller resolves. */
			lexiconOff;
			lexiconSource;
			/** @param deps - model callbacks used by editor listeners and transforms. */
			constructor(deps) {
				this.deps = deps;
				this.editor = ys({
					namespace: "dsh-composer",
					nodes: [
						ReferenceChipNode,
						CommandChipNode,
						TextRefNode,
						QuoteNode
					],
					onError: (error) => {
						throw error;
					}
				});
			}
			/**
			* Install editor behavior after the model holds this runtime.
			* @returns unregister callback that also detaches the editor root.
			*/
			register() {
				const preserveExternalSelection = () => {
					const root = this.editor.getRootElement();
					if (root !== null && !root.contains(root.ownerDocument.activeElement)) Al(bo);
					return false;
				};
				const unregister = Eu(O$1(this.editor), this.editor.registerNodeTransform(QuoteNode, (node) => {
					node.setLabels(this.deps.quoteLabels());
				}), this.editor.registerCommand(REMOVE_QUOTE_COMMAND, (key) => this.removeQuote(key), 4), this.editor.registerCommand(un$2, (event) => this.deleteAdjacentQuote(event, true), -4), this.editor.registerCommand(dn$1, (event) => this.deleteAdjacentQuote(event, false), -4), this.editor.registerCommand(Mn$1, () => {
					this.editor.update(preserveExternalSelection, { discrete: true });
					return false;
				}, 4), this.editor.registerCommand(Ie$2, preserveExternalSelection, 4), this.editor.registerNodeTransform(zi, preserveExternalSelection), registerReferenceActivation(this.editor, (source, reference) => this.deps.openReference(source, reference)), O(this.editor, z(), HISTORY_MERGE_DELAY_MS), this.editor.registerUpdateListener(() => {
					this.deps.onUpdate();
				}), registerCommandChipSeat(this.editor), registerCommandChipSelection(this.editor), registerTextRefDecoration(this.editor, () => this.deps.lexicon()), () => {
					this.lexiconOff?.();
					this.lexiconOff = void 0;
					this.lexiconSource = void 0;
				});
				return () => {
					unregister();
					this.editor.setRootElement(null);
				};
			}
			/** The latest committed editor projection. */
			get projection() {
				return this.projected;
			}
			/**
			* Run one editor edit whose result is observable on return. At the top
			* level this is a discrete update. Inside this editor's own update —
			* command handlers land here synchronously (space/enter picks, paste) —
			* $-functions are already legal, and wrapping them in update() would DEFER
			* them past the synchronous bail answer (and a nested discrete throws);
			* the body runs directly and the outer update commits it.
			* @param fn - the $-edit body.
			*/
			applyEdit(fn, tag) {
				if (this.editor._updating) {
					if (tag !== void 0) Al(tag);
					fn();
					return;
				}
				this.editor.update(fn, {
					discrete: true,
					...tag === void 0 ? {} : { tag }
				});
			}
			/**
			* Reconnect decorations when the optional trigger provider changes.
			* The rescan reads the current editor and does not replace its content.
			*/
			refreshLexiconSubscription() {
				const lexicon = this.deps.resolveLexicon();
				if (lexicon === this.lexiconSource) return;
				this.lexiconOff?.();
				this.lexiconSource = lexicon;
				this.lexiconOff = lexicon?.subscribe(() => {
					rescanTextRefs(this.editor);
				});
				rescanTextRefs(this.editor);
			}
			/**
			* Re-project inside the existing editor update callback.
			* @returns the projection preceding this read.
			*/
			refreshProjection() {
				const prev = this.projected;
				this.projected = this.editor.getEditorState().read(() => $projectComposer((key) => this.occurrenceIdOf(key)));
				return prev;
			}
			occurrenceIdOf(key) {
				const existing = this.occurrenceIds.get(key);
				if (existing !== void 0) return existing;
				this.occurrenceSeq += 1;
				this.occurrenceIds.set(key, this.occurrenceSeq);
				return this.occurrenceSeq;
			}
			/**
			* Replace the whole draft (persisted-draft seed and programmatic writes).
			* Placeholder-sanitized; newlines split paragraphs; the caret lands at the
			* end. Merged into history so a seed is not an undoable step of its own.
			* @param text - the full next draft.
			*/
			setDraft(text) {
				const clean = text.replace(REFERENCE_PLACEHOLDER_RE, "");
				if (clean === this.projection.clipboardText && this.projection.occurrences.length === 0 && this.projection.quotes.length === 0) return;
				this.editor.update(() => {
					nl().clear();
					$appendParagraphs(clean);
				}, {
					discrete: true,
					tag: xo
				});
			}
			/**
			* Add plain text after the current draft as new paragraphs, keeping its text
			* and references; an empty draft takes the text as its whole content.
			* Placeholder-sanitized; the caret lands at the end; merged into history
			* like {@link setDraft}.
			* @param text - plain text to add.
			*/
			appendDraft(text) {
				const clean = text.replace(REFERENCE_PLACEHOLDER_RE, "");
				if (clean === "") return;
				if (this.projection.clipboardText === "" && this.projection.occurrences.length === 0) {
					this.setDraft(clean);
					return;
				}
				this.editor.update(() => {
					$appendParagraphs(clean);
				}, {
					discrete: true,
					tag: xo
				});
			}
			/**
			* Insert pasted plain text over the current editor selection
			* (placeholder-sanitized). The paste event's own default is suppressed by
			* the caller; PASTE_TAG makes the paste its own history boundary, so one
			* undo never removes both the paste and typing inside the merge window.
			* @param text - pasted plain text.
			*/
			paste(text) {
				const clean = text.replace(REFERENCE_PLACEHOLDER_RE, "");
				if (clean === "") return;
				this.applyEdit(() => {
					const selection = Kr();
					if (ur(selection)) {
						selection.insertText(clean);
						return;
					}
					const root = nl();
					if (root.getChildrenSize() === 0) root.append(es$1());
					root.selectEnd().insertText(clean);
				}, Co);
			}
			/**
			* The live selection as a detect-coordinate span (menu-launcher synthetic
			* hits replace it on pick); an absent selection answers a collapsed span at
			* the document end.
			* @returns the ordered [start, end) span in detect coordinates.
			*/
			caretSpan() {
				if (this.projection.selection !== null) return this.projection.selection;
				const at = this.projection.detectText.length;
				return {
					start: at,
					end: at
				};
			}
			/**
			* Replace a mapped span without applying the model's phase or revision guards.
			* @param span - detect-coordinate range.
			* @param text - inserted text.
			* @returns whether the range mapped and the edit applied.
			*/
			replaceText(span, text) {
				let applied = false;
				this.applyEdit(() => {
					applied = $replaceDetectSpanWithText(span, text);
				});
				return applied;
			}
			/**
			* Insert an asynchronous text result as one independent undo operation.
			* @param span - owner-validated insertion range.
			* @param text - text sanitized with the same rules as paste.
			* @returns whether the range mapped and the edit applied.
			*/
			insertAsyncText(span, text) {
				let applied = false;
				const clean = text.replace(REFERENCE_PLACEHOLDER_RE, "");
				this.applyEdit(() => {
					applied = $replaceDetectSpanWithText(span, clean);
				}, Co);
				return applied;
			}
			/**
			* Insert a reference chip with the existing trailing-space rule.
			* @param span - detect-coordinate range.
			* @param ref - reference fields.
			* @param tail - the character following the range before editing.
			* @returns whether the range mapped and the edit applied.
			*/
			insertReference(span, ref, tail) {
				let applied = false;
				this.applyEdit(() => {
					applied = $replaceDetectSpanWithNodes(span, tail === " " ? [$createReferenceChipNode(ref)] : [$createReferenceChipNode(ref), Go(" ")]);
				});
				return applied;
			}
			/**
			* Replace a span with a command chip followed by the claim token's
			* argument separator, unless the separator already follows.
			* @param span - detect-coordinate range.
			* @param claim - the command claim the chip anchors.
			* @param tail - the character following the range before editing.
			* @param mergeHistory - merge into the previous history entry (a restored
			* draft's chip is part of its seed, not an undoable step).
			* @returns whether the range mapped and the edit applied.
			*/
			insertCommand(span, claim, tail, mergeHistory = false) {
				const separator = claim.token.slice(claim.token.trimEnd().length);
				let applied = false;
				this.applyEdit(() => {
					applied = $replaceDetectSpanWithNodes(span, separator === "" || tail === separator.charAt(0) ? [$createCommandChipNode(claim)] : [$createCommandChipNode(claim), Go(separator)]);
				}, mergeHistory ? xo : void 0);
				return applied;
			}
			/**
			* Insert an ordered file-reference batch after the live selection without deleting it.
			* @param references - validated references in source order.
			* @returns whether the live insertion position accepted the batch.
			*/
			insertFileReferences(references) {
				if (references.length === 0) return true;
				let applied = false;
				this.applyEdit(() => {
					const projection = $projectComposer((key) => this.occurrenceIdOf(key));
					const at = projection.selection?.end ?? projection.detectText.length;
					const before = projection.detectText.slice(0, at);
					const nodes = references.flatMap((ref) => [$createReferenceChipNode(ref), Go(" ")]);
					if (before !== "" && !/\s$/u.test(before)) nodes.unshift(Go(" "));
					applied = $replaceDetectSpanWithNodes({
						start: at,
						end: at
					}, nodes);
				}, Co);
				return applied;
			}
			/**
			* Insert one quote after the retained draft selection as an independent undo edit.
			* @param text - nonblank selected transcript text.
			* @param labels - current localized editor controls.
			* @returns whether the insertion position accepted the node.
			*/
			insertQuote(text, labels) {
				let applied = false;
				this.applyEdit(() => {
					const projection = $projectComposer((key) => this.occurrenceIdOf(key));
					const at = projection.selection?.end ?? projection.detectText.length;
					applied = $replaceDetectSpanWithNodes({
						start: at,
						end: at
					}, [$createQuoteNode(text, labels), Go(" ")]);
				}, Co);
				return applied;
			}
			/** Remove one quote node and leave the editor caret at its former position. */
			removeQuote(key) {
				const node = Ys(key);
				if (!$isQuoteNode(node)) return false;
				const parent = node.getParent();
				const offset = node.getIndexWithinParent();
				const separator = node.getNextSibling();
				Al(mo);
				if (Xo(separator) && separator.getTextContent().startsWith(" ")) {
					const remaining = separator.getTextContent().slice(1);
					if (remaining === "") separator.remove();
					else separator.setTextContent(remaining);
				}
				node.remove();
				const caret = Math.min(offset, parent?.getChildrenSize() ?? 0);
				parent?.select(caret, caret);
				queueMicrotask(() => {
					this.editor.getRootElement()?.focus({ preventScroll: true });
				});
				return true;
			}
			/** Delete the QuoteNode immediately beside one collapsed caret. */
			deleteAdjacentQuote(event, backward) {
				const selection = Kr();
				if (!ur(selection) || !selection.isCollapsed()) return false;
				let adjacent = kl(selection.anchor, backward);
				if (!$isQuoteNode(adjacent) && backward && selection.anchor.type === "text") {
					const anchor = selection.anchor.getNode();
					if (Xo(anchor) && selection.anchor.offset === 1 && anchor.getTextContent().startsWith(" ")) adjacent = anchor.getPreviousSibling();
				}
				if (!$isQuoteNode(adjacent)) return false;
				event.preventDefault();
				return this.removeQuote(adjacent.getKey());
			}
			/**
			* Clear committed content using the model's suffix decision inside the editor update.
			* @param prefixLength - returns the clipboard-prefix length to remove, or null to clear the root.
			*/
			clearCommittedDraft(prefixLength) {
				this.editor.update(() => {
					const layout = $composerLayout();
					const length = prefixLength(layout.clipboardText);
					if (length !== null) {
						$replaceDetectSpanWithText({
							start: 0,
							end: detectOffsetOfClipboardOffset(layout, length)
						}, "");
						return;
					}
					const root = nl();
					root.clear();
					root.selectEnd();
				}, {
					discrete: true,
					tag: [xo, DRAFT_SUBMITTED_TAG]
				});
			}
			/**
			* Import semantic content or a model-selected failure snapshot with fresh reference nodes.
			* @param draft - clipboard text.
			* @param occurrences - reference occurrences in clipboard order.
			* @param quotes - atomic quotes in clipboard order.
			* @param labels - localized quote controls.
			*/
			restoreDraft(draft, occurrences, quotes = [], labels = { remove: "" }) {
				this.editor.update(() => {
					const root = nl();
					root.clear();
					let paragraph = es$1();
					root.append(paragraph);
					const appendText = (text) => {
						const lines = text.replace(REFERENCE_PLACEHOLDER_RE, "").split("\n");
						for (let i = 0; i < lines.length; i += 1) {
							const line = lines[i];
							if (line !== "") paragraph.append(Go(line));
							if (i < lines.length - 1) {
								paragraph = es$1();
								root.append(paragraph);
							}
						}
					};
					let cursor = 0;
					const spans = [...occurrences.map((reference) => ({
						kind: "reference",
						value: reference
					})), ...quotes.map((quote) => ({
						kind: "quote",
						value: quote
					}))].sort((a, b) => a.value.offset - b.value.offset);
					for (const span of spans) {
						const occurrence = span.value;
						appendText(draft.slice(cursor, occurrence.offset));
						if (span.kind === "quote") {
							paragraph.append($createQuoteNode(span.value.text, labels));
							cursor = occurrence.offset + occurrence.length;
							continue;
						}
						const reference = span.value;
						paragraph.append(new ReferenceChipNode({
							source: reference.source,
							ref: reference.ref,
							label: reference.label,
							...reference.appearance === void 0 ? {} : { appearance: reference.appearance },
							clipboardText: reference.clipboardText
						}, reference.invalid === true));
						cursor = occurrence.offset + occurrence.length;
					}
					appendText(draft.slice(cursor));
					root.selectEnd();
				}, {
					discrete: true,
					tag: xo
				});
			}
			/** Cut the editor's undo history after a committed clear or restoration. */
			clearHistory() {
				this.editor.dispatchCommand(Nn$1, void 0);
			}
		};
		//#endregion
		//#region lib/types/client/input/facade.js
		/** Guard tier from the machine phase. */
		function guardOf(phase) {
			switch (phase) {
				case "plain": return "plain";
				case "claimed": return "claimed";
				default: return "frozen";
			}
		}
		/** Whether an attempt owns the draft: the editor and attachments are read-only until it settles. */
		function frozen(phase) {
			return phase === "adjudicating" || phase === "submitting" || phase === "sending";
		}
		/** Whether two projections differ in content (selection and caret excluded). */
		function projectionContentChanged(prev, next) {
			if (prev.clipboardText !== next.clipboardText || prev.detectText !== next.detectText) return true;
			if (prev.command !== next.command) return true;
			if (prev.quotes.length !== next.quotes.length || prev.quotes.some((quote, i) => {
				const old = next.quotes[i];
				return old?.text !== quote.text || old.offset !== quote.offset;
			})) return true;
			if (prev.occurrences.length !== next.occurrences.length) return true;
			return next.occurrences.some((occ, i) => {
				const old = prev.occurrences[i];
				return old === void 0 || old.occurrenceId !== occ.occurrenceId || old.invalid !== occ.invalid;
			});
		}
		/** Message of a failure surfaced as a composer notice. */
		function errorText(error) {
			return error instanceof Error ? error.message : String(error);
		}
		const EMPTY_QUEUE$1 = [];
		/** Unavailable catalogs contain no named text references. */
		const EMPTY_LEXICON$1 = /* @__PURE__ */ new Map();
		/**
		* The per-session input facade: scoped-event application verbs +
		* setDraft/submit + the published InputState store, over a shell-owned
		* Lexical editor.
		*/
		var SessionInputShell = class {
			deps;
			/** Published editor projection + submit-plane state + queue overlay (the InputZone currency source). */
			state;
			/** Latest surfaced notice (null after clear); the bar renders errors as banners and information inline. */
			notices = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(null);
			/** The shell-owned editor (text + chip truth); the composer binds its contenteditable to it. */
			get editor() {
				return this.draftEditor.editor;
			}
			/** The public provide-channel action face (one stable identity per session). */
			actions = {
				insertQuote: (text) => this.insertQuote(text),
				captureInsertion: () => ({
					...this.caretSpan(),
					draftRev: this.rev
				}),
				insertText: (text, span) => {
					if (frozen(this.snapshot.phase) || this.disposed) return false;
					if (span.draftRev !== this.rev) return false;
					return this.draftEditor.insertAsyncText(span, text);
				},
				setDraft: (text) => {
					this.setDraft(text);
				},
				persistDraft: () => {
					this.persistCurrentDraft();
				},
				addAttachments: (ids) => this.addAttachments(ids),
				removeAttachment: (id) => {
					this.removeAttachment(id);
				},
				pruneAttachments: (ids) => {
					this.pruneAttachments(ids);
				},
				submit: () => {
					this.submit("queue");
				}
			};
			core = new SubmitMachine();
			draftEditor;
			get projection() {
				return this.draftEditor.projection;
			}
			rev = 0;
			unregister;
			noticeSeq = 0;
			lastPublishedDraft;
			draftSnapshotCache;
			attachmentIds = [];
			disposed = false;
			/** Conversation store writer for the current semantic document. */
			persistDraft;
			/** A restored draft's command token waiting for the trigger pipeline, with the revision its restore produced. */
			pendingCommand;
			/** The in-flight claim resolution for a restored command chip. */
			commandRestore;
			/** The mounted composer's file-picker opener (scoped pick-files event target). */
			filePicker;
			unsubscribeInbox;
			constructor(deps) {
				this.deps = deps;
				this.draftEditor = new DraftEditorRuntime({
					onUpdate: () => {
						this.onEditorUpdate();
					},
					quoteLabels: () => ({ remove: this.deps.quoteRemoveLabel?.() ?? "" }),
					openReference: (source, reference) => this.deps.inputTriggers?.()?.openReference(source, reference) ?? false,
					lexicon: () => this.lexicon.getSnapshot(),
					resolveLexicon: () => this.deps.inputTriggers?.()?.lexicon
				});
				this.unregister = this.draftEditor.register();
				this.state = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(this.compose());
				this.unsubscribeInbox = deps.inbox?.subscribe(() => {
					this.publish();
				});
			}
			/** Re-project, sync the claim with the leading command chip, publish, and feed trigger tracking after every editor commit. */
			onEditorUpdate() {
				if (projectionContentChanged(this.draftEditor.refreshProjection(), this.projection)) {
					this.rev += 1;
					this.dispatchRun({
						type: "draft-changed",
						command: this.projection.command
					});
				}
				const caret = this.projection.caret;
				if (caret !== null) this.deps.inputTriggers?.()?.track(this.projection.detectText, caret, { tier: guardOf(this.core.state.phase) }, this.rev);
			}
			/**
			* Replace the whole draft (persisted-draft seed and programmatic writes).
			* Placeholder-sanitized; newlines split paragraphs; the caret lands at the
			* end. Merged into history so a seed is not an undoable step of its own.
			* @param text - plain text or the complete semantic document.
			*/
			setDraft(text) {
				const draft = resolveDraftInput(text);
				this.cancelCommandRestore();
				if (draft.references.length === 0 && (draft.quotes?.length ?? 0) === 0) this.draftEditor.setDraft(draft.text);
				else this.draftEditor.restoreDraft(draft.text, draft.references, draft.quotes, { remove: this.deps.quoteRemoveLabel?.() ?? "" });
				if (draft.command === void 0) return;
				this.pendingCommand = {
					token: draft.command.token,
					rev: this.rev
				};
				this.restoreCommand();
			}
			/** @param text - selected transcript text. @returns whether the editable draft accepted the quote. */
			insertQuote(text) {
				if (this.disposed || this.snapshot.phase !== "plain" || this.deps.quoteInsertionAllowed?.() === false || text.trim() === "") return false;
				const inserted = this.draftEditor.insertQuote(text.replace(/\r\n?/gu, "\n"), { remove: this.deps.quoteRemoveLabel?.() ?? "" });
				if (inserted) this.focus();
				return inserted;
			}
			/**
			* Reconnect optional catalog notifications and resume a pending command
			* chip restore without waiting for another edit.
			*/
			refreshLexiconSubscription() {
				if (this.disposed) return;
				this.draftEditor.refreshLexiconSubscription();
				this.restoreCommand();
			}
			/**
			* Rebuild the command chip a restored draft carried once the trigger
			* pipeline can resolve its claim. The rebuild applies only at the revision
			* the restore produced: an edit made while the claim resolves keeps the
			* literal token, which Enter still adjudicates as the command.
			*/
			restoreCommand() {
				const pending = this.pendingCommand;
				const inputTriggers = this.deps.inputTriggers?.();
				if (pending === void 0 || inputTriggers === void 0 || this.disposed) return;
				this.pendingCommand = void 0;
				const restore = new AbortController();
				this.commandRestore = restore;
				const spelling = pending.token.trimEnd();
				inputTriggers.resolveClaim(spelling, restore.signal).then((claim) => {
					if (restore.signal.aborted) return;
					this.commandRestore = void 0;
					if (claim !== void 0) this.applyClaim(claim, {
						start: 0,
						end: spelling.length,
						draftRev: pending.rev
					}, true);
				}, (_error) => {
					if (this.commandRestore === restore) this.commandRestore = void 0;
				});
			}
			/** Drop a pending or in-flight command chip restore. */
			cancelCommandRestore() {
				this.pendingCommand = void 0;
				this.commandRestore?.abort();
				this.commandRestore = void 0;
			}
			/** Current semantic document, stable until its content revision changes. */
			get draftSnapshot() {
				if (this.draftSnapshotCache?.revision === this.rev) return this.draftSnapshotCache.value;
				const value = snapshotDraft(this.projection.clipboardText, this.projection.occurrences, this.projection.command?.token, this.projection.quotes);
				this.draftSnapshotCache = {
					revision: this.rev,
					value
				};
				return value;
			}
			/** Persist the latest document without changing the editor or binding a writer. */
			persistCurrentDraft() {
				this.persistDraft?.(this.draftSnapshot);
			}
			/**
			* Apply one new-task request to this already-initialized input model.
			* @param options - content to adopt and the handling of an existing draft.
			* @returns applied when the requested text is adopted, even if unchanged;
			* preserved when the current draft is kept; blocked after disposal or during a pending submission.
			*/
			requestDraftInitialization(options) {
				if (this.draftInitializationBlocked()) return "blocked";
				const whenDraftExists = options.whenDraftExists ?? (options.clearPreviousDraft === true ? "replace" : "keep");
				if (whenDraftExists === "replace") {
					this.setDraft(options.prompt ?? "");
					return "applied";
				}
				if (options.prompt === void 0) return "preserved";
				if (this.snapshot.draft === "" && this.attachmentIds.length === 0) {
					this.setDraft(options.prompt);
					return "applied";
				}
				if (whenDraftExists === "keep") return "preserved";
				this.draftEditor.appendDraft(options.prompt);
				return "applied";
			}
			draftInitializationBlocked() {
				return this.disposed || frozen(this.core.state.phase);
			}
			/** Append ordered attachment ids unless an admission transaction is locked. */
			addAttachments(ids) {
				if (frozen(this.snapshot.phase)) return false;
				if (ids.length === 0) return true;
				this.attachmentIds = [...this.attachmentIds, ...ids];
				this.publish();
				return true;
			}
			/**
			* Add validated file references and attachment ids while admission is editable.
			* @param references - reference chips in source order.
			* @param ids - newly allocated attachment ids.
			* @returns false when admission is locked or the editor refuses the insertion.
			*/
			addFiles(references, ids) {
				if (frozen(this.snapshot.phase)) return false;
				if (!this.draftEditor.insertFileReferences(references)) return false;
				this.attachmentIds = [...this.attachmentIds, ...ids];
				this.publish();
				return true;
			}
			/**
			* Remove one attachment id from this draft. Busy admission phases refuse, like
			* {@link addAttachments}: a removal landing while a send serializes would
			* otherwise vanish from the rail yet still ride the in-flight send.
			*/
			removeAttachment(id) {
				if (frozen(this.snapshot.phase)) return false;
				const next = this.attachmentIds.filter((candidate) => candidate !== id);
				if (next.length === this.attachmentIds.length) return false;
				this.attachmentIds = next;
				this.publish();
				return true;
			}
			/**
			* Keep only ids that still resolve in the browser attachment registry.
			* @param available - live registry ids.
			*/
			pruneAttachments(available) {
				const keep = new Set(available);
				const next = this.attachmentIds.filter((id) => keep.has(id));
				if (next.length === this.attachmentIds.length) return;
				this.attachmentIds = next;
				this.publish();
			}
			/**
			* Insert pasted plain text over the current editor selection
			* (placeholder-sanitized). The paste event's own default is suppressed by
			* the caller; PASTE_TAG makes the paste its own history boundary, so one
			* undo never removes both the paste and typing inside the merge window.
			* @param text - pasted plain text.
			*/
			paste(text) {
				this.draftEditor.paste(text);
			}
			/**
			* Enter adjudication + submit transaction + default sink with the draft, its
			* reference chips, and its attachments as the user sent them. Effects fan
			* out from the machine; this method only feeds the event. Lock entry
			* (adjudicating/submitting/sending) force-closes the transient layers: the
			* popup dismisses and the menu tracks frozen.
			*/
			submit(mode = "queue", source) {
				if (this.disposed) return;
				const timestamp = Date.now();
				let state;
				if (this.snapshot.phase === "plain" && (this.snapshot.draft.trim() !== "" || this.attachmentIds.length > 0)) try {
					state = this.deps.submissionState?.();
				} catch (_error) {}
				const submission = Object.freeze({
					timestamp,
					mode,
					...source === void 0 ? {} : { source },
					...state === void 0 ? {} : { state }
				});
				const before = this.snapshot;
				if (before.phase === "claimed" && this.attachmentIds.length > 0 && before.claim?.attachments !== true) {
					this.notify("error", this.deps.commandAttachments.unsupportedNotice(before.claim?.token ?? before.draft));
					return;
				}
				this.dispatchRun({
					type: "enter",
					mode,
					draft: this.projection.clipboardText,
					occurrences: [...this.projection.occurrences],
					quotes: [...this.projection.quotes],
					attachmentIds: [...this.attachmentIds],
					submission
				});
				if (frozen(this.snapshot.phase)) {
					this.deps.popup?.()?.dismiss();
					this.deps.inputTriggers?.()?.track(this.projection.detectText, 0, { tier: "frozen" }, this.rev);
				}
			}
			/**
			* Keyboard arbitration while the menu is open.
			* @param key - the intercepted key.
			* @param composing - IME composition guard state.
			* @returns the menu's verdict; 'pass' when no pipeline is mounted.
			*/
			arbitrate(key, composing) {
				return this.deps.inputTriggers?.()?.arbitrate(key, composing) ?? "pass";
			}
			/**
			* Steer every still-pending queued message into the running turn (the
			* empty-draft accelerated-Enter gesture). Execution belongs to the hub's
			* queue choreography; absent dep = the gesture falls back to the machine's
			* empty-draft no-op.
			*/
			steerQueue() {
				this.deps.steerQueue?.();
			}
			/**
			* Space adjudication over the controller's hot state.
			* @returns true = a claim/insert was applied — the caller preventDefaults.
			*/
			space() {
				const inputTriggers = this.deps.inputTriggers?.();
				if (inputTriggers === void 0) return false;
				return inputTriggers.onSpace();
			}
			/** Dismiss the popupSelect shell (any interaction outside the box). */
			dismissPopup() {
				this.deps.popup?.()?.dismiss();
			}
			/**
			* The live selection as a detect-coordinate span (menu-launcher synthetic
			* hits replace it on pick); an absent selection answers a collapsed span at
			* the document end.
			* @returns the ordered [start, end) span in detect coordinates.
			*/
			caretSpan() {
				return this.draftEditor.caretSpan();
			}
			/**
			* Hot plain-text reference lexicon source for the decoration scan:
			* delegates to the controller's aggregated store. Stable
			* identity per shell; without a pipeline the snapshot is the empty Map and
			* subscribers never fire.
			*/
			lexicon = {
				getSnapshot: () => this.deps.inputTriggers?.()?.lexicon.getSnapshot() ?? EMPTY_LEXICON$1,
				subscribe: (fn) => this.deps.inputTriggers?.()?.lexicon.subscribe(fn) ?? (() => {})
			};
			/**
			* Apply one command claim (scoped begin-command event listener body): the
			* editor replaces [0, span.end) with the command chip and its separator,
			* then the machine enters claimed.
			* @param claim - the command claim from the pick path.
			* @param span - pick-time span snapshot (detect coordinates).
			* @returns whether the edit applied (phase, span CAS, and leading guard passed).
			*/
			beginCommand(claim, span) {
				return this.applyClaim(claim, span, false);
			}
			/**
			* Replace [0, span.end) with the command chip and enter claimed.
			* @param mergeHistory - merge the edit into the previous history entry.
			* @returns whether the edit applied.
			*/
			applyClaim(claim, span, mergeHistory) {
				const phase = this.core.state.phase;
				if (phase !== "plain" && phase !== "claimed") return false;
				if (span.draftRev !== this.rev) return false;
				if (this.projection.detectText.slice(0, span.start).trim() !== "") return false;
				const tail = this.projection.detectText.slice(span.end, span.end + 1);
				if (!this.draftEditor.insertCommand({
					start: 0,
					end: span.end
				}, claim, tail, mergeHistory)) return false;
				this.dispatchRun({
					type: "claim",
					claim
				});
				return true;
			}
			/**
			* Apply one reference insertion (scoped insert-reference event listener
			* body): the editor replaces the span with one chip node, followed by a
			* separating space unless one is already next.
			* @param ref - the reference insertion from the pick path.
			* @param span - pick-time span snapshot (detect coordinates).
			* @returns whether the edit applied.
			*/
			insertReference(ref, span) {
				const phase = this.core.state.phase;
				if (phase !== "plain" && phase !== "claimed") return false;
				if (span.draftRev !== this.rev) return false;
				const tail = this.projection.detectText.slice(span.end, span.end + 1);
				return this.draftEditor.insertReference(span, ref, tail);
			}
			/**
			* Consume one command token after business success (scoped consume-token
			* event listener body). Span guard: revision CAS then splice; bare-token
			* guard: trimmed-draft equality then clear.
			* @param guard - exact span or bare-token guard.
			* @returns whether the token was consumed.
			*/
			consumeToken(guard) {
				if (guard.kind === "span") {
					if (guard.span.draftRev !== this.rev || guard.span.start === guard.span.end) return false;
					return this.draftEditor.replaceText(guard.span, "");
				}
				if (guard.token === "" || this.projection.clipboardText.trim() !== guard.token) return false;
				this.setDraft("");
				return true;
			}
			/**
			* Insert plain reference text over the pick-time span (scoped insert-text
			* event listener body; the plain-text reference path). The editor gains
			* ordinary characters — no chip node; the chip look is a scan-derived
			* decoration, never state.
			* @param text - the plain reference text to splice in (e.g. `/name `).
			* @param span - pick-time span snapshot (detect coordinates).
			* @param keepCompleting - contract passenger; completion re-opening is
			* automatic here (the update listener re-tracks at the settled caret, so an
			* open token — a directory pick's trailing slash — reopens the menu without
			* an explicit re-track).
			* @returns whether the text was applied.
			*/
			insertText(text, span, keepCompleting = false) {
				if (span.draftRev !== this.rev) return false;
				return this.draftEditor.replaceText(span, text);
			}
			/**
			* Surface a notice from outside the machine (detached command results).
			* @param level - severity tier.
			* @param text - notice body.
			*/
			notify(level, text) {
				this.noticeSeq += 1;
				this.notices.set({
					level,
					text,
					seq: this.noticeSeq
				});
			}
			/**
			* Return the keyboard to the composer with the caret it last held. Lexical's
			* own focus restores its stored selection; a bare DOM focus on the
			* contenteditable would land the caret at the start instead.
			*/
			focus() {
				this.editor.getRootElement()?.focus({ preventScroll: true });
				this.editor.focus();
			}
			/**
			* Teardown the shell, abort the in-flight attempt, and return every
			* browser-owned attachment the draft still holds, including those of a
			* message the Host has not accepted yet.
			* @returns attachment ids the scope disposer must release.
			*/
			dispose() {
				if (this.disposed) return [];
				const retained = [...this.attachmentIds];
				this.disposed = true;
				this.cancelCommandRestore();
				this.dispatchRun({ type: "release" });
				this.unsubscribeInbox?.();
				this.unregister();
				return retained;
			}
			/** Read the live input state (guard derivation reads here). */
			get snapshot() {
				return this.state.getSnapshot();
			}
			/**
			* Bind the Conversation store writer without importing or saving content.
			* @param write - semantic draft writer; persistCurrentDraft flushes the initial value.
			* @returns the unbind disposer.
			*/
			bindDraftPersistence(write) {
				this.persistDraft = write;
				return () => {
					if (this.persistDraft === write) this.persistDraft = void 0;
				};
			}
			/**
			* Bind the mounted composer's file action and live intake availability.
			* @param picker - availability query and native file-dialog opener.
			* @returns the unbind disposer.
			*/
			bindFilePicker(picker) {
				this.filePicker = picker;
				return () => {
					if (this.filePicker === picker) this.filePicker = void 0;
				};
			}
			/**
			* Read the mounted composer's live file-intake availability.
			* @returns false when no accepting composer is mounted.
			*/
			canPickFiles() {
				return this.filePicker?.available() === true;
			}
			/**
			* Open the native file dialog when the mounted composer accepts files.
			* @returns whether the opener was called.
			*/
			pickFiles() {
				if (this.filePicker === void 0 || !this.filePicker.available()) return false;
				this.filePicker.open();
				return true;
			}
			/** Dispatch one machine event and execute its effects. */
			dispatchRun(ev) {
				this.run(this.core.dispatch(ev));
			}
			run(effects) {
				for (const fx of effects) this.execute(fx);
				this.publish();
			}
			execute(fx) {
				switch (fx.type) {
					case "notice":
						this.noticeSeq += 1;
						this.notices.set({
							level: fx.level,
							text: fx.text,
							seq: this.noticeSeq
						});
						return;
					case "adjudicate":
						this.adjudicate(fx.attempt, fx.draft);
						return;
					case "begin-submit":
						this.beginSubmit(fx.attempt, fx.claim, fx.args);
						return;
					case "default-sink":
						this.sinkSerialized(fx.attempt, fx.draft, fx.mode);
						return;
					case "commit-draft":
						this.commitDraft(fx.retainSuffixOf);
						return;
				}
			}
			/**
			* Execute the commit-draft effect: clear the committed content (retaining
			* a pure typed-during-flight suffix when the snapshot allows) and cut the
			* undo history so sent content cannot resurrect.
			*/
			commitDraft(retainSuffixOf) {
				this.draftEditor.clearCommittedDraft((clip) => {
					if (retainSuffixOf !== null && clip !== retainSuffixOf && clip.startsWith(retainSuffixOf)) return retainSuffixOf.length;
					return null;
				});
				this.draftEditor.clearHistory();
			}
			/**
			* Prompt serialization before the sink: expand each chip occurrence of the
			* sent draft to its owner's model form via the session controller's codec
			* routing and format each quote as Markdown, then send it with the
			* attachments captured at Enter. Owner missing or serialization failure
			* settles the send as failed, which keeps the draft. Chip-free drafts skip
			* the async detour.
			*/
			sinkSerialized(attempt, draft, mode) {
				this.notifySubmission(attempt.submission);
				const { occurrences, quotes, attachmentIds } = attempt;
				const inputTriggers = this.deps.inputTriggers?.();
				const prompt = serializeDraftPrompt(snapshotDraft(draft, occurrences, void 0, quotes), async (source, ref) => {
					if (inputTriggers === void 0) throw new Error(`no serializer for reference source "${source}"`);
					return inputTriggers.serializeReference(source, ref, attempt.signal);
				});
				const send = (text) => {
					if (this.dead(attempt)) return;
					this.settleSink(attempt, this.deps.defaultSink(text, attachmentIds, mode, attempt.signal, () => {
						this.acceptSink(attempt);
					}));
				};
				if (!(prompt instanceof Promise)) {
					send(prompt);
					return;
				}
				prompt.then(send, (error) => {
					this.failSink(attempt, error);
				});
			}
			notifySubmission(submission) {
				if (submission === void 0) return;
				try {
					this.deps.messageSubmitted?.(submission);
				} catch (_error) {}
			}
			/**
			* Settle the message being sent. Once the Host accepts it, its attachments
			* leave the draft before the editor clears; ConversationController releases
			* them when the message's echo retires. Any other outcome keeps the draft
			* and its attachments for correction.
			*/
			settleSink(attempt, pending) {
				pending.then((outcome) => {
					if (!this.dead(attempt)) this.applySinkOutcome(attempt, outcome);
				}, (error) => {
					this.failSink(attempt, error);
				});
			}
			/** Settle the message being sent as accepted when the sink learns the Host's acceptance before its outcome. */
			acceptSink(attempt) {
				if (this.dead(attempt) || this.core.sendingAttempt !== attempt) return;
				this.applySinkOutcome(attempt, { kind: "success" });
			}
			applySinkOutcome(attempt, outcome) {
				const accepted = outcome.kind === "success";
				if (accepted && attempt.attachmentIds.length > 0) {
					const sent = new Set(attempt.attachmentIds);
					this.attachmentIds = this.attachmentIds.filter((id) => !sent.has(id));
				}
				this.dispatchRun({
					type: "sink-settled",
					attempt,
					ok: accepted,
					outcome
				});
			}
			/** Settle a send that ended without a Host outcome; the draft stays for correction. */
			failSink(attempt, error) {
				if (this.dead(attempt)) return;
				this.dispatchRun({
					type: "sink-settled",
					attempt,
					ok: false,
					message: errorText(error)
				});
			}
			/** Enter adjudication: poll the session controller; failure = notice + draft retained (never a silent downgrade). */
			adjudicate(attempt, draft) {
				const inputTriggers = this.deps.inputTriggers?.();
				if (inputTriggers === void 0) {
					this.dispatchRun({
						type: "adjudicated",
						attempt,
						outcome: void 0
					});
					return;
				}
				inputTriggers.adjudicate(draft.trim(), attempt.signal, { attachments: this.attachmentIds.length }).then((outcome) => {
					if (this.dead(attempt)) return;
					this.dispatchRun({
						type: "adjudicated",
						attempt,
						outcome
					});
				}, (error) => {
					if (this.dead(attempt)) return;
					const message = error instanceof Error ? error.message : String(error);
					this.dispatchRun({
						type: "adjudication-failed",
						attempt,
						message
					});
				});
			}
			/**
			* The submit transaction: claim.submit against the session scope; ok maps
			* from the outcome kind. An accepting claim receives the serialized draft
			* attachments, which are cleared and released only on a success outcome; a
			* failure (serialize, transport, or handler error) keeps draft and attachments
			* for correction.
			*/
			beginSubmit(attempt, claim, args) {
				const attachmentIds = claim.attachments === true ? attempt.attachmentIds : [];
				Promise.resolve().then(async () => {
					const attachments = attachmentIds.length > 0 ? await this.deps.commandAttachments.serialize(attachmentIds) : [];
					if (this.dead(attempt)) return void 0;
					return claim.submit(args, this.deps.actx, attachments);
				}).then((outcome) => {
					if (outcome === void 0 || this.dead(attempt)) return;
					if (outcome.kind === "success" && attachmentIds.length > 0) {
						const submitted = new Set(attachmentIds);
						this.attachmentIds = this.attachmentIds.filter((id) => !submitted.has(id));
						this.deps.commandAttachments.release(attachmentIds);
					}
					this.dispatchRun({
						type: "submit-settled",
						attempt,
						ok: outcome.kind === "success",
						command: this.projection.command,
						outcome,
						...outcome.kind === "error" && outcome.text === void 0 ? { message: "command failed" } : {}
					});
				}, (error) => {
					if (this.dead(attempt)) return;
					const message = error instanceof Error ? error.message : String(error);
					this.dispatchRun({
						type: "submit-settled",
						attempt,
						ok: false,
						command: this.projection.command,
						message
					});
				});
			}
			/** Late-settlement guard: superseded attempts and disposed facades drop silently. */
			dead(attempt) {
				return this.disposed || attempt.signal.aborted;
			}
			compose() {
				const core = this.core.state;
				return {
					draft: this.projection.clipboardText,
					attachmentIds: this.attachmentIds,
					draftRev: this.rev,
					phase: core.phase,
					...core.claim !== void 0 ? { claim: core.claim } : {},
					occurrences: this.projection.occurrences,
					queue: this.deps.inbox?.getSnapshot()?.["next-turn"] ?? EMPTY_QUEUE$1
				};
			}
			publish() {
				const next = this.compose();
				this.state.set(next);
				const draft = this.draftSnapshot;
				if (draft !== this.lastPublishedDraft) {
					this.lastPublishedDraft = draft;
					this.persistDraft?.(draft);
				}
			}
		};
		//#endregion
		//#region lib/types/client/input/submission-analytics.js
		/**
		* Map a preset id to its fixed analytics category; custom ids never leave the Client.
		* @param id - Agent preset id the Session records.
		* @returns the built-in category, or other.
		*/
		function analyticsPreset(id) {
			switch (id) {
				case "cordis": return "creator";
				case "ptc": return "ptc";
				case "minimal": return "minimal";
				case "standard": return "standard";
				default: return "other";
			}
		}
		/**
		* Report the original message occurrence without reading newer Session facts.
		* @param ctx - client context.
		* @param submission - original occurrence and Session snapshot.
		*/
		function reportMessageSubmission(ctx, submission) {
			const { state, timestamp, mode } = submission;
			if (state === void 0) return;
			const model = state.model;
			ctx.get("productAnalytics")?.track("send_button_click", {
				...state.sessionId === void 0 ? {} : { session_id: state.sessionId },
				...model === void 0 ? {} : {
					model_name: `${model.provider}/${model.name}`,
					...model.effort === void 0 ? {} : { thinking_effort: model.effort }
				},
				run_mode: state.runMode,
				msg_type: state.running ? mode : "default",
				is_new_session: state.newSession,
				...state.agentPreset === void 0 ? {} : { agent_preset: analyticsPreset(state.agentPreset) }
			}, timestamp);
		}
		//#endregion
		//#region lib/types/client/input/hub.js
		/** Session-addressed input facade registry (SessionInputResolver face + composer-layer extras). */
		var InputHub = class {
			rootCtx;
			t;
			shells = /* @__PURE__ */ new WeakMap();
			/**
			* @param ctx - client root context (services resolved lazily per call — boot order stays free).
			* @param t - conversation-namespace translate thunk (reads the active locale at call time).
			*/
			constructor(rootCtx, t) {
				this.rootCtx = rootCtx;
				this.t = t;
			}
			/**
			* Resolve the facade for one session-scope ctx (SessionInputResolver face).
			* @param actx - session-scope context.
			* @returns the resident per-session facade.
			*/
			for(actx) {
				const sessions = this.sessions();
				const session = sessions.sessionOf(actx);
				const binding = session === void 0 ? void 0 : sessions.binding(session.sessionId);
				if (binding === void 0 || binding.session !== session) throw new Error("conversation.input.for requires a retained Session scope");
				return this.shellFor(binding);
			}
			requestDraftInitialization(binding, options) {
				if (this.sessions().binding(binding.sessionId) !== binding) throw new Error("conversation.input.requestDraftInitialization requires a retained Session binding");
				return this.shellFor(binding).requestDraftInitialization(options);
			}
			/**
			* Resolve the resident shell for an already-retained, addressable Session binding.
			* Draft import completes before return. The Session scope owns input listeners,
			* the inject-managed catalog subscription, and shell teardown.
			* @param binding - session assembly handle.
			* @returns the shell.
			*/
			shellFor(binding) {
				const existing = this.shells.get(binding);
				if (existing !== void 0) return existing;
				const { session, ctx: actx } = binding;
				const shell = new SessionInputShell({
					actx,
					submissionState: () => {
						const state = session.getSnapshot();
						const model = session.projections.faceOf("modelSelection").getSnapshot();
						const plan = session.projections.faceOf("plan").getSnapshot();
						const goal = session.projections.faceOf("goal").getSnapshot();
						const agentPreset = session.projections.faceOf("agentPreset").getSnapshot();
						const selection = model?.next ?? model?.lastUsed;
						return Object.freeze({
							...state.blank ? {} : { sessionId: state.sessionId },
							...selection == null ? {} : { model: Object.freeze({
								provider: selection.provider,
								name: selection.model,
								...selection.reasoningEffort === void 0 ? {} : { effort: selection.reasoningEffort }
							}) },
							runMode: plan?.active ? "plan" : goal?.goal.phase === "active" ? "goal" : "default",
							running: state.running,
							newSession: state.blank,
							...typeof agentPreset === "string" ? { agentPreset } : {}
						});
					},
					messageSubmitted: (submission) => {
						reportMessageSubmission(this.rootCtx, submission);
					},
					inputTriggers: () => this.controller(actx),
					popup: () => this.popup(actx),
					inbox: session.projections.faceOf("inbox"),
					defaultSink: (text, attachmentIds, mode, signal, accept) => this.sink(session, text, attachmentIds, mode, signal, accept),
					quoteRemoveLabel: () => this.t("quote.remove"),
					quoteInsertionAllowed: () => {
						const state = session.getSnapshot();
						return !state.removed && (state.subagent === null || state.subagent.address.mode === "continuable" && state.subagent.parentAvailable === true) && this.conversation().blocks.storeFor(session.sessionId).getSnapshot() === void 0;
					},
					steerQueue: () => {
						this.steerQueue(session, shell);
					},
					commandAttachments: {
						serialize: async (ids) => {
							return (await this.conversation().serializeDraftAttachments(ids)).attachments;
						},
						release: (ids) => {
							const conversation = this.rootCtx.get("conversation");
							for (const attachmentId of ids) conversation?.releaseDraftAttachment(attachmentId);
						},
						unsupportedNotice: (token) => this.t("command.attachmentsUnsupported", { command: token.trim().replace(/^\//u, "") })
					}
				});
				this.shells.set(binding, shell);
				actx.effect(() => {
					const offs = [
						actx.on("slash/input-begin-command", (req) => shell.beginCommand(req.claim, req.span) ? true : void 0),
						actx.on("slash/input-insert-reference", (req) => shell.insertReference(req.reference, req.span) ? true : void 0),
						actx.on("slash/input-consume-token", (req) => shell.consumeToken(req.guard) ? true : void 0),
						actx.on("slash/input-insert-text", (req) => shell.insertText(req.text, req.span, req.continue === true) ? true : void 0)
					];
					return () => {
						for (const off of offs) off();
						const drafts = shell.dispose();
						this.shells.delete(binding);
						const conversation = this.rootCtx.get("conversation");
						for (const attachmentId of drafts) conversation?.releaseDraftAttachment(attachmentId);
					};
				}, "conversation.input: session shell");
				actx.inject(["inputTriggers"], (scope) => {
					scope.effect(() => {
						shell.refreshLexiconSubscription();
						return () => {
							shell.refreshLexiconSubscription();
						};
					}, "conversation.input: reference catalogs");
				});
				shell.setDraft(readConversationDraft(binding.sessionId));
				return shell;
			}
			/**
			* Resident shell by session id (service-face path; the provide channel has
			* normally created it already — this covers direct id-addressed access).
			* @param id - session id.
			* @returns the shell.
			*/
			shell(id) {
				const binding = this.sessions().binding(id);
				if (binding === void 0) throw new Error(`conversation.input: session "${id}" resolved no binding`);
				return this.shellFor(binding);
			}
			/**
			* The InputBar-exclusive keyboard command face: the shell
			* satisfies it structurally; package-internal — handed through the
			* composer-bar entry's inject, never across a plugin boundary.
			* @param id - session id.
			* @returns the shell as the keyboard face.
			*/
			keyboard(id) {
				return this.shell(id);
			}
			/**
			* Query file intake without creating a Session input.
			* @param id - target Session.
			* @returns whether its mounted composer currently accepts files.
			*/
			canPickFiles(id) {
				const binding = this.sessions().binding(id);
				return binding !== void 0 && this.shells.get(binding)?.canPickFiles() === true;
			}
			/**
			* Open the target composer's file dialog under its live intake policy.
			* @param id - target Session.
			*/
			pickFiles(id) {
				const binding = this.sessions().binding(id);
				if (binding !== void 0) this.shells.get(binding)?.pickFiles();
			}
			/**
			* Resolve the optional slash controller for composer chrome that launches
			* the shared candidate menu without typing a trigger.
			* @param id - session id.
			* @returns the resident controller, or undefined when no trigger provider is installed.
			*/
			inputTriggers(id) {
				const binding = this.sessions().binding(id);
				return binding === void 0 ? void 0 : this.controller(binding.ctx);
			}
			/**
			* Default sink: prompt while the composer holds the sent draft. The session
			* is always a real host entity (materialized when its workspace was picked),
			* so there is exactly one path; a refused or failed prompt is an ordinary
			* prompt failure (banner via promptError, draft kept in the composer).
			*/
			sink(session, text, attachmentIds, mode, signal, accept) {
				if (text === "" && attachmentIds.length === 0) return Promise.resolve({ kind: "success" });
				return this.conversation().sendSession(session, text, attachmentIds, mode, signal, accept);
			}
			/**
			* Submit every still-pending queued message through QueueDock Steer, in FIFO
			* request order — the same operation as the queue dock's per-row button.
			* An Agent stopping before a command (`session/steer-unavailable`) or a row already
			* claimed by the agent (`session/queue-item-not-found`) converges silently, while a
			* genuine failure surfaces as one composer notice. Repeated triggers
			* (e.g. two rapid empty-draft chords) rely on that `session/queue-item-not-found`
			* convergence: the snapshot may still list a row the host already steered,
			* and the duplicate Steer is a silent no-op.
			* @param session - the addressed host session.
			* @param shell - the resident shell (notice outlet).
			*/
			async steerQueue(session, shell) {
				const queued = session.projections.faceOf("inbox").getSnapshot()?.["next-turn"] ?? [];
				if (queued.length === 0) return;
				for (const item of queued) {
					const result = await session.updateQueue(item.id, { kind: "steer" });
					if (result.ok) continue;
					if (result.error.code === "session/steer-unavailable" || result.error.code === "session/queue-item-not-found") return;
					shell.notify("error", this.t("queue.steerFailed"));
					return;
				}
			}
			controller(actx) {
				if (this.sessions().sessionOf(actx) === void 0) return void 0;
				return this.rootCtx.get("inputTriggers")?.sessionOf(actx);
			}
			popup(actx) {
				if (this.sessions().sessionOf(actx) === void 0) return void 0;
				return this.rootCtx.get("commandUi")?.popupFor(actx);
			}
			sessions() {
				const sessions = this.rootCtx.get("sessions");
				if (sessions === void 0) throw new Error("conversation.input: sessions service unavailable");
				return sessions;
			}
			conversation() {
				const conversation = this.rootCtx.get("conversation");
				if (conversation === void 0) throw new Error("conversation.input: conversation service unavailable");
				return conversation;
			}
		};
		//#endregion
		//#region lib/types/submission-settings.js
		/** Busy-Enter preference stored in the Host user-settings document. */
		/** Settings namespace owned by the conversation plugin. */
		const CONVERSATION_SETTINGS_NAMESPACE = "ui-conversation";
		/** Field carrying the delivery mode for plain Enter while an agent is busy. */
		const BUSY_ENTER_FIELD = "busyEnter";
		/** Busy-Enter behaviors accepted at settings and input boundaries. */
		const BUSY_ENTER_BEHAVIORS = ["queue", "steer"];
		/** Default preserves Enter-as-Queue for running conversations. */
		const DEFAULT_BUSY_ENTER_BEHAVIOR = "queue";
		/** Durable conversation schema; also the wire envelope the browser scope validates against. */
		const ConversationSettingsFields = { [BUSY_ENTER_FIELD]: Schema.union([...BUSY_ENTER_BEHAVIORS]).default(DEFAULT_BUSY_ENTER_BEHAVIOR) };
		Schema.object(ConversationSettingsFields);
		//#endregion
		//#region lib/types/client/input/submission-policy.js
		/**
		* Composer submission policy. It owns the live busy-Enter preference and
		* resolves submission gestures into queue/steer delivery modes; Host and
		* Agent keep the actual delivery-window authority.
		*/
		/**
		* Resolve one submission gesture against the busy-Enter preference. Plain
		* Enter and the primary Send button share the `enter` gesture, so the button
		* delivers exactly what Enter would. Direct `steer` is intentionally
		* best-effort: AgentLoop turns a closed-window submission into the next waking
		* Queue item.
		* @param preferred - the live busy-Enter preference.
		* @param running - whether the addressed agent currently reports busy.
		* @param gesture - plain Enter (or the Send button) or the Cmd/Ctrl-accelerated chord.
		* @param steeringAvailable - whether this session transport supports steering.
		* @returns Queue outside steer-capable busy state; otherwise the preferred mode or its opposite.
		*/
		function resolveSubmitMode(preferred, running, gesture, steeringAvailable) {
			if (!running || !steeringAvailable) return "queue";
			if (gesture === "enter") return preferred;
			return preferred === "queue" ? "steer" : "queue";
		}
		/**
		* Busy-Enter preference shared by the composer bar inject face and its
		* Settings row: one live store the bar's submission gestures and Send label
		* read, backed by the Host user-settings document when one is composed.
		*/
		var ComposerSubmissionPolicy = class {
			/** Reactive preference source for the composer bar and the Settings row. */
			busyEnter = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(DEFAULT_BUSY_ENTER_BEHAVIOR);
			unsubscribe;
			host;
			/**
			* @param host Shared configuration form; omitted keeps the browser-local default.
			*/
			constructor(host) {
				this.host = host;
				if (host !== void 0) {
					this.unsubscribe = host.subscribe(() => {
						this.adopt(host);
					});
					this.adopt(host);
				}
			}
			/** Release the preference subscription. */
			dispose() {
				this.unsubscribe?.();
			}
			/**
			* Change the busy-state submission behavior; the live value publishes
			* before the durable write starts.
			* @param behavior - Queue or Steer.
			*/
			setBusyEnter(behavior) {
				if (this.busyEnter.getSnapshot() === behavior) return;
				this.busyEnter.set(behavior);
				this.host?.set(BUSY_ENTER_FIELD, behavior);
			}
			/**
			* Adopt the scope's accepted durable behavior without writing it back.
			* @param host - the constructor-narrowed scope driving this adoption.
			*/
			adopt(host) {
				const section = host.getSnapshot().value;
				if (section === void 0 || this.busyEnter.getSnapshot() === section.busyEnter) return;
				this.busyEnter.set(section.busyEnter);
			}
		};
		//#endregion
		//#region lib/types/client/locales.js
		/** `conversation` namespace dictionaries. */
		/** Dictionary namespace owned by this plugin. */
		const NS = "conversation";
		const PLAN_NEXT_ACTION_ZH = "描述你的任务以生成计划";
		const PLAN_NEXT_ACTION_EN = "describe your task to generate plan";
		/** Simplified Chinese dictionary (the key-set source of truth). */
		const zh = {
			"quote.remove": "移除引用",
			"shortcut.newline": "换行",
			"shortcut.complementary": "使用互补的 Queue／Steer 方式",
			"shortcut.slash": "打开命令菜单",
			"shortcut.mention": "打开引用菜单",
			"hint.plan": PLAN_NEXT_ACTION_ZH,
			"hint.goal": "输入目标，智能体将持续执行",
			"hint.goal.active": "当前目标进行中。可输入 edit 修改 / pause 暂停 / resume 继续 / clear 清除",
			"placeholder.plan": PLAN_NEXT_ACTION_ZH,
			"placeholder.default": "发消息或创建任务, / 调用指令, @ 文件或对话",
			"placeholder.unavailable": "会话不可用",
			"placeholder.parentOffline": "父会话已离线，无法继续发送；仍可停止当前运行",
			"placeholder.hero": "描述你想要构建的内容, / 调用指令, @ 文件或对话",
			"placeholder.workspace": "选择一个工作区开始",
			"placeholder.steerQueue": "Cmd/Ctrl+Enter 插话发送全部排队消息",
			"input.commands": "添加文件或调用指令",
			"input.file": "文件",
			"input.stop": "停止生成",
			"input.send": "发送消息",
			"input.sending": "正在发送消息",
			"input.send.queue": "排队发送",
			"input.send.steer": "插话发送",
			"attachment.pending": "待发送附件",
			"attachment.scrollLeft": "向左滚动附件",
			"attachment.scrollRight": "向右滚动附件",
			"attachment.dropTitle": "文件或图片拖动到此处即可添加",
			"attachment.dropDesc": "图片限制：最多 {count} 张，每张 {size}",
			"attachment.dropBlocked": "当前无法添加文件或图片",
			"attachment.directoryDesktopOnly": "只有桌面端支持添加文件夹，浏览器里请添加单个文件",
			"attachment.pathUnavailable": "无法获取文件夹路径，请重新拖入",
			"attachment.pathUnsupported": "路径含有无法引用的字符，请改名后再试",
			"image.pending": "待发送图片",
			"image.openOriginal": "查看原图",
			"image.openOriginalLabel": "{label}，点击查看原图",
			"image.remove": "移除图片 {name}",
			"image.original": "原图",
			"image.label": "图片",
			"image.loadFailed": "图片加载失败，点击重试",
			"image.loading": "图片加载中…",
			"image.preview": "原图预览",
			"image.closePreview": "关闭原图预览",
			"image.unsupportedType": "仅支持 PNG、JPG、WebP、GIF 格式的图片",
			"image.tooMany": "一条消息最多添加 {count} 张图片",
			"image.fileTooLarge": "单张图片不能超过 {size}",
			"image.totalTooLarge": "图片总大小超过 {size}，请移除部分图片",
			"image.tooManyPixels": "图片分辨率过大，请压缩后重试",
			"image.dimensionTooLarge": "图片宽高不能超过 {size}px，请缩小后重试",
			"image.modelUnsupported": "当前模型不支持图片，请切换支持图片的模型",
			"image.sendFailed": "图片发送失败（{reason}），请重新添加图片后再试",
			"file.pending": "待发送文件",
			"file.remove": "移除文件 {name}",
			"file.uploading": "上传中…",
			"file.uploadFailed": "上传失败，点击重试",
			"file.retry": "重试上传 {name}",
			"file.stillUploading": "文件还在上传，请等待上传完成后发送",
			"file.sessionUnavailable": "会话不可用，无法上传文件",
			"file.notStaged": "文件尚未上传成功，请重新添加后再试",
			"file.label": "文件",
			"context.aria": "上下文已用 {percent}",
			"context.used": "上下文已用",
			"context.system": "系统提示词",
			"context.tools": "工具定义",
			"context.messages": "对话消息",
			"settings.enter.title": "繁忙时的发送行为",
			"settings.enter.description": "智能体运行时 Enter 键和发送按钮的行为；Cmd/Ctrl+Enter 使用另一行为",
			"settings.enter.queue": "排队发送",
			"settings.enter.steer": "插话发送",
			"hero.headline": "探索未至之境",
			"hero.preview": "预览版",
			"hero.chooseWorkspace": "选择工作区",
			"session.hierarchy": "会话层级",
			"session.moreViews": "更多会话视图",
			"todo.title": "任务",
			"todo.progress.done": "{done} 已完成",
			"todo.progress.active": "{active} 进行中",
			"todo.progress.pending": "{pending} 待处理",
			"todo.status.completed": "已完成",
			"todo.status.inProgress": "进行中",
			"todo.status.pending": "待处理",
			"todo.rowTitle": "更新任务清单",
			"tool.title.createGoal": "创建目标",
			"tool.title.getGoal": "查看目标",
			"tool.title.updateGoal": "更新目标",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "创建自动化任务",
			"tool.title.listSchedules": "查看自动化任务",
			"tool.title.viewSchedule": "查看自动化任务详情",
			"tool.title.editSchedule": "编辑自动化任务",
			"tool.title.deleteSchedule": "删除自动化任务",
			"tool.title.updateSchedule": "修改自动化任务",
			"detail.state": "状态",
			"detail.todo.completed": "已完成",
			"detail.todo.in_progress": "进行中",
			"detail.todo.pending": "待处理",
			"detail.todo.empty": "任务清单为空",
			"todo.diff.initial": "首次记录",
			"todo.diff.compare": "与上次清单相比",
			"todo.diff.unavailable": "旧清单不可用",
			"todo.diff.noChanges": "清单没有变化",
			"todo.diff.added": "新增 {count}",
			"todo.diff.updated": "更新 {count}",
			"todo.diff.removed": "移除 {count}",
			"todo.diff.unchanged": "{count} 项未变化",
			"todo.diff.addedItem": "新增",
			"todo.diff.updatedItem": "状态变化",
			"todo.diff.movedItem": "顺序调整",
			"todo.diff.removedItem": "移除",
			"detail.goal.empty": "没有目标",
			"detail.goal.active": "进行中",
			"detail.goal.disarmed": "等待继续",
			"detail.goal.paused": "已暂停",
			"detail.goal.blocked": "受阻",
			"detail.goal.complete": "已完成",
			"detail.goal.rounds": "执行轮次",
			"detail.goal.reason": "受阻原因",
			"detail.days": "{count} 天",
			"detail.hours": "{count} 小时",
			"detail.minutes": "{count} 分钟",
			"detail.seconds": "{count} 秒",
			"detail.schedule.once": "单次",
			"detail.schedule.every": "每 {interval}",
			"detail.schedule.when": "计划时间",
			"detail.schedule.frequency": "重复",
			"detail.schedule.scheduled": "等待触发",
			"detail.schedule.overdue": "已到期，等待会话恢复",
			"detail.schedule.active": "已开启",
			"detail.schedule.paused": "已暂停",
			"detail.schedule.ended": "已结束",
			"detail.schedule.empty": "没有自动化任务",
			"detail.schedule.deleted": "已删除",
			"detail.schedule.count": "{count} 个自动化任务",
			"detail.schedule.daily": "每天 {time}（{zone}）",
			"detail.schedule.weekly": "每周 {days} {time}（{zone}）",
			"detail.schedule.cron": "Cron {expression}（{zone}）",
			"detail.schedule.custom": "自定义",
			"detail.weekday.1": "周一",
			"detail.weekday.2": "周二",
			"detail.weekday.3": "周三",
			"detail.weekday.4": "周四",
			"detail.weekday.5": "周五",
			"detail.weekday.6": "周六",
			"detail.weekday.7": "周日",
			"detail.weekday.join": "、",
			"tool.title.inspectProviders": "检查提供方",
			"tool.title.queryRuntime": "查询运行时",
			"tool.title.inspectPlugins": "检查动态插件",
			"tool.title.workflow": "运行工作流",
			"tool.title.ralph": "运行循环工作流",
			"tool.title.readEvent": "读取事件",
			"tool.title.searchEvents": "搜索事件",
			"tool.title.traceEvent": "追踪事件",
			"tool.title.searchSessions": "搜索会话",
			"tool.title.traceSession": "追踪会话",
			"tool.title.listModels": "查看可用模型",
			"tool.title.subagent": "创建子智能体",
			"tool.title.listAgents": "查看子智能体",
			"tool.title.sendMessage": "发送消息",
			"tool.title.interruptAgent": "中断智能体",
			"tool.title.listJobs": "查看后台任务",
			"tool.title.readJob": "读取任务输出",
			"tool.title.killJob": "取消后台任务",
			"tool.title.openTerminal": "创建终端",
			"tool.title.readTerminal": "读取终端",
			"tool.title.listTerminals": "查看终端",
			"tool.title.signalTerminal": "发送终端信号",
			"tool.title.closeTerminal": "关闭终端",
			"tool.title.lsp": "查询代码符号",
			"tool.title.findDefinition": "查找定义",
			"tool.title.findReferences": "查找引用",
			"tool.title.findImplementation": "查找实现",
			"tool.title.hoverSymbol": "查看符号信息",
			"tool.title.spawnTeammate": "创建队友",
			"tool.title.createTeamTask": "创建团队任务",
			"tool.title.getTeamTask": "读取团队任务",
			"tool.title.updateTeamTask": "更新团队任务",
			"tool.title.listTeamTasks": "查看团队任务",
			"tool.title.waitAgent": "等待子智能体",
			"detail.recordedResult": "调用结果",
			"detail.empty": "暂无结果",
			"detail.none": "无",
			"detail.yes": "是",
			"detail.no": "否",
			"detail.moreInInspect": "另有 {count} 项，可在「查看」中读取",
			"detail.status.running": "运行中",
			"detail.status.idle": "空闲",
			"detail.status.ready": "就绪",
			"detail.status.inactive": "未运行",
			"detail.status.provisioning": "准备中",
			"detail.status.failed": "失败",
			"detail.status.completed": "已完成",
			"detail.status.deleted": "已删除",
			"detail.status.killed": "已取消",
			"detail.status.accepted": "已接收",
			"detail.status.queued": "已入队",
			"detail.status.exited": "已退出",
			"detail.field.id": "ID",
			"detail.field.revision": "版本",
			"detail.field.platform": "平台",
			"detail.field.provider": "提供方",
			"detail.field.model": "模型",
			"detail.field.role": "角色",
			"detail.field.context": "上下文",
			"detail.field.owner": "负责人",
			"detail.field.ready": "可开始",
			"detail.field.dependencies": "前置任务",
			"detail.field.writeScopes": "文件范围",
			"detail.field.warnings": "提示",
			"detail.field.diagnostics": "诊断",
			"detail.field.methods": "方法",
			"detail.field.inputSchema": "输入 Schema",
			"detail.field.outputSchema": "输出 Schema",
			"detail.field.currentPackage": "当前包",
			"detail.field.nextPackage": "待运行的包",
			"detail.field.latestRun": "最近运行",
			"detail.field.packages": "版本包",
			"detail.field.registrations": "注册项",
			"detail.field.props": "属性",
			"detail.field.data": "数据",
			"detail.field.source": "来源",
			"detail.field.content": "内容",
			"detail.field.message": "消息",
			"detail.field.messageId": "消息 ID",
			"detail.field.root": "根节点",
			"detail.field.pid": "进程 ID",
			"detail.field.type": "类型",
			"detail.field.time": "时间",
			"detail.field.seq": "事件序号",
			"detail.field.turn": "轮次",
			"detail.field.step": "步骤",
			"detail.field.callId": "调用 ID",
			"detail.field.agents": "启动智能体数",
			"detail.field.result": "结果",
			"detail.field.parent": "父级",
			"detail.field.depth": "层级",
			"detail.field.exitCode": "退出码",
			"detail.field.signal": "信号",
			"detail.field.previousStatus": "中断前状态",
			"detail.field.agent": "智能体 ID",
			"detail.field.job": "任务 ID",
			"detail.field.task": "任务内容",
			"detail.field.processGroup": "进程组",
			"detail.field.availability": "可用状态",
			"detail.field.bestMatch": "最相关事件",
			"detail.field.target": "目标事件",
			"detail.field.surface": "记录状态",
			"detail.agents.count": "{count} 个智能体",
			"detail.jobs.count": "{count} 个后台任务",
			"detail.terminals.count": "{count} 个终端",
			"detail.tasks.count": "{count} 个团队任务",
			"detail.tasks.nextPage": "后面还有任务；下一页位置为 {cursor}",
			"detail.locations.count": "{count} 个位置",
			"detail.location": "第 {line} 行，第 {column} 列",
			"detail.receipt.delivered": "消息已送达",
			"detail.receipt.interrupt": "已请求中断",
			"detail.receipt.started": "已启动",
			"detail.receipt.cancel": "已请求取消",
			"detail.receipt.alreadyFinished": "任务已结束",
			"detail.receipt.signal": "信号已发送",
			"detail.receipt.closed": "已关闭",
			"detail.receipt.closing": "关闭中",
			"detail.wait.noProgress": "没有正在运行的子智能体",
			"detail.wait.title": "子智能体状态",
			"detail.wait.timeout": "等待超时",
			"detail.wait.changed": "检测到变化",
			"detail.agent.reply": "智能体回复",
			"detail.models.title": "可用模型",
			"detail.output.lines": "第 {begin}–{end} 行，共 {total} 行",
			"detail.output.truncated": "输出已截断",
			"detail.providers.count": "{count} 个检查提供方",
			"detail.plugins.count": "{count} 个动态插件",
			"detail.workflow.script": "工作流脚本",
			"detail.ralph.reportedComplete": "智能体报告完成",
			"detail.ralph.reportedBlocker": "智能体报告受阻",
			"detail.ralph.limit": "已达到轮次上限",
			"detail.report.nextSteps": "待完成事项",
			"detail.trace.replacedBy": "被替换为",
			"detail.trace.replacementChain": "替换链",
			"detail.trace.replaces": "替换的事件",
			"detail.trace.sources": "引用来源",
			"detail.trace.derived": "派生事件",
			"detail.trace.ancestors": "祖先会话",
			"detail.trace.descendants": "后代会话",
			"detail.matches.count": "{count} 条匹配",
			"detail.matches.capped": "已达到结果上限，可缩小搜索范围",
			"detail.event.neighbors": "前后事件",
			"todo.completed": "{done}/{total} 已完成",
			"command.attachmentsUnsupported": "/{command} 不接受附件，请先移除附件",
			"ask.rowTitle": "提问",
			"ask.waiting": "等待回答",
			"ask.pending": "已继续工作，仍可回答",
			"ask.pendingDetail": "等待中的问题仍可在输入框中回答",
			"ask.reopen": "回答",
			"ask.review": "查看回答",
			"ask.closed": "已结束",
			"ask.closedDetail": "该问题已结束，结果见下方对话",
			"ask.cancelled": "已取消",
			"ask.cancelledDetail": "本轮已取消，未提交回答",
			"ask.interrupted": "已中断",
			"ask.interruptedDetail": "本轮已中断，未提交回答",
			"ask.answered": "{answered}/{total} 已回答",
			"ask.skipped": "未回答",
			"bash.running": "运行中",
			"bash.failed": "失败",
			"bash.stopped": "已停止",
			"row.running": "运行中",
			"row.preparing": "正在准备调用",
			"row.failed": "失败",
			"row.stopped": "已停止",
			"row.commandArguments": "命令参数",
			"row.input": "输入",
			"row.output": "输出",
			"row.inspect": "查看",
			"row.imageSize": "{width}x{height}px，{bytes} 字节",
			"row.imageSizeDownscaled": "{width}x{height}px（由 {originalWidth}x{originalHeight}px 缩小），{bytes} 字节",
			"tool.title.search": "搜索",
			"tool.title.read": "读取",
			"tool.title.bash": "运行命令",
			"tool.title.write": "写入",
			"tool.title.edit": "编辑",
			"tool.title.applyPatch": "应用补丁",
			"tool.title.code": "代码",
			"tool.title.generic": "工具调用",
			"tool.title.inspect": "查询 Cordis 环境",
			"tool.title.runCordis": "运行 Cordis 插件",
			"tool.title.stopCordis": "停止 Cordis 插件",
			"tool.title.removeCordis": "移除 Cordis 插件",
			"tool.title.pwsh": "运行命令",
			"tool.title.readImage": "读取图片",
			"tool.title.grep": "搜索文件内容",
			"tool.title.glob": "查找文件",
			"tool.title.webSearch": "网页搜索",
			"tool.title.webFetch": "网页获取",
			"tool.autoReviewRejected": "Auto review 已拒绝",
			"tool.autoReviewNotExecuted": "工具未执行。原因：{reason}",
			"tool.autoReviewReasonFallback": "Auto review 未授权此次操作",
			"diff.collapseAria": "收起差异",
			"diff.expandAria": "展开其余 {count} 行差异",
			"diff.expandRest": "… 其余 {count} 行",
			"read.window": "显示 {shown} / {total} 行",
			"read.collapseAria": "收起内容",
			"read.expandAria": "展开其余 {count} 行",
			"read.expandRest": "… 其余 {count} 行",
			"search.paths": "{shown} 个路径",
			"search.paths.truncated": "显示 {shown} / 共 {total} 个路径",
			"search.matches": "{shown} 处匹配 · {files} 个文件",
			"search.matches.truncated": "显示 {shown} / 共 {total} 处匹配 · {files} 个文件",
			"search.noResults": "无结果",
			"search.collapseAria": "收起结果",
			"search.expandAria": "展开其余 {count} 行结果",
			"search.expandRest": "… 其余 {count} 行",
			"web.noResults": "未找到结果",
			"web.sourcesTruncated": "来源列表已截断",
			"web.http": "HTTP",
			"web.contentTruncated": "内容已截断",
			"details.running": "运行中…",
			"queue.count": "{n} 条排队消息",
			"queue.sending": "发送中…",
			"queue.image": "排队消息图片",
			"queue.file": "排队文件 {name}",
			"queue.edit": "编辑排队消息",
			"queue.edit.unsupported": "包含非文本内容，暂不支持编辑",
			"queue.save": "保存排队消息",
			"queue.cancelEdit": "取消编辑",
			"queue.remove": "删除排队消息",
			"queue.steer": "插话发送",
			"queue.steer.unavailable": "仅运行中可插话发送",
			"error.sessionInUse": "当前会话已被占用，可能是其他正在运行的 DSH 导致的（如其他 dsh web、桌面端），请退出其他正在运行的 DSH 后重试。",
			"queue.editFailed": "编辑失败：这条消息可能已经开始发送。",
			"queue.removeFailed": "删除失败：这条消息可能已经开始发送。",
			"queue.steerFailed": "插话发送失败，请重试。",
			"terminal.signal": "信号 {signal}",
			"terminal.exitCode": "退出码 {code}",
			"terminal.noExitCode": "未正常退出",
			"terminal.commandLine": "命令第 {n} 行",
			"terminal.running": "运行中",
			"terminal.failed": "失败",
			"terminal.done": "已完成",
			"terminal.noOutput": "无输出",
			"terminal.collapseAria": "收起输出",
			"terminal.expandAria": "展开其余 {n} 行输出",
			"terminal.expandRest": "… 其余 {n} 行",
			"terminal.sendInput": "（发送输入）",
			"terminal.session": "终端 {sessionId}"
		};
		/** English dictionary, checked complete against the zh key set. */
		const en = {
			"quote.remove": "Remove quote",
			"shortcut.newline": "New line",
			"shortcut.complementary": "Use the complementary Queue / Steer action",
			"shortcut.slash": "Open command menu",
			"shortcut.mention": "Open reference menu",
			"hint.plan": PLAN_NEXT_ACTION_EN,
			"hint.goal": "describe the objective for a long-running task",
			"hint.goal.active": "goal active — edit / pause / resume / clear",
			"placeholder.plan": PLAN_NEXT_ACTION_EN,
			"placeholder.default": "Message or run a task, / commands, @ files or sessions",
			"placeholder.unavailable": "Session unavailable",
			"placeholder.parentOffline": "Parent session offline; sending is unavailable but you can still stop the run",
			"placeholder.hero": "Describe what you want to build, / commands, @ files or sessions",
			"placeholder.workspace": "Choose a workspace to start",
			"placeholder.steerQueue": "Cmd/Ctrl+Enter steers all queued messages",
			"input.commands": "Add files or run commands",
			"input.file": "File",
			"input.stop": "Stop generating",
			"input.send": "Send message",
			"input.sending": "Sending message",
			"input.send.queue": "Queue message",
			"input.send.steer": "Steer message",
			"attachment.pending": "Pending attachments",
			"attachment.scrollLeft": "Scroll attachments left",
			"attachment.scrollRight": "Scroll attachments right",
			"attachment.dropTitle": "Drag files or images here to add them",
			"attachment.dropDesc": "Image limit: up to {count} images, {size} each",
			"attachment.dropBlocked": "Files and images cannot be added right now",
			"attachment.directoryDesktopOnly": "Folders can only be added in the desktop app; add individual files in the browser",
			"attachment.pathUnavailable": "Could not obtain the folder path; drag it in again",
			"attachment.pathUnsupported": "The path contains characters a reference cannot carry; rename it and try again",
			"image.pending": "Pending images",
			"image.openOriginal": "View original",
			"image.openOriginalLabel": "{label}, click to view original",
			"image.remove": "Remove image {name}",
			"image.original": "Original image",
			"image.label": "Image",
			"image.loadFailed": "Image failed to load; click to retry",
			"image.loading": "Loading image…",
			"image.preview": "Original image preview",
			"image.closePreview": "Close original image preview",
			"image.unsupportedType": "Only PNG, JPG, WebP, and GIF images are supported",
			"image.tooMany": "A message can include up to {count} images",
			"image.fileTooLarge": "Each image must be smaller than {size}",
			"image.totalTooLarge": "Images exceed {size} in total; remove some and try again",
			"image.tooManyPixels": "Image resolution is too high; compress it and try again",
			"image.dimensionTooLarge": "Image sides must be at most {size}px; downscale it and try again",
			"image.modelUnsupported": "The current model does not support images; switch to a model that does",
			"image.sendFailed": "Sending images failed ({reason}); re-add them and try again",
			"file.pending": "Pending files",
			"file.remove": "Remove file {name}",
			"file.uploading": "Uploading…",
			"file.uploadFailed": "Upload failed; click to retry",
			"file.retry": "Retry uploading {name}",
			"file.stillUploading": "Files are still uploading; send after they finish",
			"file.sessionUnavailable": "Session unavailable; files cannot be uploaded",
			"file.notStaged": "The file has not finished uploading; re-add it and try again",
			"file.label": "File",
			"context.aria": "{percent} of context used",
			"context.used": "of context used",
			"context.system": "System prompt",
			"context.tools": "Tool definitions",
			"context.messages": "Messages",
			"settings.enter.title": "Send behavior while busy",
			"settings.enter.description": "What Enter and the Send button do while the agent is running; Cmd/Ctrl+Enter uses the other behavior",
			"settings.enter.queue": "Queue",
			"settings.enter.steer": "Steer",
			"hero.headline": "Into the Unknown",
			"hero.preview": "Preview",
			"hero.chooseWorkspace": "Choose workspace",
			"session.hierarchy": "Session hierarchy",
			"session.moreViews": "More conversation views",
			"todo.title": "To-dos",
			"todo.progress.done": "{done} completed",
			"todo.progress.active": "{active} in progress",
			"todo.progress.pending": "{pending} pending",
			"todo.status.completed": "Completed",
			"todo.status.inProgress": "In progress",
			"todo.status.pending": "Pending",
			"todo.rowTitle": "Update to-do list",
			"tool.title.createGoal": "Create goal",
			"tool.title.getGoal": "View goal",
			"tool.title.updateGoal": "Update goal",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "Create automation task",
			"tool.title.listSchedules": "List automation tasks",
			"tool.title.viewSchedule": "View automation task",
			"tool.title.editSchedule": "Edit automation task",
			"tool.title.deleteSchedule": "Delete automation task",
			"tool.title.updateSchedule": "Update automation task",
			"detail.state": "Status",
			"detail.todo.completed": "Completed",
			"detail.todo.in_progress": "In progress",
			"detail.todo.pending": "Pending",
			"detail.todo.empty": "The to-do list is empty",
			"todo.diff.initial": "Initial list",
			"todo.diff.compare": "Changes since the previous list",
			"todo.diff.unavailable": "Previous list unavailable",
			"todo.diff.noChanges": "No changes to the list",
			"todo.diff.added": "{count} added",
			"todo.diff.updated": "{count} updated",
			"todo.diff.removed": "{count} removed",
			"todo.diff.unchanged": "{count} unchanged",
			"todo.diff.addedItem": "Added",
			"todo.diff.updatedItem": "Status changed",
			"todo.diff.movedItem": "Reordered",
			"todo.diff.removedItem": "Removed",
			"detail.goal.empty": "No goal",
			"detail.goal.active": "Active",
			"detail.goal.disarmed": "Awaiting continuation",
			"detail.goal.paused": "Paused",
			"detail.goal.blocked": "Blocked",
			"detail.goal.complete": "Completed",
			"detail.goal.rounds": "Rounds",
			"detail.goal.reason": "Blocker",
			"detail.days": "{count} d",
			"detail.hours": "{count} h",
			"detail.minutes": "{count} min",
			"detail.seconds": "{count} s",
			"detail.schedule.once": "Once",
			"detail.schedule.every": "Every {interval}",
			"detail.schedule.when": "Scheduled for",
			"detail.schedule.frequency": "Repeat",
			"detail.schedule.scheduled": "Scheduled",
			"detail.schedule.overdue": "Overdue, awaiting session resume",
			"detail.schedule.active": "Enabled",
			"detail.schedule.paused": "Paused",
			"detail.schedule.ended": "Ended",
			"detail.schedule.empty": "No automation tasks",
			"detail.schedule.deleted": "Deleted",
			"detail.schedule.count": "{count} automation tasks",
			"detail.schedule.daily": "Every day at {time} ({zone})",
			"detail.schedule.weekly": "Weekly on {days} at {time} ({zone})",
			"detail.schedule.cron": "Cron {expression} ({zone})",
			"detail.schedule.custom": "Custom",
			"detail.weekday.1": "Mon",
			"detail.weekday.2": "Tue",
			"detail.weekday.3": "Wed",
			"detail.weekday.4": "Thu",
			"detail.weekday.5": "Fri",
			"detail.weekday.6": "Sat",
			"detail.weekday.7": "Sun",
			"detail.weekday.join": ", ",
			"tool.title.inspectProviders": "Inspect providers",
			"tool.title.queryRuntime": "Query runtime",
			"tool.title.inspectPlugins": "Inspect plugins",
			"tool.title.workflow": "Run workflow",
			"tool.title.ralph": "Run ralph loop",
			"tool.title.readEvent": "Read event",
			"tool.title.searchEvents": "Search events",
			"tool.title.traceEvent": "Trace event",
			"tool.title.searchSessions": "Search sessions",
			"tool.title.traceSession": "Trace session",
			"tool.title.listModels": "List models",
			"tool.title.subagent": "Create subagent",
			"tool.title.listAgents": "List subagents",
			"tool.title.sendMessage": "Send message",
			"tool.title.interruptAgent": "Interrupt agent",
			"tool.title.listJobs": "List background jobs",
			"tool.title.readJob": "Read job output",
			"tool.title.killJob": "Cancel background job",
			"tool.title.openTerminal": "Open terminal",
			"tool.title.readTerminal": "Read terminal",
			"tool.title.listTerminals": "List terminals",
			"tool.title.signalTerminal": "Signal terminal",
			"tool.title.closeTerminal": "Close terminal",
			"tool.title.lsp": "Query code symbols",
			"tool.title.findDefinition": "Find definition",
			"tool.title.findReferences": "Find references",
			"tool.title.findImplementation": "Find implementation",
			"tool.title.hoverSymbol": "Inspect symbol",
			"tool.title.spawnTeammate": "Create teammate",
			"tool.title.createTeamTask": "Create team task",
			"tool.title.getTeamTask": "Read team task",
			"tool.title.updateTeamTask": "Update team task",
			"tool.title.listTeamTasks": "List team tasks",
			"tool.title.waitAgent": "Wait for subagent",
			"detail.recordedResult": "Recorded result",
			"detail.empty": "No results",
			"detail.none": "None",
			"detail.yes": "Yes",
			"detail.no": "No",
			"detail.moreInInspect": "{count} more items available in Inspect",
			"detail.status.running": "Running",
			"detail.status.idle": "Idle",
			"detail.status.ready": "Ready",
			"detail.status.inactive": "Inactive",
			"detail.status.provisioning": "Provisioning",
			"detail.status.failed": "Failed",
			"detail.status.completed": "Completed",
			"detail.status.deleted": "Deleted",
			"detail.status.killed": "Cancelled",
			"detail.status.accepted": "Accepted",
			"detail.status.queued": "Queued",
			"detail.status.exited": "Exited",
			"detail.field.id": "ID",
			"detail.field.revision": "Revision",
			"detail.field.platform": "Platform",
			"detail.field.provider": "Provider",
			"detail.field.model": "Model",
			"detail.field.role": "Role",
			"detail.field.context": "Context",
			"detail.field.owner": "Owner",
			"detail.field.ready": "Ready",
			"detail.field.dependencies": "Dependencies",
			"detail.field.writeScopes": "Write scopes",
			"detail.field.warnings": "Warnings",
			"detail.field.diagnostics": "Diagnostics",
			"detail.field.methods": "Methods",
			"detail.field.inputSchema": "Input schema",
			"detail.field.outputSchema": "Output schema",
			"detail.field.currentPackage": "Current package",
			"detail.field.nextPackage": "Next package",
			"detail.field.latestRun": "Latest run",
			"detail.field.packages": "Packages",
			"detail.field.registrations": "Registrations",
			"detail.field.props": "Props",
			"detail.field.data": "Data",
			"detail.field.source": "Source",
			"detail.field.content": "Content",
			"detail.field.message": "Message",
			"detail.field.messageId": "Message ID",
			"detail.field.root": "Root",
			"detail.field.pid": "Process ID",
			"detail.field.type": "Type",
			"detail.field.time": "Time",
			"detail.field.seq": "Event sequence",
			"detail.field.turn": "Turn",
			"detail.field.step": "Step",
			"detail.field.callId": "Call ID",
			"detail.field.agents": "Agents started",
			"detail.field.result": "Result",
			"detail.field.parent": "Parent",
			"detail.field.depth": "Depth",
			"detail.field.exitCode": "Exit code",
			"detail.field.signal": "Signal",
			"detail.field.previousStatus": "Previous status",
			"detail.field.agent": "Agent ID",
			"detail.field.job": "Job ID",
			"detail.field.task": "Task",
			"detail.field.processGroup": "Process group",
			"detail.field.availability": "Availability",
			"detail.field.bestMatch": "Best match",
			"detail.field.target": "Target event",
			"detail.field.surface": "Record status",
			"detail.agents.count": "{count} agents",
			"detail.jobs.count": "{count} background jobs",
			"detail.terminals.count": "{count} terminals",
			"detail.tasks.count": "{count} team tasks",
			"detail.tasks.nextPage": "More tasks available; next cursor is {cursor}",
			"detail.locations.count": "{count} locations",
			"detail.location": "Line {line}, column {column}",
			"detail.receipt.delivered": "Message delivered",
			"detail.receipt.interrupt": "Interrupt requested",
			"detail.receipt.started": "Started",
			"detail.receipt.cancel": "Cancellation requested",
			"detail.receipt.alreadyFinished": "Already finished",
			"detail.receipt.signal": "Signal delivered",
			"detail.receipt.closed": "Closed",
			"detail.receipt.closing": "Closing",
			"detail.wait.noProgress": "No active subagents",
			"detail.wait.title": "Subagent activity",
			"detail.wait.timeout": "Wait timed out",
			"detail.wait.changed": "Change detected",
			"detail.agent.reply": "Agent response",
			"detail.models.title": "Available models",
			"detail.output.lines": "Lines {begin}–{end} of {total}",
			"detail.output.truncated": "Output truncated",
			"detail.providers.count": "{count} inspect providers",
			"detail.plugins.count": "{count} dynamic plugins",
			"detail.workflow.script": "Workflow script",
			"detail.ralph.reportedComplete": "Worker reported completion",
			"detail.ralph.reportedBlocker": "Worker reported a blocker",
			"detail.ralph.limit": "Round limit reached",
			"detail.report.nextSteps": "Remaining work",
			"detail.trace.replacedBy": "Replaced by",
			"detail.trace.replacementChain": "Replacement chain",
			"detail.trace.replaces": "Replaced events",
			"detail.trace.sources": "Source events",
			"detail.trace.derived": "Derived events",
			"detail.trace.ancestors": "Ancestor sessions",
			"detail.trace.descendants": "Descendant sessions",
			"detail.matches.count": "{count} matches",
			"detail.matches.capped": "Result limit reached; narrow the search for more",
			"detail.event.neighbors": "Surrounding events",
			"todo.completed": "{done}/{total} completed",
			"command.attachmentsUnsupported": "/{command} does not accept attachments; remove them first",
			"ask.rowTitle": "Ask question",
			"ask.waiting": "waiting",
			"ask.pending": "continued; answer still available",
			"ask.pendingDetail": "These pending questions remain answerable from the composer.",
			"ask.reopen": "Answer",
			"ask.review": "View answers",
			"ask.closed": "closed",
			"ask.closedDetail": "This question is closed; its outcome is in the conversation below.",
			"ask.cancelled": "cancelled",
			"ask.cancelledDetail": "This question set was cancelled before answers were submitted.",
			"ask.interrupted": "interrupted",
			"ask.interruptedDetail": "This question set was interrupted before answers were submitted.",
			"ask.answered": "{answered}/{total} answered",
			"ask.skipped": "Not answered",
			"bash.running": "Running",
			"bash.failed": "Failed",
			"bash.stopped": "Stopped",
			"row.running": "Running",
			"row.preparing": "Preparing tool call",
			"row.failed": "Failed",
			"row.stopped": "Stopped",
			"row.commandArguments": "Command arguments",
			"row.input": "IN",
			"row.output": "OUT",
			"row.inspect": "Inspect",
			"row.imageSize": "{width}x{height}px, {bytes} bytes",
			"row.imageSizeDownscaled": "{width}x{height}px (downscaled from {originalWidth}x{originalHeight}px), {bytes} bytes",
			"tool.title.search": "Search",
			"tool.title.read": "Read",
			"tool.title.bash": "Bash",
			"tool.title.write": "Write",
			"tool.title.edit": "Edit",
			"tool.title.applyPatch": "Apply patch",
			"tool.title.code": "Code",
			"tool.title.generic": "Tool call",
			"tool.title.inspect": "Query Cordis environment",
			"tool.title.runCordis": "Run Cordis Plugin",
			"tool.title.stopCordis": "Stop Cordis Plugin",
			"tool.title.removeCordis": "Remove Cordis Plugin",
			"tool.title.pwsh": "Pwsh",
			"tool.title.readImage": "Read image",
			"tool.title.grep": "Grep",
			"tool.title.glob": "Glob",
			"tool.title.webSearch": "Search",
			"tool.title.webFetch": "Fetch",
			"tool.autoReviewRejected": "Rejected by Auto review",
			"tool.autoReviewNotExecuted": "Tool was not executed. Reason: {reason}",
			"tool.autoReviewReasonFallback": "Auto review did not authorize this action",
			"diff.collapseAria": "Collapse diff",
			"diff.expandAria": "Expand {count} more diff lines",
			"diff.expandRest": "… {count} more lines",
			"read.window": "Showing {shown} of {total} lines",
			"read.collapseAria": "Collapse content",
			"read.expandAria": "Expand {count} more lines",
			"read.expandRest": "… {count} more lines",
			"search.paths": "{shown} paths",
			"search.paths.truncated": "Showing {shown} of {total} paths",
			"search.matches": "{shown} matches · {files} files",
			"search.matches.truncated": "Showing {shown} of {total} matches · {files} files",
			"search.noResults": "No results",
			"search.collapseAria": "Collapse results",
			"search.expandAria": "Expand {count} more result lines",
			"search.expandRest": "… {count} more lines",
			"web.noResults": "No results found",
			"web.sourcesTruncated": "Source list truncated",
			"web.http": "HTTP",
			"web.contentTruncated": "Content truncated",
			"details.running": "Running…",
			"queue.count": "{n} queued messages",
			"queue.sending": "Sending…",
			"queue.image": "Queued message image",
			"queue.file": "Queued file {name}",
			"queue.edit": "Edit queued message",
			"queue.edit.unsupported": "Contains non-text content; editing is not supported yet",
			"queue.save": "Save queued message",
			"queue.cancelEdit": "Cancel editing",
			"queue.remove": "Remove queued message",
			"queue.steer": "Steer queued message",
			"queue.steer.unavailable": "Steering is available only while the agent is running",
			"error.sessionInUse": "This session is already in use, possibly by another running DSH instance (such as dsh web or the desktop app). Quit other running DSH instances and try again.",
			"queue.editFailed": "Edit failed: this message may have already started sending.",
			"queue.removeFailed": "Removal failed: this message may have already started sending.",
			"queue.steerFailed": "Steering failed. Try again.",
			"terminal.signal": "signal {signal}",
			"terminal.exitCode": "exit code {code}",
			"terminal.noExitCode": "no exit code",
			"terminal.commandLine": "Command line {n}",
			"terminal.running": "Running",
			"terminal.failed": "Failed",
			"terminal.done": "Done",
			"terminal.noOutput": "No output",
			"terminal.collapseAria": "Collapse output",
			"terminal.expandAria": "Expand the remaining {n} output lines",
			"terminal.expandRest": "… {n} more lines",
			"terminal.sendInput": "(send input)",
			"terminal.session": "Terminal {sessionId}"
		};
		/** Japanese copy, checked against the English keys. */
		const ja = {
			"quote.remove": "引用を削除",
			"shortcut.newline": "改行",
			"shortcut.complementary": "補助のキュー / 実行中の指示変更を使用",
			"shortcut.slash": "コマンドメニューを開く",
			"shortcut.mention": "参照メニューを開く",
			"hint.plan": "計画を生成するにはタスクを説明してください",
			"hint.goal": "長時間実行するタスクの目標を説明してください",
			"hint.goal.active": "目標アクティブ — 編集 / 一時停止 / 再開 / クリア",
			"placeholder.plan": "計画を生成するにはタスクを説明してください",
			"placeholder.default": "メッセージを送信するかタスクを実行、/ コマンド、@ ファイルやセッション",
			"placeholder.unavailable": "セッションを利用できません",
			"placeholder.parentOffline": "親セッションがオフラインです。送信はできませんが、実行は停止できます",
			"placeholder.hero": "作りたいものを説明してください。/ コマンド、@ ファイルやセッション",
			"placeholder.workspace": "開始するワークスペースを選択",
			"placeholder.steerQueue": "Cmd/Ctrl+Enterでキュー内のすべてのメッセージを実行中の指示に追加",
			"input.commands": "ファイルを追加またはコマンドを実行",
			"input.file": "ファイル",
			"input.stop": "生成を停止",
			"input.send": "メッセージを送信",
			"input.sending": "メッセージを送信中",
			"input.send.queue": "メッセージをキューに追加",
			"input.send.steer": "実行中の指示にメッセージを追加",
			"attachment.pending": "保留中の添付ファイル",
			"attachment.scrollLeft": "添付ファイルを左にスクロール",
			"attachment.scrollRight": "添付ファイルを右にスクロール",
			"attachment.dropTitle": "ファイルや画像をここにドラッグして追加",
			"attachment.dropDesc": "画像の上限: 最大{count}枚、各{size}",
			"attachment.dropBlocked": "現在ファイルや画像を追加できません",
			"attachment.directoryDesktopOnly": "フォルダはデスクトップアプリでのみ追加できます。ブラウザでは個別のファイルを追加してください",
			"attachment.pathUnavailable": "フォルダのパスを取得できませんでした。もう一度ドラッグしてください",
			"attachment.pathUnsupported": "パスに参照できない文字が含まれています。名前を変更して再試行してください",
			"image.pending": "保留中の画像",
			"image.openOriginal": "元の画像を表示",
			"image.openOriginalLabel": "{label}、クリックで元の画像を表示",
			"image.remove": "画像{name}を削除",
			"image.original": "元の画像",
			"image.label": "画像",
			"image.loadFailed": "画像を読み込めませんでした。クリックで再試行",
			"image.loading": "画像を読み込み中…",
			"image.preview": "元の画像のプレビュー",
			"image.closePreview": "元の画像のプレビューを閉じる",
			"image.unsupportedType": "対応している画像形式はPNG、JPG、WebP、GIFのみです",
			"image.tooMany": "1つのメッセージに最大{count}枚の画像を含められます",
			"image.fileTooLarge": "各画像は{size}未満である必要があります",
			"image.totalTooLarge": "画像の合計が{size}を超えています。一部を削除して再試行してください",
			"image.tooManyPixels": "画像の解像度が高すぎます。圧縮して再試行してください",
			"image.dimensionTooLarge": "画像の各辺は最大{size}pxです。縮小して再試行してください",
			"image.modelUnsupported": "現在のモデルは画像に対応していません。対応モデルに切り替えてください",
			"image.sendFailed": "画像の送信に失敗しました（{reason}）。再度追加して再試行してください",
			"file.pending": "保留中のファイル",
			"file.remove": "ファイル{name}を削除",
			"file.uploading": "アップロード中…",
			"file.uploadFailed": "アップロードに失敗しました。クリックで再試行",
			"file.retry": "{name}のアップロードを再試行",
			"file.stillUploading": "ファイルをアップロード中です。完了後に送信してください",
			"file.sessionUnavailable": "セッションを利用できないため、ファイルをアップロードできません",
			"file.notStaged": "ファイルのアップロードが完了していません。再度追加して再試行してください",
			"file.label": "ファイル",
			"context.aria": "コンテキストの{percent}を使用中",
			"context.used": "コンテキスト使用量",
			"context.system": "システムプロンプト",
			"context.tools": "ツール定義",
			"context.messages": "メッセージ",
			"settings.enter.title": "実行中の送信動作",
			"settings.enter.description": "エージェントの実行中にEnterキーと送信ボタンが行う動作。Cmd/Ctrl+Enterではもう一方の動作になります",
			"settings.enter.queue": "キュー",
			"settings.enter.steer": "指示を変更",
			"hero.headline": "未知への挑戦",
			"hero.preview": "プレビュー",
			"hero.chooseWorkspace": "ワークスペースを選択",
			"session.hierarchy": "セッション階層",
			"session.moreViews": "その他の会話ビュー",
			"todo.title": "ToDo",
			"todo.progress.done": "{done}件完了",
			"todo.progress.active": "{active}件進行中",
			"todo.progress.pending": "{pending}件保留中",
			"todo.status.completed": "完了",
			"todo.status.inProgress": "進行中",
			"todo.status.pending": "保留中",
			"todo.rowTitle": "ToDoリストを更新",
			"tool.title.createGoal": "目標を作成",
			"tool.title.getGoal": "目標を表示",
			"tool.title.updateGoal": "目標を更新",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "自動化タスクを作成",
			"tool.title.viewSchedule": "自動化タスクを表示",
			"tool.title.editSchedule": "自動化タスクを編集",
			"tool.title.listSchedules": "自動化タスクを一覧表示",
			"tool.title.deleteSchedule": "自動化タスクを削除",
			"tool.title.updateSchedule": "自動化タスクを更新",
			"detail.state": "ステータス",
			"detail.todo.completed": "完了",
			"detail.todo.in_progress": "進行中",
			"detail.todo.pending": "保留中",
			"detail.todo.empty": "ToDoリストは空です",
			"todo.diff.initial": "初期リスト",
			"todo.diff.compare": "前回のリストからの変更",
			"todo.diff.unavailable": "前回のリストは利用できません",
			"todo.diff.noChanges": "リストに変更はありません",
			"todo.diff.added": "{count}件追加",
			"todo.diff.updated": "{count}件更新",
			"todo.diff.removed": "{count}件削除",
			"todo.diff.unchanged": "{count}件変更なし",
			"todo.diff.addedItem": "追加",
			"todo.diff.updatedItem": "ステータス変更",
			"todo.diff.movedItem": "順序変更",
			"todo.diff.removedItem": "削除",
			"detail.goal.empty": "目標なし",
			"detail.goal.active": "アクティブ",
			"detail.goal.disarmed": "継続待ち",
			"detail.goal.paused": "一時停止",
			"detail.goal.blocked": "ブロック中",
			"detail.goal.complete": "完了",
			"detail.goal.rounds": "ラウンド",
			"detail.goal.reason": "ブロッカー",
			"detail.days": "{count} 日",
			"detail.hours": "{count} 時間",
			"detail.minutes": "{count} 分",
			"detail.seconds": "{count} 秒",
			"detail.schedule.once": "1回のみ",
			"detail.schedule.every": "{interval} ごと",
			"detail.schedule.when": "スケジュール設定",
			"detail.schedule.frequency": "繰り返し",
			"detail.schedule.active": "有効",
			"detail.schedule.paused": "一時停止中",
			"detail.schedule.ended": "終了",
			"detail.schedule.scheduled": "スケジュール済み",
			"detail.schedule.overdue": "期限超過、セッション再開待ち",
			"detail.schedule.empty": "自動化タスクなし",
			"detail.schedule.deleted": "削除済み",
			"detail.schedule.count": "{count}件の自動化タスク",
			"detail.schedule.daily": "毎日 {time} ({zone})",
			"detail.schedule.weekly": "毎週 {days} の {time} ({zone})",
			"detail.schedule.cron": "Cron {expression} ({zone})",
			"detail.schedule.custom": "カスタム",
			"detail.weekday.1": "月",
			"detail.weekday.2": "火",
			"detail.weekday.3": "水",
			"detail.weekday.4": "木",
			"detail.weekday.5": "金",
			"detail.weekday.6": "土",
			"detail.weekday.7": "日",
			"detail.weekday.join": ", ",
			"tool.title.inspectProviders": "プロバイダーを検査",
			"tool.title.queryRuntime": "ランタイムを照会",
			"tool.title.inspectPlugins": "プラグインを検査",
			"tool.title.workflow": "ワークフローを実行",
			"tool.title.ralph": "ralph ループを実行",
			"tool.title.readEvent": "イベントを読み取り",
			"tool.title.searchEvents": "イベントを検索",
			"tool.title.traceEvent": "イベントをトレース",
			"tool.title.searchSessions": "セッションを検索",
			"tool.title.traceSession": "セッションをトレース",
			"tool.title.listModels": "モデルを一覧表示",
			"tool.title.subagent": "サブエージェントを作成",
			"tool.title.listAgents": "サブエージェントを一覧表示",
			"tool.title.sendMessage": "メッセージを送信",
			"tool.title.interruptAgent": "エージェントを中断",
			"tool.title.listJobs": "バックグラウンドジョブを一覧表示",
			"tool.title.readJob": "ジョブ出力を読み取り",
			"tool.title.killJob": "バックグラウンドジョブをキャンセル",
			"tool.title.openTerminal": "ターミナルを開く",
			"tool.title.readTerminal": "ターミナルを読み取り",
			"tool.title.listTerminals": "ターミナルを一覧表示",
			"tool.title.signalTerminal": "ターミナルにシグナル送信",
			"tool.title.closeTerminal": "ターミナルを閉じる",
			"tool.title.lsp": "コードシンボルを照会",
			"tool.title.findDefinition": "定義を検索",
			"tool.title.findReferences": "参照を検索",
			"tool.title.findImplementation": "実装を検索",
			"tool.title.hoverSymbol": "シンボルを検査",
			"tool.title.spawnTeammate": "チームメイトを作成",
			"tool.title.createTeamTask": "チームタスクを作成",
			"tool.title.getTeamTask": "チームタスクを読み取り",
			"tool.title.updateTeamTask": "チームタスクを更新",
			"tool.title.listTeamTasks": "チームタスクを一覧表示",
			"tool.title.waitAgent": "サブエージェントを待機",
			"detail.recordedResult": "記録された結果",
			"detail.empty": "結果なし",
			"detail.none": "なし",
			"detail.yes": "はい",
			"detail.no": "いいえ",
			"detail.moreInInspect": "Inspect で残り {count}件を表示できます",
			"detail.status.running": "実行中",
			"detail.status.idle": "待機中",
			"detail.status.ready": "準備完了",
			"detail.status.inactive": "非アクティブ",
			"detail.status.provisioning": "プロビジョニング中",
			"detail.status.failed": "失敗",
			"detail.status.completed": "完了",
			"detail.status.deleted": "削除済み",
			"detail.status.killed": "キャンセル済み",
			"detail.status.accepted": "承認済み",
			"detail.status.queued": "キュー待ち",
			"detail.status.exited": "終了",
			"detail.field.id": "ID",
			"detail.field.revision": "リビジョン",
			"detail.field.platform": "プラットフォーム",
			"detail.field.provider": "プロバイダー",
			"detail.field.model": "モデル",
			"detail.field.role": "ロール",
			"detail.field.context": "コンテキスト",
			"detail.field.owner": "オーナー",
			"detail.field.ready": "準備完了",
			"detail.field.dependencies": "依存関係",
			"detail.field.writeScopes": "書き込みスコープ",
			"detail.field.warnings": "警告",
			"detail.field.diagnostics": "診断",
			"detail.field.methods": "メソッド",
			"detail.field.inputSchema": "入力スキーマ",
			"detail.field.outputSchema": "出力スキーマ",
			"detail.field.currentPackage": "現在のパッケージ",
			"detail.field.nextPackage": "次のパッケージ",
			"detail.field.latestRun": "最新の実行",
			"detail.field.packages": "パッケージ",
			"detail.field.registrations": "登録",
			"detail.field.props": "Props",
			"detail.field.data": "データ",
			"detail.field.source": "ソース",
			"detail.field.content": "内容",
			"detail.field.message": "メッセージ",
			"detail.field.messageId": "メッセージ ID",
			"detail.field.root": "ルート",
			"detail.field.pid": "プロセス ID",
			"detail.field.type": "種類",
			"detail.field.time": "時刻",
			"detail.field.seq": "イベントシーケンス",
			"detail.field.turn": "ターン",
			"detail.field.step": "ステップ",
			"detail.field.callId": "呼び出し ID",
			"detail.field.agents": "起動したエージェント",
			"detail.field.result": "結果",
			"detail.field.parent": "親",
			"detail.field.depth": "深さ",
			"detail.field.exitCode": "終了コード",
			"detail.field.signal": "シグナル",
			"detail.field.previousStatus": "以前のステータス",
			"detail.field.agent": "エージェント ID",
			"detail.field.job": "ジョブ ID",
			"detail.field.task": "タスク",
			"detail.field.processGroup": "プロセスグループ",
			"detail.field.availability": "可用性",
			"detail.field.bestMatch": "最適な一致",
			"detail.field.target": "対象イベント",
			"detail.field.surface": "レコードステータス",
			"detail.agents.count": "{count} エージェント",
			"detail.jobs.count": "{count} バックグラウンドジョブ",
			"detail.terminals.count": "{count} ターミナル",
			"detail.tasks.count": "{count} チームタスク",
			"detail.tasks.nextPage": "さらにタスクがあります。次のカーソルは {cursor} です",
			"detail.locations.count": "{count}件の場所",
			"detail.location": "{line} 行目、{column} 列目",
			"detail.receipt.delivered": "メッセージを配信しました",
			"detail.receipt.interrupt": "中断を要求しました",
			"detail.receipt.started": "開始済み",
			"detail.receipt.cancel": "キャンセルを要求しました",
			"detail.receipt.alreadyFinished": "既に完了",
			"detail.receipt.signal": "シグナル送信済み",
			"detail.receipt.closed": "クローズ済み",
			"detail.receipt.closing": "クローズ中",
			"detail.wait.noProgress": "アクティブなサブエージェントなし",
			"detail.wait.title": "サブエージェントのアクティビティ",
			"detail.wait.timeout": "待機がタイムアウトしました",
			"detail.wait.changed": "変更を検出",
			"detail.agent.reply": "エージェントの応答",
			"detail.models.title": "利用可能なモデル",
			"detail.output.lines": "{total} 行中 {begin}–{end} 行",
			"detail.output.truncated": "出力は切り詰められています",
			"detail.providers.count": "{count}件の inspect プロバイダー",
			"detail.plugins.count": "{count}件の動的プラグイン",
			"detail.workflow.script": "ワークフロースクリプト",
			"detail.ralph.reportedComplete": "ワーカーが完了を報告",
			"detail.ralph.reportedBlocker": "ワーカーがブロッカーを報告",
			"detail.ralph.limit": "ラウンド上限に達しました",
			"detail.report.nextSteps": "残りの作業",
			"detail.trace.replacedBy": "置き換え元",
			"detail.trace.replacementChain": "置き換えチェーン",
			"detail.trace.replaces": "置き換えられたイベント",
			"detail.trace.sources": "ソースイベント",
			"detail.trace.derived": "派生イベント",
			"detail.trace.ancestors": "祖先セッション",
			"detail.trace.descendants": "子孫セッション",
			"detail.matches.count": "{count}件の一致",
			"detail.matches.capped": "結果の上限に達しました。さらに絞り込んでください",
			"detail.event.neighbors": "周辺のイベント",
			"todo.completed": "{done}/{total} 完了",
			"command.attachmentsUnsupported": "/{command} は添付ファイルを受け付けません。先に削除してください",
			"ask.rowTitle": "質問する",
			"ask.waiting": "待機中",
			"ask.pending": "継続中。引き続き回答できます",
			"ask.pendingDetail": "これらの保留中の質問は、コンポーザーから引き続き回答できます。",
			"ask.reopen": "回答",
			"ask.review": "回答を表示",
			"ask.closed": "クローズ済み",
			"ask.closedDetail": "この質問はクローズされました。結果は下の会話にあります。",
			"ask.cancelled": "キャンセル済み",
			"ask.cancelledDetail": "この質問セットは回答が送信される前にキャンセルされました。",
			"ask.interrupted": "中断済み",
			"ask.interruptedDetail": "この質問セットは回答が送信される前に中断されました。",
			"ask.answered": "{answered}/{total} 回答済み",
			"ask.skipped": "未回答",
			"bash.running": "実行中",
			"bash.failed": "失敗",
			"bash.stopped": "停止",
			"row.running": "実行中",
			"row.preparing": "ツール呼び出しを準備中",
			"row.failed": "失敗",
			"row.stopped": "停止",
			"row.commandArguments": "コマンド引数",
			"row.input": "IN",
			"row.output": "OUT",
			"row.inspect": "検査",
			"row.imageSize": "{width}x{height}px、{bytes} バイト",
			"row.imageSizeDownscaled": "{width}x{height}px（{originalWidth}x{originalHeight}px から縮小）、{bytes} バイト",
			"tool.title.search": "検索",
			"tool.title.read": "読み取り",
			"tool.title.bash": "Bash",
			"tool.title.write": "書き込み",
			"tool.title.edit": "編集",
			"tool.title.applyPatch": "パッチを適用",
			"tool.title.code": "コード",
			"tool.title.generic": "ツール呼び出し",
			"tool.title.inspect": "Cordis 環境を照会",
			"tool.title.runCordis": "Cordis プラグインを実行",
			"tool.title.stopCordis": "Cordis プラグインを停止",
			"tool.title.removeCordis": "Cordis プラグインを削除",
			"tool.title.pwsh": "Pwsh",
			"tool.title.readImage": "画像を読み取り",
			"tool.title.grep": "Grep",
			"tool.title.glob": "Glob",
			"tool.title.webSearch": "検索",
			"tool.title.webFetch": "取得",
			"tool.autoReviewRejected": "自動認可レビューにより拒否されました",
			"tool.autoReviewNotExecuted": "ツールは実行されませんでした。理由: {reason}",
			"tool.autoReviewReasonFallback": "自動認可レビューがこの操作を承認しませんでした",
			"diff.collapseAria": "差分を折りたたむ",
			"diff.expandAria": "差分の残り{count}行を表示",
			"diff.expandRest": "… 残り{count}行",
			"read.window": "{total}行中{shown}行を表示",
			"read.collapseAria": "内容を折りたたむ",
			"read.expandAria": "残り{count}行を表示",
			"read.expandRest": "… 残り{count}行",
			"search.paths": "{shown}件のパス",
			"search.paths.truncated": "{total}件中{shown}件のパスを表示",
			"search.matches": "{shown}件の一致 · {files}ファイル",
			"search.matches.truncated": "{total}件中{shown}件の一致を表示 · {files}ファイル",
			"search.noResults": "結果なし",
			"search.collapseAria": "結果を折りたたむ",
			"search.expandAria": "残り{count}行の結果を表示",
			"search.expandRest": "… 残り{count}行",
			"web.noResults": "結果が見つかりません",
			"web.sourcesTruncated": "ソース一覧を切り詰めました",
			"web.http": "HTTP",
			"web.contentTruncated": "内容を切り詰めました",
			"details.running": "実行中…",
			"queue.count": "{n}件のキュー済みメッセージ",
			"queue.sending": "送信中…",
			"queue.image": "キュー済みメッセージの画像",
			"queue.file": "キュー済みファイル {name}",
			"queue.edit": "キュー済みメッセージを編集",
			"queue.edit.unsupported": "テキスト以外の内容を含むため、まだ編集できません",
			"queue.save": "キュー済みメッセージを保存",
			"queue.cancelEdit": "編集をキャンセル",
			"queue.remove": "キュー済みメッセージを削除",
			"queue.steer": "キュー内のメッセージを実行中の指示に追加",
			"queue.steer.unavailable": "指示の変更はエージェントの実行中のみ利用できます",
			"error.sessionInUse": "このセッションはすでに使用中です。別の実行中のDSHインスタンス（dsh webやデスクトップアプリなど）が使用している可能性があります。他のDSHインスタンスを終了して再試行してください。",
			"queue.editFailed": "編集に失敗しました。このメッセージはすでに送信が開始されている可能性があります。",
			"queue.removeFailed": "削除に失敗しました。このメッセージはすでに送信が開始されている可能性があります。",
			"queue.steerFailed": "指示の変更に失敗しました。再試行してください。",
			"terminal.signal": "シグナル {signal}",
			"terminal.exitCode": "終了コード {code}",
			"terminal.noExitCode": "終了コードなし",
			"terminal.commandLine": "コマンドライン {n}",
			"terminal.running": "実行中",
			"terminal.failed": "失敗",
			"terminal.done": "完了",
			"terminal.noOutput": "出力なし",
			"terminal.collapseAria": "出力を折りたたむ",
			"terminal.expandAria": "残り{n}行の出力を表示",
			"terminal.expandRest": "… 残り{n}行",
			"terminal.sendInput": "(入力を送信)",
			"terminal.session": "ターミナル {sessionId}"
		};
		/** Spanish dictionary, checked against the English keys. */
		const es = {
			"quote.remove": "Eliminar cotización",
			"shortcut.newline": "Nueva linea",
			"shortcut.complementary": "Usar la acción alternativa de poner en cola o redirigir",
			"shortcut.slash": "Abrir menú de comandos",
			"shortcut.mention": "Abrir menú de referencia",
			"hint.plan": PLAN_NEXT_ACTION_EN,
			"hint.goal": "describir el objetivo de una tarea de larga duración",
			"hint.goal.active": "Objetivo activo: editar/pausar/reanudar/borrar",
			"placeholder.plan": PLAN_NEXT_ACTION_EN,
			"placeholder.default": "Envía mensajes o ejecuta una tarea, / comandos, @ archivos o sesiones",
			"placeholder.unavailable": "Sesión no disponible",
			"placeholder.parentOffline": "Sesión para padres sin conexión; El envío no está disponible pero aún puedes detener la ejecución.",
			"placeholder.hero": "Describe lo que quieres construir, / comandos, @ archivos o sesiones",
			"placeholder.workspace": "Elija un espacio de trabajo para comenzar",
			"placeholder.steerQueue": "Cmd/Ctrl+Enter dirige todos los mensajes en cola",
			"input.commands": "Agregar archivos o ejecutar comandos",
			"input.file": "Archivo",
			"input.stop": "Detener generación",
			"input.send": "Enviar mensaje",
			"input.sending": "Enviando mensaje",
			"input.send.queue": "mensaje de cola",
			"input.send.steer": "Redirigir mensaje",
			"attachment.pending": "Anexos pendientes",
			"attachment.scrollLeft": "Desplazar archivos adjuntos hacia la izquierda",
			"attachment.scrollRight": "Desplazar archivos adjuntos hacia la derecha",
			"attachment.dropTitle": "Arrastre archivos o imágenes aquí para agregarlos",
			"attachment.dropDesc": "Límite de imágenes: hasta imágenes {count}, {size} cada una",
			"attachment.dropBlocked": "No se pueden agregar archivos e imágenes en este momento",
			"attachment.directoryDesktopOnly": "Las carpetas sólo se pueden agregar en la aplicación de escritorio; agregar archivos individuales en el navegador",
			"attachment.pathUnavailable": "No se pudo obtener la ruta de la carpeta; arrástralo de nuevo",
			"attachment.pathUnsupported": "La ruta contiene caracteres que una referencia no puede contener; cámbiale el nombre y vuelve a intentarlo.",
			"image.pending": "Imágenes pendientes",
			"image.openOriginal": "Ver original",
			"image.openOriginalLabel": "{label}, haga clic para ver el original",
			"image.remove": "Eliminar imagen {name}",
			"image.original": "imagen original",
			"image.label": "Imagen",
			"image.loadFailed": "La imagen no se pudo cargar; haga clic para volver a intentar",
			"image.loading": "Cargando imagen…",
			"image.preview": "Vista previa de la imagen original",
			"image.closePreview": "Cerrar vista previa de la imagen original",
			"image.unsupportedType": "Solo se admiten imágenes PNG, JPG, WebP y GIF",
			"image.tooMany": "Un mensaje puede incluir hasta imágenes {count}.",
			"image.fileTooLarge": "Cada imagen debe ser más pequeña que {size}.",
			"image.totalTooLarge": "Las imágenes superan {size} en total; elimina algunos y vuelve a intentarlo",
			"image.tooManyPixels": "La resolución de la imagen es demasiado alta; comprímelo y vuelve a intentarlo.",
			"image.dimensionTooLarge": "Los lados de la imagen deben ser como máximo {size}px; reduce la escala y vuelve a intentarlo",
			"image.modelUnsupported": "El modelo actual no admite imágenes; cambiar a un modelo que lo haga",
			"image.sendFailed": "Error al enviar imágenes ({reason}); Vuelve a agregarlos y vuelve a intentarlo.",
			"file.pending": "Archivos pendientes",
			"file.remove": "Eliminar archivo {name}",
			"file.uploading": "Subiendo…",
			"file.uploadFailed": "La carga falló; haga clic para volver a intentar",
			"file.retry": "Reintente cargar {name}",
			"file.stillUploading": "Los archivos todavía se están cargando; enviar después de que terminen",
			"file.sessionUnavailable": "Sesión no disponible; los archivos no se pueden cargar",
			"file.notStaged": "El archivo no ha terminado de cargarse; vuelve a agregarlo y vuelve a intentarlo",
			"file.label": "Archivo",
			"context.aria": "{percent} de contexto utilizado",
			"context.used": "de contexto utilizado",
			"context.system": "Aviso del sistema",
			"context.tools": "Definiciones de herramientas",
			"context.messages": "Mensajes",
			"settings.enter.title": "Enviar comportamiento mientras está ocupado",
			"settings.enter.description": "Qué hacen los botones Intro y Enviar mientras el agente se está ejecutando; Cmd/Ctrl+Enter usa el otro comportamiento",
			"settings.enter.queue": "cola",
			"settings.enter.steer": "Redirigir",
			"hero.headline": "Hacia lo desconocido",
			"hero.preview": "Vista previa",
			"hero.chooseWorkspace": "Elige espacio de trabajo",
			"session.hierarchy": "Jerarquía de sesiones",
			"session.moreViews": "Más vistas de conversación",
			"todo.title": "Tareas pendientes",
			"todo.progress.done": "{done} completado",
			"todo.progress.active": "{active} en progreso",
			"todo.progress.pending": "{pending} pendiente",
			"todo.status.completed": "Completado",
			"todo.status.inProgress": "En progreso",
			"todo.status.pending": "Pendiente",
			"todo.rowTitle": "Actualizar lista de tareas pendientes",
			"tool.title.createGoal": "Crear objetivo",
			"tool.title.getGoal": "Ver objetivo",
			"tool.title.updateGoal": "Actualizar objetivo",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "Crear tarea de automatización",
			"tool.title.listSchedules": "Listar tareas de automatización",
			"tool.title.deleteSchedule": "Eliminar tarea de automatización",
			"tool.title.updateSchedule": "Actualizar tarea de automatización",
			"detail.state": "Estado",
			"detail.todo.completed": "Completado",
			"detail.todo.in_progress": "En progreso",
			"detail.todo.pending": "Pendiente",
			"detail.todo.empty": "La lista de tareas pendientes está vacía",
			"todo.diff.initial": "lista inicial",
			"todo.diff.compare": "Cambios desde la lista anterior",
			"todo.diff.unavailable": "Lista anterior no disponible",
			"todo.diff.noChanges": "No hay cambios en la lista.",
			"todo.diff.added": "{count} añadido",
			"todo.diff.updated": "{count} actualizado",
			"todo.diff.removed": "{count} eliminado",
			"todo.diff.unchanged": "{count} sin cambios",
			"todo.diff.addedItem": "Añadido",
			"todo.diff.updatedItem": "Estado cambiado",
			"todo.diff.movedItem": "Reordenado",
			"todo.diff.removedItem": "Eliminado",
			"detail.goal.empty": "Sin gol",
			"detail.goal.active": "Activo",
			"detail.goal.disarmed": "En espera de continuación",
			"detail.goal.paused": "En pausa",
			"detail.goal.blocked": "Bloqueado",
			"detail.goal.complete": "Completado",
			"detail.goal.rounds": "Rondas",
			"detail.goal.reason": "bloqueador",
			"detail.days": "{count} d",
			"detail.hours": "{count} h",
			"detail.minutes": "{count} mín.",
			"detail.seconds": "{count}",
			"detail.schedule.once": "una vez",
			"detail.schedule.every": "Cada {interval}",
			"detail.schedule.when": "Programado para",
			"detail.schedule.frequency": "repetir",
			"detail.schedule.scheduled": "Programado",
			"detail.schedule.overdue": "Atrasado, a la espera de reanudar la sesión.",
			"detail.schedule.empty": "Sin tareas de automatización",
			"detail.schedule.deleted": "Eliminado",
			"detail.schedule.count": "{count} tareas de automatización",
			"detail.schedule.daily": "Todos los días en {time} ({zone})",
			"detail.schedule.weekly": "Semanalmente en {days} en {time} ({zone})",
			"detail.schedule.cron": "Cron {expression} ({zone})",
			"detail.schedule.custom": "Personalizado",
			"detail.weekday.1": "lun",
			"detail.weekday.2": "mar",
			"detail.weekday.3": "mié",
			"detail.weekday.4": "jueves",
			"detail.weekday.5": "viernes",
			"detail.weekday.6": "sábado",
			"detail.weekday.7": "sol",
			"detail.weekday.join": ", ",
			"tool.title.inspectProviders": "Inspeccionar proveedores",
			"tool.title.queryRuntime": "Tiempo de ejecución de consultas",
			"tool.title.inspectPlugins": "Inspeccionar complementos",
			"tool.title.workflow": "Ejecutar flujo de trabajo",
			"tool.title.ralph": "Ejecutar bucle ralph",
			"tool.title.readEvent": "Leer evento",
			"tool.title.searchEvents": "Buscar eventos",
			"tool.title.traceEvent": "Evento de seguimiento",
			"tool.title.searchSessions": "Buscar sesiones",
			"tool.title.traceSession": "Sesión de seguimiento",
			"tool.title.listModels": "Listar modelos",
			"tool.title.subagent": "Crear subagente",
			"tool.title.listAgents": "Listar subagentes",
			"tool.title.sendMessage": "Enviar mensaje",
			"tool.title.interruptAgent": "agente de interrupción",
			"tool.title.listJobs": "Listar trabajos en segundo plano",
			"tool.title.readJob": "Leer la salida del trabajo",
			"tool.title.killJob": "Cancelar trabajo en segundo plano",
			"tool.title.openTerminal": "terminal abierta",
			"tool.title.readTerminal": "Leer terminal",
			"tool.title.listTerminals": "Lista de terminales",
			"tool.title.signalTerminal": "terminal de señal",
			"tool.title.closeTerminal": "Cerrar terminal",
			"tool.title.lsp": "Símbolos de código de consulta",
			"tool.title.findDefinition": "encontrar definición",
			"tool.title.findReferences": "encontrar referencias",
			"tool.title.findImplementation": "Encontrar implementación",
			"tool.title.hoverSymbol": "Símbolo de inspección",
			"tool.title.spawnTeammate": "Crear compañero de equipo",
			"tool.title.createTeamTask": "Crear tarea de equipo",
			"tool.title.getTeamTask": "Leer tarea de equipo",
			"tool.title.updateTeamTask": "Actualizar tarea de equipo",
			"tool.title.listTeamTasks": "Listar tareas del equipo",
			"tool.title.waitAgent": "Espere al subagente",
			"detail.recordedResult": "Resultado registrado",
			"detail.empty": "Sin resultados",
			"detail.none": "Ninguno",
			"detail.yes": "si",
			"detail.no": "No",
			"detail.moreInInspect": "{count} más artículos disponibles en Inspeccionar",
			"detail.status.running": "corriendo",
			"detail.status.idle": "inactivo",
			"detail.status.ready": "Listo",
			"detail.status.inactive": "Inactivo",
			"detail.status.provisioning": "Aprovisionamiento",
			"detail.status.failed": "Fallido",
			"detail.status.completed": "Completado",
			"detail.status.deleted": "Eliminado",
			"detail.status.killed": "Cancelado",
			"detail.status.accepted": "Aceptado",
			"detail.status.queued": "En cola",
			"detail.status.exited": "Salido",
			"detail.field.id": "ID",
			"detail.field.revision": "Revisión",
			"detail.field.platform": "Plataforma",
			"detail.field.provider": "Proveedor",
			"detail.field.model": "modelo",
			"detail.field.role": "Rol",
			"detail.field.context": "Contexto",
			"detail.field.owner": "propietario",
			"detail.field.ready": "Listo",
			"detail.field.dependencies": "Dependencias",
			"detail.field.writeScopes": "Escribir alcances",
			"detail.field.warnings": "Advertencias",
			"detail.field.diagnostics": "Diagnóstico",
			"detail.field.methods": "Métodos",
			"detail.field.inputSchema": "Esquema de entrada",
			"detail.field.outputSchema": "Esquema de salida",
			"detail.field.currentPackage": "Paquete actual",
			"detail.field.nextPackage": "Siguiente paquete",
			"detail.field.latestRun": "Última ejecución",
			"detail.field.packages": "Paquetes",
			"detail.field.registrations": "Inscripciones",
			"detail.field.props": "Accesorios",
			"detail.field.data": "Datos",
			"detail.field.source": "Fuente",
			"detail.field.content": "Contenido",
			"detail.field.message": "Mensaje",
			"detail.field.messageId": "ID de mensaje",
			"detail.field.root": "raíz",
			"detail.field.pid": "ID de proceso",
			"detail.field.type": "Tipo",
			"detail.field.time": "tiempo",
			"detail.field.seq": "Secuencia de eventos",
			"detail.field.turn": "Turno",
			"detail.field.step": "paso",
			"detail.field.callId": "ID de llamada",
			"detail.field.agents": "Los agentes comenzaron",
			"detail.field.result": "Resultado",
			"detail.field.parent": "Padre",
			"detail.field.depth": "Profundidad",
			"detail.field.exitCode": "código de salida",
			"detail.field.signal": "señal",
			"detail.field.previousStatus": "Estado anterior",
			"detail.field.agent": "ID del agente",
			"detail.field.job": "ID de trabajo",
			"detail.field.task": "Tarea",
			"detail.field.processGroup": "grupo de procesos",
			"detail.field.availability": "Disponibilidad",
			"detail.field.bestMatch": "mejor partido",
			"detail.field.target": "Evento objetivo",
			"detail.field.surface": "Estado de registro",
			"detail.agents.count": "Agentes {count}",
			"detail.jobs.count": "Trabajos en segundo plano {count}",
			"detail.terminals.count": "Terminales {count}",
			"detail.tasks.count": "Tareas del equipo {count}",
			"detail.tasks.nextPage": "Más tareas disponibles; el siguiente cursor es {cursor}",
			"detail.locations.count": "Ubicaciones de {count}",
			"detail.location": "Línea {line}, columna {column}",
			"detail.receipt.delivered": "Mensaje entregado",
			"detail.receipt.interrupt": "Interrupción solicitada",
			"detail.receipt.started": "iniciado",
			"detail.receipt.cancel": "Cancelación solicitada",
			"detail.receipt.alreadyFinished": "ya terminé",
			"detail.receipt.signal": "Señal entregada",
			"detail.receipt.closed": "Cerrado",
			"detail.receipt.closing": "Cierre",
			"detail.wait.noProgress": "No hay subagentes activos",
			"detail.wait.title": "Actividad del subagente",
			"detail.wait.timeout": "Se agotó el tiempo de espera",
			"detail.wait.changed": "Cambio detectado",
			"detail.agent.reply": "Respuesta del agente",
			"detail.models.title": "Modelos disponibles",
			"detail.output.lines": "Líneas {begin}–{end} de {total}",
			"detail.output.truncated": "Salida truncada",
			"detail.providers.count": "{count} inspeccionar proveedores",
			"detail.plugins.count": "Complementos dinámicos {count}",
			"detail.workflow.script": "Guión de flujo de trabajo",
			"detail.ralph.reportedComplete": "finalización reportada por el trabajador",
			"detail.ralph.reportedBlocker": "Trabajador reportó un bloqueador",
			"detail.ralph.limit": "Límite de ronda alcanzado",
			"detail.report.nextSteps": "Trabajo restante",
			"detail.trace.replacedBy": "Reemplazado por",
			"detail.trace.replacementChain": "Cadena de repuesto",
			"detail.trace.replaces": "Eventos reemplazados",
			"detail.trace.sources": "Eventos de origen",
			"detail.trace.derived": "Eventos derivados",
			"detail.trace.ancestors": "Sesiones de antepasados",
			"detail.trace.descendants": "Sesiones de descendientes",
			"detail.matches.count": "Partidos {count}",
			"detail.matches.capped": "Límite de resultados alcanzado; acotar la búsqueda para más",
			"detail.event.neighbors": "Eventos circundantes",
			"todo.completed": "{done}/{total} completado",
			"command.attachmentsUnsupported": "/{command} no acepta archivos adjuntos; eliminarlos primero",
			"ask.rowTitle": "hacer pregunta",
			"ask.waiting": "esperando",
			"ask.pending": "continuó; respuesta aún disponible",
			"ask.pendingDetail": "Estas cuestiones pendientes siguen siendo responsabilidad del compositor.",
			"ask.reopen": "respuesta",
			"ask.review": "Ver respuestas",
			"ask.closed": "cerrado",
			"ask.closedDetail": "Esta pregunta está cerrada; su resultado está en la conversación a continuación.",
			"ask.cancelled": "cancelado",
			"ask.cancelledDetail": "Este conjunto de preguntas se canceló antes de enviar las respuestas.",
			"ask.interrupted": "interrumpido",
			"ask.interruptedDetail": "Este conjunto de preguntas se interrumpió antes de que se enviaran las respuestas.",
			"ask.answered": "{answered}/{total} respondió",
			"ask.skipped": "No respondido",
			"bash.running": "corriendo",
			"bash.failed": "Fallido",
			"bash.stopped": "Detenido",
			"row.running": "corriendo",
			"row.preparing": "Preparando la llamada a la herramienta",
			"row.failed": "Fallido",
			"row.stopped": "Detenido",
			"row.commandArguments": "Argumentos de comando",
			"row.input": "IN",
			"row.output": "OUT",
			"row.inspect": "inspeccionar",
			"row.imageSize": "{width}x{height}px, {bytes} bytes",
			"row.imageSizeDownscaled": "{width}x{height}px (reducido de {originalWidth}x{originalHeight}px), {bytes} bytes",
			"tool.title.search": "Buscar",
			"tool.title.read": "leer",
			"tool.title.bash": "golpe",
			"tool.title.write": "escribir",
			"tool.title.edit": "Editar",
			"tool.title.applyPatch": "Aplicar parche",
			"tool.title.code": "Código",
			"tool.title.generic": "llamada de herramienta",
			"tool.title.inspect": "Consulta entorno Cordis",
			"tool.title.runCordis": "Ejecute el complemento Cordis",
			"tool.title.stopCordis": "Detener el complemento Cordis",
			"tool.title.removeCordis": "Eliminar el complemento Cordis",
			"tool.title.pwsh": "Pwsh",
			"tool.title.readImage": "Leer imagen",
			"tool.title.grep": "grep",
			"tool.title.glob": "globo",
			"tool.title.webSearch": "Buscar",
			"tool.title.webFetch": "buscar",
			"tool.autoReviewRejected": "Rechazado por Auto review",
			"tool.autoReviewNotExecuted": "La herramienta no fue ejecutada. Razón: {reason}",
			"tool.autoReviewReasonFallback": "Auto review no autorizó esta acción",
			"diff.collapseAria": "Contraer diferencia",
			"diff.expandAria": "Expanda {count} más líneas diferenciales",
			"diff.expandRest": "… {count} más líneas",
			"read.window": "Mostrando {shown} de líneas {total}",
			"read.collapseAria": "Contraer contenido",
			"read.expandAria": "Ampliar {count} más líneas",
			"read.expandRest": "… {count} más líneas",
			"search.paths": "Rutas {shown}",
			"search.paths.truncated": "Mostrando {shown} de las rutas {total}",
			"search.matches": "Coincidencias {shown} · Archivos {files}",
			"search.matches.truncated": "Mostrando {shown} de coincidencias {total} · Archivos {files}",
			"search.noResults": "Sin resultados",
			"search.collapseAria": "Contraer resultados",
			"search.expandAria": "Expandir {count} más líneas de resultados",
			"search.expandRest": "… {count} más líneas",
			"web.noResults": "No se encontraron resultados",
			"web.sourcesTruncated": "Lista de fuentes truncada",
			"web.http": "HTTP",
			"web.contentTruncated": "Contenido truncado",
			"details.running": "Corriendo…",
			"queue.count": "Mensajes en cola {n}",
			"queue.sending": "Enviando…",
			"queue.image": "Imagen de mensaje en cola",
			"queue.file": "Archivo en cola {name}",
			"queue.edit": "Editar mensaje en cola",
			"queue.edit.unsupported": "Contiene contenido que no es texto; la edición aún no es compatible",
			"queue.save": "Guardar mensaje en cola",
			"queue.cancelEdit": "Cancelar edición",
			"queue.remove": "Eliminar mensaje en cola",
			"queue.steer": "Redirigir mensaje en cola",
			"queue.steer.unavailable": "La dirección solo está disponible mientras el agente está en ejecución",
			"error.sessionInUse": "Esta sesión ya está en uso, posiblemente por otra instancia de DSH en ejecución (como la web dsh o la aplicación de escritorio). Salga de otras instancias de DSH en ejecución y vuelva a intentarlo.",
			"queue.editFailed": "Error de edición: es posible que este mensaje ya haya comenzado a enviarse.",
			"queue.removeFailed": "Error al eliminar: es posible que este mensaje ya haya comenzado a enviarse.",
			"queue.steerFailed": "La dirección falló. Intentar otra vez.",
			"terminal.signal": "señal {signal}",
			"terminal.exitCode": "código de salida {code}",
			"terminal.noExitCode": "sin código de salida",
			"terminal.commandLine": "Línea de comando {n}",
			"terminal.running": "corriendo",
			"terminal.failed": "Fallido",
			"terminal.done": "hecho",
			"terminal.noOutput": "Sin salida",
			"terminal.collapseAria": "Contraer salida",
			"terminal.expandAria": "Expanda las líneas de salida {n} restantes",
			"terminal.expandRest": "… {n} más líneas",
			"terminal.sendInput": "(enviar entrada)",
			"terminal.session": "Terminal {sessionId}",
			"tool.title.viewSchedule": "Ver tarea de automatización",
			"tool.title.editSchedule": "Editar tarea de automatización",
			"detail.schedule.active": "Habilitado",
			"detail.schedule.paused": "Pausada",
			"detail.schedule.ended": "Finalizada"
		};
		/** French dictionary, checked against the English keys. */
		const fr = {
			"quote.remove": "Supprimer le devis",
			"shortcut.newline": "Nouvelle ligne",
			"shortcut.complementary": "Utiliser l’action alternative de mise en attente ou de guidage",
			"shortcut.slash": "Ouvrir le menu des commandes",
			"shortcut.mention": "Ouvrir le menu de référence",
			"hint.plan": PLAN_NEXT_ACTION_EN,
			"hint.goal": "décrire l'objectif d'une tâche de longue durée",
			"hint.goal.active": "objectif actif — modifier/mettre en pause/reprendre/effacer",
			"placeholder.plan": PLAN_NEXT_ACTION_EN,
			"placeholder.default": "Envoyez un message ou exécutez une tâche, des commandes /, des fichiers @ ou des sessions",
			"placeholder.unavailable": "Séance indisponible",
			"placeholder.parentOffline": "Session parent hors ligne\xA0; l'envoi n'est pas disponible mais vous pouvez toujours arrêter l'exécution",
			"placeholder.hero": "Décrivez ce que vous souhaitez construire, / commandes, @ fichiers ou sessions",
			"placeholder.workspace": "Choisissez un espace de travail pour commencer",
			"placeholder.steerQueue": "Cmd/Ctrl+Entrée dirige tous les messages en file d'attente",
			"input.commands": "Ajouter des fichiers ou exécuter des commandes",
			"input.file": "Fichier",
			"input.stop": "Arrêter la génération",
			"input.send": "Envoyer le message",
			"input.sending": "Envoi du message",
			"input.send.queue": "Message de file d'attente",
			"input.send.steer": "Guider avec ce message",
			"attachment.pending": "Pièces jointes en attente",
			"attachment.scrollLeft": "Faire défiler les pièces jointes vers la gauche",
			"attachment.scrollRight": "Faire défiler les pièces jointes vers la droite",
			"attachment.dropTitle": "Faites glisser des fichiers ou des images ici pour les ajouter",
			"attachment.dropDesc": "Limite d'images\xA0: jusqu'à des images {count}, {size} chacune",
			"attachment.dropBlocked": "Les fichiers et les images ne peuvent pas être ajoutés pour le moment",
			"attachment.directoryDesktopOnly": "Les dossiers ne peuvent être ajoutés que dans l'application de bureau\xA0; ajouter des fichiers individuels dans le navigateur",
			"attachment.pathUnavailable": "Impossible d'obtenir le chemin du dossier\xA0; fais-le glisser à nouveau",
			"attachment.pathUnsupported": "Le chemin contient des caractères qu'une référence ne peut pas transporter\xA0; renommez-le et réessayez",
			"image.pending": "Images en attente",
			"image.openOriginal": "Voir l'original",
			"image.openOriginalLabel": "{label}, cliquez pour voir l'original",
			"image.remove": "Supprimer l'image {name}",
			"image.original": "Image originale",
			"image.label": "Images",
			"image.loadFailed": "L'image n'a pas pu être chargée\xA0; cliquez pour réessayer",
			"image.loading": "Chargement de l'image…",
			"image.preview": "Aperçu de l'image originale",
			"image.closePreview": "Fermer l'aperçu de l'image d'origine",
			"image.unsupportedType": "Seules les images PNG, JPG, WebP et GIF sont prises en charge",
			"image.tooMany": "Un message peut inclure jusqu'à des images {count}",
			"image.fileTooLarge": "Chaque image doit être plus petite que {size}",
			"image.totalTooLarge": "Les images dépassent {size} au total\xA0; enlève-en un peu et réessaye",
			"image.tooManyPixels": "La résolution de l'image est trop élevée\xA0; compressez-le et réessayez",
			"image.dimensionTooLarge": "Les côtés de l'image doivent être au maximum {size}px\xA0; réduisez-le et réessayez",
			"image.modelUnsupported": "Le modèle actuel ne prend pas en charge les images\xA0; passer à un modèle qui le fait",
			"image.sendFailed": "L'envoi des images a échoué ({reason})\xA0; rajoutez-les et réessayez",
			"file.pending": "Fichiers en attente",
			"file.remove": "Supprimer le fichier {name}",
			"file.uploading": "Téléchargement…",
			"file.uploadFailed": "Échec du téléchargement\xA0; cliquez pour réessayer",
			"file.retry": "Réessayez de télécharger {name}",
			"file.stillUploading": "Les fichiers sont toujours en cours de téléchargement\xA0; envoyer après avoir fini",
			"file.sessionUnavailable": "Séance indisponible\xA0; les fichiers ne peuvent pas être téléchargés",
			"file.notStaged": "Le téléchargement du fichier n'est pas terminé\xA0; rajoutez-le et réessayez",
			"file.label": "Fichier",
			"context.aria": "{percent} de contexte utilisé",
			"context.used": "du contexte utilisé",
			"context.system": "Invite système",
			"context.tools": "Définitions d'outils",
			"context.messages": "Messages",
			"settings.enter.title": "Comportement d'envoi lorsque vous êtes occupé",
			"settings.enter.description": "Ce que font Entrée et le bouton Envoyer pendant l'exécution de l'agent\xA0; Cmd/Ctrl+Entrée utilise l'autre comportement",
			"settings.enter.queue": "File d'attente",
			"settings.enter.steer": "Guider",
			"hero.headline": "Dans l'inconnu",
			"hero.preview": "Aperçu",
			"hero.chooseWorkspace": "Choisir un espace de travail",
			"session.hierarchy": "Hiérarchie des sessions",
			"session.moreViews": "Plus de vues de conversations",
			"todo.title": "À faire",
			"todo.progress.done": "{done} terminé",
			"todo.progress.active": "{active} en cours",
			"todo.progress.pending": "{pending} en attente",
			"todo.status.completed": "Terminé",
			"todo.status.inProgress": "En cours",
			"todo.status.pending": "En attente",
			"todo.rowTitle": "Mettre à jour la liste de tâches",
			"tool.title.createGoal": "Créer un objectif",
			"tool.title.getGoal": "Afficher l'objectif",
			"tool.title.updateGoal": "Objectif de mise à jour",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "Créer une tâche d'automatisation",
			"tool.title.listSchedules": "Lister les tâches d'automatisation",
			"tool.title.deleteSchedule": "Supprimer la tâche d'automatisation",
			"tool.title.updateSchedule": "Mettre à jour la tâche d'automatisation",
			"detail.state": "Statut",
			"detail.todo.completed": "Terminé",
			"detail.todo.in_progress": "En cours",
			"detail.todo.pending": "En attente",
			"detail.todo.empty": "La liste de tâches est vide",
			"todo.diff.initial": "Liste initiale",
			"todo.diff.compare": "Changements depuis la liste précédente",
			"todo.diff.unavailable": "Liste précédente indisponible",
			"todo.diff.noChanges": "Aucun changement dans la liste",
			"todo.diff.added": "{count} ajouté",
			"todo.diff.updated": "{count} mis à jour",
			"todo.diff.removed": "{count} supprimé",
			"todo.diff.unchanged": "{count} inchangé",
			"todo.diff.addedItem": "Ajouté",
			"todo.diff.updatedItem": "Statut modifié",
			"todo.diff.movedItem": "Réorganisé",
			"todo.diff.removedItem": "Supprimé",
			"detail.goal.empty": "Aucun but",
			"detail.goal.active": "Actif",
			"detail.goal.disarmed": "En attente de suite",
			"detail.goal.paused": "En pause",
			"detail.goal.blocked": "Bloqué",
			"detail.goal.complete": "Terminé",
			"detail.goal.rounds": "Tours",
			"detail.goal.reason": "Bloqueur",
			"detail.days": "{count}d",
			"detail.hours": "{count} h",
			"detail.minutes": "{count} min.",
			"detail.seconds": "{count}s",
			"detail.schedule.once": "Une fois",
			"detail.schedule.every": "Chaque {interval}",
			"detail.schedule.when": "Prévu pour",
			"detail.schedule.frequency": "Répéter",
			"detail.schedule.scheduled": "Programmé",
			"detail.schedule.overdue": "En retard, en attente de reprise de la session",
			"detail.schedule.empty": "Aucune tâche d'automatisation",
			"detail.schedule.deleted": "Supprimé",
			"detail.schedule.count": "{count} tâches d'automatisation",
			"detail.schedule.daily": "Tous les jours à {time} ({zone})",
			"detail.schedule.weekly": "Hebdomadaire sur {days} à {time} ({zone})",
			"detail.schedule.cron": "Cron {expression} ({zone})",
			"detail.schedule.custom": "Personnalisé",
			"detail.weekday.1": "lundi",
			"detail.weekday.2": "mar.",
			"detail.weekday.3": "mer",
			"detail.weekday.4": "jeu.",
			"detail.weekday.5": "vendredi",
			"detail.weekday.6": "Samedi",
			"detail.weekday.7": "Soleil",
			"detail.weekday.join": ", ",
			"tool.title.inspectProviders": "Inspecter les fournisseurs",
			"tool.title.queryRuntime": "Exécution de la requête",
			"tool.title.inspectPlugins": "Inspecter les plugins",
			"tool.title.workflow": "Exécuter le flux de travail",
			"tool.title.ralph": "Exécuter la boucle Ralph",
			"tool.title.readEvent": "Lire l'événement",
			"tool.title.searchEvents": "Rechercher des événements",
			"tool.title.traceEvent": "Événement de trace",
			"tool.title.searchSessions": "Rechercher des sessions",
			"tool.title.traceSession": "Session de traçage",
			"tool.title.listModels": "Liste des modèles",
			"tool.title.subagent": "Créer un sous-agent",
			"tool.title.listAgents": "Liste des sous-agents",
			"tool.title.sendMessage": "Envoyer le message",
			"tool.title.interruptAgent": "Agent d'interruption",
			"tool.title.listJobs": "Répertorier les tâches en arrière-plan",
			"tool.title.readJob": "Lire le résultat de la tâche",
			"tool.title.killJob": "Annuler le travail en arrière-plan",
			"tool.title.openTerminal": "Terminal ouvert",
			"tool.title.readTerminal": "Lire le terminal",
			"tool.title.listTerminals": "Liste des terminaux",
			"tool.title.signalTerminal": "Borne de signal",
			"tool.title.closeTerminal": "Fermer le terminal",
			"tool.title.lsp": "Symboles du code de requête",
			"tool.title.findDefinition": "Trouver une définition",
			"tool.title.findReferences": "Trouver des références",
			"tool.title.findImplementation": "Trouver la mise en œuvre",
			"tool.title.hoverSymbol": "Inspecter le symbole",
			"tool.title.spawnTeammate": "Créer un coéquipier",
			"tool.title.createTeamTask": "Créer une tâche d'équipe",
			"tool.title.getTeamTask": "Lire la tâche d'équipe",
			"tool.title.updateTeamTask": "Mettre à jour la tâche de l'équipe",
			"tool.title.listTeamTasks": "Répertorier les tâches de l'équipe",
			"tool.title.waitAgent": "Attendez le sous-agent",
			"detail.recordedResult": "Résultat enregistré",
			"detail.empty": "Aucun résultat",
			"detail.none": "Aucun",
			"detail.yes": "Oui",
			"detail.no": "Non",
			"detail.moreInInspect": "{count} plus d'articles disponibles dans Inspecter",
			"detail.status.running": "Courir",
			"detail.status.idle": "Inactif",
			"detail.status.ready": "Prêt",
			"detail.status.inactive": "Inactif",
			"detail.status.provisioning": "Approvisionnement",
			"detail.status.failed": "Échec",
			"detail.status.completed": "Terminé",
			"detail.status.deleted": "Supprimé",
			"detail.status.killed": "Annulé",
			"detail.status.accepted": "Accepté",
			"detail.status.queued": "En file d'attente",
			"detail.status.exited": "Quitté",
			"detail.field.id": "ID",
			"detail.field.revision": "Révision",
			"detail.field.platform": "Plateforme",
			"detail.field.provider": "Fournisseur",
			"detail.field.model": "Modèle",
			"detail.field.role": "Rôle",
			"detail.field.context": "Contexte",
			"detail.field.owner": "Propriétaire",
			"detail.field.ready": "Prêt",
			"detail.field.dependencies": "Dépendances",
			"detail.field.writeScopes": "Écrire des étendues",
			"detail.field.warnings": "Avertissements",
			"detail.field.diagnostics": "Diagnostic",
			"detail.field.methods": "Méthodes",
			"detail.field.inputSchema": "Schéma d'entrée",
			"detail.field.outputSchema": "Schéma de sortie",
			"detail.field.currentPackage": "Forfait actuel",
			"detail.field.nextPackage": "Forfait suivant",
			"detail.field.latestRun": "Dernière course",
			"detail.field.packages": "Forfaits",
			"detail.field.registrations": "Inscriptions",
			"detail.field.props": "Accessoires",
			"detail.field.data": "Données",
			"detail.field.source": "Source",
			"detail.field.content": "Contenu",
			"detail.field.message": "Message",
			"detail.field.messageId": "Identifiant du message",
			"detail.field.root": "Racine",
			"detail.field.pid": "ID de processus",
			"detail.field.type": "Tapez",
			"detail.field.time": "Temps",
			"detail.field.seq": "Séquence d'événements",
			"detail.field.turn": "Tour",
			"detail.field.step": "Étape",
			"detail.field.callId": "Identifiant d'appel",
			"detail.field.agents": "Les agents ont commencé",
			"detail.field.result": "Résultat",
			"detail.field.parent": "Parent",
			"detail.field.depth": "Profondeur",
			"detail.field.exitCode": "Code de sortie",
			"detail.field.signal": "Signal",
			"detail.field.previousStatus": "Statut précédent",
			"detail.field.agent": "ID d'agent",
			"detail.field.job": "ID de travail",
			"detail.field.task": "Tâche",
			"detail.field.processGroup": "Groupe de processus",
			"detail.field.availability": "Disponibilité",
			"detail.field.bestMatch": "Meilleure correspondance",
			"detail.field.target": "Événement cible",
			"detail.field.surface": "Statut d'enregistrement",
			"detail.agents.count": "Agents {count}",
			"detail.jobs.count": "Travaux d'arrière-plan {count}",
			"detail.terminals.count": "Bornes {count}",
			"detail.tasks.count": "Tâches de l'équipe {count}",
			"detail.tasks.nextPage": "Plus de tâches disponibles\xA0; le curseur suivant est {cursor}",
			"detail.locations.count": "Localisations {count}",
			"detail.location": "Ligne {line}, colonne {column}",
			"detail.receipt.delivered": "Message délivré",
			"detail.receipt.interrupt": "Interruption demandée",
			"detail.receipt.started": "Commencé",
			"detail.receipt.cancel": "Annulation demandée",
			"detail.receipt.alreadyFinished": "Déjà fini",
			"detail.receipt.signal": "Signal délivré",
			"detail.receipt.closed": "Fermé",
			"detail.receipt.closing": "Clôture",
			"detail.wait.noProgress": "Aucun sous-agent actif",
			"detail.wait.title": "Activité du sous-agent",
			"detail.wait.timeout": "Le délai d'attente a expiré",
			"detail.wait.changed": "Changement détecté",
			"detail.agent.reply": "Réponse de l'agent",
			"detail.models.title": "Modèles disponibles",
			"detail.output.lines": "Lignes {begin}–{end} de {total}",
			"detail.output.truncated": "Sortie tronquée",
			"detail.providers.count": "{count} inspecte les fournisseurs",
			"detail.plugins.count": "Plugins dynamiques {count}",
			"detail.workflow.script": "Script de flux de travail",
			"detail.ralph.reportedComplete": "Le travailleur a signalé l'achèvement",
			"detail.ralph.reportedBlocker": "Le travailleur a signalé un bloqueur",
			"detail.ralph.limit": "Limite de tours atteinte",
			"detail.report.nextSteps": "Travail restant",
			"detail.trace.replacedBy": "Remplacé par",
			"detail.trace.replacementChain": "Chaîne de remplacement",
			"detail.trace.replaces": "Événements remplacés",
			"detail.trace.sources": "Événements sources",
			"detail.trace.derived": "Événements dérivés",
			"detail.trace.ancestors": "Séances d'ancêtres",
			"detail.trace.descendants": "Séances descendantes",
			"detail.matches.count": "Correspondances {count}",
			"detail.matches.capped": "Limite de résultat atteinte\xA0; affiner la recherche pour en savoir plus",
			"detail.event.neighbors": "Événements environnants",
			"todo.completed": "{done}/{total} terminé",
			"command.attachmentsUnsupported": "/{command} n'accepte pas les pièces jointes\xA0; retirez-les d'abord",
			"ask.rowTitle": "Poser une question",
			"ask.waiting": "en attendant",
			"ask.pending": "suite\xA0; réponse toujours disponible",
			"ask.pendingDetail": "Ces questions en suspens restent à la charge du compositeur.",
			"ask.reopen": "Réponse",
			"ask.review": "Afficher les réponses",
			"ask.closed": "fermé",
			"ask.closedDetail": "Cette question est fermée ; son résultat est dans la conversation ci-dessous.",
			"ask.cancelled": "annulé",
			"ask.cancelledDetail": "Cet ensemble de questions a été annulé avant que les réponses ne soient soumises.",
			"ask.interrupted": "interrompu",
			"ask.interruptedDetail": "Cette série de questions a été interrompue avant que les réponses ne soient soumises.",
			"ask.answered": "{answered}/{total} répondu",
			"ask.skipped": "Pas de réponse",
			"bash.running": "Courir",
			"bash.failed": "Échec",
			"bash.stopped": "Arrêté",
			"row.running": "Courir",
			"row.preparing": "Préparation de l'appel à l'outil",
			"row.failed": "Échec",
			"row.stopped": "Arrêté",
			"row.commandArguments": "Arguments de commande",
			"row.input": "IN",
			"row.output": "OUT",
			"row.inspect": "Inspecter",
			"row.imageSize": "{width}x{height}px, {bytes} octets",
			"row.imageSizeDownscaled": "{width}x{height}px (réduction de {originalWidth}x{originalHeight}px), {bytes} octets",
			"tool.title.search": "Rechercher",
			"tool.title.read": "Lire",
			"tool.title.bash": "Frapper",
			"tool.title.write": "Écrire",
			"tool.title.edit": "Modifier",
			"tool.title.applyPatch": "Appliquer le patch",
			"tool.title.code": "Coder",
			"tool.title.generic": "Appel d'outil",
			"tool.title.inspect": "Interroger l'environnement Cordis",
			"tool.title.runCordis": "Exécuter le plugin Cordis",
			"tool.title.stopCordis": "Arrêter le plug-in Cordis",
			"tool.title.removeCordis": "Supprimer le plug-in Cordis",
			"tool.title.pwsh": "Pwsh",
			"tool.title.readImage": "Lire l'image",
			"tool.title.grep": "Grep",
			"tool.title.glob": "Glob",
			"tool.title.webSearch": "Rechercher",
			"tool.title.webFetch": "Récupérer",
			"tool.autoReviewRejected": "Rejeté par Auto review",
			"tool.autoReviewNotExecuted": "L'outil n'a pas été exécuté. Raison\xA0: {reason}",
			"tool.autoReviewReasonFallback": "Auto review n'a pas autorisé cette action",
			"diff.collapseAria": "Réduire la différence",
			"diff.expandAria": "Développez {count} plus de lignes de différence",
			"diff.expandRest": "… {count} plus de lignes",
			"read.window": "Affichage des lignes {shown} des lignes {total}",
			"read.collapseAria": "Réduire le contenu",
			"read.expandAria": "Développez {count} plus de lignes",
			"read.expandRest": "… {count} plus de lignes",
			"search.paths": "Chemins {shown}",
			"search.paths.truncated": "Affichage des chemins {shown} sur {total}",
			"search.matches": "Correspondances {shown} · Fichiers {files}",
			"search.matches.truncated": "Affichage des correspondances {shown} des correspondances {total} · Fichiers {files}",
			"search.noResults": "Aucun résultat",
			"search.collapseAria": "Réduire les résultats",
			"search.expandAria": "Développez {count} plus de lignes de résultats",
			"search.expandRest": "… {count} plus de lignes",
			"web.noResults": "Aucun résultat trouvé",
			"web.sourcesTruncated": "Liste source tronquée",
			"web.http": "HTTP",
			"web.contentTruncated": "Contenu tronqué",
			"details.running": "Courir…",
			"queue.count": "Messages en file d'attente {n}",
			"queue.sending": "Envoi…",
			"queue.image": "Image du message en file d'attente",
			"queue.file": "Fichier en file d'attente {name}",
			"queue.edit": "Modifier le message en file d'attente",
			"queue.edit.unsupported": "Contient du contenu non textuel\xA0; l'édition n'est pas encore prise en charge",
			"queue.save": "Enregistrer le message en file d'attente",
			"queue.cancelEdit": "Annuler la modification",
			"queue.remove": "Supprimer le message en file d'attente",
			"queue.steer": "Guider avec le message en attente",
			"queue.steer.unavailable": "Le pilotage est disponible uniquement lorsque l'agent est en cours d'exécution",
			"error.sessionInUse": "Cette session est déjà utilisée, éventuellement par une autre instance DSH en cours d'exécution (telle que le Web dsh ou l'application de bureau). Quittez les autres instances DSH en cours d'exécution et réessayez.",
			"queue.editFailed": "Échec de la modification\xA0: l'envoi de ce message a peut-être déjà commencé.",
			"queue.removeFailed": "Échec de la suppression\xA0: l'envoi de ce message a peut-être déjà commencé.",
			"queue.steerFailed": "La direction a échoué. Essayer à nouveau.",
			"terminal.signal": "signal {signal}",
			"terminal.exitCode": "code de sortie {code}",
			"terminal.noExitCode": "pas de code de sortie",
			"terminal.commandLine": "Ligne de commande {n}",
			"terminal.running": "Courir",
			"terminal.failed": "Échec",
			"terminal.done": "Terminé",
			"terminal.noOutput": "Aucune sortie",
			"terminal.collapseAria": "Réduire la sortie",
			"terminal.expandAria": "Développez les lignes de sortie {n} restantes",
			"terminal.expandRest": "… {n} plus de lignes",
			"terminal.sendInput": "(envoyer une entrée)",
			"terminal.session": "Borne {sessionId}",
			"tool.title.viewSchedule": "Voir la tâche d'automatisation",
			"tool.title.editSchedule": "Modifier la tâche d'automatisation",
			"detail.schedule.active": "Activé",
			"detail.schedule.paused": "Suspendue",
			"detail.schedule.ended": "Terminée"
		};
		/** German dictionary, checked against the English keys. */
		const de = {
			"quote.remove": "Zitat entfernen",
			"shortcut.newline": "Neue Zeile",
			"shortcut.complementary": "Die alternative Aktion zum Vormerken oder Lenken verwenden",
			"shortcut.slash": "Befehlsmenü öffnen",
			"shortcut.mention": "Referenzmenü öffnen",
			"hint.plan": PLAN_NEXT_ACTION_EN,
			"hint.goal": "Beschreiben Sie das Ziel einer lang andauernden Aufgabe",
			"hint.goal.active": "Ziel aktiv – Bearbeiten / Anhalten / Fortsetzen / Löschen",
			"placeholder.plan": PLAN_NEXT_ACTION_EN,
			"placeholder.default": "Senden Sie eine Nachricht oder führen Sie eine Aufgabe, /-Befehle, @-Dateien oder Sitzungen aus",
			"placeholder.unavailable": "Sitzung nicht verfügbar",
			"placeholder.parentOffline": "Elternsitzung offline; Das Senden ist nicht möglich, aber Sie können den Lauf trotzdem stoppen",
			"placeholder.hero": "Beschreiben Sie, was Sie erstellen möchten: /-Befehle, @-Dateien oder Sitzungen",
			"placeholder.workspace": "Wählen Sie einen Arbeitsbereich zum Starten aus",
			"placeholder.steerQueue": "Cmd/Strg+Enter steuert alle Nachrichten in der Warteschlange",
			"input.commands": "Fügen Sie Dateien hinzu oder führen Sie Befehle aus",
			"input.file": "Datei",
			"input.stop": "Generierung stoppen",
			"input.send": "Nachricht senden",
			"input.sending": "Nachricht wird gesendet",
			"input.send.queue": "Warteschlangennachricht",
			"input.send.steer": "Mit Nachricht lenken",
			"attachment.pending": "Ausstehende Anhänge",
			"attachment.scrollLeft": "Anhänge nach links scrollen",
			"attachment.scrollRight": "Anhänge nach rechts scrollen",
			"attachment.dropTitle": "Ziehen Sie Dateien oder Bilder hierher, um sie hinzuzufügen",
			"attachment.dropDesc": "Bildbeschränkung: bis zu {count} Bilder, jeweils {size}",
			"attachment.dropBlocked": "Dateien und Bilder können derzeit nicht hinzugefügt werden",
			"attachment.directoryDesktopOnly": "Ordner können nur in der Desktop-App hinzugefügt werden; einzelne Dateien im Browser hinzufügen",
			"attachment.pathUnavailable": "Der Ordnerpfad konnte nicht abgerufen werden; Ziehen Sie es erneut hinein",
			"attachment.pathUnsupported": "Der Pfad enthält Zeichen, die eine Referenz nicht enthalten kann; Benennen Sie es um und versuchen Sie es erneut",
			"image.pending": "Ausstehende Bilder",
			"image.openOriginal": "Original ansehen",
			"image.openOriginalLabel": "{label}, klicken Sie, um das Original anzuzeigen",
			"image.remove": "Bild {name} entfernen",
			"image.original": "Originalbild",
			"image.label": "Bild",
			"image.loadFailed": "Bild konnte nicht geladen werden; Klicken Sie, um es noch einmal zu versuchen",
			"image.loading": "Bild wird geladen…",
			"image.preview": "Originalbildvorschau",
			"image.closePreview": "Originalbildvorschau schließen",
			"image.unsupportedType": "Es werden nur PNG-, JPG-, WebP- und GIF-Bilder unterstützt",
			"image.tooMany": "Eine Nachricht kann bis zu {count} Bilder enthalten",
			"image.fileTooLarge": "Jedes Bild muss kleiner als {size} sein",
			"image.totalTooLarge": "Die Anzahl der Bilder übersteigt insgesamt {size}; Entfernen Sie einige davon und versuchen Sie es erneut",
			"image.tooManyPixels": "Die Bildauflösung ist zu hoch; Komprimieren Sie es und versuchen Sie es erneut",
			"image.dimensionTooLarge": "Bildseiten dürfen höchstens {size}px sein; Skalieren Sie es herunter und versuchen Sie es erneut",
			"image.modelUnsupported": "Das aktuelle Modell unterstützt keine Bilder; Wechseln Sie zu einem Modell, das dies tut",
			"image.sendFailed": "Das Senden von Bildern ist fehlgeschlagen ({reason}); Fügen Sie sie erneut hinzu und versuchen Sie es erneut",
			"file.pending": "Ausstehende Dateien",
			"file.remove": "Datei {name} entfernen",
			"file.uploading": "Hochladen…",
			"file.uploadFailed": "Hochladen fehlgeschlagen; Klicken Sie, um es noch einmal zu versuchen",
			"file.retry": "Versuchen Sie erneut, {name} hochzuladen",
			"file.stillUploading": "Dateien werden noch hochgeladen; senden, nachdem sie fertig sind",
			"file.sessionUnavailable": "Sitzung nicht verfügbar; Dateien können nicht hochgeladen werden",
			"file.notStaged": "Der Upload der Datei wurde noch nicht abgeschlossen. Fügen Sie es erneut hinzu und versuchen Sie es erneut",
			"file.label": "Datei",
			"context.aria": "{percent} des verwendeten Kontexts",
			"context.used": "des verwendeten Kontexts",
			"context.system": "Systemaufforderung",
			"context.tools": "Werkzeugdefinitionen",
			"context.messages": "Nachrichten",
			"settings.enter.title": "Sendeverhalten, während beschäftigt ist",
			"settings.enter.description": "Was die Eingabetaste und die Schaltfläche „Senden“ bewirken, während der Agent ausgeführt wird; Cmd/Strg+Enter verwendet das andere Verhalten",
			"settings.enter.queue": "Warteschlange",
			"settings.enter.steer": "Lenken",
			"hero.headline": "Ins Unbekannte",
			"hero.preview": "Vorschau",
			"hero.chooseWorkspace": "Wählen Sie einen Arbeitsbereich",
			"session.hierarchy": "Sitzungshierarchie",
			"session.moreViews": "Weitere Konversationsansichten",
			"todo.title": "Aufgaben",
			"todo.progress.done": "{done} abgeschlossen",
			"todo.progress.active": "{active} in Bearbeitung",
			"todo.progress.pending": "{pending} ausstehend",
			"todo.status.completed": "Abgeschlossen",
			"todo.status.inProgress": "In Bearbeitung",
			"todo.status.pending": "Ausstehend",
			"todo.rowTitle": "To-Do-Liste aktualisieren",
			"tool.title.createGoal": "Ziel erstellen",
			"tool.title.getGoal": "Ziel ansehen",
			"tool.title.updateGoal": "Ziel aktualisieren",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "Automatisierungsaufgabe erstellen",
			"tool.title.listSchedules": "Automatisierungsaufgaben auflisten",
			"tool.title.deleteSchedule": "Automatisierungsaufgabe löschen",
			"tool.title.updateSchedule": "Automatisierungsaufgabe aktualisieren",
			"detail.state": "Status",
			"detail.todo.completed": "Abgeschlossen",
			"detail.todo.in_progress": "In Bearbeitung",
			"detail.todo.pending": "Ausstehend",
			"detail.todo.empty": "Die To-Do-Liste ist leer",
			"todo.diff.initial": "Erste Liste",
			"todo.diff.compare": "Änderungen gegenüber der vorherigen Liste",
			"todo.diff.unavailable": "Vorherige Liste nicht verfügbar",
			"todo.diff.noChanges": "Keine Änderungen an der Liste",
			"todo.diff.added": "{count} hinzugefügt",
			"todo.diff.updated": "{count} aktualisiert",
			"todo.diff.removed": "{count} entfernt",
			"todo.diff.unchanged": "{count} unverändert",
			"todo.diff.addedItem": "Hinzugefügt",
			"todo.diff.updatedItem": "Status geändert",
			"todo.diff.movedItem": "Nachbestellt",
			"todo.diff.removedItem": "Entfernt",
			"detail.goal.empty": "Kein Ziel",
			"detail.goal.active": "Aktiv",
			"detail.goal.disarmed": "Warten auf Fortsetzung",
			"detail.goal.paused": "Angehalten",
			"detail.goal.blocked": "Blockiert",
			"detail.goal.complete": "Abgeschlossen",
			"detail.goal.rounds": "Runden",
			"detail.goal.reason": "Blocker",
			"detail.days": "{count} d",
			"detail.hours": "{count} h",
			"detail.minutes": "{count} min",
			"detail.seconds": "{count} s",
			"detail.schedule.once": "Einmal",
			"detail.schedule.every": "Jeder {interval}",
			"detail.schedule.when": "Geplant für",
			"detail.schedule.frequency": "Wiederholen",
			"detail.schedule.scheduled": "Geplant",
			"detail.schedule.overdue": "Überfällig, ich warte auf die Fortsetzung der Sitzung",
			"detail.schedule.empty": "Keine Automatisierungsaufgaben",
			"detail.schedule.deleted": "Gelöscht",
			"detail.schedule.count": "{count} Automatisierungsaufgaben",
			"detail.schedule.daily": "Täglich um {time} ({zone})",
			"detail.schedule.weekly": "Wöchentlich auf {days} um {time} ({zone})",
			"detail.schedule.cron": "Cron {expression} ({zone})",
			"detail.schedule.custom": "Benutzerdefiniert",
			"detail.weekday.1": "Mo",
			"detail.weekday.2": "Di",
			"detail.weekday.3": "Mi",
			"detail.weekday.4": "Do",
			"detail.weekday.5": "Fr",
			"detail.weekday.6": "Sa",
			"detail.weekday.7": "Sonne",
			"detail.weekday.join": ", ",
			"tool.title.inspectProviders": "Anbieter prüfen",
			"tool.title.queryRuntime": "Abfragelaufzeit",
			"tool.title.inspectPlugins": "Plugins prüfen",
			"tool.title.workflow": "Workflow ausführen",
			"tool.title.ralph": "Führen Sie die Ralph-Schleife aus",
			"tool.title.readEvent": "Veranstaltung lesen",
			"tool.title.searchEvents": "Suchen Sie nach Ereignissen",
			"tool.title.traceEvent": "Trace-Ereignis",
			"tool.title.searchSessions": "Sitzungen suchen",
			"tool.title.traceSession": "Trace-Sitzung",
			"tool.title.listModels": "Modelle auflisten",
			"tool.title.subagent": "Subagent erstellen",
			"tool.title.listAgents": "Subagenten auflisten",
			"tool.title.sendMessage": "Nachricht senden",
			"tool.title.interruptAgent": "Interrupt-Agent",
			"tool.title.listJobs": "Hintergrundjobs auflisten",
			"tool.title.readJob": "Jobausgabe lesen",
			"tool.title.killJob": "Hintergrundjob abbrechen",
			"tool.title.openTerminal": "Terminal öffnen",
			"tool.title.readTerminal": "Terminal lesen",
			"tool.title.listTerminals": "Terminals auflisten",
			"tool.title.signalTerminal": "Signalklemme",
			"tool.title.closeTerminal": "Terminal schließen",
			"tool.title.lsp": "Codesymbole abfragen",
			"tool.title.findDefinition": "Definition finden",
			"tool.title.findReferences": "Finden Sie Referenzen",
			"tool.title.findImplementation": "Umsetzung finden",
			"tool.title.hoverSymbol": "Symbol prüfen",
			"tool.title.spawnTeammate": "Teamkollege erstellen",
			"tool.title.createTeamTask": "Teamaufgabe erstellen",
			"tool.title.getTeamTask": "Teamaufgabe lesen",
			"tool.title.updateTeamTask": "Teamaufgabe aktualisieren",
			"tool.title.listTeamTasks": "Teamaufgaben auflisten",
			"tool.title.waitAgent": "Warten Sie auf den Subagenten",
			"detail.recordedResult": "Aufgezeichnetes Ergebnis",
			"detail.empty": "Keine Ergebnisse",
			"detail.none": "Keine",
			"detail.yes": "Ja",
			"detail.no": "Nein",
			"detail.moreInInspect": "{count} weitere Artikel in Inspect verfügbar",
			"detail.status.running": "Laufen",
			"detail.status.idle": "Leerlauf",
			"detail.status.ready": "Bereit",
			"detail.status.inactive": "Inaktiv",
			"detail.status.provisioning": "Bereitstellung",
			"detail.status.failed": "Fehlgeschlagen",
			"detail.status.completed": "Abgeschlossen",
			"detail.status.deleted": "Gelöscht",
			"detail.status.killed": "Abgesagt",
			"detail.status.accepted": "Akzeptiert",
			"detail.status.queued": "In der Warteschlange",
			"detail.status.exited": "Ausgegangen",
			"detail.field.id": "ID",
			"detail.field.revision": "Überarbeitung",
			"detail.field.platform": "Plattform",
			"detail.field.provider": "Anbieter",
			"detail.field.model": "Modell",
			"detail.field.role": "Rolle",
			"detail.field.context": "Kontext",
			"detail.field.owner": "Besitzer",
			"detail.field.ready": "Bereit",
			"detail.field.dependencies": "Abhängigkeiten",
			"detail.field.writeScopes": "Bereiche schreiben",
			"detail.field.warnings": "Warnungen",
			"detail.field.diagnostics": "Diagnose",
			"detail.field.methods": "Methoden",
			"detail.field.inputSchema": "Eingabeschema",
			"detail.field.outputSchema": "Ausgabeschema",
			"detail.field.currentPackage": "Aktuelles Paket",
			"detail.field.nextPackage": "Nächstes Paket",
			"detail.field.latestRun": "Letzter Lauf",
			"detail.field.packages": "Pakete",
			"detail.field.registrations": "Anmeldungen",
			"detail.field.props": "Requisiten",
			"detail.field.data": "Daten",
			"detail.field.source": "Quelle",
			"detail.field.content": "Inhalt",
			"detail.field.message": "Nachricht",
			"detail.field.messageId": "Nachrichten-ID",
			"detail.field.root": "Wurzel",
			"detail.field.pid": "Prozess-ID",
			"detail.field.type": "Typ",
			"detail.field.time": "Zeit",
			"detail.field.seq": "Ereignissequenz",
			"detail.field.turn": "Runde",
			"detail.field.step": "Schritt",
			"detail.field.callId": "Aufruf-ID",
			"detail.field.agents": "Agenten begannen",
			"detail.field.result": "Ergebnis",
			"detail.field.parent": "Eltern",
			"detail.field.depth": "Tiefe",
			"detail.field.exitCode": "Exit-Code",
			"detail.field.signal": "Signal",
			"detail.field.previousStatus": "Vorheriger Stand",
			"detail.field.agent": "Agenten-ID",
			"detail.field.job": "Job-ID",
			"detail.field.task": "Aufgabe",
			"detail.field.processGroup": "Prozessgruppe",
			"detail.field.availability": "Verfügbarkeit",
			"detail.field.bestMatch": "Beste Übereinstimmung",
			"detail.field.target": "Zielereignis",
			"detail.field.surface": "Aufnahmestatus",
			"detail.agents.count": "{count}-Agenten",
			"detail.jobs.count": "{count} Hintergrundjobs",
			"detail.terminals.count": "{count}-Klemmen",
			"detail.tasks.count": "{count} Teamaufgaben",
			"detail.tasks.nextPage": "Weitere Aufgaben verfügbar; Der nächste Cursor ist {cursor}",
			"detail.locations.count": "{count}-Standorte",
			"detail.location": "Zeile {line}, Spalte {column}",
			"detail.receipt.delivered": "Nachricht zugestellt",
			"detail.receipt.interrupt": "Unterbrechung angefordert",
			"detail.receipt.started": "Begonnen",
			"detail.receipt.cancel": "Stornierung beantragt",
			"detail.receipt.alreadyFinished": "Schon fertig",
			"detail.receipt.signal": "Signal geliefert",
			"detail.receipt.closed": "Geschlossen",
			"detail.receipt.closing": "Schließung",
			"detail.wait.noProgress": "Keine aktiven Subagenten",
			"detail.wait.title": "Aktivität des Subagenten",
			"detail.wait.timeout": "Wartezeit abgelaufen",
			"detail.wait.changed": "Änderung erkannt",
			"detail.agent.reply": "Antwort des Agenten",
			"detail.models.title": "Verfügbare Modelle",
			"detail.output.lines": "Linien {begin}–{end} von {total}",
			"detail.output.truncated": "Ausgabe abgeschnitten",
			"detail.providers.count": "{count} prüft Anbieter",
			"detail.plugins.count": "Dynamische {count}-Plugins",
			"detail.workflow.script": "Workflow-Skript",
			"detail.ralph.reportedComplete": "Der Arbeiter hat die Fertigstellung gemeldet",
			"detail.ralph.reportedBlocker": "Der Arbeiter hat einen Blocker gemeldet",
			"detail.ralph.limit": "Rundenlimit erreicht",
			"detail.report.nextSteps": "Verbleibende Arbeit",
			"detail.trace.replacedBy": "Ersetzt durch",
			"detail.trace.replacementChain": "Ersatzkette",
			"detail.trace.replaces": "Ereignisse ersetzt",
			"detail.trace.sources": "Quellereignisse",
			"detail.trace.derived": "Abgeleitete Ereignisse",
			"detail.trace.ancestors": "Ahnensitzungen",
			"detail.trace.descendants": "Nachkommende Sitzungen",
			"detail.matches.count": "{count} Übereinstimmungen",
			"detail.matches.capped": "Ergebnisgrenze erreicht; Grenzen Sie die Suche auf mehr ein",
			"detail.event.neighbors": "Umliegende Veranstaltungen",
			"todo.completed": "{done}/{total} abgeschlossen",
			"command.attachmentsUnsupported": "/{command} akzeptiert keine Anhänge; Entfernen Sie sie zuerst",
			"ask.rowTitle": "Frage stellen",
			"ask.waiting": "warten",
			"ask.pending": "Fortsetzung; Antwort noch verfügbar",
			"ask.pendingDetail": "Diese offenen Fragen bleiben vom Komponisten zu beantworten.",
			"ask.reopen": "Antwort",
			"ask.review": "Antworten anzeigen",
			"ask.closed": "geschlossen",
			"ask.closedDetail": "Diese Frage ist geschlossen; Das Ergebnis finden Sie im folgenden Gespräch.",
			"ask.cancelled": "abgesagt",
			"ask.cancelledDetail": "Dieser Fragensatz wurde gelöscht, bevor die Antworten übermittelt wurden.",
			"ask.interrupted": "unterbrochen",
			"ask.interruptedDetail": "Dieser Fragensatz wurde unterbrochen, bevor Antworten übermittelt wurden.",
			"ask.answered": "{answered}/{total} antwortete",
			"ask.skipped": "Nicht beantwortet",
			"bash.running": "Laufen",
			"bash.failed": "Fehlgeschlagen",
			"bash.stopped": "Angehalten",
			"row.running": "Laufen",
			"row.preparing": "Werkzeugaufruf wird vorbereitet",
			"row.failed": "Fehlgeschlagen",
			"row.stopped": "Angehalten",
			"row.commandArguments": "Befehlsargumente",
			"row.input": "IN",
			"row.output": "OUT",
			"row.inspect": "Inspizieren",
			"row.imageSize": "{width}x{height}px, {bytes} Bytes",
			"row.imageSizeDownscaled": "{width}x{height}px (herunterskaliert von {originalWidth}x{originalHeight}px), {bytes} Bytes",
			"tool.title.search": "Suchen",
			"tool.title.read": "Lesen",
			"tool.title.bash": "Bash",
			"tool.title.write": "Schreiben",
			"tool.title.edit": "Bearbeiten",
			"tool.title.applyPatch": "Patch anwenden",
			"tool.title.code": "Code",
			"tool.title.generic": "Werkzeugaufruf",
			"tool.title.inspect": "Fragen Sie die Cordis-Umgebung ab",
			"tool.title.runCordis": "Führen Sie das Cordis-Plugin aus",
			"tool.title.stopCordis": "Stoppen Sie das Cordis-Plugin",
			"tool.title.removeCordis": "Entfernen Sie das Cordis-Plugin",
			"tool.title.pwsh": "Pwsh",
			"tool.title.readImage": "Bild lesen",
			"tool.title.grep": "Grep",
			"tool.title.glob": "Globus",
			"tool.title.webSearch": "Suchen",
			"tool.title.webFetch": "Holen",
			"tool.autoReviewRejected": "Abgelehnt von Auto review",
			"tool.autoReviewNotExecuted": "Werkzeug wurde nicht ausgeführt. Grund: {reason}",
			"tool.autoReviewReasonFallback": "Auto review hat diese Aktion nicht autorisiert",
			"diff.collapseAria": "Differenz ausblenden",
			"diff.expandAria": "Erweitern Sie {count} um weitere Diff-Linien",
			"diff.expandRest": "… {count} weitere Zeilen",
			"read.window": "Zeigt {shown} der {total}-Linien",
			"read.collapseAria": "Inhalt reduzieren",
			"read.expandAria": "Erweitern Sie {count} um weitere Zeilen",
			"read.expandRest": "… {count} weitere Zeilen",
			"search.paths": "{shown}-Pfade",
			"search.paths.truncated": "Zeigt {shown} von {total}-Pfaden",
			"search.matches": "{shown} entspricht · {files}-Dateien",
			"search.matches.truncated": "Zeigt {shown} von {total}-Übereinstimmungen · {files}-Dateien",
			"search.noResults": "Keine Ergebnisse",
			"search.collapseAria": "Ergebnisse reduzieren",
			"search.expandAria": "Erweitern Sie {count} um weitere Ergebniszeilen",
			"search.expandRest": "… {count} weitere Zeilen",
			"web.noResults": "Keine Ergebnisse gefunden",
			"web.sourcesTruncated": "Quellenliste gekürzt",
			"web.http": "HTTP",
			"web.contentTruncated": "Inhalt abgeschnitten",
			"details.running": "Laufen…",
			"queue.count": "{n} Nachrichten in der Warteschlange",
			"queue.sending": "Senden…",
			"queue.image": "Nachrichtenbild in der Warteschlange",
			"queue.file": "Datei in der Warteschlange {name}",
			"queue.edit": "Bearbeiten Sie die Nachricht in der Warteschlange",
			"queue.edit.unsupported": "Enthält Nicht-Textinhalte; Bearbeitung wird noch nicht unterstützt",
			"queue.save": "Speichern Sie die Nachricht in der Warteschlange",
			"queue.cancelEdit": "Bearbeitung abbrechen",
			"queue.remove": "Entfernen Sie die Nachricht in der Warteschlange",
			"queue.steer": "Mit vorgemerkter Nachricht lenken",
			"queue.steer.unavailable": "Die Steuerung ist nur verfügbar, während der Agent ausgeführt wird",
			"error.sessionInUse": "Diese Sitzung wird bereits verwendet, möglicherweise von einer anderen laufenden DSH-Instanz (z. B. dsh Web oder der Desktop-App). Beenden Sie andere laufende DSH-Instanzen und versuchen Sie es erneut.",
			"queue.editFailed": "Bearbeitung fehlgeschlagen: Der Versand dieser Nachricht wurde möglicherweise bereits gestartet.",
			"queue.removeFailed": "Fehler beim Entfernen: Der Versand dieser Nachricht wurde möglicherweise bereits gestartet.",
			"queue.steerFailed": "Lenkung versagt. Versuchen Sie es erneut.",
			"terminal.signal": "Signal {signal}",
			"terminal.exitCode": "Exit-Code {code}",
			"terminal.noExitCode": "kein Exit-Code",
			"terminal.commandLine": "Befehlszeile {n}",
			"terminal.running": "Laufen",
			"terminal.failed": "Fehlgeschlagen",
			"terminal.done": "Fertig",
			"terminal.noOutput": "Keine Ausgabe",
			"terminal.collapseAria": "Ausgabe reduzieren",
			"terminal.expandAria": "Erweitern Sie die verbleibenden {n}-Ausgabezeilen",
			"terminal.expandRest": "… {n} weitere Zeilen",
			"terminal.sendInput": "(Eingabe senden)",
			"terminal.session": "Terminal {sessionId}",
			"tool.title.viewSchedule": "Automatisierungsaufgabe anzeigen",
			"tool.title.editSchedule": "Automatisierungsaufgabe bearbeiten",
			"detail.schedule.active": "Aktiviert",
			"detail.schedule.paused": "Pausiert",
			"detail.schedule.ended": "Beendet"
		};
		/** Russian dictionary, checked against the English keys. */
		const ru = {
			"quote.remove": "Удалить цитату",
			"shortcut.newline": "Новая линия",
			"shortcut.complementary": "Использовать альтернативное действие: поставить в очередь или направить",
			"shortcut.slash": "Открыть командное меню",
			"shortcut.mention": "Открыть справочное меню",
			"hint.plan": PLAN_NEXT_ACTION_EN,
			"hint.goal": "описать цель долгосрочной задачи",
			"hint.goal.active": "цель активна — изменить/приостановить/возобновить/очистить",
			"placeholder.plan": PLAN_NEXT_ACTION_EN,
			"placeholder.default": "Отправьте сообщение или запустите задачу, /команды, @файлы или сеансы",
			"placeholder.unavailable": "Сеанс недоступен",
			"placeholder.parentOffline": "Родительская сессия в автономном режиме; отправка недоступна, но вы все равно можете остановить запуск",
			"placeholder.hero": "Опишите, что вы хотите построить: /команды, @файлы или сеансы.",
			"placeholder.workspace": "Выберите рабочее пространство для начала",
			"placeholder.steerQueue": "Cmd/Ctrl+Enter управляет всеми сообщениями в очереди.",
			"input.commands": "Добавляйте файлы или запускайте команды",
			"input.file": "Файл",
			"input.stop": "Остановить генерацию",
			"input.send": "Отправить сообщение",
			"input.sending": "Отправка сообщения",
			"input.send.queue": "Сообщение в очереди",
			"input.send.steer": "Направить сообщение",
			"attachment.pending": "Ожидающие вложения",
			"attachment.scrollLeft": "Прокрутить вложения влево",
			"attachment.scrollRight": "Прокрутить вложения вправо",
			"attachment.dropTitle": "Перетащите файлы или изображения сюда, чтобы добавить их.",
			"attachment.dropDesc": "Ограничение изображений: до изображений {count}, по {size} каждое.",
			"attachment.dropBlocked": "Файлы и изображения не могут быть добавлены прямо сейчас.",
			"attachment.directoryDesktopOnly": "Папки можно добавлять только в настольном приложении; добавлять отдельные файлы в браузере",
			"attachment.pathUnavailable": "Не удалось получить путь к папке; перетащите это снова",
			"attachment.pathUnsupported": "Путь содержит символы, которые не может содержать ссылка; переименуй его и попробуй еще раз",
			"image.pending": "Ожидающие изображения",
			"image.openOriginal": "Посмотреть оригинал",
			"image.openOriginalLabel": "{label}, нажмите, чтобы посмотреть оригинал",
			"image.remove": "Удалить изображение {name}",
			"image.original": "Исходное изображение",
			"image.label": "Изображение",
			"image.loadFailed": "Изображение не удалось загрузить; нажмите, чтобы повторить попытку",
			"image.loading": "Загрузка изображения…",
			"image.preview": "Предварительный просмотр исходного изображения",
			"image.closePreview": "Закрыть предварительный просмотр исходного изображения",
			"image.unsupportedType": "Поддерживаются только изображения PNG, JPG, WebP и GIF.",
			"image.tooMany": "Сообщение может содержать до {count} изображений.",
			"image.fileTooLarge": "Каждое изображение должно быть меньше {size}.",
			"image.totalTooLarge": "Общее количество изображений превышает {size}; удалите некоторые и попробуйте еще раз",
			"image.tooManyPixels": "Разрешение изображения слишком высокое; сожми его и попробуй еще раз",
			"image.dimensionTooLarge": "Стороны изображения должны быть не более {size}px; уменьшите масштаб и попробуйте еще раз",
			"image.modelUnsupported": "Текущая модель не поддерживает изображения; переключиться на модель, которая делает",
			"image.sendFailed": "Отправка изображений не удалась ({reason}); добавьте их повторно и попробуйте еще раз",
			"file.pending": "Ожидающие файлы",
			"file.remove": "Удалить файл {name}",
			"file.uploading": "Загрузка…",
			"file.uploadFailed": "Загрузка не удалась; нажмите, чтобы повторить попытку",
			"file.retry": "Повторите загрузку {name}.",
			"file.stillUploading": "Файлы все еще загружаются; отправить после того, как они закончат",
			"file.sessionUnavailable": "Сессия недоступна; файлы не могут быть загружены",
			"file.notStaged": "Загрузка файла не завершена; добавьте его еще раз и попробуйте еще раз",
			"file.label": "Файл",
			"context.aria": "{percent} используемого контекста",
			"context.used": "используемого контекста",
			"context.system": "Системная подсказка",
			"context.tools": "Определения инструментов",
			"context.messages": "Сообщения",
			"settings.enter.title": "Отправлять поведение во время занятости",
			"settings.enter.description": "Что делают кнопки «Ввод» и «Отправить» во время работы агента; Cmd/Ctrl+Enter использует другое поведение.",
			"settings.enter.queue": "Очередь",
			"settings.enter.steer": "Направить",
			"hero.headline": "В неизвестность",
			"hero.preview": "Предварительный просмотр",
			"hero.chooseWorkspace": "Выберите рабочее пространство",
			"session.hierarchy": "Иерархия сеансов",
			"session.moreViews": "Больше просмотров беседы",
			"todo.title": "Дела",
			"todo.progress.done": "{done} завершено",
			"todo.progress.active": "{active} в процессе",
			"todo.progress.pending": "{pending} в ожидании",
			"todo.status.completed": "Завершено",
			"todo.status.inProgress": "В процессе",
			"todo.status.pending": "Ожидается",
			"todo.rowTitle": "Обновить список дел",
			"tool.title.createGoal": "Создать цель",
			"tool.title.getGoal": "Посмотреть цель",
			"tool.title.updateGoal": "Обновить цель",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "Создать задачу автоматизации",
			"tool.title.listSchedules": "Показать задачи автоматизации",
			"tool.title.deleteSchedule": "Удалить задачу автоматизации",
			"tool.title.updateSchedule": "Обновить задачу автоматизации",
			"detail.state": "Статус",
			"detail.todo.completed": "Завершено",
			"detail.todo.in_progress": "В процессе",
			"detail.todo.pending": "Ожидается",
			"detail.todo.empty": "Список дел пуст",
			"todo.diff.initial": "Первоначальный список",
			"todo.diff.compare": "Изменения по сравнению с предыдущим списком",
			"todo.diff.unavailable": "Предыдущий список недоступен",
			"todo.diff.noChanges": "Никаких изменений в списке",
			"todo.diff.added": "{count} добавлен",
			"todo.diff.updated": "{count} обновлен",
			"todo.diff.removed": "{count} удален.",
			"todo.diff.unchanged": "{count} без изменений",
			"todo.diff.addedItem": "Добавлено",
			"todo.diff.updatedItem": "Статус изменен",
			"todo.diff.movedItem": "Переупорядочен",
			"todo.diff.removedItem": "Удален",
			"detail.goal.empty": "Нет цели",
			"detail.goal.active": "Активный",
			"detail.goal.disarmed": "Ожидание продолжения",
			"detail.goal.paused": "Приостановлено",
			"detail.goal.blocked": "Заблокировано",
			"detail.goal.complete": "Завершено",
			"detail.goal.rounds": "Раунды",
			"detail.goal.reason": "Блокатор",
			"detail.days": "{count} д",
			"detail.hours": "{count} ч",
			"detail.minutes": "{count} мин.",
			"detail.seconds": "{count} с",
			"detail.schedule.once": "Однажды",
			"detail.schedule.every": "Каждый {interval}",
			"detail.schedule.when": "Запланировано на",
			"detail.schedule.frequency": "Повторить",
			"detail.schedule.scheduled": "Запланировано",
			"detail.schedule.overdue": "Просрочено, ждём возобновления сеанса",
			"detail.schedule.empty": "Нет задач автоматизации",
			"detail.schedule.deleted": "Удалено",
			"detail.schedule.count": "{count} задачи автоматизации",
			"detail.schedule.daily": "Каждый день в {time} ({zone})",
			"detail.schedule.weekly": "Еженедельно на {days} по адресу {time} ({zone})",
			"detail.schedule.cron": "Крон {expression} ({zone})",
			"detail.schedule.custom": "Произвольно",
			"detail.weekday.1": "Пн.",
			"detail.weekday.2": "Вт",
			"detail.weekday.3": "ср.",
			"detail.weekday.4": "Чт",
			"detail.weekday.5": "Пт",
			"detail.weekday.6": "Суббота",
			"detail.weekday.7": "Солнце",
			"detail.weekday.join": ", ",
			"tool.title.inspectProviders": "Проверка поставщиков",
			"tool.title.queryRuntime": "Время выполнения запроса",
			"tool.title.inspectPlugins": "Проверьте плагины",
			"tool.title.workflow": "Запустить рабочий процесс",
			"tool.title.ralph": "Запустить цикл Ральфа",
			"tool.title.readEvent": "Чтение события",
			"tool.title.searchEvents": "Поиск событий",
			"tool.title.traceEvent": "Отследить событие",
			"tool.title.searchSessions": "Поиск сеансов",
			"tool.title.traceSession": "Трассировка сеанса",
			"tool.title.listModels": "Список моделей",
			"tool.title.subagent": "Создать субагент",
			"tool.title.listAgents": "Список субагентов",
			"tool.title.sendMessage": "Отправить сообщение",
			"tool.title.interruptAgent": "Агент прерываний",
			"tool.title.listJobs": "Список фоновых заданий",
			"tool.title.readJob": "Чтение результатов задания",
			"tool.title.killJob": "Отменить фоновое задание",
			"tool.title.openTerminal": "Открыть терминал",
			"tool.title.readTerminal": "Чтение терминала",
			"tool.title.listTerminals": "Список терминалов",
			"tool.title.signalTerminal": "Сигнальный терминал",
			"tool.title.closeTerminal": "Закрыть терминал",
			"tool.title.lsp": "Символы кода запроса",
			"tool.title.findDefinition": "Найти определение",
			"tool.title.findReferences": "Найдите ссылки",
			"tool.title.findImplementation": "Найти реализацию",
			"tool.title.hoverSymbol": "Символ проверки",
			"tool.title.spawnTeammate": "Создать товарища по команде",
			"tool.title.createTeamTask": "Создать командную задачу",
			"tool.title.getTeamTask": "Прочитать командное задание",
			"tool.title.updateTeamTask": "Обновить групповую задачу",
			"tool.title.listTeamTasks": "Перечислить командные задачи",
			"tool.title.waitAgent": "Подождите субагента",
			"detail.recordedResult": "Записанный результат",
			"detail.empty": "Нет результатов",
			"detail.none": "Нет",
			"detail.yes": "Да",
			"detail.no": "Нет",
			"detail.moreInInspect": "{count} больше элементов доступно в Inspect",
			"detail.status.running": "Бег",
			"detail.status.idle": "Простой",
			"detail.status.ready": "Готово",
			"detail.status.inactive": "Неактивный",
			"detail.status.provisioning": "обеспечение",
			"detail.status.failed": "Не удалось",
			"detail.status.completed": "Завершено",
			"detail.status.deleted": "Удалено",
			"detail.status.killed": "Отменено",
			"detail.status.accepted": "Принято",
			"detail.status.queued": "В очереди",
			"detail.status.exited": "Вышел",
			"detail.field.id": "ID",
			"detail.field.revision": "Редакция",
			"detail.field.platform": "Платформа",
			"detail.field.provider": "Поставщик",
			"detail.field.model": "Модель",
			"detail.field.role": "Роль",
			"detail.field.context": "Контекст",
			"detail.field.owner": "Владелец",
			"detail.field.ready": "Готово",
			"detail.field.dependencies": "Зависимости",
			"detail.field.writeScopes": "Запись областей",
			"detail.field.warnings": "Предупреждения",
			"detail.field.diagnostics": "Диагностика",
			"detail.field.methods": "Методы",
			"detail.field.inputSchema": "Входная схема",
			"detail.field.outputSchema": "Выходная схема",
			"detail.field.currentPackage": "Текущий пакет",
			"detail.field.nextPackage": "Следующий пакет",
			"detail.field.latestRun": "Последний запуск",
			"detail.field.packages": "Пакеты",
			"detail.field.registrations": "Регистрации",
			"detail.field.props": "Реквизит",
			"detail.field.data": "Данные",
			"detail.field.source": "Источник",
			"detail.field.content": "Содержание",
			"detail.field.message": "Сообщение",
			"detail.field.messageId": "Идентификатор сообщения",
			"detail.field.root": "Корень",
			"detail.field.pid": "Идентификатор процесса",
			"detail.field.type": "Тип",
			"detail.field.time": "Время",
			"detail.field.seq": "Последовательность событий",
			"detail.field.turn": "Ход",
			"detail.field.step": "Шаг",
			"detail.field.callId": "Идентификатор вызова",
			"detail.field.agents": "Агенты запущены",
			"detail.field.result": "Результат",
			"detail.field.parent": "Родитель",
			"detail.field.depth": "Глубина",
			"detail.field.exitCode": "Код выхода",
			"detail.field.signal": "Сигнал",
			"detail.field.previousStatus": "Предыдущий статус",
			"detail.field.agent": "Идентификатор агента",
			"detail.field.job": "Идентификатор вакансии",
			"detail.field.task": "Задача",
			"detail.field.processGroup": "Группа процессов",
			"detail.field.availability": "Доступность",
			"detail.field.bestMatch": "Лучший матч",
			"detail.field.target": "Целевое событие",
			"detail.field.surface": "Статус записи",
			"detail.agents.count": "{count} агенты",
			"detail.jobs.count": "{count} фоновые задания",
			"detail.terminals.count": "Клеммы {count}",
			"detail.tasks.count": "{count} командные задачи",
			"detail.tasks.nextPage": "Доступно больше задач; следующий курсор — {cursor}",
			"detail.locations.count": "{count} локации",
			"detail.location": "Строка {line}, столбец {column}",
			"detail.receipt.delivered": "Сообщение доставлено",
			"detail.receipt.interrupt": "Запрошено прерывание",
			"detail.receipt.started": "Началось",
			"detail.receipt.cancel": "Запрос на отмену",
			"detail.receipt.alreadyFinished": "Уже закончено",
			"detail.receipt.signal": "Сигнал доставлен",
			"detail.receipt.closed": "Закрыто",
			"detail.receipt.closing": "Закрытие",
			"detail.wait.noProgress": "Нет активных субагентов",
			"detail.wait.title": "Субагентская деятельность",
			"detail.wait.timeout": "Время ожидания истекло",
			"detail.wait.changed": "Обнаружено изменение",
			"detail.agent.reply": "Ответ агента",
			"detail.models.title": "Доступные модели",
			"detail.output.lines": "Линии {begin} – {end} из {total}",
			"detail.output.truncated": "Вывод усечен",
			"detail.providers.count": "{count} проверяет поставщиков",
			"detail.plugins.count": "Динамические плагины {count}",
			"detail.workflow.script": "Сценарий рабочего процесса",
			"detail.ralph.reportedComplete": "Работник сообщил о завершении",
			"detail.ralph.reportedBlocker": "Работник сообщил о блокировщике",
			"detail.ralph.limit": "Достигнут лимит раундов",
			"detail.report.nextSteps": "Оставшаяся работа",
			"detail.trace.replacedBy": "Заменено на",
			"detail.trace.replacementChain": "Замена цепи",
			"detail.trace.replaces": "Замененные события",
			"detail.trace.sources": "Исходные события",
			"detail.trace.derived": "Производные события",
			"detail.trace.ancestors": "Сеансы предков",
			"detail.trace.descendants": "Потомки сеансов",
			"detail.matches.count": "{count} совпадений",
			"detail.matches.capped": "Достигнут предел результатов; сузить поиск для большего",
			"detail.event.neighbors": "Сопутствующие события",
			"todo.completed": "{done}/{total} завершено",
			"command.attachmentsUnsupported": "/{command} не принимает вложения; сначала удали их",
			"ask.rowTitle": "Задать вопрос",
			"ask.waiting": "ожидание",
			"ask.pending": "продолжение; ответ еще доступен",
			"ask.pendingDetail": "На эти нерешенные вопросы остается ответ композитора.",
			"ask.reopen": "Ответ",
			"ask.review": "Посмотреть ответы",
			"ask.closed": "закрыто",
			"ask.closedDetail": "Этот вопрос закрыт; его результат в разговоре ниже.",
			"ask.cancelled": "отменен",
			"ask.cancelledDetail": "Этот набор вопросов был отменен до того, как были отправлены ответы.",
			"ask.interrupted": "прерванный",
			"ask.interruptedDetail": "Этот набор вопросов был прерван до того, как были представлены ответы.",
			"ask.answered": "{answered}/{total} ответил",
			"ask.skipped": "Не ответил",
			"bash.running": "Бег",
			"bash.failed": "Не удалось",
			"bash.stopped": "Остановлено",
			"row.running": "Бег",
			"row.preparing": "Подготовка вызова инструмента",
			"row.failed": "Не удалось",
			"row.stopped": "Остановлено",
			"row.commandArguments": "Аргументы команды",
			"row.input": "IN",
			"row.output": "OUT",
			"row.inspect": "Осмотреть",
			"row.imageSize": "{width}x{height}px, {bytes} байт",
			"row.imageSizeDownscaled": "{width}x{height}px (уменьшено с {originalWidth}x{originalHeight}px), {bytes} байт",
			"tool.title.search": "Поиск",
			"tool.title.read": "Читать",
			"tool.title.bash": "Баш",
			"tool.title.write": "Написать",
			"tool.title.edit": "Редактировать",
			"tool.title.applyPatch": "Применить патч",
			"tool.title.code": "Код",
			"tool.title.generic": "Вызов инструмента",
			"tool.title.inspect": "Запрос среды Cordis",
			"tool.title.runCordis": "Запустите плагин Cordis",
			"tool.title.stopCordis": "Остановить плагин Cordis",
			"tool.title.removeCordis": "Удалить плагин Cordis",
			"tool.title.pwsh": "Пшш",
			"tool.title.readImage": "Читать изображение",
			"tool.title.grep": "Греп",
			"tool.title.glob": "Глоб",
			"tool.title.webSearch": "Поиск",
			"tool.title.webFetch": "Получить",
			"tool.autoReviewRejected": "Отклонено Auto review",
			"tool.autoReviewNotExecuted": "Инструмент не был выполнен. Причина: {reason}",
			"tool.autoReviewReasonFallback": "Auto review не санкционировал это действие",
			"diff.collapseAria": "Свернуть разницу",
			"diff.expandAria": "Разверните {count} больше строк различий",
			"diff.expandRest": "… {count} еще строки",
			"read.window": "Показаны линии {shown} {total}.",
			"read.collapseAria": "Свернуть содержимое",
			"read.expandAria": "Разверните {count} еще строки",
			"read.expandRest": "… {count} еще строки",
			"search.paths": "{shown} пути",
			"search.paths.truncated": "Отображение путей {shown} из {total}",
			"search.matches": "{shown} соответствует · файлам {files}",
			"search.matches.truncated": "Отображение {shown} совпадений {total} · Файлы {files}",
			"search.noResults": "Нет результатов",
			"search.collapseAria": "Свернуть результаты",
			"search.expandAria": "Разверните {count} больше строк результатов",
			"search.expandRest": "… {count} еще строки",
			"web.noResults": "Результаты не найдены",
			"web.sourcesTruncated": "Список источников сокращен",
			"web.http": "HTTP",
			"web.contentTruncated": "Содержание усечено",
			"details.running": "Бег…",
			"queue.count": "Сообщения в очереди {n}",
			"queue.sending": "Отправка…",
			"queue.image": "Изображение сообщения в очереди",
			"queue.file": "Файл в очереди {name}",
			"queue.edit": "Изменить сообщение в очереди",
			"queue.edit.unsupported": "Содержит нетекстовый контент; редактирование пока не поддерживается",
			"queue.save": "Сохранить сообщение в очереди",
			"queue.cancelEdit": "Отменить редактирование",
			"queue.remove": "Удалить сообщение из очереди",
			"queue.steer": "Направить сообщение из очереди",
			"queue.steer.unavailable": "Управление доступно только во время работы агента.",
			"error.sessionInUse": "Этот сеанс уже используется, возможно, другим работающим экземпляром DSH (например, веб-сайтом dsh или настольным приложением). Закройте другие работающие экземпляры DSH и повторите попытку.",
			"queue.editFailed": "Не удалось изменить: возможно, это сообщение уже начало отправляться.",
			"queue.removeFailed": "Удаление не удалось: возможно, это сообщение уже начало отправляться.",
			"queue.steerFailed": "Рулевое управление не удалось. Попробуйте еще раз.",
			"terminal.signal": "сигнал {signal}",
			"terminal.exitCode": "код выхода {code}",
			"terminal.noExitCode": "нет кода выхода",
			"terminal.commandLine": "Командная строка {n}",
			"terminal.running": "Бег",
			"terminal.failed": "Не удалось",
			"terminal.done": "Готово",
			"terminal.noOutput": "Нет вывода",
			"terminal.collapseAria": "Свернуть вывод",
			"terminal.expandAria": "Разверните оставшиеся выходные строки {n}.",
			"terminal.expandRest": "… {n} еще строки",
			"terminal.sendInput": "(отправить ввод)",
			"terminal.session": "Терминал {sessionId}",
			"tool.title.viewSchedule": "Посмотреть задачу автоматизации",
			"tool.title.editSchedule": "Изменить задачу автоматизации",
			"detail.schedule.active": "Включено",
			"detail.schedule.paused": "Приостановлена",
			"detail.schedule.ended": "Завершена"
		};
		/** Portuguese dictionary, checked against the English keys. */
		const pt = {
			"quote.remove": "Remover cotação",
			"shortcut.newline": "Nova linha",
			"shortcut.complementary": "Usar a ação alternativa de enfileirar ou orientar",
			"shortcut.slash": "Abrir menu de comando",
			"shortcut.mention": "Abrir menu de referência",
			"hint.plan": PLAN_NEXT_ACTION_EN,
			"hint.goal": "descrever o objetivo de uma tarefa de longa duração",
			"hint.goal.active": "meta ativa — editar/pausar/resumir/limpar",
			"placeholder.plan": PLAN_NEXT_ACTION_EN,
			"placeholder.default": "Envie mensagens ou execute uma tarefa, / comandos, @ arquivos ou sessões",
			"placeholder.unavailable": "Sessão indisponível",
			"placeholder.parentOffline": "Sessão pai offline; o envio não está disponível, mas você ainda pode interromper a execução",
			"placeholder.hero": "Descreva o que você deseja construir, / comandos, @ arquivos ou sessões",
			"placeholder.workspace": "Escolha um espaço de trabalho para começar",
			"placeholder.steerQueue": "Cmd/Ctrl+Enter direciona todas as mensagens na fila",
			"input.commands": "Adicione arquivos ou execute comandos",
			"input.file": "Arquivo",
			"input.stop": "Parar geração",
			"input.send": "Enviar mensagem",
			"input.sending": "Enviando mensagem",
			"input.send.queue": "Mensagem de fila",
			"input.send.steer": "Orientar com mensagem",
			"attachment.pending": "Anexos pendentes",
			"attachment.scrollLeft": "Rolar anexos para a esquerda",
			"attachment.scrollRight": "Rolar os anexos para a direita",
			"attachment.dropTitle": "Arraste arquivos ou imagens aqui para adicioná-los",
			"attachment.dropDesc": "Limite de imagens: até {count} imagens, {size} cada",
			"attachment.dropBlocked": "Arquivos e imagens não podem ser adicionados no momento",
			"attachment.directoryDesktopOnly": "As pastas só podem ser adicionadas no aplicativo de desktop; adicione arquivos individuais no navegador",
			"attachment.pathUnavailable": "Não foi possível obter o caminho da pasta; arraste-o novamente",
			"attachment.pathUnsupported": "O caminho contém caracteres que uma referência não pode transportar; renomeie-o e tente novamente",
			"image.pending": "Imagens pendentes",
			"image.openOriginal": "Ver original",
			"image.openOriginalLabel": "{label}, clique para ver o original",
			"image.remove": "Remover imagem {name}",
			"image.original": "Imagem original",
			"image.label": "Imagem",
			"image.loadFailed": "A imagem não foi carregada; clique para tentar novamente",
			"image.loading": "Carregando imagem…",
			"image.preview": "Visualização da imagem original",
			"image.closePreview": "Fechar visualização da imagem original",
			"image.unsupportedType": "Somente imagens PNG, JPG, WebP e GIF são suportadas",
			"image.tooMany": "Uma mensagem pode incluir até {count} imagens",
			"image.fileTooLarge": "Cada imagem deve ser menor que {size}",
			"image.totalTooLarge": "As imagens excedem {size} no total; remova alguns e tente novamente",
			"image.tooManyPixels": "A resolução da imagem é muito alta; comprima e tente novamente",
			"image.dimensionTooLarge": "Os lados da imagem devem ter no máximo {size}px; diminua a escala e tente novamente",
			"image.modelUnsupported": "O modelo atual não suporta imagens; mude para um modelo que faça",
			"image.sendFailed": "Falha no envio de imagens ({reason}); adicione-os novamente e tente novamente",
			"file.pending": "Arquivos pendentes",
			"file.remove": "Remover arquivo {name}",
			"file.uploading": "Fazendo upload…",
			"file.uploadFailed": "Falha no upload; clique para tentar novamente",
			"file.retry": "Tente fazer upload novamente {name}",
			"file.stillUploading": "Os arquivos ainda estão sendo carregados; enviar depois que terminarem",
			"file.sessionUnavailable": "Sessão indisponível; os arquivos não podem ser carregados",
			"file.notStaged": "O upload do arquivo não foi concluído; adicione novamente e tente novamente",
			"file.label": "Arquivo",
			"context.aria": "{percent} de contexto usado",
			"context.used": "do contexto usado",
			"context.system": "Alerta do sistema",
			"context.tools": "Definições de ferramentas",
			"context.messages": "Mensagens",
			"settings.enter.title": "Enviar comportamento enquanto estiver ocupado",
			"settings.enter.description": "O que o botão Enter e o botão Enviar fazem enquanto o agente está em execução; Cmd/Ctrl+Enter usa o outro comportamento",
			"settings.enter.queue": "Fila",
			"settings.enter.steer": "Orientar",
			"hero.headline": "Para o desconhecido",
			"hero.preview": "Visualização",
			"hero.chooseWorkspace": "Escolha o espaço de trabalho",
			"session.hierarchy": "Hierarquia de sessão",
			"session.moreViews": "Mais visualizações de conversas",
			"todo.title": "Tarefas",
			"todo.progress.done": "{done} concluído",
			"todo.progress.active": "{active} em andamento",
			"todo.progress.pending": "{pending} pendente",
			"todo.status.completed": "Concluído",
			"todo.status.inProgress": "Em andamento",
			"todo.status.pending": "Pendente",
			"todo.rowTitle": "Atualizar lista de tarefas",
			"tool.title.createGoal": "Criar meta",
			"tool.title.getGoal": "Ver meta",
			"tool.title.updateGoal": "Atualizar meta",
			"tool.preparing.content": "{kilobytes}KB",
			"tool.title.createSchedule": "Criar tarefa de automação",
			"tool.title.listSchedules": "Listar tarefas de automação",
			"tool.title.deleteSchedule": "Excluir tarefa de automação",
			"tool.title.updateSchedule": "Atualizar tarefa de automação",
			"detail.state": "Estado",
			"detail.todo.completed": "Concluído",
			"detail.todo.in_progress": "Em andamento",
			"detail.todo.pending": "Pendente",
			"detail.todo.empty": "A lista de tarefas está vazia",
			"todo.diff.initial": "Lista inicial",
			"todo.diff.compare": "Mudanças desde a lista anterior",
			"todo.diff.unavailable": "Lista anterior indisponível",
			"todo.diff.noChanges": "Sem alterações na lista",
			"todo.diff.added": "{count} adicionado",
			"todo.diff.updated": "{count} atualizado",
			"todo.diff.removed": "{count} removido",
			"todo.diff.unchanged": "{count} inalterado",
			"todo.diff.addedItem": "Adicionado",
			"todo.diff.updatedItem": "Status alterado",
			"todo.diff.movedItem": "Reordenado",
			"todo.diff.removedItem": "Removido",
			"detail.goal.empty": "Sem objetivo",
			"detail.goal.active": "Ativo",
			"detail.goal.disarmed": "Aguardando continuação",
			"detail.goal.paused": "Pausado",
			"detail.goal.blocked": "Bloqueado",
			"detail.goal.complete": "Concluído",
			"detail.goal.rounds": "Rodadas",
			"detail.goal.reason": "Bloqueador",
			"detail.days": "{count}d",
			"detail.hours": "{count}h",
			"detail.minutes": "{count} min",
			"detail.seconds": "{count} segundos",
			"detail.schedule.once": "Uma vez",
			"detail.schedule.every": "A cada {interval}",
			"detail.schedule.when": "Agendado para",
			"detail.schedule.frequency": "Repetir",
			"detail.schedule.scheduled": "Agendado",
			"detail.schedule.overdue": "Atrasado, aguardando retomada da sessão",
			"detail.schedule.empty": "Sem tarefas de automação",
			"detail.schedule.deleted": "Excluído",
			"detail.schedule.count": "{count} tarefas de automação",
			"detail.schedule.daily": "Todos os dias às {time} ({zone})",
			"detail.schedule.weekly": "Semanalmente em {days} às {time} ({zone})",
			"detail.schedule.cron": "Cron {expression} ({zone})",
			"detail.schedule.custom": "Personalizado",
			"detail.weekday.1": "segunda-feira",
			"detail.weekday.2": "Terça",
			"detail.weekday.3": "Quarta",
			"detail.weekday.4": "Qui",
			"detail.weekday.5": "Sexta-feira",
			"detail.weekday.6": "Sábado",
			"detail.weekday.7": "Sol",
			"detail.weekday.join": ", ",
			"tool.title.inspectProviders": "Inspecionar fornecedores",
			"tool.title.queryRuntime": "Tempo de execução da consulta",
			"tool.title.inspectPlugins": "Inspecionar plug-ins",
			"tool.title.workflow": "Executar fluxo de trabalho",
			"tool.title.ralph": "Execute o circuito Ralph",
			"tool.title.readEvent": "Ler evento",
			"tool.title.searchEvents": "Pesquisar eventos",
			"tool.title.traceEvent": "Evento de rastreamento",
			"tool.title.searchSessions": "Buscar sessões",
			"tool.title.traceSession": "Sessão de rastreamento",
			"tool.title.listModels": "Listar modelos",
			"tool.title.subagent": "Criar subagente",
			"tool.title.listAgents": "Listar subagentes",
			"tool.title.sendMessage": "Enviar mensagem",
			"tool.title.interruptAgent": "Agente de interrupção",
			"tool.title.listJobs": "Listar trabalhos em segundo plano",
			"tool.title.readJob": "Ler saída do trabalho",
			"tool.title.killJob": "Cancelar trabalho em segundo plano",
			"tool.title.openTerminal": "Terminal aberto",
			"tool.title.readTerminal": "Ler terminal",
			"tool.title.listTerminals": "Listar terminais",
			"tool.title.signalTerminal": "Terminal de sinal",
			"tool.title.closeTerminal": "Fechar terminal",
			"tool.title.lsp": "Símbolos de código de consulta",
			"tool.title.findDefinition": "Encontre a definição",
			"tool.title.findReferences": "Encontre referências",
			"tool.title.findImplementation": "Encontre implementação",
			"tool.title.hoverSymbol": "Símbolo de inspeção",
			"tool.title.spawnTeammate": "Criar companheiro de equipe",
			"tool.title.createTeamTask": "Criar tarefa de equipe",
			"tool.title.getTeamTask": "Ler tarefa da equipe",
			"tool.title.updateTeamTask": "Atualizar tarefa da equipe",
			"tool.title.listTeamTasks": "Listar tarefas da equipe",
			"tool.title.waitAgent": "Aguarde o subagente",
			"detail.recordedResult": "Resultado registrado",
			"detail.empty": "Nenhum resultado",
			"detail.none": "Nenhum",
			"detail.yes": "Sim",
			"detail.no": "Não",
			"detail.moreInInspect": "Mais {count} itens disponíveis no Inspecionar",
			"detail.status.running": "Correndo",
			"detail.status.idle": "Inativo",
			"detail.status.ready": "Pronto",
			"detail.status.inactive": "Inativo",
			"detail.status.provisioning": "Provisionamento",
			"detail.status.failed": "Falha",
			"detail.status.completed": "Concluído",
			"detail.status.deleted": "Excluído",
			"detail.status.killed": "Cancelado",
			"detail.status.accepted": "Aceito",
			"detail.status.queued": "Na fila",
			"detail.status.exited": "Saiu",
			"detail.field.id": "ID",
			"detail.field.revision": "Revisão",
			"detail.field.platform": "Plataforma",
			"detail.field.provider": "Provedor",
			"detail.field.model": "Modelo",
			"detail.field.role": "Função",
			"detail.field.context": "Contexto",
			"detail.field.owner": "Proprietário",
			"detail.field.ready": "Pronto",
			"detail.field.dependencies": "Dependências",
			"detail.field.writeScopes": "Escrever escopos",
			"detail.field.warnings": "Avisos",
			"detail.field.diagnostics": "Diagnóstico",
			"detail.field.methods": "Métodos",
			"detail.field.inputSchema": "Esquema de entrada",
			"detail.field.outputSchema": "Esquema de saída",
			"detail.field.currentPackage": "Pacote atual",
			"detail.field.nextPackage": "Próximo pacote",
			"detail.field.latestRun": "Última execução",
			"detail.field.packages": "Pacotes",
			"detail.field.registrations": "Inscrições",
			"detail.field.props": "Adereços",
			"detail.field.data": "Dados",
			"detail.field.source": "Fonte",
			"detail.field.content": "Conteúdo",
			"detail.field.message": "Mensagem",
			"detail.field.messageId": "ID da mensagem",
			"detail.field.root": "Raiz",
			"detail.field.pid": "ID do processo",
			"detail.field.type": "Tipo",
			"detail.field.time": "Hora",
			"detail.field.seq": "Sequência de eventos",
			"detail.field.turn": "Turno",
			"detail.field.step": "Passo",
			"detail.field.callId": "ID de chamada",
			"detail.field.agents": "Agentes iniciados",
			"detail.field.result": "Resultado",
			"detail.field.parent": "Pai",
			"detail.field.depth": "Profundidade",
			"detail.field.exitCode": "Código de saída",
			"detail.field.signal": "Sinal",
			"detail.field.previousStatus": "Estado anterior",
			"detail.field.agent": "ID do agente",
			"detail.field.job": "ID do trabalho",
			"detail.field.task": "Tarefa",
			"detail.field.processGroup": "Grupo de processos",
			"detail.field.availability": "Disponibilidade",
			"detail.field.bestMatch": "Melhor correspondência",
			"detail.field.target": "Evento alvo",
			"detail.field.surface": "Status do registro",
			"detail.agents.count": "{count} agentes",
			"detail.jobs.count": "{count} trabalhos em segundo plano",
			"detail.terminals.count": "{count} terminais",
			"detail.tasks.count": "{count} tarefas de equipe",
			"detail.tasks.nextPage": "Mais tarefas disponíveis; o próximo cursor é {cursor}",
			"detail.locations.count": "{count} locais",
			"detail.location": "Linha {line}, coluna {column}",
			"detail.receipt.delivered": "Mensagem entregue",
			"detail.receipt.interrupt": "Interrupção solicitada",
			"detail.receipt.started": "Iniciado",
			"detail.receipt.cancel": "Cancelamento solicitado",
			"detail.receipt.alreadyFinished": "Já terminei",
			"detail.receipt.signal": "Sinal entregue",
			"detail.receipt.closed": "Fechado",
			"detail.receipt.closing": "Fechando",
			"detail.wait.noProgress": "Nenhum subagente ativo",
			"detail.wait.title": "Atividade do subagente",
			"detail.wait.timeout": "A espera expirou",
			"detail.wait.changed": "Alteração detectada",
			"detail.agent.reply": "Resposta do agente",
			"detail.models.title": "Modelos disponíveis",
			"detail.output.lines": "Linhas {begin}–{end} de {total}",
			"detail.output.truncated": "Saída truncada",
			"detail.providers.count": "{count} inspecionar provedores",
			"detail.plugins.count": "{count} plug-ins dinâmicos",
			"detail.workflow.script": "Roteiro de fluxo de trabalho",
			"detail.ralph.reportedComplete": "Conclusão relatada pelo trabalhador",
			"detail.ralph.reportedBlocker": "Trabalhador relatou um bloqueador",
			"detail.ralph.limit": "Limite de rodadas atingido",
			"detail.report.nextSteps": "Trabalho restante",
			"detail.trace.replacedBy": "Substituído por",
			"detail.trace.replacementChain": "Cadeia de substituição",
			"detail.trace.replaces": "Eventos substituídos",
			"detail.trace.sources": "Eventos de origem",
			"detail.trace.derived": "Eventos derivados",
			"detail.trace.ancestors": "Sessões ancestrais",
			"detail.trace.descendants": "Sessões de descendentes",
			"detail.matches.count": "{count} correspondências",
			"detail.matches.capped": "Limite de resultados atingido; restringir a busca por mais",
			"detail.event.neighbors": "Eventos circundantes",
			"todo.completed": "{done}/{total} concluído",
			"command.attachmentsUnsupported": "/{command} não aceita anexos; remova-os primeiro",
			"ask.rowTitle": "Faça uma pergunta",
			"ask.waiting": "esperando",
			"ask.pending": "continuou; resposta ainda disponível",
			"ask.pendingDetail": "Essas questões pendentes permanecem respondidas pelo compositor.",
			"ask.reopen": "Resposta",
			"ask.review": "Ver respostas",
			"ask.closed": "fechado",
			"ask.closedDetail": "Esta questão está encerrada; seu resultado está na conversa abaixo.",
			"ask.cancelled": "cancelado",
			"ask.cancelledDetail": "Este conjunto de perguntas foi cancelado antes do envio das respostas.",
			"ask.interrupted": "interrompido",
			"ask.interruptedDetail": "Este conjunto de perguntas foi interrompido antes do envio das respostas.",
			"ask.answered": "{answered}/{total} respondeu",
			"ask.skipped": "Não respondido",
			"bash.running": "Correndo",
			"bash.failed": "Falha",
			"bash.stopped": "Parado",
			"row.running": "Correndo",
			"row.preparing": "Preparando chamada de ferramenta",
			"row.failed": "Falha",
			"row.stopped": "Parado",
			"row.commandArguments": "Argumentos de comando",
			"row.input": "IN",
			"row.output": "OUT",
			"row.inspect": "Inspecionar",
			"row.imageSize": "{width}x{height}px, {bytes} bytes",
			"row.imageSizeDownscaled": "{width}x{height}px (reduzido de {originalWidth}x{originalHeight}px), {bytes} bytes",
			"tool.title.search": "Pesquisar",
			"tool.title.read": "Leia",
			"tool.title.bash": "Bash",
			"tool.title.write": "Escreva",
			"tool.title.edit": "Editar",
			"tool.title.applyPatch": "Aplicar patch",
			"tool.title.code": "Código",
			"tool.title.generic": "Chamada de ferramenta",
			"tool.title.inspect": "Consultar ambiente Cordis",
			"tool.title.runCordis": "Execute o plug-in Cordis",
			"tool.title.stopCordis": "Parar o plug-in Cordis",
			"tool.title.removeCordis": "Remover plug-in Cordis",
			"tool.title.pwsh": "Pwsh",
			"tool.title.readImage": "Ler imagem",
			"tool.title.grep": "Grep",
			"tool.title.glob": "globo",
			"tool.title.webSearch": "Pesquisar",
			"tool.title.webFetch": "Buscar",
			"tool.autoReviewRejected": "Rejeitado por Auto review",
			"tool.autoReviewNotExecuted": "A ferramenta não foi executada. Motivo: {reason}",
			"tool.autoReviewReasonFallback": "Auto review não autorizou esta ação",
			"diff.collapseAria": "Recolher diferença",
			"diff.expandAria": "Expanda mais {count} linhas de diferenças",
			"diff.expandRest": "… mais {count} linhas",
			"read.window": "Mostrando {shown} de {total} linhas",
			"read.collapseAria": "Recolher conteúdo",
			"read.expandAria": "Expanda mais {count} linhas",
			"read.expandRest": "… mais {count} linhas",
			"search.paths": "{shown} caminhos",
			"search.paths.truncated": "Mostrando {shown} de {total} caminhos",
			"search.matches": "{shown} correspondências · {files} arquivos",
			"search.matches.truncated": "Mostrando {shown} de {total} correspondências · {files} arquivos",
			"search.noResults": "Nenhum resultado",
			"search.collapseAria": "Recolher resultados",
			"search.expandAria": "Expanda mais {count} linhas de resultados",
			"search.expandRest": "… mais {count} linhas",
			"web.noResults": "Nenhum resultado encontrado",
			"web.sourcesTruncated": "Lista de fontes truncada",
			"web.http": "HTTP",
			"web.contentTruncated": "Conteúdo truncado",
			"details.running": "Correndo…",
			"queue.count": "{n} mensagens na fila",
			"queue.sending": "Enviando…",
			"queue.image": "Imagem de mensagem na fila",
			"queue.file": "Arquivo na fila {name}",
			"queue.edit": "Editar mensagem na fila",
			"queue.edit.unsupported": "Contém conteúdo não textual; a edição ainda não é suportada",
			"queue.save": "Salvar mensagem na fila",
			"queue.cancelEdit": "Cancelar edição",
			"queue.remove": "Remover mensagem na fila",
			"queue.steer": "Orientar com mensagem da fila",
			"queue.steer.unavailable": "A direção está disponível apenas enquanto o agente está em execução",
			"error.sessionInUse": "Esta sessão já está em uso, possivelmente por outra instância DSH em execução (como dsh web ou aplicativo de desktop). Saia de outras instâncias DSH em execução e tente novamente.",
			"queue.editFailed": "Falha na edição: esta mensagem pode já ter começado a ser enviada.",
			"queue.removeFailed": "Falha na remoção: esta mensagem pode já ter começado a ser enviada.",
			"queue.steerFailed": "A direção falhou. Tente novamente.",
			"terminal.signal": "sinal {signal}",
			"terminal.exitCode": "código de saída {code}",
			"terminal.noExitCode": "sem código de saída",
			"terminal.commandLine": "Linha de comando {n}",
			"terminal.running": "Correndo",
			"terminal.failed": "Falha",
			"terminal.done": "Concluído",
			"terminal.noOutput": "Sem saída",
			"terminal.collapseAria": "Recolher saída",
			"terminal.expandAria": "Expanda as {n} linhas de saída restantes",
			"terminal.expandRest": "… mais {n} linhas",
			"terminal.sendInput": "(enviar entrada)",
			"terminal.session": "Terminal {sessionId}",
			"tool.title.viewSchedule": "Ver tarefa de automação",
			"tool.title.editSchedule": "Editar tarefa de automação",
			"detail.schedule.active": "Habilitado",
			"detail.schedule.paused": "Pausada",
			"detail.schedule.ended": "Concluída"
		};
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/queue/QueueDock.module.css.mjs
		const css$6 = "._7yHdaG_dock{box-sizing:border-box;width:calc(100% - var(--dsh-composer-side-clearance) - var(--dsh-composer-side-clearance) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));max-width:calc(var(--dsh-composer-card-max-width) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));margin:0 auto calc(0px - var(--dsh-composer-stack-gap) - 3px);padding:0 var(--dsh-composer-dock-inset);flex:none}._7yHdaG_panel{isolation:isolate;border-radius:var(--dsw-radius-lg) var(--dsw-radius-lg) 0 0;--dsh-scrollbar-thumb:var(--dsw-alias-scrollbar-bg-l2);--dsh-scrollbar-thumb-hover:var(--dsw-alias-scrollbar-hover-l2);width:100%;padding:2px 0;position:relative;overflow:hidden}._7yHdaG_panel:before{z-index:-1;border-radius:inherit;background:var(--dsw-specific-menu);backdrop-filter:var(--dsw-menu-backdrop-filter);content:\"\";pointer-events:none;position:absolute;inset:0}._7yHdaG_panel:after{border:.5px solid var(--dsw-alias-border-l1);border-radius:inherit;content:\"\";pointer-events:none;border-bottom:none;position:absolute;inset:0}._7yHdaG_header{box-sizing:border-box;border-radius:var(--dsw-radius-md);width:100%;height:36px;color:var(--dsw-alias-label-primary);text-align:left;cursor:pointer;background:0 0;border:none;align-items:center;gap:10px;padding:4px 12px;display:flex}._7yHdaG_header:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}._7yHdaG_header:disabled{cursor:default}._7yHdaG_lead{color:var(--dsw-alias-label-tertiary);flex:none;place-items:center;display:grid}._7yHdaG_count{min-width:0;font-family:Inter, var(--dsw-font-family);flex:auto;font-size:13px;font-weight:500;line-height:24px}._7yHdaG_chevron{width:14px;height:14px;color:var(--dsw-alias-label-tertiary);flex:none;place-items:center;display:grid}._7yHdaG_list{max-height:180px;margin:0;padding:0;list-style:none;overflow-y:auto}._7yHdaG_row{box-sizing:border-box;border-radius:var(--dsw-radius-md);align-items:center;gap:10px;width:100%;min-height:36px;padding:4px 5px 4px 12px;display:flex}._7yHdaG_row+._7yHdaG_row{box-shadow:inset 0 1px 0 var(--dsw-alias-border-l1)}._7yHdaG_attachments{flex:none;gap:4px;min-width:0;max-width:55%;display:flex;overflow:hidden}._7yHdaG_pendingRow ._7yHdaG_attachments{flex-shrink:1}._7yHdaG_file{border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-bg-base);box-sizing:border-box;flex:0 180px;align-items:center;gap:4px;min-width:74px;height:24px;padding:0 6px;display:inline-flex;overflow:hidden}._7yHdaG_fileIcon{flex:none;width:16px;height:16px;display:inline-flex}._7yHdaG_fileName{min-width:0;color:var(--dsw-alias-label-primary-dimmed);font:var(--dsw-font-xs-13);text-overflow:ellipsis;white-space:nowrap;overflow:hidden}._7yHdaG_fileSize{color:var(--dsw-alias-label-tertiary);white-space:nowrap;flex:none;font-size:10px}._7yHdaG_thumb{border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-xs);background:var(--dsw-alias-bg-base);object-fit:cover;width:24px;height:24px}._7yHdaG_preview{min-width:0;font:var(--dsw-font-xs-13);font-family:Inter, var(--dsw-font-family);color:var(--dsw-alias-label-primary-dimmed);flex:auto}._7yHdaG_actions{flex:none;align-items:center;gap:10px;display:flex}._7yHdaG_status{color:var(--dsw-alias-label-tertiary);font:var(--dsw-font-xs-13);white-space:nowrap;flex:none}._7yHdaG_action{corner-shape:round;width:28px;height:28px;color:var(--dsw-alias-label-tertiary);cursor:pointer;background:0 0;border:none;border-radius:999px;flex:none;place-items:center;padding:0;display:grid}@media (hover:hover){._7yHdaG_action:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}}._7yHdaG_action:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}._7yHdaG_action:disabled{cursor:default;opacity:.45}";
		const tagId$6 = "@deepseek-ai/dsh-client-ui-conversation/QueueDock.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$6) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$6;
			tag.textContent = css$6;
			document.head.appendChild(tag);
		}
		var QueueDock_module_css_default = {
			"action": "_7yHdaG_action",
			"actions": "_7yHdaG_actions",
			"attachments": "_7yHdaG_attachments",
			"chevron": "_7yHdaG_chevron",
			"count": "_7yHdaG_count",
			"dock": "_7yHdaG_dock",
			"file": "_7yHdaG_file",
			"fileIcon": "_7yHdaG_fileIcon",
			"fileName": "_7yHdaG_fileName",
			"fileSize": "_7yHdaG_fileSize",
			"header": "_7yHdaG_header",
			"lead": "_7yHdaG_lead",
			"list": "_7yHdaG_list",
			"panel": "_7yHdaG_panel",
			"pendingRow": "_7yHdaG_pendingRow",
			"preview": "_7yHdaG_preview",
			"row": "_7yHdaG_row",
			"status": "_7yHdaG_status",
			"thumb": "_7yHdaG_thumb"
		};
		//#endregion
		//#region lib/types/client/queue/QueueDock.js
		const EMPTY_QUEUE = [];
		const QUEUE_TEXT_FACTS = {
			collapseWhitespace: true,
			trimWhitespace: true
		};
		function textOf(content) {
			if (!content.every((block) => block.type === "text")) return null;
			return content.map((block) => block.text).join("");
		}
		/**
		* Durable references carried by one queued row. Inbox projections are wire data
		* despite their typed face, so an image block without a reference is skipped
		* rather than trusted.
		* @param content - the row's wire content blocks.
		* @returns the row's durable image references in block order.
		*/
		function queueAttachments(content) {
			const attachments = [];
			for (const block of content) {
				if (block.type === "image") {
					const { attachment } = block;
					if (attachment !== void 0) attachments.push({
						type: "image",
						attachment
					});
				}
				if (block.type === "file") {
					const { attachment } = block;
					if (attachment !== void 0) attachments.push({
						type: "file",
						attachment
					});
				}
			}
			return attachments;
		}
		/** Compact file identity used beside queue thumbnails. */
		function QueueFile({ attachment, label }) {
			return (0, react_jsx_runtime.jsxs)("span", {
				className: QueueDock_module_css_default.file,
				"aria-label": label,
				title: attachment.name,
				children: [
					(0, react_jsx_runtime.jsx)("span", {
						className: QueueDock_module_css_default.fileIcon,
						"aria-hidden": true,
						children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.FileTypeIcon, {
							path: attachment.name,
							size: 16
						})
					}),
					(0, react_jsx_runtime.jsx)("span", {
						className: QueueDock_module_css_default.fileName,
						children: attachment.name
					}),
					(0, react_jsx_runtime.jsx)("span", {
						className: QueueDock_module_css_default.fileSize,
						children: (0, _deepseek_ai_dsh_client_ui_primitives.fileSizeText)(attachment.bytes)
					})
				]
			});
		}
		/** One durable queued image as a fixed-size thumbnail; a load failure keeps the empty placeholder. */
		function QueueThumb({ attachment, loadImage, label }) {
			const [url, setUrl] = (0, react.useState)(null);
			(0, react.useEffect)(() => {
				let alive = true;
				loadImage(attachment).then((resolved) => {
					if (alive) setUrl(resolved);
				}, () => {});
				return () => {
					alive = false;
				};
			}, [attachment, loadImage]);
			return url === null ? (0, react_jsx_runtime.jsx)("span", {
				className: QueueDock_module_css_default.thumb,
				"aria-hidden": true
			}) : (0, react_jsx_runtime.jsx)("img", {
				className: QueueDock_module_css_default.thumb,
				src: url,
				alt: label
			});
		}
		/**
		* Queue strip: one item renders directly; multiple items default to a
		* collapsible count header; an empty queue renders nothing. Local queued submissions
		* show sending status and disabled actions until their Host queue rows arrive.
		*/
		function QueueDock({ useSession, useProjection, updateQueue, notify, loadImage, renderFactorySlot, t }) {
			const inbox = useProjection("inbox");
			const pendingSubmissions = useSession((s) => s.pendingSubmissions);
			const queue = (0, react.useMemo)(() => {
				const rows = inbox?.["next-turn"] ?? EMPTY_QUEUE;
				const inChat = new Set(pendingSubmissions.filter((item) => item.placement === "transcript").map((item) => item.requestId));
				return inChat.size === 0 ? rows : rows.filter(({ source }) => source.kind !== "user" || !("rpcId" in source) || !inChat.has(source.rpcId));
			}, [inbox, pendingSubmissions]);
			const pendingQueue = (0, react.useMemo)(() => {
				const admitted = new Set(queue.flatMap(({ source }) => source.kind === "user" && "rpcId" in source ? [source.rpcId] : []));
				return pendingSubmissions.filter((submission) => submission.placement === "queued" && !admitted.has(submission.requestId));
			}, [pendingSubmissions, queue]);
			const rowCount = queue.length + pendingQueue.length;
			const running = useSession((s) => s.running);
			const queueMutable = useSession((s) => s.subagent === null || s.subagent.address.mode === "continuable");
			const [editing, setEditing] = (0, react.useState)(null);
			const [busy, setBusy] = (0, react.useState)(null);
			const [collapsed, setCollapsed] = (0, react.useState)(true);
			const listId = (0, react.useId)();
			(0, react.useEffect)(() => {
				if (rowCount === 0 && !collapsed) setCollapsed(true);
				if (editing !== null && (!queueMutable || !queue.some((row) => row.id === editing.id))) setEditing(null);
			}, [
				collapsed,
				editing,
				queue,
				queueMutable,
				rowCount
			]);
			if (rowCount === 0) return null;
			const interactionActive = queueMutable && (editing !== null || busy !== null);
			const expanded = !collapsed || interactionActive;
			const listVisible = rowCount === 1 || expanded;
			const applyAction = async (itemId, action, failure) => {
				setBusy(itemId);
				try {
					await updateQueue(itemId, action);
					return true;
				} catch {
					notify("error", failure);
					return false;
				} finally {
					setBusy((current) => current === itemId ? null : current);
				}
			};
			const saveEdit = async () => {
				if (editing === null || editing.text.trim() === "") return;
				if (await applyAction(editing.id, {
					kind: "edit",
					content: [{
						type: "text",
						text: editing.text
					}]
				}, t("queue.editFailed"))) setEditing(null);
			};
			return (0, react_jsx_runtime.jsx)("div", {
				className: QueueDock_module_css_default.dock,
				"data-queue-dock": "",
				children: (0, react_jsx_runtime.jsxs)("div", {
					className: QueueDock_module_css_default.panel,
					children: [rowCount > 1 && (0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						className: QueueDock_module_css_default.header,
						"aria-controls": listId,
						"aria-expanded": expanded,
						disabled: interactionActive,
						onClick: () => {
							setCollapsed((value) => !value);
						},
						children: [
							(0, react_jsx_runtime.jsx)("span", {
								className: QueueDock_module_css_default.lead,
								"aria-hidden": true,
								children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconQueueOutlineRegular, {})
							}),
							(0, react_jsx_runtime.jsx)("span", {
								className: QueueDock_module_css_default.count,
								children: t("queue.count", { n: rowCount })
							}),
							!listVisible && pendingQueue.length > 0 && (0, react_jsx_runtime.jsx)("span", {
								className: QueueDock_module_css_default.status,
								role: "status",
								children: t("queue.sending")
							}),
							(0, react_jsx_runtime.jsx)("span", {
								className: QueueDock_module_css_default.chevron,
								"aria-hidden": true,
								children: expanded ? (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChevronDownOutlineRegular, {}) : (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChevronUpOutlineRegular, {})
							})
						]
					}), (0, react_jsx_runtime.jsxs)("ul", {
						id: listId,
						className: QueueDock_module_css_default.list,
						hidden: !listVisible,
						children: [listVisible && queue.map((row) => {
							const attachments = queueAttachments(row.content);
							const text = textOf(row.content);
							return (0, react_jsx_runtime.jsxs)("li", {
								className: QueueDock_module_css_default.row,
								children: [
									rowCount === 1 && (0, react_jsx_runtime.jsx)("span", {
										className: QueueDock_module_css_default.lead,
										"aria-hidden": true,
										children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconQueueOutlineRegular, {})
									}),
									editing?.id === row.id ? (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.InlineEditor, {
										value: editing.text,
										label: t("queue.edit"),
										onChange: (text) => {
											setEditing({
												id: row.id,
												text
											});
										},
										onSave: () => {
											saveEdit();
										},
										onCancel: () => {
											setEditing(null);
										}
									}) : (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [attachments.length > 0 && (0, react_jsx_runtime.jsx)("span", {
										className: QueueDock_module_css_default.attachments,
										children: attachments.map((item, index) => item.type === "image" ? (0, react_jsx_runtime.jsx)(QueueThumb, {
											attachment: item.attachment,
											loadImage,
											label: t("queue.image")
										}, `${item.attachment.attachmentId}:${index}`) : (0, react_jsx_runtime.jsx)(QueueFile, {
											attachment: item.attachment,
											label: t("queue.file", { name: item.attachment.name })
										}, `${item.attachment.attachmentId}:${item.attachment.name}:${index}`))
									}), (0, react_jsx_runtime.jsx)("span", {
										className: QueueDock_module_css_default.preview,
										children: renderFactorySlot("conversation.user.text", {
											text: row.content.filter((block) => block.type === "text").map((block) => block.text).join(""),
											facts: QUEUE_TEXT_FACTS,
											interactive: false,
											ellipsis: true
										})
									})] }),
									queueMutable && (0, react_jsx_runtime.jsx)("div", {
										className: QueueDock_module_css_default.actions,
										children: editing?.id === row.id ? (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [(0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
											portal: true,
											label: t("queue.save"),
											side: "bottom",
											delayMs: 500,
											children: (0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: QueueDock_module_css_default.action,
												"aria-label": t("queue.save"),
												disabled: busy !== null || editing.text.trim() === "",
												onClick: () => {
													saveEdit();
												},
												children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconCheckOutlineRegular, { size: 14 })
											})
										}), (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
											portal: true,
											label: t("queue.cancelEdit"),
											side: "bottom",
											delayMs: 500,
											children: (0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: QueueDock_module_css_default.action,
												"aria-label": t("queue.cancelEdit"),
												disabled: busy !== null,
												onClick: () => {
													setEditing(null);
												},
												children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconCloseOutlineRegular, { size: 14 })
											})
										})] }) : (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
											(0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
												portal: true,
												label: t("queue.edit"),
												side: "bottom",
												delayMs: 500,
												disabled: text === null,
												children: (0, react_jsx_runtime.jsx)("button", {
													type: "button",
													className: QueueDock_module_css_default.action,
													"aria-label": t("queue.edit"),
													title: text === null ? t("queue.edit.unsupported") : void 0,
													disabled: busy !== null || text === null,
													onClick: () => {
														if (text !== null) setEditing({
															id: row.id,
															text
														});
													},
													children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconEditOutlineRegular, { size: 14 })
												})
											}),
											(0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
												portal: true,
												label: t("queue.remove"),
												side: "bottom",
												delayMs: 500,
												children: (0, react_jsx_runtime.jsx)("button", {
													type: "button",
													className: QueueDock_module_css_default.action,
													"aria-label": t("queue.remove"),
													disabled: busy !== null,
													onClick: () => {
														applyAction(row.id, { kind: "remove" }, t("queue.removeFailed"));
													},
													children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconTrashOutlineRegular, { size: 14 })
												})
											}),
											(0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
												portal: true,
												label: t("queue.steer"),
												side: "bottom",
												delayMs: 500,
												disabled: !running,
												children: (0, react_jsx_runtime.jsx)("button", {
													type: "button",
													className: QueueDock_module_css_default.action,
													"aria-label": t("queue.steer"),
													title: running ? void 0 : t("queue.steer.unavailable"),
													disabled: busy !== null || !running,
													onClick: () => {
														applyAction(row.id, { kind: "steer" }, t("queue.steerFailed"));
													},
													children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconSendOutlineRegular, {})
												})
											})
										] })
									})
								]
							}, row.id);
						}), listVisible && pendingQueue.map((submission) => {
							return (0, react_jsx_runtime.jsxs)("li", {
								className: `${QueueDock_module_css_default.row} ${QueueDock_module_css_default.pendingRow}`,
								"data-submission-echo": "",
								children: [
									rowCount === 1 && (0, react_jsx_runtime.jsx)("span", {
										className: QueueDock_module_css_default.lead,
										"aria-hidden": true,
										children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconQueueOutlineRegular, {})
									}),
									submission.attachments.length > 0 && (0, react_jsx_runtime.jsx)("span", {
										className: QueueDock_module_css_default.attachments,
										children: submission.attachments.map((attachment, index) => attachment.type === "image" ? (0, react_jsx_runtime.jsx)("img", {
											className: QueueDock_module_css_default.thumb,
											src: attachment.value.previewUrl,
											alt: t("queue.image")
										}, `${attachment.value.previewUrl}:${index}`) : (0, react_jsx_runtime.jsx)(QueueFile, {
											attachment: attachment.value,
											label: t("queue.file", { name: attachment.value.name })
										}, `${attachment.value.attachmentId}:${attachment.value.name}:${index}`))
									}),
									(0, react_jsx_runtime.jsx)("span", {
										className: QueueDock_module_css_default.preview,
										children: renderFactorySlot("conversation.user.text", {
											text: submission.text,
											facts: QUEUE_TEXT_FACTS,
											interactive: false,
											ellipsis: true
										})
									}),
									(0, react_jsx_runtime.jsx)("span", {
										className: QueueDock_module_css_default.status,
										role: "status",
										children: t("queue.sending")
									}),
									queueMutable && (0, react_jsx_runtime.jsxs)("div", {
										className: QueueDock_module_css_default.actions,
										children: [
											(0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: QueueDock_module_css_default.action,
												"aria-label": t("queue.edit"),
												title: t("queue.sending"),
												disabled: true,
												children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconEditOutlineRegular, { size: 14 })
											}),
											(0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: QueueDock_module_css_default.action,
												"aria-label": t("queue.remove"),
												title: t("queue.sending"),
												disabled: true,
												children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconTrashOutlineRegular, { size: 14 })
											}),
											(0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: QueueDock_module_css_default.action,
												"aria-label": t("queue.steer"),
												title: t("queue.sending"),
												disabled: true,
												children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconSendOutlineRegular, {})
											})
										]
									})
								]
							}, submission.requestId);
						})]
					})]
				})
			});
		}
		/** Registers queue actions backed by the session-scoped conversation service. */
		const queueDockEntry = {
			name: "conversation-queue-dock",
			inject: [
				"slots",
				"conversation",
				"sessions",
				"uiConversation"
			],
			apply(ctx) {
				ctx.slots.inject("conversation.input.dock", () => ctx.slots.register({
					name: "conversation.input.dock",
					id: "queue",
					order: 20,
					locale: NS,
					inject: (sessionId) => {
						const actx = ctx.sessions.scope(sessionId);
						if (actx === void 0) throw new Error(`queue dock: session "${sessionId}" resolved no scope`);
						const conversation = actx.get("conversation");
						if (conversation === void 0) throw new Error("queue dock: conversation service unavailable");
						return {
							updateQueue: (itemId, action) => conversation.updateQueue(itemId, action),
							notify: (level, text) => {
								conversation.input.for(actx).notify(level, text);
							},
							loadImage: (attachment) => ctx.uiConversation.imageUrl(sessionId, attachment)
						};
					}
				}, QueueDock));
			}
		};
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/settings/EnterBehaviorRow.module.css.mjs
		const css$5 = ".T1PP_q_row{border-bottom:.5px solid var(--dsw-alias-border-l2);align-items:center;gap:8px;padding:16px 0;display:flex}.T1PP_q_rowText{flex-direction:column;flex:1;gap:4px;min-width:0;padding-right:48px;display:flex}@media (width<=767px){html:not([data-windows-titlebar]):not([data-platform=darwin]) .T1PP_q_rowText{padding-right:16px}}.T1PP_q_title{color:var(--dsw-alias-label-primary);font-size:14px;font-weight:400;line-height:22px}.T1PP_q_desc{color:var(--dsw-alias-label-tertiary);font-size:12px;font-weight:400;line-height:18px}.T1PP_q_selector{border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-module-platform);height:36px;font:inherit;color:var(--dsw-alias-label-primary);cursor:pointer;border:none;align-items:center;gap:12px;padding:0 14px;font-size:14px;line-height:22px;display:inline-flex}@media (hover:hover){.T1PP_q_selector:hover{background:var(--dsw-alias-interactive-bg-hover)}}.T1PP_q_chevron{flex:none}";
		const tagId$5 = "@deepseek-ai/dsh-client-ui-conversation/EnterBehaviorRow.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$5) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$5;
			tag.textContent = css$5;
			document.head.appendChild(tag);
		}
		var EnterBehaviorRow_module_css_default = {
			"chevron": "T1PP_q_chevron",
			"desc": "T1PP_q_desc",
			"row": "T1PP_q_row",
			"rowText": "T1PP_q_rowText",
			"selector": "T1PP_q_selector",
			"title": "T1PP_q_title"
		};
		//#endregion
		//#region lib/types/client/settings/EnterBehaviorRow.js
		/** General Settings row for the Composer's busy-state Enter preference. */
		const OPTIONS = [{
			id: "queue",
			label: "settings.enter.queue"
		}, {
			id: "steer",
			label: "settings.enter.steer"
		}];
		/**
		* Render the busy-state Enter behavior selector.
		* @param props - composed Settings slot props.
		* @returns the preference row.
		*/
		function EnterBehaviorRow({ useBusyEnter, setBusyEnter, t }) {
			const behavior = useBusyEnter((value) => value);
			const [open, setOpen] = (0, react.useState)(false);
			const selectedLabel = behavior === "queue" ? "settings.enter.queue" : "settings.enter.steer";
			return (0, react_jsx_runtime.jsxs)("div", {
				className: EnterBehaviorRow_module_css_default.row,
				children: [(0, react_jsx_runtime.jsxs)("div", {
					className: EnterBehaviorRow_module_css_default.rowText,
					children: [(0, react_jsx_runtime.jsx)("div", {
						className: EnterBehaviorRow_module_css_default.title,
						children: t("settings.enter.title")
					}), (0, react_jsx_runtime.jsx)("div", {
						className: EnterBehaviorRow_module_css_default.desc,
						children: t("settings.enter.description")
					})]
				}), (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
					open,
					onClose: () => {
						setOpen(false);
					},
					items: OPTIONS.map((option) => ({
						id: option.id,
						label: t(option.label)
					})),
					selectedId: behavior,
					onSelect: (id) => {
						setOpen(false);
						setBusyEnter(id);
					},
					align: "end",
					portal: true,
					anchor: (0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						className: EnterBehaviorRow_module_css_default.selector,
						"aria-haspopup": "menu",
						"aria-expanded": open,
						onClick: () => {
							setOpen((value) => !value);
						},
						children: [t(selectedLabel), (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChevronDownOutlineRegular, { className: EnterBehaviorRow_module_css_default.chevron })]
					})
				})]
			});
		}
		//#endregion
		//#region lib/types/client/contract/snapshot.js
		/** Empty Conversation value used before a Session binding is available. */
		const EMPTY_CONVERSATION_SNAPSHOT = {
			views: {
				get: () => void 0,
				grouped: () => void 0
			},
			activeTargets: /* @__PURE__ */ new Set()
		};
		/**
		* Resolve the shell phase without adding Conversation data to the Session snapshot.
		* @param session - current Session lifecycle state.
		* @param conversation - current target-neutral Conversation state.
		* @returns the phase used by the header, View ring, and composer layout.
		*/
		function conversationPhase(session, conversation) {
			return conversation.activeTargets.size > 0 || !session.blank && !session.awaitingFirstTurn || session.running ? "active" : session.promptAttempted ? "engaging" : "blank";
		}
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/skeleton/ConversationRoot.module.css.mjs
		const css$4 = ".wSkVaW_root{background:var(--dsw-alias-bg-base);flex-direction:column;min-width:0;height:100%;display:flex;position:relative}.wSkVaW_header{box-sizing:border-box;border-bottom:.5px solid var(--dsw-alias-border-l3);flex:none;grid-template-columns:auto minmax(0,1fr);min-height:76px;padding:10px 28px 0 20px;display:grid}.wSkVaW_header:where(:not(:has(.wSkVaW_tabs))){min-height:0;padding-bottom:10px}.wSkVaW_headerBlank{border-bottom:none;min-height:0;padding-bottom:0}.wSkVaW_headerBlank .wSkVaW_headerCorner{margin-left:auto}[data-platform=darwin] .wSkVaW_headerLeading,[data-platform=darwin] .wSkVaW_headerActions,[data-platform=darwin] .wSkVaW_headerUtilities,[data-platform=darwin] .wSkVaW_headerCorner{-webkit-app-region:no-drag}.wSkVaW_titleRow{min-height:30px;grid-column:2;align-items:center;gap:0;padding-inline-start:max(0px, calc(var(--dsh-frame-leading-clearance,0px) - 20px));display:flex;container-type:inline-size}.wSkVaW_titleCluster{--title-cluster-fade:20px;min-width:0;margin:-4px calc(-1 * var(--title-cluster-fade)) -4px -4px;padding:4px var(--title-cluster-fade) 4px 4px;mask-image:linear-gradient(to left, transparent calc(.3 * var(--title-cluster-fade)), #000 var(--title-cluster-fade));flex:1;align-items:center;gap:10px;display:flex;overflow:clip}.wSkVaW_titleCluster:has(+.wSkVaW_headerUtilities:empty){--title-cluster-fade:8px}.wSkVaW_headerLeading{flex:none;grid-area:1/1;align-items:center;gap:8px;display:flex}.wSkVaW_crumbs{white-space:nowrap;align-items:center;gap:4px;min-width:0;display:flex;overflow:hidden}.wSkVaW_crumbSeg{align-items:center;gap:4px;min-width:0;display:inline-flex}.wSkVaW_crumbSep{color:var(--dsw-alias-label-caption);font-size:14px;line-height:20px}.wSkVaW_crumb{border-radius:var(--dsw-radius-md);max-width:220px;color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap;cursor:pointer;background:0 0;border:none;padding:4px 8px;font-size:14px;line-height:20px;display:inline-block;overflow:hidden}.wSkVaW_crumbSubagent{font-size:12px;line-height:18px}@media (hover:hover){button.wSkVaW_crumb:hover{background:var(--dsw-alias-interactive-bg-hover)}}.wSkVaW_crumbCurrent{color:var(--dsw-alias-label-primary);cursor:default;font-weight:500}.wSkVaW_headerActions{flex:none;align-items:center;gap:8px;display:flex}.wSkVaW_headerUtilities{flex:none;align-items:center;gap:8px;margin-left:20px;display:flex}.wSkVaW_headerUtilities:empty{display:none}.wSkVaW_headerCorner{flex:none;align-items:center;margin-left:8px;margin-right:-16px;display:flex}.wSkVaW_headerCorner:empty{display:none}.wSkVaW_tabs{z-index:1;box-sizing:border-box;flex-wrap:wrap;grid-column:1/-1;align-items:flex-start;gap:16px 20px;width:100%;min-width:0;margin-top:10px;padding-left:8px;display:flex;position:relative}@media (width<=767px){html:not([data-platform]) .wSkVaW_tabs{padding-left:0}}.wSkVaW_viewTabs{flex-wrap:wrap;gap:32px;min-width:0;min-height:25px;display:flex}.wSkVaW_tab{--dsh-tab-hit-inline:10px;box-sizing:border-box;min-height:35px;margin:-10px calc(-1 * var(--dsh-tab-hit-inline)) 0;padding:10px var(--dsh-tab-hit-inline) 9px;color:var(--dsw-alias-label-tertiary);cursor:pointer;background:0 0;border:none;font-size:13px;font-weight:500;line-height:16px;position:relative}.wSkVaW_tab:after{content:\"\";right:var(--dsh-tab-hit-inline);bottom:-1px;left:var(--dsh-tab-hit-inline);background:0 0;border-radius:2px;height:2px;position:absolute}.wSkVaW_tabActive{color:var(--dsw-alias-state-business-primary)}.wSkVaW_tabActive:after{background:var(--dsw-alias-state-business-primary)}.wSkVaW_viewsMoreAnchor{flex:none}.wSkVaW_viewsMore{width:22px;height:22px;color:var(--dsw-alias-label-secondary);margin-top:-3px;padding:0}.wSkVaW_viewsMoreActive{color:var(--dsw-alias-state-business-primary)}.wSkVaW_tabLabel{text-overflow:ellipsis;white-space:nowrap;max-width:88px;display:block;overflow:hidden}.wSkVaW_viewsMore[aria-expanded=true]{background:var(--dsw-alias-interactive-bg-hover)}.wSkVaW_viewsMoreMenu{width:288px;max-width:calc(100vw - 24px)}.wSkVaW_viewArea{flex-direction:column;flex:1;min-height:0;display:flex}.wSkVaW_widthHandle{z-index:0;width:min(10px, calc((100% - var(--dsh-chat-content-width)) / 2 - 24px - 24px));cursor:col-resize;position:absolute;top:0;bottom:0}.wSkVaW_widthHandle[data-side=left]{right:calc(50% + var(--dsh-chat-content-width) / 2 + 24px)}.wSkVaW_widthHandle[data-side=right]{left:calc(50% + var(--dsh-chat-content-width) / 2 + 24px)}.wSkVaW_widthHandle:after{content:\"\";background:linear-gradient(to bottom, transparent calc(var(--dsh-width-handle-pointer-y,50%) - 36px), var(--dsw-alias-scrollbar-bg-l1) calc(var(--dsh-width-handle-pointer-y,50%) - 8px), var(--dsw-alias-scrollbar-bg-l1) calc(var(--dsh-width-handle-pointer-y,50%) + 8px), transparent calc(var(--dsh-width-handle-pointer-y,50%) + 36px));opacity:0;pointer-events:none;border-radius:2px;width:2px;position:absolute;top:0;bottom:0}.wSkVaW_widthHandle[data-side=left]:after{right:4px}.wSkVaW_widthHandle[data-side=right]:after{left:4px}.wSkVaW_widthHandle[data-dragging]:after{opacity:1}@media (hover:hover){.wSkVaW_widthHandle:hover:after{opacity:1}}.wSkVaW_root:has([data-conversation-composer-overlay]) .wSkVaW_widthHandle{display:none}.wSkVaW_composerStack{--dsh-composer-stack-gap:6px;gap:var(--dsh-composer-stack-gap);flex-direction:column;display:flex}.wSkVaW_composerSeat{--dsh-composer-text-max-height:336px;flex-direction:column;flex:none;display:flex}.wSkVaW_root[data-phase=active]{overflow:hidden}.wSkVaW_root[data-phase=active] .wSkVaW_header{flex:none}.wSkVaW_body{--dsh-chat-content-width:var(--dsh-chat-user-width,clamp(680px, calc(var(--dsh-conversation-column-width,0px) * .64), 920px));--dsh-composer-card-max-width:calc(var(--dsh-chat-content-width) + 32px);--dsh-composer-side-clearance:16px;--dsh-composer-dock-inset:8px;flex-direction:column;flex:1;min-height:0;display:flex;position:relative}.wSkVaW_embeddedBody{--dsh-chat-content-width:min(calc(100% - 32px), 920px);--dsh-composer-card-max-width:min(calc(100% - 16px), 952px);--dsh-composer-side-clearance:8px;--dsh-composer-dock-inset:8px;overflow:hidden}.wSkVaW_scrollBody{scrollbar-gutter:stable;flex-direction:column;flex:1;min-height:0;margin-right:2px;display:flex;overflow-y:auto}.wSkVaW_scrollBody::-webkit-scrollbar-track{margin:2px}.wSkVaW_root[data-phase=active] .wSkVaW_viewArea,.wSkVaW_embeddedBody[data-content-phase=active] .wSkVaW_viewArea{flex:1 0 auto;min-height:auto}.wSkVaW_root[data-phase=active] .wSkVaW_composerSeat,.wSkVaW_embeddedBody[data-content-phase=active] .wSkVaW_composerSeat{z-index:9;will-change:transform;overflow-anchor:none;background:linear-gradient(180deg, color-mix(in srgb, var(--dsw-alias-bg-base) 0%, transparent) 0px, var(--dsw-alias-bg-base) 36px);margin-top:auto;position:sticky;bottom:0}.wSkVaW_scrollBody:has([data-conversation-composer-overlay]){scrollbar-gutter:auto;position:relative;overflow:hidden auto}.wSkVaW_scrollBody:has([data-conversation-composer-overlay])>[data-slot=conversation\\.session]>.wSkVaW_viewArea{flex:1 1 0;min-height:0;overflow:hidden}.wSkVaW_scrollBody:has([data-conversation-composer-overlay])>.wSkVaW_composerSeat{right:var(--dsh-scrollbar-width);position:absolute;bottom:0;left:0}.wSkVaW_composerHero{width:min(calc(var(--dsh-composer-card-max-width) + 2 * var(--dsh-composer-side-clearance)), 100%);z-index:1;align-self:center;gap:8px;padding-bottom:32px}.wSkVaW_heroWorkspaceRow{align-items:center;gap:2px;min-width:0;margin-top:4px;padding:0 16px 0 20px;display:flex}.wSkVaW_heroOptions{flex:none;align-items:center;gap:2px;min-width:0;margin-left:auto;display:flex}.wSkVaW_heroOptions:empty{display:none}.wSkVaW_root[data-phase=hero] .wSkVaW_scrollBody,.wSkVaW_embeddedBody[data-content-phase=hero] .wSkVaW_scrollBody{justify-content:center;overflow-y:auto}.wSkVaW_root[data-phase=settling] .wSkVaW_composerSeat,.wSkVaW_embeddedBody[data-content-phase=settling] .wSkVaW_composerSeat{visibility:hidden}";
		const tagId$4 = "@deepseek-ai/dsh-client-ui-conversation/ConversationRoot.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$4) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$4;
			tag.textContent = css$4;
			document.head.appendChild(tag);
		}
		var ConversationRoot_module_css_default = {
			"body": "wSkVaW_body",
			"composerHero": "wSkVaW_composerHero",
			"composerSeat": "wSkVaW_composerSeat",
			"composerStack": "wSkVaW_composerStack",
			"crumb": "wSkVaW_crumb",
			"crumbCurrent": "wSkVaW_crumbCurrent",
			"crumbSeg": "wSkVaW_crumbSeg",
			"crumbSep": "wSkVaW_crumbSep",
			"crumbSubagent": "wSkVaW_crumbSubagent",
			"crumbs": "wSkVaW_crumbs",
			"embeddedBody": "wSkVaW_embeddedBody",
			"header": "wSkVaW_header",
			"headerActions": "wSkVaW_headerActions",
			"headerBlank": "wSkVaW_headerBlank",
			"headerCorner": "wSkVaW_headerCorner",
			"headerLeading": "wSkVaW_headerLeading",
			"headerUtilities": "wSkVaW_headerUtilities",
			"heroOptions": "wSkVaW_heroOptions",
			"heroWorkspaceRow": "wSkVaW_heroWorkspaceRow",
			"root": "wSkVaW_root",
			"scrollBody": "wSkVaW_scrollBody",
			"tab": "wSkVaW_tab",
			"tabActive": "wSkVaW_tabActive",
			"tabLabel": "wSkVaW_tabLabel",
			"tabs": "wSkVaW_tabs",
			"titleCluster": "wSkVaW_titleCluster",
			"titleRow": "wSkVaW_titleRow",
			"viewArea": "wSkVaW_viewArea",
			"viewTabs": "wSkVaW_viewTabs",
			"viewsMore": "wSkVaW_viewsMore",
			"viewsMoreActive": "wSkVaW_viewsMoreActive",
			"viewsMoreAnchor": "wSkVaW_viewsMoreAnchor",
			"viewsMoreMenu": "wSkVaW_viewsMoreMenu",
			"widthHandle": "wSkVaW_widthHandle"
		};
		//#endregion
		//#region lib/types/client/skeleton/ConversationWidthControls.js
		/** localStorage key for the dragged transcript width preference (px). */
		const WIDTH_PREF_KEY = "dsh.conversation.contentWidth";
		/** Floor for a dragged content width; matches the layout center-column minimum. */
		const CONTENT_MIN = 640;
		/** Horizontal room reserved for both handles and their safe edge zones. */
		const CONTENT_EDGE_BUDGET = 176;
		const WHEEL_DELTA_LINE = 1;
		const WHEEL_DELTA_PAGE = 2;
		const FALLBACK_WHEEL_LINE_PX = 16;
		/** Read a valid persisted width preference, or null when absent or corrupt. */
		function readWidthPreference() {
			const raw = localStorage.getItem(WIDTH_PREF_KEY);
			if (raw === null) return null;
			const value = Number(raw);
			return Number.isFinite(value) && value > 0 ? value : null;
		}
		/** Resolve the width displayed for one measured Conversation column. */
		function resolveContentWidth(columnWidth, preference) {
			const max = Math.max(CONTENT_MIN, columnWidth - CONTENT_EDGE_BUDGET);
			if (preference !== null) return Math.min(Math.max(preference, CONTENT_MIN), max);
			return Math.max(680, Math.min(columnWidth * .64, 920));
		}
		/** Convert a wheel event's vertical delta to scrollport pixels. */
		function wheelDeltaY(event, scrollport) {
			if (event.deltaMode === WHEEL_DELTA_LINE) {
				const lineHeight = Number.parseFloat(getComputedStyle(scrollport).lineHeight);
				return event.deltaY * (Number.isFinite(lineHeight) ? lineHeight : FALLBACK_WHEEL_LINE_PX);
			}
			if (event.deltaMode === WHEEL_DELTA_PAGE) return event.deltaY * scrollport.clientHeight;
			return event.deltaY;
		}
		/** One pointer-captured transcript width handle. */
		function WidthHandle(props) {
			const dragging = (0, react.useRef)(false);
			const base = (0, react.useRef)(0);
			const origin = (0, react.useRef)(0);
			const latest = (0, react.useRef)(0);
			const frame = (0, react.useRef)(null);
			const callbacks = (0, react.useRef)(props);
			callbacks.current = props;
			const outwardWidth = () => {
				const dx = latest.current - origin.current;
				const outward = callbacks.current.side === "right" ? dx : -dx;
				return base.current + outward * 2;
			};
			const cancelFrame = () => {
				if (frame.current !== null) {
					cancelAnimationFrame(frame.current);
					frame.current = null;
				}
			};
			const onPointerDown = (0, react.useCallback)((event) => {
				if (event.button !== 0) return;
				event.preventDefault();
				event.currentTarget.setPointerCapture(event.pointerId);
				origin.current = event.clientX;
				latest.current = event.clientX;
				base.current = callbacks.current.onStart();
				dragging.current = true;
				event.currentTarget.toggleAttribute("data-dragging", true);
			}, []);
			const onPointerMove = (0, react.useCallback)((event) => {
				if (!dragging.current) return;
				if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
				const box = event.currentTarget.getBoundingClientRect();
				event.currentTarget.style.setProperty("--dsh-width-handle-pointer-y", `${event.clientY - box.top}px`);
				latest.current = event.clientX;
				frame.current ??= requestAnimationFrame(() => {
					frame.current = null;
					callbacks.current.onDrag(outwardWidth());
				});
			}, []);
			const onPointerUp = (0, react.useCallback)((event) => {
				if (!dragging.current) return;
				if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
				dragging.current = false;
				event.currentTarget.toggleAttribute("data-dragging", false);
				event.currentTarget.releasePointerCapture(event.pointerId);
				cancelFrame();
				latest.current = event.clientX;
				if (latest.current !== origin.current) callbacks.current.onCommit(outwardWidth());
				callbacks.current.onEnd();
			}, []);
			const onPointerCancel = (0, react.useCallback)((event) => {
				if (!dragging.current) return;
				dragging.current = false;
				event.currentTarget.toggleAttribute("data-dragging", false);
				cancelFrame();
				callbacks.current.onEnd();
			}, []);
			const onWheel = (0, react.useCallback)((event) => {
				const body = event.currentTarget.parentElement;
				/* v8 ignore next -- a width handle renders only inside the Conversation body. */
				if (body === null) return;
				const scrollport = body.querySelector(":scope > [data-conversation-scroll]");
				/* v8 ignore next -- the Conversation body always contains its direct scroll element. */
				if (scrollport === null) return;
				if (event.ctrlKey || event.deltaY === 0) return;
				scrollport.scrollBy({ top: wheelDeltaY(event, scrollport) });
			}, []);
			return (0, react_jsx_runtime.jsx)("div", {
				className: ConversationRoot_module_css_default.widthHandle,
				"data-side": props.side,
				"data-width-handle": props.side,
				onPointerDown,
				onPointerMove,
				onPointerUp,
				onPointerCancel,
				onLostPointerCapture: onPointerCancel,
				onWheel
			});
		}
		/**
		* Install the main Conversation width axis and render its drag handles.
		* @param props - Mounted Conversation body and current presentation phase.
		* @returns two active-phase width handles, or no controls outside the active phase.
		*/
		function ConversationWidthControls({ container, phase }) {
			const publishWidths = (0, react.useCallback)((container) => {
				const target = container.parentElement ?? container;
				const column = container.offsetWidth;
				target.style.setProperty("--dsh-conversation-column-width", `${column}px`);
				const preference = readWidthPreference();
				if (preference === null) target.style.removeProperty("--dsh-chat-user-width");
				else target.style.setProperty("--dsh-chat-user-width", `${resolveContentWidth(column, preference)}px`);
			}, []);
			(0, react.useLayoutEffect)(() => {
				if (container === null) return;
				const observer = new ResizeObserver(() => {
					publishWidths(container);
				});
				observer.observe(container);
				publishWidths(container);
				return () => {
					observer.disconnect();
				};
			}, [container, publishWidths]);
			const onStart = (0, react.useCallback)(() => {
				if (container === null) return 680;
				return resolveContentWidth(container.offsetWidth, readWidthPreference());
			}, [container]);
			const onDrag = (0, react.useCallback)((width) => {
				if (container === null) return;
				(container.parentElement ?? container).style.setProperty("--dsh-chat-user-width", `${resolveContentWidth(container.offsetWidth, width)}px`);
			}, [container]);
			const onCommit = (0, react.useCallback)((width) => {
				if (container === null) return;
				localStorage.setItem(WIDTH_PREF_KEY, `${resolveContentWidth(container.offsetWidth, width)}`);
			}, [container]);
			const onEnd = (0, react.useCallback)(() => {
				if (container !== null) publishWidths(container);
			}, [container, publishWidths]);
			if (container === null || phase !== "active") return null;
			return ["left", "right"].map((side) => (0, react_jsx_runtime.jsx)(WidthHandle, {
				side,
				onStart,
				onDrag,
				onCommit,
				onEnd
			}, side));
		}
		//#endregion
		//#region lib/types/client/skeleton/ConversationMainPanel.js
		const CONTENT_SLOTS = { widthControls: ConversationWidthControls };
		/**
		* Render the existing main Conversation frame around the extracted content.
		* @param props - the original `main.conversation` Slot props.
		* @returns the unchanged root, Header, content, and width-control subtree.
		*/
		function ConversationMainPanel(props) {
			const { sessionId, useSession, useSessions, useConversation, renderSlot, renderFactorySlot } = props;
			const session = useSession((s) => s);
			const conversation = useConversation((s) => s);
			const shellPhase = session === void 0 || conversation === void 0 ? "blank" : conversationPhase(session, conversation);
			const openState = session?.openState;
			const summaryBlank = useSessions((s) => sessionId === void 0 ? void 0 : s.byId[sessionId]?.blank);
			const parentAvailabilityPending = session?.subagent?.address.mode === "continuable" && session.subagent.parentAvailable === void 0;
			const settling = sessionId !== void 0 && (shellPhase === "blank" && openState === "loading" && summaryBlank !== true || parentAvailabilityPending);
			const hero = sessionId === void 0 || shellPhase === "blank" && (openState === "open" || summaryBlank === true);
			const phase = settling ? "settling" : hero ? "hero" : "active";
			return (0, react_jsx_runtime.jsxs)("div", {
				className: ConversationRoot_module_css_default.root,
				"data-phase": phase,
				children: [renderSlot("conversation.header", {}), renderFactorySlot("conversation.content", {
					variant: "main",
					phase,
					hero
				}, { slots: CONTENT_SLOTS })]
			});
		}
		//#endregion
		//#region lib/types/client/skeleton/ConversationRoot.js
		function ConversationRoot(props) {
			return (0, react_jsx_runtime.jsx)(ConversationMainPanel, { ...props });
		}
		/**
		* The text one Workspace is labeled with. A Workspace still carrying the
		* automatic first-use title reads as the caller's localized default name; every
		* other title reads verbatim in every language. A title the user typed as
		* exactly {@link DEFAULT_WORKSPACE_DIRECTORY} is labeled as the default too;
		* nothing else depends on the distinction.
		* @param title - stored Workspace title.
		* @param localizedDefault - the default Workspace name in the active language.
		* @returns the title to display.
		*/
		function workspaceDisplayTitle(title, localizedDefault) {
			return title === "default-workspace" ? localizedDefault : title;
		}
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/skeleton/HeroShell.module.css.mjs
		const css$3 = ".pXSMma_root{justify-content:center;align-items:center;min-width:0;height:100%;padding:0 24px;display:flex}.pXSMma_stack{width:100%;max-width:var(--dsh-composer-card-max-width);flex-direction:column;align-items:stretch;gap:12px;display:flex;overflow:visible}.pXSMma_headline{color:var(--dsw-alias-label-primary);flex-wrap:wrap;justify-content:center;align-items:center;gap:12px 10px;font-size:26px;font-weight:500;line-height:32px;display:flex}.pXSMma_titleGroup{flex-wrap:wrap;justify-content:center;align-items:center;gap:4px 7px;min-width:0;display:flex}.pXSMma_previewBadge{border:.5px solid var(--dsw-alias-interactive-bg-hover);corner-shape:round;background:var(--dsw-alias-state-business-tertiary);color:var(--dsw-alias-label-primary-bluish);font-family:var(--ds-font-family-code);white-space:nowrap;border-radius:999px;align-self:flex-start;margin-top:2px;padding:1px 7px 0;font-size:12px;font-weight:500;line-height:18px}.pXSMma_fishHitbox{flex:none;justify-content:center;align-items:center;display:inline-flex}.pXSMma_fish{transform-origin:50% 60%;color:var(--dsw-alias-label-primary);display:block;overflow:visible}@keyframes pXSMma_hero-fish-swim{0%,to{transform:none}35%{transform:rotate(-4deg)translate(-.4px,-.9px)}70%{transform:rotate(1.6deg)translate(.3px,.2px)}}@media (hover:hover) and (prefers-reduced-motion:no-preference){.pXSMma_fishHitbox:hover .pXSMma_fish{animation:1.6s ease-in-out infinite pXSMma_hero-fish-swim}}.pXSMma_body{flex-direction:column;gap:12px;min-width:0;display:flex;position:relative;overflow:visible}.pXSMma_body>*{z-index:1;position:relative}.pXSMma_body>.pXSMma_workspaceRow{z-index:10;align-items:center;min-width:0;padding-left:8px;display:flex}.pXSMma_workspace{border-radius:var(--dsw-radius-sm);max-width:min(100%,360px);min-height:28px;color:var(--dsw-alias-label-primary);cursor:pointer;background:0 0;border:none;align-items:center;gap:4px;padding:0 8px;font-size:13px;font-weight:500;line-height:20px;display:inline-flex}.pXSMma_workspace[aria-expanded=true]{background:var(--dsw-alias-interactive-bg-hover)}@media (hover:hover){.pXSMma_workspace:not(:disabled):hover{background:var(--dsw-alias-interactive-bg-hover)}}.pXSMma_workspace:disabled{cursor:default}.pXSMma_folder{color:var(--dsw-alias-label-primary);flex:none}.pXSMma_workspaceLabel{text-overflow:ellipsis;white-space:nowrap;min-width:0;overflow:hidden}.pXSMma_chevron{color:var(--dsw-alias-label-caption);flex:none}.pXSMma_modalInput{box-sizing:border-box;border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-lg);width:100%;height:44px;color:var(--dsw-alias-label-primary);background:0 0;outline:none;padding:7px 14px;font-size:14px;font-weight:400;line-height:22px}.pXSMma_modalInput::placeholder{color:var(--dsw-alias-label-caption)}.pXSMma_modalInput:disabled{color:var(--dsw-alias-label-dimmed)}.pXSMma_modalAction{min-width:72px}.pXSMma_modalError{color:var(--dsw-alias-state-error-primary);margin-top:8px;font-size:12px;line-height:18px}";
		const tagId$3 = "@deepseek-ai/dsh-client-ui-conversation/HeroShell.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$3) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$3;
			tag.textContent = css$3;
			document.head.appendChild(tag);
		}
		var HeroShell_module_css_default = {
			"body": "pXSMma_body",
			"chevron": "pXSMma_chevron",
			"fish": "pXSMma_fish",
			"fishHitbox": "pXSMma_fishHitbox",
			"folder": "pXSMma_folder",
			"headline": "pXSMma_headline",
			"hero-fish-swim": "pXSMma_hero-fish-swim",
			"modalAction": "pXSMma_modalAction",
			"modalError": "pXSMma_modalError",
			"modalInput": "pXSMma_modalInput",
			"previewBadge": "pXSMma_previewBadge",
			"root": "pXSMma_root",
			"stack": "pXSMma_stack",
			"titleGroup": "pXSMma_titleGroup",
			"workspace": "pXSMma_workspace",
			"workspaceLabel": "pXSMma_workspaceLabel",
			"workspaceRow": "pXSMma_workspaceRow"
		};
		//#endregion
		//#region lib/types/client/skeleton/EmptyHero.js
		/**
		* Basename label for the workspace chip (the shared derivation);
		* separator-only paths echo the raw cwd.
		* @param cwd - workspace directory path (non-empty).
		* @returns chip label.
		*/
		function workspaceLabel(cwd) {
			const base = workspaceTitleOf(cwd);
			return base !== "" ? base : cwd;
		}
		/**
		* The workspace chip (folder + label + chevron), always interactive: before
		* the first message the workspace stays switchable — picking another one
		* moves the New Session flow to that workspace's blank session. Without a
		* label the chip renders its placeholder state: closed folder + the
		* "Choose workspace" call to action.
		* @param props.label - chip label (see {@link workspaceLabel}); omitted → placeholder.
		* @param props.menuOpen - menu expansion echo.
		* @param props.onClick - menu toggle.
		* @returns the chip button element.
		*/
		function WorkspaceChip({ buttonRef, label, menuOpen = false, onClick, t }) {
			return (0, react_jsx_runtime.jsxs)("button", {
				ref: buttonRef,
				type: "button",
				className: HeroShell_module_css_default.workspace,
				"aria-label": t("hero.chooseWorkspace"),
				"aria-haspopup": "menu",
				"aria-expanded": menuOpen,
				onClick,
				children: [
					label === void 0 ? (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconFolderCloseRegular, {
						className: HeroShell_module_css_default.folder,
						size: 16
					}) : (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconFolderOpenRegular, {
						className: HeroShell_module_css_default.folder,
						size: 16
					}),
					(0, react_jsx_runtime.jsx)("span", {
						className: HeroShell_module_css_default.workspaceLabel,
						children: label ?? t("hero.chooseWorkspace")
					}),
					(0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChevronDownOutlineRegular, {
						className: HeroShell_module_css_default.chevron,
						size: 12
					})
				]
			});
		}
		const HERO_SWIM_UP_PATH = "M22.403 0.567C22.145 0.477 22.068 0.718 21.939 0.85C21.895 0.893 21.86 0.947 21.824 0.997C21.515 1.421 21.13 1.721 20.591 1.77C19.829 1.867 19.221 2.244 18.712 2.958C18.535 2.227 18.116 1.839 17.516 1.626C17.203 1.506 16.887 1.379 16.663 1.064C16.508 0.839 16.462 0.581 16.383 0.329C16.332 0.176 16.283 0.02 16.121 -0.002C15.944 -0.029 15.875 0.133 15.805 0.269C15.52 0.822 15.408 1.43 15.42 2.046C15.449 3.432 16.031 4.532 17.202 5.274C17.337 5.356 17.374 5.445 17.335 5.582C17.261 5.862 17.169 6.134 17.086 6.413C17.032 6.59 16.952 6.63 16.764 6.558C16.118 6.301 15.562 5.909 15.074 5.433C14.248 4.633 13.5 3.751 12.568 3.06C12.349 2.898 12.13 2.748 11.903 2.605C10.952 1.682 12.028 0.923 12.277 0.833C12.537 0.739 12.367 0.416 11.526 0.42C10.684 0.424 9.914 0.706 8.933 1.081C8.789 1.138 8.638 1.179 8.484 1.213C7.593 1.044 6.668 1.006 5.702 1.115C3.883 1.318 2.43 2.178 1.362 3.646C0.079 5.41 -0.223 7.415 0.147 9.506C0.535 11.71 1.66 13.535 3.389 14.962C5.181 16.441 7.246 17.166 9.601 17.027C11.032 16.944 12.624 16.753 14.421 15.232C14.874 15.458 15.35 15.548 16.138 15.615C16.746 15.672 17.331 15.585 17.784 15.491C18.493 15.341 18.444 14.684 18.188 14.564C16.108 13.595 16.565 13.989 16.15 13.67C17.206 12.42 18.82 10.198 19.363 7.086C19.421 6.709 19.484 6.171 19.469 5.866C19.458 5.681 19.493 5.604 19.681 5.556C20.199 5.412 20.691 5.172 21.125 4.806C22.366 3.824 22.758 2.554 22.708 1.1C22.7 0.878 22.649 0.654 22.403 0.567ZM11.175 14.451C9.159 12.726 8.182 12.088 7.778 12.067C7.401 12.047 7.469 12.505 7.552 12.807C7.639 13.103 7.752 13.313 7.91 13.581C8.02 13.758 8.095 14.01 7.801 14.16C7.152 14.487 6.023 13.806 5.97 13.772C4.657 12.85 3.559 11.766 2.785 10.369C2.037 9.025 1.603 7.583 1.532 6.044C1.513 5.672 1.622 5.541 1.992 5.473C2.479 5.383 2.981 5.364 3.468 5.436C5.525 5.736 7.276 6.675 8.744 8.323C9.582 9.299 10.216 10.425 10.869 11.496C11.563 12.592 12.31 13.603 13.262 14.414C13.598 14.696 13.866 14.91 14.123 15.068C13.349 15.154 12.058 15.167 11.175 14.452L11.175 14.451ZM12.141 8.26C12.141 8.095 12.273 7.963 12.439 7.963C12.476 7.963 12.511 7.971 12.541 7.982C12.582 7.997 12.62 8.019 12.65 8.053C12.704 8.106 12.733 8.181 12.733 8.26C12.733 8.425 12.601 8.556 12.435 8.556C12.27 8.556 12.141 8.425 12.141 8.26ZM15.142 9.799C14.949 9.878 14.757 9.945 14.572 9.953C14.284 9.968 13.972 9.851 13.802 9.709C13.537 9.487 13.348 9.363 13.27 8.977C13.236 8.812 13.255 8.556 13.284 8.41C13.352 8.094 13.277 7.892 13.055 7.708C12.873 7.558 12.643 7.516 12.39 7.516C12.296 7.516 12.209 7.475 12.145 7.441C12.039 7.389 11.952 7.257 12.035 7.096C12.062 7.043 12.19 6.916 12.22 6.893C12.563 6.698 12.96 6.762 13.326 6.908C13.665 7.047 13.922 7.302 14.292 7.663C14.669 8.098 14.738 8.218 14.953 8.545C15.123 8.801 15.277 9.063 15.383 9.364C15.447 9.551 15.364 9.705 15.142 9.799Z";
		const HERO_SWIM_DOWN_PATH = "M23.271 2.216C23.039 2.071 22.91 2.287 22.755 2.388C22.703 2.42 22.656 2.464 22.61 2.505C22.214 2.848 21.771 3.054 21.225 2.956C20.412 2.784 19.68 2.919 19.005 3.435C18.92 2.663 18.493 2.157 17.808 1.798C17.446 1.621 17.08 1.449 16.83 1.111C16.656 0.872 16.611 0.612 16.524 0.354C16.469 0.198 16.414 0.039 16.223 0.009C16.017 -0.024 15.936 0.137 15.856 0.271C15.539 0.822 15.418 1.43 15.429 2.046C15.454 3.432 16.041 4.538 17.196 5.36C17.325 5.456 17.356 5.547 17.312 5.674C17.229 5.936 17.134 6.191 17.051 6.454C16.999 6.623 16.921 6.659 16.738 6.58C16.107 6.306 15.56 5.909 15.074 5.433C14.248 4.633 13.5 3.751 12.568 3.06C12.349 2.898 12.13 2.748 11.903 2.605C10.952 1.682 12.028 0.923 12.277 0.833C12.537 0.739 12.367 0.416 11.526 0.42C10.684 0.424 9.914 0.706 8.933 1.081C8.789 1.138 8.638 1.179 8.484 1.213C7.593 1.044 6.668 1.006 5.702 1.115C3.883 1.318 2.43 2.178 1.362 3.646C0.079 5.41 -0.223 7.415 0.147 9.506C0.535 11.71 1.66 13.535 3.389 14.962C5.181 16.441 7.246 17.166 9.601 17.027C11.032 16.944 12.624 16.753 14.421 15.232C14.874 15.458 15.35 15.548 16.138 15.615C16.746 15.672 17.331 15.585 17.784 15.491C18.493 15.341 18.444 14.684 18.188 14.564C16.108 13.595 16.565 13.989 16.15 13.67C17.206 12.42 18.82 10.198 19.278 7.246C19.318 6.948 19.375 6.534 19.371 6.293C19.371 6.145 19.411 6.092 19.597 6.098C20.113 6.109 20.619 6.051 21.096 5.891C22.503 5.375 23.169 4.232 23.448 2.804C23.49 2.586 23.491 2.356 23.271 2.216ZM11.175 14.49C9.159 13.005 8.182 12.567 7.778 12.621C7.401 12.673 7.469 13.087 7.552 13.354C7.639 13.619 7.752 13.797 7.91 14.024C8.02 14.175 8.095 14.406 7.801 14.609C7.152 15.063 6.023 14.63 5.97 14.609C4.657 13.941 3.559 12.965 2.785 11.569C2.037 10.225 1.603 8.783 1.532 7.244C1.513 6.872 1.622 6.741 1.992 6.673C2.479 6.583 2.981 6.564 3.468 6.636C5.525 6.936 7.276 7.843 8.744 9.163C9.582 9.888 10.216 10.783 10.869 11.679C11.563 12.659 12.31 13.617 13.262 14.415C13.598 14.696 13.866 14.91 14.123 15.068C13.349 15.155 12.058 15.177 11.175 14.491L11.175 14.49ZM12.141 8.26C12.141 8.095 12.273 7.963 12.439 7.963C12.476 7.963 12.511 7.971 12.541 7.982C12.582 7.997 12.62 8.019 12.65 8.053C12.704 8.106 12.733 8.181 12.733 8.26C12.733 8.425 12.601 8.556 12.435 8.556C12.27 8.556 12.141 8.425 12.141 8.26ZM15.142 9.799C14.949 9.878 14.757 9.945 14.572 9.953C14.284 9.968 13.972 9.851 13.802 9.709C13.537 9.487 13.348 9.363 13.27 8.977C13.236 8.812 13.255 8.556 13.284 8.41C13.352 8.094 13.277 7.892 13.055 7.708C12.873 7.558 12.643 7.516 12.39 7.516C12.296 7.516 12.209 7.475 12.145 7.441C12.039 7.389 11.952 7.257 12.035 7.096C12.062 7.043 12.19 6.916 12.22 6.893C12.563 6.698 12.96 6.762 13.326 6.908C13.665 7.047 13.922 7.302 14.292 7.663C14.669 8.098 14.738 8.218 14.953 8.545C15.123 8.801 15.277 9.063 15.383 9.364C15.447 9.551 15.364 9.705 15.142 9.799Z";
		/**
		* The hero fish (34px wide), static at rest. Hovering swims the whale in
		* place: a gentle head-up sway (CSS, on the hitbox hover) while the body
		* itself morphs — SMIL interpolates `d` through the tail-up and tail-down
		* targets on the same 1.6s period, so the tail wags and the fin flutters in
		* real curve deformation. Decorative — hidden from the accessibility tree;
		* reduced motion keeps the static filled logo on hover (sampled at
		* mouseenter; a mid-hover preference change takes effect on the next enter).
		* @param props.hovering - driven by the hitbox parent's pointer state.
		* @returns the fish svg element.
		*/
		function HeroFish({ hovering }) {
			return (0, react_jsx_runtime.jsx)("svg", {
				className: HeroShell_module_css_default.fish,
				width: 34,
				height: 34 * _deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_VIEWBOX.height / _deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_VIEWBOX.width,
				viewBox: `0 0 ${_deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_VIEWBOX.width} ${_deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_VIEWBOX.height}`,
				fill: "none",
				"aria-hidden": "true",
				children: (0, react_jsx_runtime.jsx)("path", {
					d: _deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_PATH,
					fill: "currentColor",
					children: hovering && (0, react_jsx_runtime.jsx)("animate", {
						attributeName: "d",
						values: `${_deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_PATH};${HERO_SWIM_UP_PATH};${_deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_PATH};${HERO_SWIM_DOWN_PATH};${_deepseek_ai_dsh_client_ui_primitives.FISH_LOGO_PATH}`,
						keyTimes: "0;0.35;0.55;0.75;1",
						calcMode: "spline",
						keySplines: "0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1",
						dur: "1.6s",
						repeatCount: "indefinite"
					})
				})
			});
		}
		/**
		* Render the hero chrome (headline only; no composer, no workspace row).
		* @param props - see {@link HeroShellProps}.
		* @returns the centered hero element tree.
		*/
		function HeroShell({ t, renderSlot, children }) {
			const [hovering, setHovering] = (0, react.useState)(false);
			return (0, react_jsx_runtime.jsxs)("div", {
				className: HeroShell_module_css_default.root,
				children: [(0, react_jsx_runtime.jsxs)("div", {
					className: HeroShell_module_css_default.stack,
					children: [(0, react_jsx_runtime.jsxs)("div", {
						className: HeroShell_module_css_default.headline,
						children: [(0, react_jsx_runtime.jsx)("span", {
							className: HeroShell_module_css_default.fishHitbox,
							onPointerEnter: (event) => {
								if (event.pointerType !== "touch" && window.matchMedia("(hover: hover) and (prefers-reduced-motion: no-preference)").matches) setHovering(true);
							},
							onPointerLeave: () => {
								setHovering(false);
							},
							children: renderSlot("conversation.hero.brand.mark", {
								size: 34,
								className: HeroShell_module_css_default.fish
							}, { fallback: (0, react_jsx_runtime.jsx)(HeroFish, { hovering }) })
						}), (0, react_jsx_runtime.jsxs)("span", {
							className: HeroShell_module_css_default.titleGroup,
							children: [(0, react_jsx_runtime.jsx)("span", { children: t("hero.headline") }), (0, react_jsx_runtime.jsx)("span", {
								className: HeroShell_module_css_default.previewBadge,
								children: t("hero.preview")
							})]
						})]
					}), (0, react_jsx_runtime.jsx)("div", { className: HeroShell_module_css_default.body })]
				}), children]
			});
		}
		//#endregion
		//#region lib/types/client/skeleton/ConversationContent.js
		function ConversationSessionView({ renderSlot }) {
			return renderSlot("conversation.session", {});
		}
		function NoConversationWidthControls() {
			return null;
		}
		/**
		* Render the shared Conversation body and its occurrence-selected local Components.
		* @param props - Factory input, standard Session sources, and Conversation seats.
		* @returns the Conversation view, Composer, and optional width controls.
		*/
		function ConversationContent(props) {
			const { sessionId, phase, hero, useSession, useSessions, useSessionStatus, useWorkspaces, useInput, useComposerBlock, renderSlot, renderSlotChain, selectWorkspace, t, useFactorySlot } = props;
			const session = useSession((snapshot) => snapshot);
			const Views = useFactorySlot("views", ConversationSessionView);
			const WidthControls = useFactorySlot("widthControls", NoConversationWidthControls);
			const [body, setBody] = (0, react.useState)(null);
			const pendingInteraction = useSessionStatus((snapshot) => sessionId === void 0 ? void 0 : snapshot.get(sessionId)?.pendingInteraction);
			const inputState = useInput((s) => s);
			const cwd = useSessions((s) => sessionId === void 0 ? void 0 : s.byId[sessionId]?.cwd);
			const workspaces = useWorkspaces((s) => s);
			const composerBlock = useComposerBlock((block) => block);
			const [pickerOpen, setPickerOpen] = (0, react.useState)(false);
			const [pendingWorkspaceId, setPendingWorkspaceId] = (0, react.useState)();
			const pickerAnchor = (0, react.useRef)(null);
			const seatObserver = (0, react.useRef)(null);
			const seatResizeRef = (0, react.useCallback)((seat) => {
				seatObserver.current?.disconnect();
				seatObserver.current = null;
				const scroller = seat?.parentElement ?? null;
				if (seat === null || scroller === null) return;
				seatObserver.current = new ResizeObserver(() => {
					scroller.style.setProperty("--dsh-composer-height", `${seat.offsetHeight}px`);
					scroller.style.setProperty("--dsh-conversation-viewport-height", `${scroller.clientHeight}px`);
				});
				seatObserver.current.observe(seat);
				seatObserver.current.observe(scroller);
			}, []);
			const sessionWorkspace = sessionId === void 0 ? void 0 : workspaces.items.find((workspace) => workspace.sessionIds.includes(sessionId));
			const pendingWorkspace = workspaces.items.find((workspace) => workspace.workspaceId === pendingWorkspaceId);
			(0, react.useEffect)(() => {
				if (pendingWorkspaceId === void 0) return;
				if (sessionWorkspace?.workspaceId === pendingWorkspaceId || workspaces.phase === "ready" && pendingWorkspace === void 0) setPendingWorkspaceId(void 0);
			}, [
				pendingWorkspaceId,
				sessionWorkspace?.workspaceId,
				workspaces.phase,
				pendingWorkspace
			]);
			const zone = session === void 0 || inputState === void 0 ? void 0 : {
				session,
				input: inputState
			};
			const storedChipTitle = pendingWorkspace?.title ?? (sessionId === void 0 ? void 0 : sessionWorkspace?.title ?? (workspaces.phase === "ready" || cwd === void 0 || cwd === "" ? void 0 : workspaceLabel(cwd)));
			const chipTitle = storedChipTitle === void 0 ? void 0 : workspaceDisplayTitle(storedChipTitle, t("workspace.defaultName"));
			const heroWorkspaceRow = (0, react_jsx_runtime.jsxs)("div", {
				className: ConversationRoot_module_css_default.heroWorkspaceRow,
				children: [
					(0, react_jsx_runtime.jsx)(WorkspaceChip, {
						buttonRef: pickerAnchor,
						label: chipTitle,
						menuOpen: pickerOpen,
						onClick: () => {
							setPickerOpen((open) => !open);
						},
						t
					}),
					renderSlot("conversation.hero.workspace", {
						open: pickerOpen,
						anchorRef: pickerAnchor,
						selectedId: pendingWorkspaceId ?? sessionWorkspace?.workspaceId,
						onPick: (workspaceId) => {
							setPickerOpen(false);
							setPendingWorkspaceId(workspaceId);
							selectWorkspace(workspaceId).catch(() => {
								setPendingWorkspaceId((current) => current === workspaceId ? void 0 : current);
							});
						},
						onClose: () => {
							setPickerOpen(false);
						}
					}),
					renderSlot("conversation.hero.agentPreset", {}),
					sessionId === void 0 ? null : (0, react_jsx_runtime.jsx)("div", {
						className: ConversationRoot_module_css_default.heroOptions,
						children: renderSlot("conversation.hero.options", {})
					})
				]
			});
			const inert = sessionId === void 0 || hero && chipTitle === void 0;
			const inputBar = renderSlot("conversation.composer.bar", {
				variant: hero ? "hero" : "composer",
				...inert ? {
					disabled: true,
					placeholder: t("placeholder.workspace"),
					workspacePickerOpen: pickerOpen,
					onRequestWorkspace: () => {
						setPickerOpen(true);
					}
				} : !inert && composerBlock !== void 0 ? {
					blocked: composerBlock,
					placeholder: composerBlock.reason
				} : hero ? { placeholder: t("placeholder.hero") } : {}
			});
			const composerBar = (0, react_jsx_runtime.jsxs)("div", {
				className: clsx(ConversationRoot_module_css_default.composerStack, hero && ConversationRoot_module_css_default.composerHero),
				children: [
					hero && (0, react_jsx_runtime.jsx)(HeroShell, {
						t,
						renderSlot
					}),
					hero && heroWorkspaceRow,
					zone !== void 0 && renderSlot("conversation.input.dock", zone),
					inputBar
				]
			});
			const composer = renderSlotChain("conversation.composer", {
				sessionId,
				session,
				pendingInteraction
			}, {
				fallback: composerBar,
				fallbackOnly: sessionId === void 0,
				overlay: true
			});
			const composerSeat = (0, react_jsx_runtime.jsx)("div", {
				ref: seatResizeRef,
				className: ConversationRoot_module_css_default.composerSeat,
				"data-composer-seat": "",
				"data-conversation-region": "composer",
				children: composer
			});
			return (0, react_jsx_runtime.jsxs)("div", {
				ref: setBody,
				className: clsx(ConversationRoot_module_css_default.body, props.variant === "embedded" && ConversationRoot_module_css_default.embeddedBody),
				"data-conversation-content": "",
				"data-conversation-session": sessionId,
				"data-conversation-region": "chat",
				"data-content-phase": phase,
				children: [(0, react_jsx_runtime.jsxs)("div", {
					className: ConversationRoot_module_css_default.scrollBody,
					"data-conversation-scroll": "",
					children: [sessionId === void 0 ? null : (0, react_jsx_runtime.jsx)(Views, {}), composerSeat]
				}), (0, react_jsx_runtime.jsx)(WidthControls, {
					container: body,
					phase
				})]
			});
		}
		//#endregion
		//#region lib/types/client/skeleton/ConversationPanel.js
		/**
		* Render the Conversation with optional current-Session binding.
		* @param props - main-slot inputs and the declared Conversation renderer.
		* @returns the Conversation subtree.
		*/
		function ConversationPanel({ renderSlot }) {
			return renderSlot("main.conversation", {});
		}
		//#endregion
		//#region lib/types/client/skeleton/ConversationHeader.js
		/** Resident conversation navigation and Session-specific header content. */
		/**
		* Keeps global navigation available before a Session exists.
		* @param props - Optional Session sources and authorized header slots.
		* @returns The persistent header with any selected Session's title and views.
		*/
		function ConversationHeader({ sessionId, useSession, useConversation, renderSlot }) {
			const session = useSession((s) => s);
			const conversation = useConversation((s) => s);
			const blank = session === void 0 || conversation === void 0 || session.blank && conversationPhase(session, conversation) === "blank";
			return (0, react_jsx_runtime.jsxs)("header", {
				className: clsx(ConversationRoot_module_css_default.header, blank && ConversationRoot_module_css_default.headerBlank),
				"data-window-drag": true,
				children: [(0, react_jsx_runtime.jsx)("div", {
					className: ConversationRoot_module_css_default.headerLeading,
					"data-conversation-header-leading": "",
					children: renderSlot("conversation.header.leading", {})
				}), sessionId === void 0 ? (0, react_jsx_runtime.jsx)("div", { className: ConversationRoot_module_css_default.titleRow }) : renderSlot("conversation.session.header", { hideChrome: blank })]
			});
		}
		/**
		* Resolve a preferred registered View, then Chat, without choosing another View.
		* @param tabs - currently registered Views.
		* @param selectedId - preferred View identity, when one is stored.
		* @returns the selected View, Chat fallback, or undefined when neither is registered.
		*/
		function resolveActiveView(tabs, selectedId) {
			return (selectedId === null ? void 0 : tabs.find((view) => view.id === selectedId)) ?? tabs.find((view) => view.id === "chat");
		}
		//#endregion
		//#region lib/types/client/view-pins.js
		/** In-memory pin choices for the Conversation View tabs. */
		/** View whose tab always shows and never enters the customization list. */
		const FIXED_VIEW_ID = "chat";
		const NO_VIEWS = [];
		/**
		* Create the in-memory View pin list; the snapshot keeps its reference until the list changes.
		* @returns Unpinned View ids and the pin mutation.
		*/
		function createViewPins() {
			const store = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)({ unpinned: NO_VIEWS });
			return {
				unpinned: {
					getSnapshot: () => store.getSnapshot().unpinned,
					subscribe: (listener) => store.subscribe(listener)
				},
				setPinned: (id, pinned) => {
					const current = store.getSnapshot().unpinned;
					if (id === "chat" || pinned !== current.includes(id)) return;
					store.set({ unpinned: pinned ? current.filter((entry) => entry !== id) : [...current, id] });
				}
			};
		}
		//#endregion
		//#region lib/types/client/skeleton/DefaultConversationViews.js
		/**
		* Renders the active Session view inside the resident scrollport and keeps
		* the input draft persisted while blank Hero chrome is visible.
		* @param props - Strict Session input/store, view ledger, and render shares.
		* @returns the active view area, or null while the Session remains blank.
		*/
		function DefaultConversationViews({ view, useSession, useConversation, useConversationViews, inputActions, useStore, actions, renderSlot, bindDraftPersistence, openView, useInspectCall }) {
			const tabs = useConversationViews((value) => value);
			const inspectCall = useInspectCall((value) => value);
			const active = resolveActiveView(tabs, useStore((s) => s.view));
			const session = useSession((s) => s);
			const conversation = useConversation((s) => s);
			const viewRequest = useStore((s) => s.viewRequest ?? null);
			(0, react.useEffect)(() => {
				const unbindDraftPersistence = bindDraftPersistence(actions.setDraft);
				inputActions.persistDraft();
				return () => {
					unbindDraftPersistence();
				};
			}, [inputActions]);
			if (session.blank && conversationPhase(session, conversation) === "blank") return null;
			const viewId = view ?? active?.id;
			return (0, react_jsx_runtime.jsx)("div", {
				className: ConversationRoot_module_css_default.viewArea,
				children: viewId !== void 0 && renderSlot("conversation.view", {
					inspectCall,
					viewRequest,
					openView,
					completeViewRequest: actions.completeViewRequest
				}, { only: viewId })
			});
		}
		//#endregion
		//#region lib/types/client/skeleton/ConversationSession.js
		/** Strict per-session header/body content inserted into the resident conversation layout. */
		/** The View tab row's More launcher; its menu rows come from `conversation.session.header.views.actions`. */
		function ViewsMoreMenu({ label, current, entries, onOpen, onPinnedChange, renderSlot }) {
			const [open, setOpen] = (0, react.useState)(false);
			const onDismiss = () => {
				setOpen(false);
			};
			return (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
				open,
				onClose: onDismiss,
				portal: true,
				autoFocus: true,
				className: ConversationRoot_module_css_default.viewsMoreAnchor,
				listClassName: ConversationRoot_module_css_default.viewsMoreMenu,
				anchor: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
					label,
					portal: true,
					children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						size: "sm",
						className: clsx(ConversationRoot_module_css_default.viewsMore, current && ConversationRoot_module_css_default.viewsMoreActive),
						"aria-label": label,
						"aria-haspopup": "menu",
						"aria-expanded": open,
						onClick: () => {
							setOpen((value) => !value);
						},
						children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconEllipsisOutlineRegular, { size: 13 })
					})
				}),
				children: renderSlot("conversation.session.header.views.actions", {
					entries,
					onOpen,
					onPinnedChange,
					onDismiss
				})
			});
		}
		/** Approximate 13px text advance: full-width glyphs take one em, other glyphs about half. */
		const WIDE_GLYPH = /[\u1100-\u115F\u2E80-\uA4CF\uAC00-\uD7A3\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFF60\uFFE0-\uFFE6]/u;
		const WIDE_GLYPH_WIDTH = 13;
		const NARROW_GLYPH_WIDTH = 7;
		/** Mirrors the `.tabLabel` max-width in `ConversationRoot.module.css`. */
		const TAB_LABEL_MAX_WIDTH = 88;
		/** Estimate whether a View tab label exceeds its 88px cell. */
		function labelNeedsTooltip(label) {
			let width = 0;
			for (const glyph of label) width += WIDE_GLYPH.test(glyph) ? WIDE_GLYPH_WIDTH : NARROW_GLYPH_WIDTH;
			return width > TAB_LABEL_MAX_WIDTH;
		}
		/** One View tab label; its full-name tooltip is offered only when the text is expected to overflow. */
		function ViewTabLabel({ label }) {
			return (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
				label,
				portal: true,
				disabled: !labelNeedsTooltip(label),
				children: (0, react_jsx_runtime.jsx)("span", {
					className: ConversationRoot_module_css_default.tabLabel,
					children: label
				})
			});
		}
		function deriveAncestry(list, id) {
			const chain = [];
			const seen = /* @__PURE__ */ new Set();
			let cursor = id;
			while (cursor !== void 0) {
				if (seen.has(cursor)) break;
				seen.add(cursor);
				const summary = list.byId[cursor];
				if (summary === void 0) break;
				chain.unshift({
					id: summary.id,
					displayTitle: summary.displayTitle,
					subagent: summary.origin === "subagent"
				});
				if (summary.origin !== "subagent") break;
				cursor = summary.parentId;
			}
			return chain;
		}
		function equalBreadcrumbs(left, right) {
			return left.length === right.length && left.every((item, index) => {
				const other = right.at(index);
				return other !== void 0 && item.id === other.id && item.displayTitle === other.displayTitle;
			});
		}
		/**
		* Renders Session header chrome above the resident conversation scrollport.
		* @param props - Strict Session store, view ledger, navigation, render, and locale shares.
		* @returns Session navigation controls, with title and tabs after conversation starts.
		*/
		function ConversationSessionHeader({ sessionId, hideChrome, useSessions, useConversationViews, useStore, renderSlot, open, useContextMenu, selectView, setPinned, t, useEntryPins, useEntryActions }) {
			const { getTriggerProps } = useContextMenu();
			const tabs = useConversationViews((value) => value);
			const active = resolveActiveView(tabs, useStore((s) => s.view));
			const ancestry = useSessions((s) => deriveAncestry(s, sessionId), equalBreadcrumbs);
			const unpinned = useEntryPins((ids) => ids);
			const hasEntryActions = useEntryActions((registered) => registered);
			const showTabs = !hideChrome && tabs.length > 1;
			const tabRow = (0, react.useRef)(null);
			const [visibleViewLimit, setVisibleViewLimit] = (0, react.useState)(1);
			(0, react.useLayoutEffect)(() => {
				const row = tabRow.current;
				if (row === null || !hasEntryActions) return;
				const updateLimit = () => {
					setVisibleViewLimit(Math.max(1, Math.floor((row.clientWidth - 48) / 120)));
				};
				updateLimit();
				if (typeof ResizeObserver === "undefined") return;
				const observer = new ResizeObserver(updateLimit);
				observer.observe(row);
				return () => {
					observer.disconnect();
				};
			}, [showTabs, hasEntryActions]);
			const { visibleTabs, moreTabs } = (0, react.useMemo)(() => {
				const preferred = [...tabs.filter((tab) => tab.id === FIXED_VIEW_ID), ...tabs.filter((tab) => tab.id !== "chat" && !unpinned.includes(tab.id))];
				const visibleTabs = hasEntryActions ? preferred.slice(0, visibleViewLimit) : preferred;
				const visibleIds = new Set(visibleTabs.map((tab) => tab.id));
				return {
					visibleTabs,
					moreTabs: tabs.filter((tab) => !visibleIds.has(tab.id))
				};
			}, [
				tabs,
				unpinned,
				hasEntryActions,
				visibleViewLimit
			]);
			const currentInMore = moreTabs.some((tab) => tab.id === active?.id);
			return (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [(0, react_jsx_runtime.jsxs)("div", {
				className: ConversationRoot_module_css_default.titleRow,
				children: [!hideChrome && (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [(0, react_jsx_runtime.jsxs)("div", {
					className: ConversationRoot_module_css_default.titleCluster,
					children: [(0, react_jsx_runtime.jsxs)("nav", {
						className: ConversationRoot_module_css_default.crumbs,
						"aria-label": t("session.hierarchy"),
						children: [ancestry.map((summary, index) => {
							const last = index === ancestry.length - 1;
							const title = last ? (0, react_jsx_runtime.jsx)("span", {
								className: clsx(ConversationRoot_module_css_default.crumb, summary.subagent && ConversationRoot_module_css_default.crumbSubagent, ConversationRoot_module_css_default.crumbCurrent),
								children: summary.displayTitle
							}) : (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								className: clsx(ConversationRoot_module_css_default.crumb, summary.subagent && ConversationRoot_module_css_default.crumbSubagent),
								onClick: () => {
									open(summary.id);
								},
								children: summary.displayTitle
							});
							const lineage = last || summary.subagent;
							const lineageOwner = {
								lineageSessionId: summary.id,
								displayTitle: summary.displayTitle,
								...last ? {} : { openTitle: () => {
									open(summary.id);
								} }
							};
							return (0, react_jsx_runtime.jsxs)("span", {
								className: ConversationRoot_module_css_default.crumbSeg,
								...getTriggerProps({
									kind: "session",
									value: {
										sessionId: summary.id,
										displayTitle: summary.displayTitle
									}
								}),
								children: [index > 0 && (0, react_jsx_runtime.jsx)("span", {
									className: ConversationRoot_module_css_default.crumbSep,
									children: "/"
								}), lineage ? summary.subagent ? renderSlot("conversation.session.header.lineage", lineageOwner, { fallback: title }) : (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [title, renderSlot("conversation.session.header.lineage", lineageOwner, { fallback: null })] }) : title]
							}, summary.id);
						}), ancestry.length === 0 && (0, react_jsx_runtime.jsx)("span", {
							className: ConversationRoot_module_css_default.crumbCurrent,
							children: sessionId
						})]
					}), (0, react_jsx_runtime.jsx)("div", {
						className: ConversationRoot_module_css_default.headerActions,
						children: renderSlot("conversation.session.header.actions", {})
					})]
				}), (0, react_jsx_runtime.jsx)("div", {
					className: ConversationRoot_module_css_default.headerUtilities,
					children: renderSlot("conversation.session.header.utilities", {})
				})] }), (0, react_jsx_runtime.jsx)("div", {
					className: ConversationRoot_module_css_default.headerCorner,
					"data-conversation-header-corner": "",
					children: renderSlot("conversation.session.header.corner", {})
				})]
			}), showTabs && (0, react_jsx_runtime.jsxs)("div", {
				ref: tabRow,
				className: ConversationRoot_module_css_default.tabs,
				children: [(0, react_jsx_runtime.jsx)("div", {
					className: ConversationRoot_module_css_default.viewTabs,
					role: "tablist",
					"data-conversation-tabs": "",
					children: visibleTabs.map((viewTab) => (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": viewTab.id === active?.id,
						className: clsx(ConversationRoot_module_css_default.tab, viewTab.id === active?.id && ConversationRoot_module_css_default.tabActive),
						onClick: () => {
							selectView(viewTab.id);
						},
						children: (0, react_jsx_runtime.jsx)(ViewTabLabel, { label: viewTab.label })
					}, viewTab.id))
				}), hasEntryActions && (0, react_jsx_runtime.jsx)(ViewsMoreMenu, {
					label: t("session.moreViews"),
					current: currentInMore,
					entries: moreTabs.map((viewTab) => ({
						id: viewTab.id,
						label: viewTab.label,
						pinned: !unpinned.includes(viewTab.id),
						active: viewTab.id === active?.id
					})),
					onOpen: selectView,
					onPinnedChange: setPinned,
					renderSlot
				})]
			})] });
		}
		/**
		* Renders the active Session view inside the resident scrollport and keeps
		* the input draft mirrored while blank Hero chrome is visible.
		* @param props - Strict Session input/store, view ledger, and render shares.
		* @returns the active view area, or null while the Session remains blank.
		*/
		function ConversationSession(props) {
			return (0, react_jsx_runtime.jsx)(DefaultConversationViews, { ...props });
		}
		//#endregion
		//#region lib/types/client/input/editor/ComposerContentEditable.js
		/**
		* The composer's contenteditable host: binds one shell-owned Lexical editor
		* to a resident div. Session-maybe by design — a null editor renders the
		* same DOM inert (the no-session Workspace-trigger state), so switching
		* between the two never swaps the element tree. Editability has ONE writer:
		* this component reflects the `editable` prop onto the editor; nothing else
		* calls setEditable.
		*/
		/**
		* Render the composer's editable surface.
		* @param props - editor binding, editability, and div passthroughs.
		* @returns the resident contenteditable div.
		*/
		function ComposerContentEditable({ editor, editable, ...rest }) {
			const ref = (0, react.useRef)(null);
			(0, react.useLayoutEffect)(() => {
				const el = ref.current;
				if (editor === null || el === null) return;
				editor.setRootElement(el);
				return () => {
					editor.setRootElement(null);
				};
			}, [editor]);
			(0, react.useLayoutEffect)(() => {
				if (editor !== null) editor.setEditable(editable);
			}, [editor, editable]);
			return (0, react_jsx_runtime.jsx)("div", {
				ref,
				contentEditable: editor !== null && editable,
				suppressContentEditableWarning: true,
				role: "textbox",
				"aria-multiline": "true",
				"data-composer-input": true,
				...rest
			});
		}
		//#endregion
		//#region lib/types/client/input/editor/DecoratorPortals.js
		/**
		* Decorator render loop: portals every decorator node's React face into its
		* host element (what @lexical/react's composer does internally, scoped to
		* this composer's needs). Chip DOM identity rides the NodeKey — text edits
		* around a chip never remount its portal.
		*/
		/**
		* Render every decorator's React face into its editor host element.
		* @param props - the editor to observe.
		* @returns the live portal set.
		*/
		function DecoratorPortals({ editor }) {
			const [decorators, setDecorators] = react.useState(() => editor === null ? {} : editor.getDecorators());
			react.useLayoutEffect(() => {
				if (editor === null) return;
				setDecorators(editor.getDecorators());
				return editor.registerDecoratorListener((next) => {
					setDecorators(next);
				});
			}, [editor]);
			if (editor === null) return null;
			return (0, react_jsx_runtime.jsx)(react_jsx_runtime.Fragment, { children: Object.entries(decorators).map(([key, jsx]) => {
				const el = editor.getElementByKey(key);
				return el === null ? null : (0, react_dom.createPortal)(jsx, el, key);
			}) });
		}
		//#endregion
		//#region lib/types/client/input/editor/DraftEditor.js
		/**
		* Render the existing scrollport, editable surface, placeholder, and chip portals.
		* @param props - borrowed editor and presentation values; this component owns no Hooks.
		* @returns the existing text-area DOM without an additional wrapper.
		*/
		function DraftEditor({ classNames: css, editor, scrollRef, editable, editorDisabled, phase, placeholderText, ariaLabel, workspaceTrigger, workspacePickerOpen, onWorkspaceKeyDown, hint, showPlaceholder }) {
			return (0, react_jsx_runtime.jsx)("div", {
				ref: scrollRef,
				className: css.scroll,
				"data-input-scroll": true,
				children: (0, react_jsx_runtime.jsxs)(_deepseek_ai_dsh_client_ui_primitives.HoverCardGroup, {
					className: css.grow,
					children: [
						(0, react_jsx_runtime.jsx)(ComposerContentEditable, {
							editor: workspaceTrigger ? null : editor,
							editable,
							className: clsx(css.input, editorDisabled && css.inputDisabled),
							"data-phase": phase,
							"aria-disabled": editorDisabled || void 0,
							"data-placeholder": placeholderText,
							"aria-label": ariaLabel,
							"aria-haspopup": workspaceTrigger ? "menu" : void 0,
							"aria-expanded": workspaceTrigger ? workspacePickerOpen : void 0,
							tabIndex: workspaceTrigger ? 0 : void 0,
							onKeyDown: workspaceTrigger ? onWorkspaceKeyDown : void 0,
							style: hint === null ? void 0 : { "--dsh-composer-hint": JSON.stringify(hint) }
						}),
						showPlaceholder && (0, react_jsx_runtime.jsx)("div", {
							"aria-hidden": true,
							className: css.placeholder,
							"data-composer-placeholder": true,
							children: placeholderText
						}),
						(0, react_jsx_runtime.jsx)(DecoratorPortals, { editor: workspaceTrigger ? null : editor })
					]
				})
			});
		}
		//#endregion
		//#region lib/types/client/input/editor/keymap.js
		/** Composition state a keydown can trust (see the module doc's Safari note). */
		function isComposingEvent(event, recentlyComposing) {
			return event.isComposing || event.keyCode === 229 || recentlyComposing();
		}
		function isApplePlatform() {
			return typeof navigator !== "undefined" && /Mac|iPod|iPhone|iPad/.test(navigator.platform);
		}
		/** Whether the browser caret touches one side of an atomic quote element. */
		function domCaretTouches(element, backward) {
			const selection = element.ownerDocument.defaultView?.getSelection();
			if (selection === null || selection === void 0 || !selection.isCollapsed) return false;
			const focus = selection.focusNode;
			if (focus === null) return false;
			const parent = element.parentNode;
			if (parent === null) return false;
			const offset = selection.focusOffset;
			if (focus === parent) return focus.childNodes.item(backward ? offset - 1 : offset) === element;
			if (focus.nodeType === Node.TEXT_NODE) {
				const size = focus.textContent?.length ?? 0;
				if (backward ? offset !== 0 : offset !== size) return false;
			} else if (backward ? offset !== 0 : offset !== focus.childNodes.length) return false;
			let boundary = focus;
			while (boundary.parentNode !== null && boundary.parentNode !== parent) {
				if ((backward ? boundary.previousSibling : boundary.nextSibling) !== null) return false;
				boundary = boundary.parentNode;
			}
			return boundary.parentNode === parent && (backward ? boundary.previousSibling : boundary.nextSibling) === element;
		}
		/** Find an atomic quote immediately beside both editor and browser carets. */
		function adjacentQuote(editor, backward) {
			const selection = Kr();
			if (!ur(selection) || !selection.isCollapsed()) return null;
			const adjacent = kl(selection.focus, backward);
			if (!$isQuoteNode(adjacent)) return null;
			const element = editor.getElementByKey(adjacent.getKey());
			return element !== null && domCaretTouches(element, backward) ? adjacent : null;
		}
		function lineLeadingQuoteBeforeSelection(editor) {
			let quote = adjacentQuote(editor, true);
			if (quote === null) return null;
			let previous = quote.getPreviousSibling();
			while (previous !== null) {
				if (Yi(previous)) return quote;
				if ($isQuoteNode(previous)) {
					quote = previous;
					previous = previous.getPreviousSibling();
					continue;
				}
				if (!Xo(previous)) return null;
				const text = previous.getTextContent();
				const lastBreak = text.lastIndexOf("\n");
				if (lastBreak >= 0) return text.slice(lastBreak + 1) === "" ? quote : null;
				if (text.trim() !== "") return null;
				const precedingQuote = previous.getPreviousSibling();
				if (!$isQuoteNode(precedingQuote)) return null;
				quote = precedingQuote;
				previous = quote.getPreviousSibling();
			}
			return quote;
		}
		/** Put the browser caret before an adjacent line-leading quote. */
		function moveBeforeQuote(editor, event) {
			if (event.shiftKey) return false;
			const quote = lineLeadingQuoteBeforeSelection(editor);
			if (quote === null) return false;
			const element = editor.getElementByKey(quote.getKey());
			if (element === null) return false;
			const view = element.ownerDocument.defaultView;
			if (view === null) return false;
			const domSelection = view.getSelection();
			if (domSelection === null) return false;
			const range = element.ownerDocument.createRange();
			range.setStartBefore(element);
			range.collapse(true);
			domSelection.removeAllRanges();
			domSelection.addRange(range);
			event.preventDefault();
			return true;
		}
		/** Move from immediately before a quote to the end of its hard line. */
		function movePastQuote(editor, event) {
			if (!isApplePlatform() || event.key !== "ArrowRight" || !event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return false;
			const quote = adjacentQuote(editor, false);
			if (quote === null) return false;
			const block = quote.getParent();
			if (!Pi(block)) return false;
			let lineEnd = quote.getIndexWithinParent() + 1;
			while (lineEnd < block.getChildrenSize()) {
				const child = block.getChildAtIndex(lineEnd);
				if (Yi(child)) break;
				if (Xo(child)) {
					const hardBreak = child.getTextContent().indexOf("\n");
					if (hardBreak >= 0) {
						event.preventDefault();
						child.select(hardBreak, hardBreak);
						return true;
					}
				}
				lineEnd += 1;
			}
			event.preventDefault();
			block.select(lineEnd, lineEnd);
			return true;
		}
		/**
		* Register the composer keymap on one editor.
		* @param editor - the shell-owned editor.
		* @param handlers - bar-supplied behavior.
		* @returns the unregister disposer.
		*/
		function registerComposerKeymap(editor, handlers) {
			let composing = false;
			let composingUntil = 0;
			let rootElement = null;
			const syncComposition = () => {
				rootElement?.toggleAttribute("data-composer-composing", composing || editor.isComposing());
			};
			const onCompositionStart = () => {
				composing = true;
				syncComposition();
			};
			const onCompositionEnd = () => {
				composing = false;
				composingUntil = Date.now() + 10;
				editor.update(() => {}, { onUpdate: syncComposition });
			};
			const recentlyComposing = () => composing || Date.now() < composingUntil;
			const arrow = (key) => (event) => {
				const inComposition = event !== null && isComposingEvent(event, recentlyComposing);
				if (handlers.arbitrate(key, inComposition) !== "pass") {
					event?.preventDefault();
					return true;
				}
				return false;
			};
			return Eu(editor.registerRootListener((root, prevRoot) => {
				prevRoot?.removeEventListener("compositionstart", onCompositionStart);
				prevRoot?.removeEventListener("compositionend", onCompositionEnd);
				prevRoot?.removeAttribute("data-composer-composing");
				composing = false;
				composingUntil = 0;
				rootElement = root;
				root?.addEventListener("compositionstart", onCompositionStart);
				root?.addEventListener("compositionend", onCompositionEnd);
				syncComposition();
			}), editor.registerCommand(tn$2, (event) => {
				if (!isApplePlatform() || !event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return false;
				if (event.key.toLowerCase() === "a") return moveBeforeQuote(editor, event);
				return false;
			}, 4), editor.registerCommand(nn$2, (event) => movePastQuote(editor, event), 4), editor.registerUpdateListener(syncComposition), editor.registerCommand(sn$2, arrow("up"), 4), editor.registerCommand(ln$2, arrow("down"), 4), editor.registerCommand(hn$2, (event) => arrow(event.shiftKey ? "tabBack" : "tab")(event), 4), editor.registerCommand(fn$1, (event) => {
				handlers.dismissPopup();
				if (handlers.arbitrate("escape", isComposingEvent(event, recentlyComposing)) === "consumed") {
					event.preventDefault();
					return true;
				}
				return false;
			}, 4), editor.registerCommand(an$1, (event) => {
				if (isComposingEvent(event, recentlyComposing)) return false;
				if (handlers.space()) {
					event.preventDefault();
					return true;
				}
				return false;
			}, 4), editor.registerCommand(cn$1, (event) => {
				if (event !== null && (event.altKey || event.getModifierState("AltGraph") || event.ctrlKey && event.metaKey || event.shiftKey && (event.ctrlKey || event.metaKey))) return true;
				if (event?.shiftKey === true) return false;
				if (event !== null && isComposingEvent(event, recentlyComposing)) return true;
				if (handlers.arbitrate("enter", false) !== "pass") {
					event?.preventDefault();
					return true;
				}
				event?.preventDefault();
				if (event?.repeat === true) return true;
				if (!handlers.canSubmit()) return true;
				handlers.submit(event?.ctrlKey === true || event?.metaKey === true);
				return true;
			}, 4), editor.registerCommand(Je$2, (event) => {
				const clipboardData = event.clipboardData ?? null;
				if (clipboardData === null) return false;
				const files = [];
				const directories = /* @__PURE__ */ new Set();
				for (const item of clipboardData.items) {
					if (item.kind !== "file") continue;
					const file = item.getAsFile();
					if (file === null) continue;
					files.push(file);
					if (typeof item.webkitGetAsEntry === "function" && item.webkitGetAsEntry()?.isDirectory === true) directories.add(file);
				}
				if (files.length > 0) handlers.intakeFiles(files, directories.size === 0 ? void 0 : directories);
				const text = clipboardData.getData("text/plain");
				if (text === "") {
					if (files.length === 0) return false;
					event.preventDefault();
					return true;
				}
				event.preventDefault();
				handlers.pasteText(text);
				return true;
			}, 4));
		}
		//#endregion
		//#region lib/types/client/input/editor/view-binding.js
		/**
		* Transfer mobile editor focus after a submission empties the draft.
		* A control the user already focused retains focus.
		* @param editor - the Session-owned editor.
		* @param destination - stable, focusable non-text element that retains the composer's keyboard position.
		* @returns the update-listener cleanup.
		*/
		function installDraftKeyboardDismissal(editor, destination) {
			return editor.registerUpdateListener(({ editorState, tags }) => {
				if (!tags.has("dsh-draft-submitted") || !(0, _deepseek_ai_dsh_client_ui_primitives.isMobileDevice)()) return;
				const input = editor.getRootElement();
				if (input === null || input.ownerDocument.activeElement !== input) return;
				if (editorState.read(() => nl().getTextContentSize() === 0) && destination.current !== null) (0, _deepseek_ai_dsh_client_ui_primitives.focusWithoutRing)(destination.current, { preventScroll: true });
			});
		}
		/**
		* Reveal the DOM selection within the draft's own scrollport.
		* @param scrollRef - the InputBar-owned scrollport reference.
		*/
		function revealDraftSelection(scrollRef) {
			const scrollEl = scrollRef.current;
			if (scrollEl === null || scrollEl.scrollHeight <= scrollEl.clientHeight) return;
			const selection = window.getSelection();
			if (selection === null || selection.rangeCount === 0) return;
			let rect = selection.getRangeAt(0).getBoundingClientRect();
			if (rect.height === 0 && rect.width === 0) {
				const anchor = selection.anchorNode;
				const el = anchor instanceof HTMLElement ? anchor : anchor?.parentElement;
				if (el === void 0 || el === null) return;
				rect = el.getBoundingClientRect();
			}
			const box = scrollEl.getBoundingClientRect();
			if (rect.bottom > box.bottom) scrollEl.scrollTop += rect.bottom - box.bottom;
			else if (rect.top < box.top) scrollEl.scrollTop -= box.top - rect.top;
		}
		/**
		* Focus the borrowed editor and reveal its restored selection.
		* @param editor - the Session-owned editor.
		* @param revealSelection - reveal the selection after Lexical restores it.
		*/
		function focusDraftEditor(editor, revealSelection) {
			editor.getRootElement()?.focus({ preventScroll: true });
			editor.focus(() => {
				revealSelection();
			});
		}
		/**
		* Forward wheel movement at the draft's edge to its conversation scrollport.
		* @param scrollRef - the InputBar-owned scrollport reference.
		* @returns the listener cleanup, or undefined when the element is absent.
		*/
		function installDraftWheel(scrollRef) {
			const el = scrollRef.current;
			if (el === null) return;
			const onWheel = (e) => {
				const host = el.closest("[data-conversation-scroll]");
				if (!(host instanceof HTMLElement) || e.deltaY === 0) return;
				const atTop = el.scrollTop <= 0;
				const atEnd = el.scrollTop + el.clientHeight >= el.scrollHeight - 1;
				if (e.deltaY < 0 && !atTop || e.deltaY > 0 && !atEnd) return;
				e.preventDefault();
				host.scrollTop += e.deltaY;
			};
			el.addEventListener("wheel", onWheel, { passive: false });
			return () => {
				el.removeEventListener("wheel", onWheel);
			};
		}
		/**
		* Bind this view's file dialog through the existing keyboard face.
		* @param keyboard - the Session-owned composer operations.
		* @param gate - live intake availability retained by InputBar.
		* @param fileInputRef - the view's native file input.
		* @returns the picker unbind disposer.
		*/
		function installDraftFilePicker(keyboard, gate, fileInputRef) {
			return keyboard.bindFilePicker({
				available: () => gate.current.canAcceptDrop && fileInputRef.current !== null && !fileInputRef.current.disabled,
				open: () => {
					fileInputRef.current?.click();
				}
			});
		}
		/**
		* Bind editor gestures to the view's live guards and Session operations.
		* @param editor - the borrowed Session-owned editor.
		* @param keyboard - the existing composer keyboard operations.
		* @param gate - live view values read by the installed handlers.
		* @returns the keymap disposer.
		*/
		function installDraftKeymap(editor, keyboard, gate) {
			return registerComposerKeymap(editor, {
				arbitrate: (key, composing) => keyboard.arbitrate(key, composing),
				space: () => {
					if (gate.current.machineBusy || gate.current.locked) return false;
					return keyboard.space();
				},
				dismissPopup: () => {
					keyboard.dismissPopup();
				},
				canSubmit: () => !gate.current.locked && !gate.current.machineBusy,
				submit: (accelerated) => {
					const g = gate.current;
					if (accelerated && g.canSteerQueue) {
						keyboard.steerQueue();
						return;
					}
					if (g.uploadsPending) {
						g.showToast(g.uploadsHeldText);
						return;
					}
					keyboard.submit(resolveSubmitMode(g.busyEnter, g.running, accelerated ? "accelerated" : "enter", g.steeringAvailable), "enter");
				},
				intakeFiles: (files, directories) => {
					gate.current.intakeFiles(files, directories);
				},
				pasteText: (text) => {
					if (gate.current.machineBusy || gate.current.locked) return;
					keyboard.paste(text);
				}
			});
		}
		/**
		* Keep a toolbar press from moving focus away from the draft.
		* @param event - the toolbar button's mouse event.
		* @param editor - the borrowed editor, absent in the inert view.
		*/
		function keepDraftFocus(event, editor) {
			event.preventDefault();
			editor?.getRootElement()?.focus({ preventScroll: true });
		}
		//#endregion
		//#region lib/types/client/image-labels.js
		/** Attachment error and limit copy owned by the conversation input flow. */
		/**
		* Byte count as user-facing megabytes (`10MB`, `2.5MB`).
		* @param bytes - the byte count.
		* @returns the rounded megabyte text.
		*/
		function imageSizeText(bytes) {
			const mb = bytes / (1024 * 1024);
			return `${Number.isInteger(mb) ? String(mb) : mb.toFixed(1)}MB`;
		}
		/**
		* Product copy for a host attachment rejection (the `details.reason` of
		* `session/attachment-invalid` or `subagent/attachment-invalid`).
		* User-solvable reasons name the limit and the way out;
		* reasons the user cannot act on fold into one send-failed line carrying the
		* reason code for a bug report.
		* @param t - the conversation-namespace translate.
		* @param reason - the wire `details.reason` code.
		* @param limits - projected limits interpolated into count/size copy, when known.
		* @returns the banner text.
		*/
		function attachmentErrorText(t, reason, limits) {
			switch (reason) {
				case "MODEL_DOES_NOT_SUPPORT_IMAGES": return t("image.modelUnsupported");
				case "FILE_NOT_STAGED": return t("file.notStaged");
				case "IMAGE_TOO_MANY_PIXELS": return t("image.tooManyPixels");
				case "IMAGE_DIMENSION_TOO_LARGE":
					if (limits !== void 0) return t("image.dimensionTooLarge", { size: limits.maxImageDimension });
					break;
				case "INVALID_IMAGE":
				case "IMAGE_TYPE_MISMATCH": return t("image.unsupportedType");
				case "TOO_MANY_IMAGES":
					if (limits !== void 0) return t("image.tooMany", { count: limits.maxImagesPerMessage });
					break;
				case "IMAGE_TOO_LARGE":
					if (limits !== void 0) return t("image.fileTooLarge", { size: imageSizeText(limits.maxImageBytes) });
					break;
				case "IMAGES_TOO_LARGE":
					if (limits !== void 0) return t("image.totalTooLarge", { size: imageSizeText(limits.maxMessageImageBytes) });
					break;
				default: break;
			}
			return t("image.sendFailed", { reason });
		}
		//#endregion
		//#region lib/types/client/context-occupancy.js
		/**
		* Resolve bounded display occupancy from independently updated pressure fields.
		* @param pressure - latest token-meter projection.
		* @returns occupancy, or null until numerator and capacity are known.
		*/
		function contextOccupancy(pressure) {
			const usedTokens = pressure?.projectedTokens ?? pressure?.pressureTokens;
			if (usedTokens === void 0 || pressure?.contextWindow === void 0) return null;
			return {
				percent: Math.min(100, Math.round(usedTokens / pressure.contextWindow * 100)),
				usedTokens,
				contextWindow: pressure.contextWindow
			};
		}
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/skeleton/ContextMeter.module.css.mjs
		const css$2 = ".JObwrW_root{flex:none;display:inline-flex}.JObwrW_trigger{border-radius:var(--dsw-radius-sm);color:var(--dsw-alias-label-tertiary);font-family:inherit;font-size:var(--dsh-content-font-size-secondary,13px);font-variant-numeric:tabular-nums;line-height:calc(20px + var(--dsh-content-font-delta-secondary,0px));white-space:nowrap;cursor:pointer;background:0 0;border:none;flex:none;align-items:center;gap:6px;padding:1px 8px;display:inline-flex}.JObwrW_trigger[aria-expanded=true]{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}@media (hover:hover){.JObwrW_trigger:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}}.JObwrW_track{fill:none;stroke:var(--dsw-alias-border-l3);stroke-width:2px}.JObwrW_fill{fill:none;stroke:var(--dsw-alias-label-tertiary);stroke-width:2px;stroke-linecap:round}.JObwrW_panel{z-index:1100;box-sizing:border-box;border-radius:var(--dsw-radius-lg);background:var(--dsw-specific-menu);width:min(264px,100vw - 24px);backdrop-filter:var(--dsw-menu-backdrop-filter);--dsw-elevation-stroke-color:var(--dsw-alias-border-l1);box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-secondary);cursor:default;max-width:var(--dsh-anchored-max-width,none);max-height:var(--dsh-anchored-max-height,none);--dsh-scrollbar-thumb:var(--dsw-alias-scrollbar-bg-l2);--dsh-scrollbar-thumb-hover:var(--dsw-alias-scrollbar-hover-l2);border:0;padding:12px;font-size:12px;line-height:20px;position:fixed;overflow:hidden auto}.JObwrW_header{align-items:center;gap:6px;display:flex}.JObwrW_figures{font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-primary);margin-left:auto;font-weight:500}.JObwrW_percent{color:var(--dsw-alias-label-primary);font-weight:500}.JObwrW_headline{color:var(--dsw-alias-label-tertiary)}.JObwrW_headline:empty{display:none}.JObwrW_bar{corner-shape:round;background:var(--dsw-alias-interactive-bg-hover);border-radius:999px;gap:1px;height:4px;margin:10px 0 12px;display:flex;overflow:hidden}.JObwrW_segment{background:var(--meter-tint,var(--dsw-alias-label-tertiary));border-radius:1px;flex:none;min-width:2px;height:100%}.JObwrW_swatch{background:var(--meter-tint);vertical-align:baseline;border-radius:2px;width:8px;height:8px;margin-right:6px;display:inline-block}.JObwrW_colorSystem{--meter-tint:var(--dsw-static-neutral-bluish-400)}.JObwrW_colorTools{--meter-tint:#a78bfa}.JObwrW_colorMessages{--meter-tint:var(--dsw-static-blue-450)}.JObwrW_rows{margin:6px 0 0}.JObwrW_row{justify-content:space-between;align-items:center;gap:12px;padding:2px 0;display:flex}.JObwrW_row dt{color:var(--dsw-alias-label-secondary)}.JObwrW_row dd{font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-primary);margin:0}";
		const tagId$2 = "@deepseek-ai/dsh-client-ui-conversation/ContextMeter.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$2) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$2;
			tag.textContent = css$2;
			document.head.appendChild(tag);
		}
		var ContextMeter_module_css_default = {
			"bar": "JObwrW_bar",
			"colorMessages": "JObwrW_colorMessages",
			"colorSystem": "JObwrW_colorSystem",
			"colorTools": "JObwrW_colorTools",
			"figures": "JObwrW_figures",
			"fill": "JObwrW_fill",
			"header": "JObwrW_header",
			"headline": "JObwrW_headline",
			"panel": "JObwrW_panel",
			"percent": "JObwrW_percent",
			"root": "JObwrW_root",
			"row": "JObwrW_row",
			"rows": "JObwrW_rows",
			"segment": "JObwrW_segment",
			"swatch": "JObwrW_swatch",
			"track": "JObwrW_track",
			"trigger": "JObwrW_trigger"
		};
		//#endregion
		//#region lib/types/client/skeleton/ContextMeter.js
		/** Composer context-occupancy meter: a ring and percentage below the card fed by the
		* `contextPressure` projection, with a click-open panel of the heuristic
		* `contextBreakdown` composition (system prompt, tools, conversation).
		* Renders nothing until a provider reports both pressure and a route
		* capacity. */
		/** Ring geometry: 14px viewBox, 2px stroke. */
		const RADIUS = 5.5;
		const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
		/**
		* Marker the localized occupancy sentence is split on, so the panel headline
		* keeps the reading in its own tone while each locale still owns the word
		* order (`45% of context used` / `上下文已用 45%`).
		*/
		const READING_SLOT = "\0";
		/** Panel legend rows, in bar-segment order; each color class carries the shared swatch/segment tint. */
		const ROWS = [
			{
				key: "systemTokens",
				label: "context.system",
				color: ContextMeter_module_css_default.colorSystem
			},
			{
				key: "toolsTokens",
				label: "context.tools",
				color: ContextMeter_module_css_default.colorTools
			},
			{
				key: "messageTokens",
				label: "context.messages",
				color: ContextMeter_module_css_default.colorMessages
			}
		];
		/**
		* Format a token count for the compact context panel.
		* @param value - token count.
		* @param t - Conversation locale seat with shared compact-number templates.
		* @returns Compact localized count using K or M when needed.
		*/
		function formatTokens(value, t) {
			const scaled = (candidate) => candidate >= 100 ? String(Math.round(candidate)) : String(Math.round(candidate * 10) / 10);
			if (value < 1e3) return String(value);
			if (value < 1e6) return t("number.thousand", { value: scaled(value / 1e3) });
			return t("number.million", { value: scaled(value / 1e6) });
		}
		function ContextMeter({ useProjection, t }) {
			const pressure = useProjection("contextPressure");
			const breakdown = useProjection("contextBreakdown");
			const [open, setOpen] = (0, react.useState)(false);
			const rootRef = (0, react.useRef)(null);
			const panelRef = (0, react.useRef)(null);
			const context = contextOccupancy(pressure);
			const available = context !== null;
			const position = (0, _deepseek_ai_dsh_client_ui_primitives.useAnchoredPosition)({
				open: open && available,
				anchorRef: rootRef,
				panelRef,
				side: "top",
				gap: 8,
				margin: 12
			});
			(0, _deepseek_ai_dsh_client_ui_primitives.useDismissOnOutsidePointer)(rootRef, open && available, setOpen, panelRef);
			(0, react.useEffect)(() => {
				if (!available && open) setOpen(false);
			}, [available, open]);
			(0, react.useEffect)(() => {
				if (!open || !available) return;
				const onKeyDown = (e) => {
					if (e.key === "Escape") setOpen(false);
				};
				document.addEventListener("keydown", onKeyDown);
				return () => {
					document.removeEventListener("keydown", onKeyDown);
				};
			}, [available, open]);
			if (context === null) return null;
			const percent = context.percent;
			const reading = `${percent}%`;
			const [headBefore = "", headAfter = ""] = t("context.aria", { percent: READING_SLOT }).split(READING_SLOT).map((part) => part.trim());
			const breakdownTotal = breakdown === void 0 ? 0 : breakdown.systemTokens + breakdown.toolsTokens + breakdown.messageTokens;
			const segments = (breakdown === void 0 || breakdownTotal === 0 ? [{
				key: "total",
				color: void 0,
				width: percent
			}] : ROWS.map((row) => ({
				key: row.key,
				color: row.color,
				width: percent * breakdown[row.key] / breakdownTotal
			}))).filter((part) => part.width > 0);
			return (0, react_jsx_runtime.jsxs)("span", {
				ref: rootRef,
				className: ContextMeter_module_css_default.root,
				children: [(0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
					label: t("context.aria", { percent: reading }),
					side: "top",
					delayMs: 200,
					disabled: open,
					portal: true,
					children: (0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						className: ContextMeter_module_css_default.trigger,
						"aria-label": t("context.aria", { percent: reading }),
						"aria-haspopup": "dialog",
						"aria-expanded": open,
						onClick: () => {
							setOpen(!open);
						},
						children: [(0, react_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 14 14",
							width: "14",
							height: "14",
							"aria-hidden": true,
							children: [(0, react_jsx_runtime.jsx)("circle", {
								className: ContextMeter_module_css_default.track,
								cx: "7",
								cy: "7",
								r: RADIUS
							}), (0, react_jsx_runtime.jsx)("circle", {
								className: ContextMeter_module_css_default.fill,
								cx: "7",
								cy: "7",
								r: RADIUS,
								strokeDasharray: `${CIRCUMFERENCE * percent / 100} ${CIRCUMFERENCE}`,
								transform: "rotate(-90 7 7)"
							})]
						}), (0, react_jsx_runtime.jsx)("span", { children: reading })]
					})
				}), open && (0, react_dom.createPortal)((0, react_jsx_runtime.jsxs)("div", {
					ref: panelRef,
					className: ContextMeter_module_css_default.panel,
					style: position ?? {
						visibility: "hidden",
						left: 0,
						top: 0
					},
					role: "dialog",
					"aria-label": t("context.used"),
					children: [
						(0, react_jsx_runtime.jsxs)("div", {
							className: ContextMeter_module_css_default.header,
							children: [
								(0, react_jsx_runtime.jsx)("span", {
									className: ContextMeter_module_css_default.headline,
									children: headBefore
								}),
								(0, react_jsx_runtime.jsx)("span", {
									className: ContextMeter_module_css_default.percent,
									children: reading
								}),
								(0, react_jsx_runtime.jsx)("span", {
									className: ContextMeter_module_css_default.headline,
									children: headAfter
								}),
								(0, react_jsx_runtime.jsx)("span", {
									className: ContextMeter_module_css_default.figures,
									children: `~${formatTokens(context.usedTokens, t)} / ${formatTokens(context.contextWindow, t)}`
								})
							]
						}),
						(0, react_jsx_runtime.jsx)("div", {
							className: ContextMeter_module_css_default.bar,
							children: segments.map((segment) => (0, react_jsx_runtime.jsx)("div", {
								className: segment.color === void 0 ? ContextMeter_module_css_default.segment : `${ContextMeter_module_css_default.segment} ${segment.color}`,
								style: { width: `${segment.width}%` }
							}, segment.key))
						}),
						breakdown !== void 0 && (0, react_jsx_runtime.jsx)("dl", {
							className: ContextMeter_module_css_default.rows,
							children: ROWS.map((row) => (0, react_jsx_runtime.jsxs)("div", {
								className: ContextMeter_module_css_default.row,
								children: [(0, react_jsx_runtime.jsxs)("dt", { children: [(0, react_jsx_runtime.jsx)("span", {
									className: `${ContextMeter_module_css_default.swatch} ${row.color}`,
									"aria-hidden": true
								}), t(row.label)] }), (0, react_jsx_runtime.jsx)("dd", { children: `~${formatTokens(breakdown[row.key], t)}` })]
							}, row.key))
						})
					]
				}), document.body)]
			});
		}
		//#endregion
		//#region lib/types/client/skeleton/control-row-layout.js
		/** Content-sized model collapse for the composer's two control groups. */
		/**
		* Collapse the model text only when the expanded controls cannot share a line.
		* The model seat consumes the row's inherited display variables; wrapping remains
		* available when even the icon cannot fit. Each notification is measured synchronously.
		* @param row - Composer control row with its leading and trailing groups.
		* @returns Disconnect the layout observers and font listener.
		*/
		function observeControlRow(row) {
			const measure = () => {
				row.removeAttribute("data-model-compact");
				const style = getComputedStyle(row);
				const available = row.getBoundingClientRect().width - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
				const widths = Array.from(row.children, (child) => child.getBoundingClientRect().width).filter((width) => width > 0);
				const needed = widths.reduce((sum, width) => sum + width, 0) + Math.max(0, widths.length - 1) * parseFloat(style.columnGap);
				row.toggleAttribute("data-model-compact", needed > available);
			};
			const resize = new ResizeObserver(measure);
			resize.observe(row);
			for (const child of row.children) resize.observe(child);
			const mutation = new MutationObserver(measure);
			mutation.observe(row, {
				subtree: true,
				childList: true,
				characterData: true,
				attributes: true,
				attributeFilter: ["hidden"]
			});
			const fonts = document.fonts;
			fonts.addEventListener("loadingdone", measure);
			measure();
			return () => {
				resize.disconnect();
				mutation.disconnect();
				fonts.removeEventListener("loadingdone", measure);
			};
		}
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/skeleton/InputBar.module.css.mjs
		const css$1 = ".uV2eYG_root{padding:0 var(--dsh-composer-side-clearance) 4px;flex-direction:column;align-items:center;display:flex}.uV2eYG_dock{justify-content:center;align-items:center;gap:12px;max-width:100%;padding-top:4px;display:flex}.uV2eYG_root:not(.uV2eYG_hero)>.uV2eYG_dock{min-height:calc(22px + var(--dsh-content-font-delta-secondary,0px))}.uV2eYG_hero .uV2eYG_dock:empty{display:none}.uV2eYG_hero{padding:0 var(--dsh-composer-side-clearance)}.uV2eYG_notice{width:100%;max-width:var(--dsh-composer-card-max-width);border-radius:var(--dsw-radius-md);background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary);margin-bottom:6px;padding:4px 8px;font-size:12px;line-height:18px}.uV2eYG_card{box-sizing:border-box;width:100%;max-width:var(--dsh-composer-card-max-width);--dsw-elevation-stroke-color:var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-panel);background:var(--dsw-specific-input-major);box-shadow:var(--dsw-elevation-soft);font-size:var(--dsh-content-font-size,14px);line-height:calc(24px + var(--dsh-content-font-delta,0px));--dsh-scrollbar-thumb:var(--dsw-alias-scrollbar-bg-l2);--dsh-scrollbar-thumb-hover:var(--dsw-alias-scrollbar-hover-l2);border:0;flex-direction:column;gap:12px;padding-top:8px;display:flex;position:relative}@media (pointer:coarse){.uV2eYG_card{font-size:max(16px, var(--dsh-content-font-size,14px))}}.uV2eYG_cardWorkspaceTrigger{--dsw-elevation-stroke-color:transparent;cursor:pointer}.uV2eYG_cardWorkspaceTrigger:after{content:\"\";box-sizing:border-box;border-radius:var(--dsw-radius-panel);color:var(--dsw-alias-border-l4);pointer-events:none;border:1px dashed;transition:color .1s;position:absolute;inset:0}.uV2eYG_cardWorkspaceTrigger :disabled{pointer-events:none}@media (hover:hover){.uV2eYG_cardWorkspaceTrigger:hover:after{color:var(--dsw-alias-state-business-primary)}}.uV2eYG_accessory{align-items:center;gap:8px;padding:10px 12px 0;display:flex}.uV2eYG_overlayAnchor{height:0;position:absolute;inset:0 0 auto}.uV2eYG_scroll{max-height:var(--dsh-composer-text-max-height);margin-right:4px;overflow-y:auto}.uV2eYG_scroll::-webkit-scrollbar-track{margin-top:8px}.uV2eYG_grow{position:relative}.uV2eYG_pending{corner-shape:round;background:var(--dsw-alias-state-business-primary);border-radius:50%;width:8px;height:8px;animation:1s ease-in-out infinite alternate uV2eYG_input-pending}@keyframes uV2eYG_input-pending{0%{opacity:.35}to{opacity:1}}.uV2eYG_input{box-sizing:border-box;min-height:36px;font-family:var(--dsw-font-family);font-size:inherit;line-height:inherit;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;color:var(--dsw-alias-label-primary);caret-color:var(--dsw-alias-state-business-primary);outline:none;padding:4px 8px 0 14px}.uV2eYG_input p{margin:0}.uV2eYG_input p:last-child:after{content:var(--dsh-composer-hint);color:var(--dsw-alias-label-caption)}.uV2eYG_input[data-composer-composing] p:last-child:after{content:none}.uV2eYG_input[data-composer-chip-selected]{caret-color:#0000}.uV2eYG_input[data-composer-composing]+.uV2eYG_placeholder{visibility:hidden}.uV2eYG_placeholder{color:var(--dsw-alias-label-caption);white-space:nowrap;text-overflow:ellipsis;pointer-events:none;user-select:none;position:absolute;inset:4px 8px auto 14px;overflow:hidden}.uV2eYG_inputDisabled{color:var(--dsw-alias-label-tertiary);cursor:not-allowed}.uV2eYG_input[aria-haspopup=menu]{cursor:pointer}.uV2eYG_hero .uV2eYG_input{min-height:52px}.uV2eYG_hero .uV2eYG_placeholder{white-space:normal;-webkit-line-clamp:2;line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box}.uV2eYG_row{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;min-width:0;padding:2px 8px 6px;display:flex;container-type:inline-size}.uV2eYG_row[data-model-compact]{--dsh-composer-model-text-display:none;--dsh-composer-model-icon-display:block}.uV2eYG_tools,.uV2eYG_modes,.uV2eYG_trailing{align-items:center;min-width:0;display:flex}.uV2eYG_tools,.uV2eYG_modes{gap:12px}.uV2eYG_trailing{flex:none;gap:12px;margin-left:auto}@container (width<=560px){.uV2eYG_tools,.uV2eYG_modes,.uV2eYG_trailing{gap:8px}}.uV2eYG_add{corner-shape:round;background:var(--dsw-specific-selector);width:28px;height:28px;color:var(--dsw-alias-label-primary);cursor:pointer;border:none;border-radius:999px;flex:none;place-items:center;display:grid}@media (hover:hover){.uV2eYG_add:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover-solid)}}.uV2eYG_add:disabled{opacity:.5;cursor:default}.uV2eYG_select{border-radius:var(--dsw-radius-sm);max-width:220px;height:28px;color:var(--dsw-alias-label-secondary);white-space:nowrap;cursor:pointer;appearance:none;background-color:#0000;background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12' fill='none'%3E%3Cpath d='M3 4.5L6 7.5L9 4.5' stroke='%2381858C' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E\");background-position:right 4px center;background-repeat:no-repeat;background-size:12px 12px;border:none;outline:none;padding:0 20px 0 8px;font-size:13px;font-weight:500;line-height:20px}@media (hover:hover){.uV2eYG_select:hover:not(:disabled){background-color:var(--dsw-alias-interactive-bg-hover)}}.uV2eYG_select:disabled{opacity:.5;cursor:default}.uV2eYG_primary{corner-shape:round;background:var(--dsw-alias-button-info-fill);color:#fff;cursor:pointer;border:none;border-radius:999px;flex:none;place-items:center;width:34px;height:34px;transition:background-color .1s;display:grid;transform:translateY(-2px)}@media (hover:hover){.uV2eYG_primary:hover:not(:disabled){background:var(--dsw-alias-button-info-hover)}}.uV2eYG_primary:disabled{opacity:.4;cursor:default}.uV2eYG_primary[data-sending]:disabled{opacity:1;cursor:progress}.uV2eYG_sendingSpinner{animation:.8s linear infinite uV2eYG_input-sending}@media (prefers-reduced-motion:reduce){.uV2eYG_sendingSpinner{animation-duration:2.4s}}@keyframes uV2eYG_input-sending{to{transform:rotate(360deg)}}.uV2eYG_retry{border-radius:var(--dsw-radius-sm);color:inherit;cursor:pointer;background:0 0;border:1px solid;margin-left:8px;padding:1px 8px;font-size:12px}.uV2eYG_standardControls{align-items:center;gap:12px;min-width:0;display:flex}.uV2eYG_tools[hidden],.uV2eYG_standardControls[hidden]{display:none}.uV2eYG_trailingActive{flex:1;margin-left:0}.uV2eYG_activity{flex:none;align-items:center;display:flex}.uV2eYG_activity:empty{display:none}.uV2eYG_activityExpanded{flex:1;min-width:0}";
		const tagId$1 = "@deepseek-ai/dsh-client-ui-conversation/InputBar.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId$1) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId$1;
			tag.textContent = css$1;
			document.head.appendChild(tag);
		}
		var InputBar_module_css_default = {
			"accessory": "uV2eYG_accessory",
			"activity": "uV2eYG_activity",
			"activityExpanded": "uV2eYG_activityExpanded",
			"add": "uV2eYG_add",
			"card": "uV2eYG_card",
			"cardWorkspaceTrigger": "uV2eYG_cardWorkspaceTrigger",
			"dock": "uV2eYG_dock",
			"grow": "uV2eYG_grow",
			"hero": "uV2eYG_hero",
			"input": "uV2eYG_input",
			"input-pending": "uV2eYG_input-pending",
			"input-sending": "uV2eYG_input-sending",
			"inputDisabled": "uV2eYG_inputDisabled",
			"modes": "uV2eYG_modes",
			"notice": "uV2eYG_notice",
			"overlayAnchor": "uV2eYG_overlayAnchor",
			"pending": "uV2eYG_pending",
			"placeholder": "uV2eYG_placeholder",
			"primary": "uV2eYG_primary",
			"retry": "uV2eYG_retry",
			"root": "uV2eYG_root",
			"row": "uV2eYG_row",
			"scroll": "uV2eYG_scroll",
			"select": "uV2eYG_select",
			"sendingSpinner": "uV2eYG_sendingSpinner",
			"standardControls": "uV2eYG_standardControls",
			"tools": "uV2eYG_tools",
			"trailing": "uV2eYG_trailing",
			"trailingActive": "uV2eYG_trailingActive"
		};
		//#endregion
		//#region lib/types/client/skeleton/InputBar.js
		/** The default composer body: the 'conversation.composer.bar' slot entry.
		* Machine state arrives through the standard provide channel
		* (useInput + inputActions); the keyboard/DOM command face and stop arrive
		* through this entry's own inject, whose hooks compartment binds
		* useNotices/useLexicon; layout-phase inputs (variant and placeholder) ride
		* the owner props. Session facts
		* (running/removed/promptError) are self-selected via useSession.
		*
		* The text surface is the shell-owned Lexical editor bound here through
		* ComposerContentEditable; chips render as decorator portals, and the
		* keymap registers submit/menu/paste gestures on the editor command layer.
		* The no-session state renders the SAME div inert as the Workspace-picker
		* trigger instead of a parallel tree.
		*/
		const InputBar = (0, react.memo)(function InputBar({ useSession, useInput, inputActions, keyboard, addFiles, removeAttachment, resolveDraftAttachments, retryFileUpload, toggleCommandMenu, stop, t, renderSlot, useBusyEnter, useFileUploads, useNotices, useLexicon, useMenuLauncher, useStopShortcut, useAccess, useProjection, sessionId, variant, disabled: inert = false, blocked, workspacePickerOpen = false, onRequestWorkspace, placeholder, accessory }) {
			const input = useInput((s) => s);
			const notice = useNotices((s) => s);
			const busyEnter = useBusyEnter((s) => s);
			const stopKeys = useStopShortcut((keys) => keys);
			const promptDenied = useAccess("session/prompt") === false;
			const cancelDenied = useAccess("session/cancel") === false;
			const uploadDenied = useAccess("fileUploads/upload") === false;
			const stopAction = cancelDenied ? void 0 : stop;
			const commandMenuOpen = useMenuLauncher((source) => source === "command");
			const [activity, setActivity] = (0, react.useState)(false);
			(0, react.useEffect)(() => {
				setActivity(false);
			}, [sessionId]);
			const promptError = useSession((s) => s.promptError) ?? null;
			const running = useSession((s) => s.running) ?? false;
			const subagent = useSession((s) => s.subagent) ?? null;
			const removed = useSession((s) => s.removed) ?? false;
			const planActive = useProjection("plan", (plan) => plan !== void 0 && (plan.pending ? !plan.active : plan.active));
			const hasGoal = useProjection("goal", (goal) => goal != null);
			const live = input !== void 0 && keyboard !== void 0 && inputActions !== void 0;
			const draft = input?.draft ?? "";
			const editor = keyboard?.editor ?? null;
			const attachments = (0, react.useMemo)(() => input === void 0 || resolveDraftAttachments === void 0 ? [] : resolveDraftAttachments(input.attachmentIds), [resolveDraftAttachments, input?.attachmentIds]);
			const empty = draft.trim() === "" && attachments.length === 0;
			const uploads = useFileUploads((snapshot) => snapshot);
			const uploadsPending = attachments.some((attachment) => attachment.kind === "file" ? uploads[attachment.id]?.status !== "ready" : uploads[attachment.id] !== void 0 && uploads[attachment.id]?.status !== "ready");
			const [toast, setToast] = (0, react.useState)(null);
			const toastSeq = (0, react.useRef)(0);
			const showToast = (0, react.useCallback)((text) => {
				toastSeq.current += 1;
				setToast({
					seq: toastSeq.current,
					text
				});
			}, []);
			const dismissToast = (0, react.useCallback)(() => {
				setToast(null);
			}, []);
			const imageLimits = useProjection("imageLimits");
			const failedUpload = attachments.map((attachment) => uploads[attachment.id]).find((upload) => upload?.status === "error");
			const uploadsHeldText = failedUpload?.status !== "error" ? t("file.stillUploading") : failedUpload.reason === void 0 ? t("file.uploadFailed") : attachmentErrorText(t, failedUpload.reason, imageLimits);
			(0, react.useEffect)(() => {
				if (promptError === null) return;
				const { error } = promptError;
				if (error.code === "session/writer-held") {
					showToast(t("error.sessionInUse"));
					return;
				}
				showToast(error.code === "session/attachment-invalid" || error.code === "subagent/attachment-invalid" ? attachmentErrorText(t, error.details.reason, imageLimits) : `${error.message} (${error.code})`);
			}, [
				promptError,
				showToast,
				t,
				imageLimits
			]);
			(0, react.useEffect)(() => {
				if (notice?.level === "error") showToast(notice.text);
			}, [notice, showToast]);
			const rowRef = (0, react.useRef)(null);
			(0, react.useLayoutEffect)(() => {
				const row = rowRef.current;
				if (row === null) return;
				return observeControlRow(row);
			}, []);
			const cardRef = (0, react.useRef)(null);
			const scrollRef = (0, react.useRef)(null);
			const continuable = subagent?.address.mode === "continuable";
			const parentOffline = continuable && subagent.parentAvailable !== true;
			const disabled = removed || inert || !live || blocked !== void 0 || parentOffline;
			const locked = disabled;
			const modelSeatLocked = removed || inert || !live;
			const machineBusy = input?.phase === "adjudicating" || input?.phase === "submitting" || input?.phase === "sending";
			const sending = input?.phase === "sending";
			const workspaceTrigger = inert && !removed && onRequestWorkspace !== void 0;
			const editorDisabled = removed || locked && !workspaceTrigger;
			const editable = live && !locked && !machineBusy;
			const steeringAvailable = subagent === null || subagent.address.mode === "continuable";
			const canSteerQueue = !locked && !machineBusy && !commandMenuOpen && empty && running && steeringAvailable && input.queue.length > 0;
			(0, react.useEffect)(() => {
				if (input === void 0 || inputActions === void 0) return;
				if (attachments.length !== input.attachmentIds.length) inputActions.pruneAttachments(attachments.map((attachment) => attachment.id));
			}, [
				attachments,
				input?.attachmentIds,
				inputActions
			]);
			const revealSelection = () => {
				revealDraftSelection(scrollRef);
			};
			(0, react.useEffect)(() => {
				if (locked || editor === null) return;
				if ((0, _deepseek_ai_dsh_client_ui_primitives.isMobileDevice)()) return;
				focusDraftEditor(editor, revealSelection);
			}, [
				locked,
				sessionId,
				editor
			]);
			const busyPhaseSeen = (0, react.useRef)(false);
			(0, react.useEffect)(() => {
				if (machineBusy) {
					busyPhaseSeen.current = true;
					return;
				}
				if (!busyPhaseSeen.current) return;
				busyPhaseSeen.current = false;
				if (locked || editor === null) return;
				if (document.activeElement !== null && document.activeElement !== document.body) return;
				if ((0, _deepseek_ai_dsh_client_ui_primitives.isMobileDevice)()) {
					if (cardRef.current !== null) (0, _deepseek_ai_dsh_client_ui_primitives.focusWithoutRing)(cardRef.current, { preventScroll: true });
				} else focusDraftEditor(editor, revealSelection);
			}, [machineBusy]);
			(0, react.useEffect)(() => {
				if (locked || draft === "") return;
				revealSelection();
			}, [draft !== ""]);
			(0, react.useEffect)(() => {
				return installDraftWheel(scrollRef);
			}, []);
			const intakeFiles = (0, react.useCallback)((files, directories) => {
				if (uploadDenied || locked || machineBusy || subagent !== null && !continuable || addFiles === void 0 || files.length === 0) return;
				const rejected = (() => {
					if (continuable && files.some((file) => directories?.has(file) || !isImageMediaType(file.type))) return t("image.unsupportedType");
					if (imageLimits !== void 0) {
						const mediaTypes = imageLimits.mediaTypes;
						const images = files.filter((file) => mediaTypes.includes(file.type));
						const imageAttachments = attachments.filter((attachment) => attachment.kind === "image");
						if (imageAttachments.length + images.length > imageLimits.maxImagesPerMessage) return t("image.tooMany", { count: imageLimits.maxImagesPerMessage });
						if (images.some((file) => file.size > imageLimits.maxImageBytes)) return t("image.fileTooLarge", { size: imageSizeText(imageLimits.maxImageBytes) });
						if (imageAttachments.reduce((sum, attachment) => sum + attachment.file.size, 0) + images.reduce((sum, file) => sum + file.size, 0) > imageLimits.maxMessageImageBytes) return t("image.totalTooLarge", { size: imageSizeText(imageLimits.maxMessageImageBytes) });
					}
					return addFiles(files, directories);
				})();
				if (rejected !== null) showToast(rejected);
			}, [
				uploadDenied,
				locked,
				machineBusy,
				subagent,
				continuable,
				addFiles,
				attachments,
				imageLimits,
				showToast,
				t
			]);
			const canAcceptDrop = !uploadDenied && (subagent === null || continuable) && !locked && !machineBusy && addFiles !== void 0;
			const fileInputRef = (0, react.useRef)(null);
			const onPickFiles = (e) => {
				const picked = e.target.files === null ? [] : [...e.target.files];
				e.target.value = "";
				if (picked.length > 0) intakeFiles(picked);
			};
			const gate = (0, react.useRef)({
				locked,
				machineBusy,
				canSteerQueue,
				running,
				steeringAvailable,
				busyEnter,
				intakeFiles,
				uploadsPending,
				uploadsHeldText,
				showToast,
				canAcceptDrop
			});
			gate.current = {
				locked,
				machineBusy,
				canSteerQueue,
				running,
				steeringAvailable,
				busyEnter,
				intakeFiles,
				uploadsPending,
				uploadsHeldText,
				showToast,
				canAcceptDrop
			};
			(0, react.useEffect)(() => {
				if (keyboard === void 0) return;
				return installDraftFilePicker(keyboard, gate, fileInputRef);
			}, [keyboard]);
			(0, react.useEffect)(() => {
				if (editor === null || keyboard === void 0) return;
				return installDraftKeymap(editor, keyboard, gate);
			}, [editor, keyboard]);
			(0, react.useEffect)(() => {
				if (editor === null) return;
				return installDraftKeyboardDismissal(editor, cardRef);
			}, [editor]);
			const keepFocus = (e) => {
				keepDraftFocus(e, editor);
			};
			const onCardMouseDown = (e) => {
				if (!editable || editor === null || e.button !== 0 || e.defaultPrevented) return;
				const target = e.target;
				if (!(target instanceof Element) || !e.currentTarget.contains(target)) return;
				if (target.closest("[data-composer-overlay]") !== null) return;
				if (scrollRef.current?.contains(target)) return;
				const control = target.closest("button, a, input, select, textarea, [role=\"button\"], [contenteditable], [tabindex]");
				if (control !== null && control !== e.currentTarget && e.currentTarget.contains(control)) return;
				e.preventDefault();
				if (document.activeElement !== editor.getRootElement()) focusDraftEditor(editor, revealSelection);
			};
			const onToggleCommandMenu = () => {
				if (keyboard === void 0) return;
				if (editor !== null) focusDraftEditor(editor, revealSelection);
				toggleCommandMenu?.(keyboard.caretSpan());
			};
			const onWorkspaceKeyDown = (e) => {
				if (!workspaceTrigger) return;
				if (e.key === "Enter" || e.key === " ") {
					e.preventDefault();
					onRequestWorkspace();
				}
			};
			const primaryStops = running && subagent === null && !sending && (empty || blocked !== void 0);
			const primaryDisabled = primaryStops ? stopAction === void 0 : empty || disabled || machineBusy || uploadsPending;
			const interruptible = running && (continuable || sending && subagent === null);
			const primarySubmitMode = resolveSubmitMode(busyEnter, running, "enter", steeringAvailable);
			const plainMessageDraft = !empty && input?.phase === "plain" && !draft.trimStart().startsWith("/");
			const primaryLabel = primaryStops ? t("input.stop") : sending ? t("input.sending") : running && steeringAvailable && !disabled && !uploadsPending && plainMessageDraft ? t(primarySubmitMode === "steer" ? "input.send.steer" : "input.send.queue") : t("input.send");
			const onPrimary = () => {
				if (primaryStops) {
					stopAction?.();
					return;
				}
				if (keyboard === void 0) return;
				/* v8 ignore next -- defensive: the primary button is disabled for empty, disabled, and pending-upload states. */
				if (!empty && !disabled && !machineBusy && !uploadsPending) keyboard.submit(primarySubmitMode, "click");
			};
			const claimActive = (input?.phase === "claimed" || input?.phase === "submitting") && input.claim !== void 0 && draft.startsWith(input.claim.token);
			const rawHint = claimActive && input.claim.hint !== void 0 && draft.slice(input.claim.token.length).trim() === "" ? input.claim.hint : null;
			const hint = (() => {
				if (rawHint === null) return null;
				const commandName = input?.claim?.name ?? "";
				const hintKey = `hint.${commandName === "goal" && hasGoal ? "goal.active" : commandName}`;
				const translated = t(hintKey);
				return translated !== hintKey ? translated : rawHint;
			})();
			const placeholderText = placeholder ?? (parentOffline ? t("placeholder.parentOffline") : disabled ? t("placeholder.unavailable") : canSteerQueue ? t("placeholder.steerQueue") : planActive ? t("placeholder.plan") : t("placeholder.default"));
			return (0, react_jsx_runtime.jsxs)("div", {
				className: clsx(InputBar_module_css_default.root, variant === "hero" && InputBar_module_css_default.hero),
				children: [
					toast !== null && (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: toast.text,
						icon: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconWarningOutlineRegular, {}),
						anchor: cardRef.current,
						onDone: dismissToast
					}, toast.seq),
					notice?.level === "info" && (0, react_jsx_runtime.jsx)("div", {
						className: InputBar_module_css_default.notice,
						role: "status",
						children: notice.text
					}),
					(0, react_jsx_runtime.jsxs)("div", {
						ref: cardRef,
						tabIndex: -1,
						className: clsx(InputBar_module_css_default.card, workspaceTrigger && InputBar_module_css_default.cardWorkspaceTrigger),
						"data-composer-card": true,
						onClick: workspaceTrigger ? onRequestWorkspace : void 0,
						onPointerDown: workspaceTrigger ? (e) => {
							e.stopPropagation();
						} : void 0,
						onMouseDown: onCardMouseDown,
						children: [
							sessionId !== void 0 && (0, react_jsx_runtime.jsx)("div", {
								className: InputBar_module_css_default.overlayAnchor,
								"data-composer-overlay": true,
								children: renderSlot("conversation.input.overlay", {})
							}),
							accessory !== void 0 && (0, react_jsx_runtime.jsx)("div", {
								className: InputBar_module_css_default.accessory,
								children: accessory
							}),
							renderSlot("conversation.input.attachments", {
								attachments,
								canAcceptDrop,
								onAddFiles: intakeFiles,
								onRemoveAttachment: (id) => {
									removeAttachment?.(id);
								},
								uploads,
								onRetryFile: (id) => {
									retryFileUpload?.(id);
								},
								uploadFailureText: (reason) => attachmentErrorText(t, reason, imageLimits),
								dropLimits: imageLimits === void 0 ? void 0 : {
									count: imageLimits.maxImagesPerMessage,
									size: imageSizeText(imageLimits.maxImageBytes)
								}
							}),
							(0, react_jsx_runtime.jsx)(DraftEditor, {
								classNames: InputBar_module_css_default,
								editor,
								scrollRef,
								editable,
								editorDisabled,
								phase: input?.phase ?? "inert",
								placeholderText,
								ariaLabel: workspaceTrigger ? t("hero.chooseWorkspace") : placeholderText,
								workspaceTrigger,
								workspacePickerOpen,
								onWorkspaceKeyDown,
								hint,
								showPlaceholder: draft === "" && attachments.length === 0 && !claimActive
							}),
							(0, react_jsx_runtime.jsxs)("div", {
								ref: rowRef,
								className: InputBar_module_css_default.row,
								children: [(0, react_jsx_runtime.jsxs)("div", {
									className: InputBar_module_css_default.tools,
									hidden: activity,
									children: [
										(0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
											label: t("input.commands"),
											side: "top",
											delayMs: 500,
											portal: true,
											children: (0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: InputBar_module_css_default.add,
												"aria-label": t("input.commands"),
												"aria-haspopup": "listbox",
												"aria-expanded": commandMenuOpen,
												disabled: locked || toggleCommandMenu === void 0,
												onMouseDown: keepFocus,
												onClick: onToggleCommandMenu,
												children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconPlusOutlineMedium, { size: 14 })
											})
										}),
										(0, react_jsx_runtime.jsx)("input", {
											ref: fileInputRef,
											type: "file",
											multiple: true,
											disabled: !canAcceptDrop || subagent !== null,
											hidden: true,
											onChange: onPickFiles
										}),
										(0, react_jsx_runtime.jsxs)("div", {
											className: InputBar_module_css_default.modes,
											children: [sessionId === void 0 ? null : renderSlot("conversation.input.permission", { locked }), sessionId === void 0 ? null : renderSlot("conversation.input.plan", { locked })]
										}),
										input === void 0 || sessionId === void 0 ? null : renderSlot("conversation.input.left", {})
									]
								}), (0, react_jsx_runtime.jsxs)("div", {
									className: clsx(InputBar_module_css_default.trailing, activity && InputBar_module_css_default.trailingActive),
									children: [
										(0, react_jsx_runtime.jsxs)("div", {
											className: InputBar_module_css_default.standardControls,
											hidden: activity,
											children: [input === void 0 || sessionId === void 0 ? null : renderSlot("conversation.input.right", {}), sessionId === void 0 ? null : renderSlot("conversation.input.model", { locked: modelSeatLocked })]
										}),
										input === void 0 || sessionId === void 0 ? null : (0, react_jsx_runtime.jsx)("div", {
											className: activity ? InputBar_module_css_default.activityExpanded : InputBar_module_css_default.activity,
											children: renderSlot("conversation.input.activity", {
												locked,
												onActiveChange: setActivity
											})
										}),
										interruptible && !cancelDenied && (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
											label: t("input.stop"),
											shortcutKeys: stopKeys,
											side: "top",
											delayMs: 500,
											disabled: stopAction === void 0,
											portal: true,
											children: (0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: InputBar_module_css_default.primary,
												"aria-label": t("input.stop"),
												disabled: stopAction === void 0,
												onMouseDown: keepFocus,
												onClick: stopAction,
												children: (0, react_jsx_runtime.jsx)("svg", {
													viewBox: "0 0 16 16",
													width: "16",
													height: "16",
													"aria-hidden": true,
													children: (0, react_jsx_runtime.jsx)("rect", {
														x: "3",
														y: "3",
														width: "10",
														height: "10",
														rx: "3",
														fill: "currentColor"
													})
												})
											})
										}),
										(primaryStops ? cancelDenied : promptDenied) ? null : (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
											label: primaryStops ? t("input.stop") : primaryLabel,
											shortcutKeys: primaryStops ? stopKeys : void 0,
											side: "top",
											delayMs: 500,
											disabled: primaryDisabled,
											portal: true,
											children: (0, react_jsx_runtime.jsx)("button", {
												type: "button",
												className: InputBar_module_css_default.primary,
												"aria-label": primaryLabel,
												"aria-busy": sending,
												"data-sending": sending ? "" : void 0,
												disabled: primaryDisabled,
												onMouseDown: keepFocus,
												onClick: onPrimary,
												children: primaryStops ? (0, react_jsx_runtime.jsx)("svg", {
													viewBox: "0 0 16 16",
													width: "16",
													height: "16",
													"aria-hidden": true,
													children: (0, react_jsx_runtime.jsx)("rect", {
														x: "3",
														y: "3",
														width: "10",
														height: "10",
														rx: "3",
														fill: "currentColor"
													})
												}) : sending ? (0, react_jsx_runtime.jsxs)("svg", {
													className: InputBar_module_css_default.sendingSpinner,
													viewBox: "0 0 16 16",
													width: "16",
													height: "16",
													"aria-hidden": true,
													children: [(0, react_jsx_runtime.jsx)("circle", {
														cx: "8",
														cy: "8",
														r: "6",
														fill: "none",
														stroke: "currentColor",
														strokeOpacity: "0.35",
														strokeWidth: "2"
													}), (0, react_jsx_runtime.jsx)("path", {
														d: "M8 2a6 6 0 0 1 6 6",
														fill: "none",
														stroke: "currentColor",
														strokeWidth: "2",
														strokeLinecap: "round"
													})]
												}) : (0, react_jsx_runtime.jsx)("svg", {
													viewBox: "0 0 16 16",
													width: "16",
													height: "16",
													"aria-hidden": true,
													children: (0, react_jsx_runtime.jsx)("path", {
														d: "M8.3125 0.980183C8.66767 1.0531 8.97902 1.20418 9.2627 1.43233C9.48724 1.61297 9.73029 1.85793 9.97949 2.10714L14.707 6.83468L13.293 8.24874L9 3.95577V15.0417H7V3.95577L2.70703 8.24874L1.29297 6.83468L6.02051 2.10714C6.26971 1.85793 6.51277 1.61297 6.7373 1.43233C6.97662 1.23986 7.28445 1.04402 7.6875 0.980183C7.8973 0.947006 8.1031 0.95516 8.3125 0.980183Z",
														fill: "currentColor"
													})
												})
											})
										})
									]
								})]
							})
						]
					}),
					(0, react_jsx_runtime.jsxs)("div", {
						className: InputBar_module_css_default.dock,
						"data-composer-dock": true,
						children: [variant === "composer" && input !== void 0 && sessionId !== void 0 ? renderSlot("conversation.composer.dock", {}) : null, activity ? null : (0, react_jsx_runtime.jsx)(ContextMeter, {
							useProjection,
							t
						})]
					})
				]
			});
		});
		//#endregion
		//#region \0dsh-css:/home/runner/work/deepseek-harness/deepseek-harness/packages/client/ui-conversation/src/client/skeleton/TodoPanel.module.css.mjs
		const css = ".lXshSW_root{box-sizing:border-box;width:calc(100% - var(--dsh-composer-side-clearance) - var(--dsh-composer-side-clearance) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));max-width:calc(var(--dsh-composer-card-max-width) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset) - var(--dsh-composer-dock-inset));--dsw-elevation-stroke-color:var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg);background:var(--dsw-specific-menu);backdrop-filter:var(--dsw-menu-backdrop-filter);box-shadow:var(--dsw-elevation-panel);--dsh-scrollbar-thumb:var(--dsw-alias-scrollbar-bg-l2);--dsh-scrollbar-thumb-hover:var(--dsw-alias-scrollbar-hover-l2);border:0;flex:none;margin:0 auto;overflow:hidden}.lXshSW_body{flex-direction:column;gap:8px;padding:6px 12px;display:flex}.lXshSW_header{text-align:left;cursor:pointer;background:0 0;border:none;align-items:center;gap:10px;width:100%;padding:0;display:flex}.lXshSW_lead{color:var(--dsw-alias-label-tertiary);flex:none;place-items:center;display:grid}.lXshSW_title{color:var(--dsw-alias-label-primary);flex:none;font-size:13px;font-weight:500;line-height:24px}.lXshSW_progress{min-width:0;color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap;flex:auto;font-size:13px;font-weight:400;line-height:20px;overflow:hidden}.lXshSW_chevron{color:var(--dsw-alias-label-tertiary);flex:none;place-items:center;display:grid}.lXshSW_list{flex-direction:column;gap:8px;max-height:180px;margin:0;padding:0;list-style:none;display:flex;overflow-y:auto}.lXshSW_item{min-width:0;color:var(--dsw-alias-label-secondary);align-items:center;gap:10px;font-size:13px;line-height:20px;display:flex}.lXshSW_glyph{flex:none;place-items:center;width:16px;height:16px;display:grid}.lXshSW_content{text-overflow:ellipsis;white-space:nowrap;min-width:0;overflow:hidden}";
		const tagId = "@deepseek-ai/dsh-client-ui-conversation/TodoPanel.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@deepseek-ai/dsh-client-ui-conversation";
			tag.dataset.pluginCss = tagId;
			tag.textContent = css;
			document.head.appendChild(tag);
		}
		var TodoPanel_module_css_default = {
			"body": "lXshSW_body",
			"chevron": "lXshSW_chevron",
			"content": "lXshSW_content",
			"glyph": "lXshSW_glyph",
			"header": "lXshSW_header",
			"item": "lXshSW_item",
			"lead": "lXshSW_lead",
			"list": "lXshSW_list",
			"progress": "lXshSW_progress",
			"root": "lXshSW_root",
			"title": "lXshSW_title"
		};
		//#endregion
		//#region lib/types/client/skeleton/TodoPanel.js
		/** Local exhaustiveness helper — client packages do not depend on `dsh-llm`. */
		/* v8 ignore next 3 -- closed-union backstop; only reached if status is forged */
		function assertNever(value) {
			throw new Error(`unreachable todo status: ${String(value)}`);
		}
		/** Map Todo lifecycle state onto the shared compact status language. */
		function statusDotState(status) {
			switch (status) {
				case "completed": return "done";
				case "in_progress": return "ongoing";
				case "pending": return "idle";
				/* v8 ignore next -- closed TodoItem status union */
				default: return assertNever(status);
			}
		}
		/** Return the localized status announced beside one decorative marker. */
		function statusLabel(status, t) {
			switch (status) {
				case "completed": return t("todo.status.completed");
				case "in_progress": return t("todo.status.inProgress");
				case "pending": return t("todo.status.pending");
				/* v8 ignore next -- closed TodoItem status union */
				default: return assertNever(status);
			}
		}
		/** Header summary: "·"-joined per-status counts; zero-count segments are omitted as noise (a non-empty list keeps at least one). */
		function progressLabel(todos, t) {
			const done = todos.filter((item) => item.status === "completed").length;
			const active = todos.filter((item) => item.status === "in_progress").length;
			const pending = todos.length - done - active;
			return [
				...done > 0 ? [t("todo.progress.done", { done })] : [],
				...active > 0 ? [t("todo.progress.active", { active })] : [],
				...pending > 0 ? [t("todo.progress.pending", { pending })] : []
			].join(" · ");
		}
		function TodoPanel({ todos, t }) {
			const [collapsed, setCollapsed] = (0, react.useState)(true);
			if (todos.length === 0) return null;
			return (0, react_jsx_runtime.jsx)("section", {
				className: TodoPanel_module_css_default.root,
				"data-testid": "todo-panel",
				"aria-label": t("todo.title"),
				children: (0, react_jsx_runtime.jsxs)("div", {
					className: TodoPanel_module_css_default.body,
					children: [(0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						className: TodoPanel_module_css_default.header,
						"aria-expanded": !collapsed,
						onClick: () => {
							setCollapsed((v) => !v);
						},
						children: [
							(0, react_jsx_runtime.jsx)("span", {
								className: TodoPanel_module_css_default.lead,
								"aria-hidden": true,
								children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChecklistOutlineRegular, {})
							}),
							(0, react_jsx_runtime.jsx)("span", {
								className: TodoPanel_module_css_default.title,
								children: t("todo.title")
							}),
							(0, react_jsx_runtime.jsx)("span", {
								className: TodoPanel_module_css_default.progress,
								children: progressLabel(todos, t)
							}),
							(0, react_jsx_runtime.jsx)("span", {
								className: TodoPanel_module_css_default.chevron,
								"aria-hidden": true,
								children: collapsed ? (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChevronUpOutlineRegular, {}) : (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChevronDownOutlineRegular, {})
							})
						]
					}), !collapsed && (0, react_jsx_runtime.jsx)("ul", {
						className: TodoPanel_module_css_default.list,
						children: todos.map((item) => (0, react_jsx_runtime.jsxs)("li", {
							className: TodoPanel_module_css_default.item,
							"data-status": item.status,
							children: [(0, react_jsx_runtime.jsx)("span", {
								className: TodoPanel_module_css_default.glyph,
								role: "img",
								"aria-label": statusLabel(item.status, t),
								children: (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, { state: statusDotState(item.status) })
							}), (0, react_jsx_runtime.jsx)("span", {
								className: TodoPanel_module_css_default.content,
								children: item.content
							})]
						}, item.content))
					})]
				})
			});
		}
		/** Renders the current todo projection, or nothing when it is absent. */
		function TodoDock({ useProjection, t }) {
			return (0, react_jsx_runtime.jsx)(TodoPanel, {
				todos: useProjection("todos") ?? [],
				t
			});
		}
		/** Registers the projected todo dock. */
		const todoDockEntry = {
			name: "conversation-todo-dock",
			inject: ["slots"],
			apply(ctx) {
				ctx.slots.inject("conversation.input.dock", () => ctx.slots.register({
					name: "conversation.input.dock",
					id: "todo",
					order: 0,
					locale: NS
				}, TodoDock));
			}
		};
		//#endregion
		//#region lib/types/client/stop-sequence.js
		/** One short-lived first press, cleared before an accepted cancellation runs. */
		var StopSequence = class {
			intervalMs;
			release;
			first;
			timer;
			/**
			* @param intervalMs - validated maximum time between independent presses.
			* @param release - releases observations retained by the pending first press.
			*/
			constructor(intervalMs, release) {
				this.intervalMs = intervalMs;
				this.release = release;
			}
			/** Clear the first press and its expiry timer. */
			reset() {
				this.first = void 0;
				clearTimeout(this.timer);
				this.timer = void 0;
				this.release();
			}
			/**
			* Accept one eligible, non-repeated Escape against freshly resolved current state.
			* @param target - live turn and actual focused input region.
			* @returns whether this press requested cancellation.
			*/
			press(target) {
				const first = this.first;
				this.reset();
				if (first !== void 0 && performance.now() <= first.deadline && first.target.sessionId === target.sessionId && first.target.turn === target.turn && first.target.generation === target.generation && first.target.region === target.region) {
					target.cancel();
					return true;
				}
				this.first = {
					target,
					deadline: performance.now() + this.intervalMs
				};
				this.timer = setTimeout(() => {
					this.reset();
				}, this.intervalMs + 1);
				return false;
			}
		};
		//#endregion
		//#region lib/types/client/stop-shortcut.js
		/**
		* Subscribe fixed input to the same Session cancellation used by the stop button.
		* @param shortcuts - window keyboard arbitration and validated sequence interval.
		* @param sessions - live Session identities and lifecycle sources.
		* @param openTurn - stable current-turn source for a live Session binding.
		* @param uiSession - current pending-interaction status.
		* @param cancel - scoped stop operation that preserves Queue and reports failures.
		* @returns disposer releasing the input subscription, pending watches and expiry timer.
		*/
		function installStopShortcut(shortcuts, sessions, openTurn, uiSession, cancel) {
			let unwatch = () => {};
			const sequence = new StopSequence(shortcuts.stopSequenceMs, () => {
				unwatch();
				unwatch = () => {};
			});
			const reset = () => {
				sequence.reset();
			};
			const off = shortcuts.observeFixedInput((input) => {
				if (input.type === "reset") {
					reset();
					return;
				}
				const { gesture, context } = input;
				if (gesture.code !== "Escape" || gesture.repeat || gesture.composing || gesture.defaultPrevented || gesture.control || gesture.alt || gesture.shift || gesture.meta || context.modal !== null || context.region === "terminal" || context.target === null) {
					reset();
					return;
				}
				const target = context.target;
				const occurrence = target.closest("[data-conversation-session]");
				const region = target.closest("[data-conversation-region]");
				if (occurrence === null || region === null || !occurrence.contains(region) || target.closest("[data-approval-key], iframe, .xterm, [inert]") !== null) {
					reset();
					return;
				}
				const sessionId = occurrence.dataset.conversationSession;
				const binding = sessions.binding(sessionId);
				if (binding === void 0) {
					reset();
					return;
				}
				const turnSource = openTurn(binding);
				const currentTurn = () => {
					const session = binding.session.getSnapshot();
					if (!session.running || session.removed || session.subagent !== null && session.subagent.address.mode !== "continuable" || uiSession.sessionStatus.getSnapshot().get(sessionId)?.pendingInteraction !== void 0) return void 0;
					return turnSource.getSnapshot();
				};
				const turn = currentTurn();
				if (turn === void 0) {
					reset();
					return;
				}
				input.consume();
				if (sequence.press({
					sessionId,
					turn,
					generation: binding,
					region,
					cancel: () => {
						cancel(sessionId);
					}
				})) return;
				const changed = () => {
					if (sessions.binding(sessionId) !== binding || currentTurn() !== turn) reset();
				};
				const disposers = [
					turnSource.subscribe(changed),
					binding.session.subscribe(changed),
					uiSession.sessionStatus.subscribe(changed)
				];
				unwatch = () => {
					for (const dispose of disposers) dispose();
				};
			});
			return () => {
				off();
				reset();
			};
		}
		//#endregion
		//#region lib/types/client/apply.js
		/** Services required by the Conversation plugin. */
		const inject = [
			"slots",
			"sessions",
			"fileUpload",
			"uiSession",
			"uiWorkspace",
			"locale",
			"configForms"
		];
		/** Validated Conversation runtime configuration. */
		const Config = Schema.object({ maxConcurrentFileUploads: Schema.natural().min(1).default(2) });
		const ABSENT_NOTICES = {
			getSnapshot: () => null,
			subscribe: () => () => {}
		};
		const ABSENT_BLOCK = {
			getSnapshot: () => void 0,
			subscribe: () => () => {}
		};
		const EMPTY_LEXICON = /* @__PURE__ */ new Map();
		const ABSENT_LEXICON = {
			getSnapshot: () => EMPTY_LEXICON,
			subscribe: () => () => {}
		};
		const ABSENT_MENU_LAUNCHER = {
			getSnapshot: () => null,
			subscribe: () => () => {}
		};
		const EMPTY_FILE_UPLOADS = {};
		const ABSENT_FILE_UPLOADS = {
			getSnapshot: () => EMPTY_FILE_UPLOADS,
			subscribe: () => () => {}
		};
		/** The shell-installed bridge, when this document runs inside the Desktop application. */
		function hostPathBridge() {
			return globalThis.__DSH_HOST_PATHS__;
		}
		/** Resolve the session-scoped Conversation action face, failing loud. */
		function scopedConversation(sessions, id) {
			const scoped = sessions.scope(id);
			if (scoped === void 0) throw new Error(`ui-conversation: session "${id}" resolved no scope`);
			const conversation = scoped.get("conversation");
			if (conversation === void 0) throw new Error("ui-conversation: conversation service unavailable through the session scope");
			return conversation;
		}
		/** Resolve package-internal attachment operations from the public service. */
		function concreteConversation(ctx) {
			const conversation = ctx.get("conversation");
			if (conversation === void 0) throw new Error("ui-conversation: conversation service unavailable");
			return conversation;
		}
		/**
		* Mount the Conversation core and target-neutral presentation.
		* @param ctx - Client root context.
		*/
		function apply(ctx, config = Config({})) {
			const sessions = ctx.sessions;
			const slots = ctx.slots;
			const maxConcurrentFileUploads = config.maxConcurrentFileUploads;
			const workspaceNavigation = ctx.get("uiWorkspace");
			const uiConversation = new UiConversation(ctx, sessions);
			uiConversation.userText.register(sessionReferenceRule);
			uiConversation.userText.register(collapseWhitespaceRule);
			uiConversation.userText.register(trimWhitespaceRule);
			slots.registerFactory({
				name: "conversation.user.text",
				scope: "session",
				children: { "conversation.user.text.node": {
					kind: "keyed",
					scope: "session",
					inline: true
				} },
				inject: () => ({
					hooks: { userTextRevision: {
						getSnapshot: () => uiConversation.userText.getSnapshot(),
						subscribe: (listener) => uiConversation.userText.subscribe(listener)
					} },
					createUserTextEvaluator: () => uiConversation.userText.createEvaluator(),
					reportTransformFailure: (error) => {
						console.error("[ui-conversation] user-text transformation failed:", error);
					}
				})
			}, UserText);
			slots.inject("conversation.user.text.node", function* () {
				yield slots.register({
					name: "conversation.user.text.node",
					key: "text",
					priority: 100
				}, PlainUserText);
				yield slots.register({
					name: "conversation.user.text.node",
					key: "session",
					priority: 100
				}, SessionReference);
			});
			ctx.effect(() => ctx.locale.register(NS, {
				zh,
				en,
				ja,
				es,
				fr,
				de,
				ru,
				pt
			}), "ui-conversation: dictionaries");
			const t = ctx.locale.bind(NS);
			const conversationStore = createConversationStore();
			const submissionPolicy = new ComposerSubmissionPolicy(ctx.configForms.get(CONVERSATION_SETTINGS_NAMESPACE));
			ctx.effect(() => () => {
				submissionPolicy.dispose();
			});
			ctx.slots.inject("settings.general.item", () => ctx.slots.register({
				name: "settings.general.item",
				id: "composer-enter",
				order: 20,
				locale: NS,
				inject: () => ({
					hooks: { busyEnter: submissionPolicy.busyEnter },
					setBusyEnter: (behavior) => {
						submissionPolicy.setBusyEnter(behavior);
					}
				})
			}, EnterBehaviorRow));
			const viewTabs = () => {
				const tabs = [];
				for (const entry of slots.entries("conversation.view")) {
					/* v8 ignore next -- list registration validates id at load. */
					if (entry.options.id === void 0) continue;
					if (!ctx.configForms.developerTools.enabled.getSnapshot() && entry.options.id === "trajectory") continue;
					tabs.push({
						id: entry.options.id,
						label: (0, _deepseek_ai_dsh_client_ui_slots.resolveSlotLabel)(entry.options.label) ?? entry.options.id
					});
				}
				return tabs;
			};
			const activateView = (sessionId, preferred) => {
				const active = resolveActiveView(viewTabs(), preferred);
				if (active !== void 0) uiConversation.binding(sessionId).activate(active.id);
			};
			const restoreView = (sessionId) => {
				activateView(sessionId, readConversationViewPreference(sessionId));
			};
			const conversationViews = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)(viewTabs());
			const viewPins = createViewPins();
			const viewActions = {
				getSnapshot: () => slots.entriesOfSlot("conversation.session.header.views.actions").length > 0,
				subscribe: (listener) => slots.subscribe("conversation.session.header.views.actions", listener)
			};
			const bindings = /* @__PURE__ */ new Set();
			const trackedBindings = /* @__PURE__ */ new WeakSet();
			const trackBinding = (binding) => {
				if (trackedBindings.has(binding)) return;
				trackedBindings.add(binding);
				bindings.add(binding);
				binding.ctx.effect(() => () => {
					bindings.delete(binding);
				}, "ui-conversation: active Provider binding");
			};
			const refreshViews = () => {
				const current = conversationViews.getSnapshot();
				const next = viewTabs();
				if (!(current.length === next.length && current.every((tab, index) => {
					const candidate = next.at(index);
					return candidate !== void 0 && tab.id === candidate.id && tab.label === candidate.label;
				}))) conversationViews.set(next);
				for (const binding of bindings) restoreView(binding.sessionId);
			};
			ctx.effect(() => {
				const disposeViews = slots.subscribe("conversation.view", refreshViews);
				const disposeLocale = ctx.locale.subscribe(refreshViews);
				const disposeDeveloperTools = ctx.configForms.developerTools.enabled.subscribe(refreshViews);
				return () => {
					disposeDeveloperTools();
					disposeLocale();
					disposeViews();
				};
			}, "ui-conversation: View selection");
			const stop = (sessionId) => {
				scopedConversation(sessions, sessionId).cancel().catch((_error) => {});
			};
			const stopShortcut = (0, _deepseek_ai_dsh_client_store.createSnapshotStore)([]);
			ctx.inject(["shortcuts"], (scope) => {
				const fixedInputs = [
					{
						id: "fixed.send",
						label: () => t("input.send"),
						keys: ["Enter"],
						bindings: [{
							code: "Enter",
							modifiers: []
						}],
						group: "input"
					},
					{
						id: "fixed.newline",
						label: () => t("shortcut.newline"),
						keys: scope.shortcuts.describeBinding({
							code: "Enter",
							modifiers: ["shift"]
						}).keys,
						bindings: [{
							code: "Enter",
							modifiers: ["shift"]
						}],
						group: "input"
					},
					{
						id: "fixed.complementary",
						label: () => t("shortcut.complementary"),
						keys: scope.shortcuts.describeBinding({
							code: "Enter",
							modifiers: ["primary"]
						}).keys,
						bindings: [{
							code: "Enter",
							modifiers: ["control"]
						}, {
							code: "Enter",
							modifiers: ["meta"]
						}],
						group: "input"
					},
					{
						id: "fixed.slash",
						label: () => t("shortcut.slash"),
						keys: ["/"],
						bindings: [{
							code: "Slash",
							modifiers: []
						}],
						group: "input"
					},
					{
						id: "fixed.mention",
						label: () => t("shortcut.mention"),
						keys: ["@"],
						bindings: [{
							code: "Digit2",
							modifiers: ["shift"]
						}],
						group: "input"
					}
				];
				for (const command of fixedInputs) scope.effect(() => scope.shortcuts.registerFixed(command), `ui-conversation: ${command.id}`);
				scope.effect(() => installStopShortcut(scope.shortcuts, sessions, (binding) => uiConversation.binding(binding).openTurn, ctx.uiSession, stop), "ui-conversation: fixed stop input");
				scope.effect(() => {
					const command = {
						id: "response.stop",
						label: () => t("input.stop"),
						keys: ["Esc", "Esc"],
						bindings: [{
							code: "Escape",
							modifiers: []
						}],
						group: "input"
					};
					const dispose = scope.shortcuts.registerFixed(command);
					stopShortcut.set(command.keys);
					return () => {
						stopShortcut.set([]);
						dispose();
					};
				}, "ui-conversation: fixed stop reference");
			});
			const inputHub = new InputHub(ctx, t);
			const composerBlocks = new ComposerBlockRegistry();
			ctx.inject(["commandUi"], (scope) => {
				const commands = scope.get("commandUi");
				scope.effect(() => commands.register({
					name: "file",
					label: () => t("input.file"),
					icon: _deepseek_ai_dsh_client_ui_primitives.IconPaperclipOutlineRegular,
					available: (session) => inputHub.canPickFiles(session.sessionId),
					ui: {
						kind: "action",
						run: (session) => {
							inputHub.pickFiles(session.sessionId);
						}
					}
				}), "ui-conversation: File action");
			});
			ctx.uiSession.provide({
				hooks: ["conversation", "input"],
				props: ["inputActions"],
				resolve: (binding) => {
					trackBinding(binding);
					const shell = inputHub.shellFor(binding);
					const conversation = uiConversation.binding(binding);
					restoreView(binding.sessionId);
					return {
						hooks: {
							conversation: conversation.snapshot,
							input: shell.state
						},
						props: { inputActions: shell.actions }
					};
				}
			});
			const registerConversationRoot = () => slots.register({
				name: "main.conversation",
				children: { "conversation.header": {
					kind: "single",
					scope: "session-maybe"
				} }
			}, ConversationRoot);
			const registerConversationContent = () => slots.registerFactory({
				name: "conversation.content",
				scope: "session-maybe",
				locale: NS,
				children: {
					"conversation.session": {
						kind: "single",
						scope: "session"
					},
					"conversation.composer": {
						kind: "chain",
						scope: "session"
					},
					"conversation.composer.bar": {
						kind: "single",
						scope: "session-maybe"
					},
					"conversation.input.dock": {
						kind: "list",
						scope: "session"
					},
					"conversation.hero.brand.mark": {
						kind: "single",
						scope: "root"
					},
					"conversation.hero.workspace": {
						kind: "single",
						scope: "root"
					},
					"conversation.hero.agentPreset": {
						kind: "single",
						scope: "session-maybe"
					},
					"conversation.hero.options": {
						kind: "list",
						scope: "session"
					}
				},
				slots: {
					views: { scope: "session" },
					widthControls: { scope: "root" }
				},
				inject: (sessionId) => ({
					hooks: { composerBlock: sessionId === void 0 ? ABSENT_BLOCK : composerBlocks.storeFor(sessionId) },
					selectWorkspace: (workspaceId) => workspaceNavigation.openWorkspace(workspaceId, (nextId) => {
						if (sessionId !== void 0 && nextId !== sessionId) {
							const from = inputHub.shell(sessionId);
							if (from.snapshot.phase !== "plain" && from.snapshot.phase !== "claimed") return;
							const draft = from.draftSnapshot;
							const attachmentIds = from.snapshot.attachmentIds;
							const next = inputHub.shell(nextId);
							if (attachmentIds.length === 0 || next.addAttachments(attachmentIds)) {
								const binding = sessions.binding(nextId);
								if (binding === void 0) throw new Error(`ui-conversation: session "${nextId}" resolved no binding`);
								const ordinary = binding.session.getSnapshot().subagent === null;
								concreteConversation(ctx).rebindDraftFiles(nextId, attachmentIds, ordinary);
								if (draft.text !== "") {
									next.setDraft(draft);
									from.setDraft("");
								}
								if (attachmentIds.length > 0) for (const id of attachmentIds) from.removeAttachment(id);
							}
						}
					})
				})
			}, ConversationContent);
			const registerConversationSession = () => slots.register({
				name: "conversation.session",
				children: { "conversation.view": {
					kind: "list",
					scope: "session"
				} },
				store: conversationStore,
				inject: (sessionId, actions) => {
					const openView = (view, focus) => {
						if (!viewTabs().some((tab) => tab.id === view)) return;
						activateView(sessionId, view);
						actions.openView(view, focus);
					};
					const inspectionTarget = () => uiConversation.views.entries().find((definition) => definition.toolCallFocus !== void 0 && conversationViews.getSnapshot().some((view) => view.id === definition.target));
					const inspectCall = (callId) => {
						const target = inspectionTarget();
						if (target?.toolCallFocus !== void 0) openView(target.target, target.toolCallFocus(callId));
					};
					return {
						hooks: {
							conversationViews,
							inspectCall: {
								getSnapshot: () => inspectionTarget() === void 0 ? void 0 : inspectCall,
								subscribe: (listener) => {
									const disposeViews = conversationViews.subscribe(listener);
									const disposeDefinitions = uiConversation.views.subscribe(listener);
									return () => {
										disposeViews();
										disposeDefinitions();
									};
								}
							}
						},
						bindDraftPersistence: (write) => inputHub.shell(sessionId).bindDraftPersistence(write),
						openView
					};
				}
			}, ConversationSession);
			const registerHeader = () => slots.register({
				name: "conversation.header",
				children: {
					"conversation.header.leading": {
						kind: "single",
						scope: "root"
					},
					"conversation.session.header": {
						kind: "single",
						scope: "session"
					}
				}
			}, ConversationHeader);
			const registerSessionHeader = () => slots.register({
				name: "conversation.session.header",
				locale: NS,
				children: {
					"conversation.session.header.lineage": {
						kind: "single",
						scope: "session"
					},
					"conversation.session.header.actions": {
						kind: "list",
						scope: "session"
					},
					"conversation.session.header.utilities": {
						kind: "list",
						scope: "session"
					},
					"conversation.session.header.corner": {
						kind: "single",
						scope: "session"
					},
					"conversation.session.header.views.actions": {
						kind: "list",
						scope: "root"
					}
				},
				store: conversationStore,
				inject: (sessionId, actions) => ({
					hooks: {
						conversationViews,
						entryPins: viewPins.unpinned,
						entryActions: viewActions
					},
					setPinned: viewPins.setPinned,
					open: (id) => {
						workspaceNavigation.openSession(id);
					},
					selectView: (view) => {
						activateView(sessionId, view);
						actions.setView(view);
					}
				})
			}, ConversationSessionHeader);
			const nativeComposerSpec = {
				name: "conversation.composer.bar",
				locale: NS,
				children: {
					"conversation.input.attachments": {
						kind: "single",
						scope: "session-maybe"
					},
					"conversation.input.overlay": {
						kind: "list",
						scope: "session"
					},
					"conversation.input.permission": {
						kind: "single",
						scope: "session"
					},
					"conversation.input.left": {
						kind: "list",
						scope: "session"
					},
					"conversation.input.plan": {
						kind: "single",
						scope: "session"
					},
					"conversation.input.right": {
						kind: "list",
						scope: "session"
					},
					"conversation.input.model": {
						kind: "single",
						scope: "session"
					},
					"conversation.input.activity": {
						kind: "single",
						scope: "session"
					},
					"conversation.composer.dock": {
						kind: "list",
						scope: "session"
					}
				},
				inject: (sessionId) => {
					if (sessionId === void 0) return {
						keyboard: void 0,
						addFiles: void 0,
						removeAttachment: void 0,
						resolveDraftAttachments: void 0,
						retryFileUpload: void 0,
						toggleCommandMenu: void 0,
						stop: void 0,
						hooks: {
							stopShortcut,
							busyEnter: submissionPolicy.busyEnter,
							fileUploads: ABSENT_FILE_UPLOADS,
							notices: ABSENT_NOTICES,
							lexicon: ABSENT_LEXICON,
							menuLauncher: ABSENT_MENU_LAUNCHER
						}
					};
					const conversation = concreteConversation(ctx);
					const shell = inputHub.shell(sessionId);
					const inputTriggers = inputHub.inputTriggers(sessionId);
					const bridge = hostPathBridge();
					return {
						keyboard: shell,
						addFiles: (files, directories = /* @__PURE__ */ new Set()) => {
							if (sessions.binding(sessionId) === void 0) return t("file.sessionUnavailable");
							const { phase } = shell.snapshot;
							if (phase === "adjudicating" || phase === "submitting" || phase === "sending") return t("attachment.dropBlocked");
							const uploads = [];
							const references = [];
							const cwd = sessions.list.getSnapshot().byId[sessionId]?.cwd;
							for (const file of files) {
								const directory = directories.has(file);
								if (bridge === void 0 && directory) return t("attachment.directoryDesktopOnly");
								const path = bridge?.pathFor(file) ?? "";
								if (directory && path === "") return t("attachment.pathUnavailable");
								if (path === "" || !directory && isImageMediaType(file.type)) {
									uploads.push(file);
									continue;
								}
								const relative = relativizeToCwd(path, cwd);
								const mention = formatFileMention({
									path: directory ? `${relative}/` : relative,
									kind: "file"
								}, false);
								if (mention === void 0) return t("attachment.pathUnsupported");
								const label = workspaceTitleOf(path) || file.name;
								references.push({
									source: "reference",
									ref: mention,
									label: directory ? `${label}/` : label,
									appearance: directory ? "folder" : "file",
									clipboardText: mention
								});
							}
							try {
								const ordinary = sessions.binding(sessionId)?.session.getSnapshot().subagent === null;
								const drafts = conversation.createDrafts(sessionId, uploads, ordinary);
								if (!shell.addFiles(references, drafts.map((draft) => draft.id))) {
									conversation.releaseDraftAttachments(drafts);
									return t("attachment.dropBlocked");
								}
								return null;
							} catch (error) {
								if (error instanceof UnsupportedImageMediaTypeError) return t("image.unsupportedType");
								return error instanceof Error ? error.message : String(error);
							}
						},
						removeAttachment: (id) => {
							if (shell.removeAttachment(id)) conversation.releaseDraftAttachment(id);
						},
						resolveDraftAttachments: (ids) => conversation.resolveDraftAttachments(ids),
						retryFileUpload: (id) => {
							if (sessions.binding(sessionId) !== void 0) conversation.retryFileUpload(sessionId, id);
						},
						toggleCommandMenu: inputTriggers === void 0 ? void 0 : (selection) => {
							shell.dismissPopup();
							const snapshot = shell.snapshot;
							inputTriggers.toggleSource("command", {
								trigger: "/",
								query: "",
								quoted: false,
								position: snapshot.draft.slice(0, selection.start).trim() === "" ? "leading" : "inline",
								span: {
									...selection,
									draftRev: snapshot.draftRev
								}
							});
						},
						stop: () => {
							stop(sessionId);
						},
						hooks: {
							stopShortcut,
							busyEnter: submissionPolicy.busyEnter,
							fileUploads: conversation.fileUploads,
							notices: shell.notices,
							lexicon: shell.lexicon,
							menuLauncher: inputTriggers?.launcher ?? ABSENT_MENU_LAUNCHER
						}
					};
				}
			};
            const registerComposerBar = () => slots.register({name:'conversation.composer.bar'},
                function NativeComposerSeat({renderFactorySlot,variant,blocked,disabled,workspacePickerOpen,onRequestWorkspace,placeholder,accessory}){
                    return renderFactorySlot('naumi.native.composer.bar',{variant,blocked,disabled,workspacePickerOpen,onRequestWorkspace,placeholder,accessory});
                });
            const registerSharedComposer = () => slots.registerFactory({
                ...nativeComposerSpec, name:'naumi.native.composer.bar', scope:'session-maybe'
            }, function SharedNativeComposer(props){
                const useNativeSession=props.useSession;
                const useSession=selector=>useNativeSession(s=>selector(s===void 0?s:{...s,running:props.groupBusy ?? s.running}));
                return (0, react_jsx_runtime.jsx)(InputBar,{...props,useSession});
            });
            const registerGroupComposer = () => slots.registerFactory({
                name:'naumi.group.composer',scope:'session',store:conversationStore,
                inject:sessionId=>({bindGroupDraft:write=>inputHub.shell(sessionId).bindDraftPersistence(write)})
            }, function GroupComposerBridge({renderFactorySlot,bindGroupDraft,actions,inputActions,groupBusy,placeholder,accessory}){
                (0,react.useEffect)(()=>{const unbind=bindGroupDraft(actions.setDraft);inputActions.persistDraft();return unbind;},[inputActions,actions]);
                return renderFactorySlot('naumi.native.composer.bar',{variant:'composer',groupBusy,placeholder,accessory});
            });
            slots.inject("main", function* () {
				yield slots.register({
					name: "main",
					key: "conversation",
					children: { "main.conversation": {
						kind: "single",
						scope: "session-maybe"
					} }
				}, ConversationPanel);
				yield registerConversationRoot();
				yield registerConversationContent();
				yield registerConversationSession();
				yield registerHeader();
				yield registerSessionHeader();
				yield registerSharedComposer();
                yield registerGroupComposer();
                yield registerComposerBar();
			});
			ctx.plugin(ConversationController, {
				input: inputHub,
				blocks: composerBlocks,
				maxConcurrentFileUploads
			});
			ctx.plugin(todoDockEntry);
			ctx.plugin(queueDockEntry);
		}
		//#endregion
		exports.Config = Config;
		exports.ConversationController = ConversationController;
		exports.ConversationDefinitionRegistry = ConversationDefinitionRegistry;
		exports.ConversationEventRegistry = ConversationEventRegistry;
		exports.ConversationLocationIndex = ConversationLocationIndex;
		exports.ConversationNodeAssembler = ConversationNodeAssembler;
		exports.ConversationViewRegistry = ConversationViewRegistry;
		exports.EMPTY_CONVERSATION_SNAPSHOT = EMPTY_CONVERSATION_SNAPSHOT;
		exports.UiConversation = UiConversation;
		exports.UnsupportedImageMediaTypeError = UnsupportedImageMediaTypeError;
		exports.apply = apply;
		exports.conversationPhase = conversationPhase;
		exports.inject = inject;
		exports.inspectRequestPrompt = inspectRequestPrompt;
		return module.exports;
	}
});

//# sourceMappingURL=client.js.map
# Naumi 数字员工 PRD

版本：1.0。日期：2026-11-16。状态：需求已定稿，分阶段实现。负责人：产品所有者确认需求，GPT-6.1 Sol 实施。

## 0. 阅读与交付约定

- 本文覆盖近期关于 Bot 员工化、长期记忆、心跳、性格、动态人物设定、协作、组织与本地优先的全部需求。
- 每项需求有 ID、优先级、归属、规则与验收条件。实现进度见 `DIGITAL_EMPLOYEE_DELIVERY.md`，不以本文存在代替功能完成。
- 当前代码基线：`290fea0`。已有 Bot 身份/目录/关联会话、同机跨 Bot 派单、结果回传、显式重试与重启恢复。
- 本期不改左侧导航、模型选择位置、浏览器集成或企业业务登录；新 UI 统一浅色、简洁，无营销标语。
- 验证层级区分：单元/真实本地容器与 HTTP/实际运行服务/真实模型/服务器部署/员工安装包，不互相替代。

## 1. 产品目标

Bot 是拥有稳定身份、职责、记忆、做事风格、协作关系与可核验交付的数字员工，而不是一条换名会话。

### 核心体验

1. 已有员工可以直接接任务；简单身份创建不再探索源码。
2. 新开会话、切换模型或重启客户端，不丢已持久化的员工身份和长期记忆。
3. 明确的长期偏好能跨任务使用，一次性指令不意外改写长期设定。
4. 主管调用已有员工，不用临时队友冒充现有员工。
5. 员工可主动关注已授权工作，但不通过无意义心跳持续调用模型。
6. 控制中心故障不导致本地资料、记忆、队列与工作区不可用。

### 非目标

- 不伪造人类经历、真实情绪、意识或已完成的业务操作。
- 不把人物设定当授权，不以模型自述代替外部业务回执。
- 不承诺网络分区时无限写入、实时撤权与无重复自动接管同时成立。
- 不把本地测试通过当服务器、跨租户、多设备或安装包上线。

## 2. 用户与角色

| 角色 | 主要操作 | 边界 |
| --- | --- | --- |
| 企业管理员 | 注册组织/设备、岗位、能力、预算、离线政策 | 管理本组织，不跨租户 |
| 直属主管 | 派单、反馈、验收、调整已授权工作习惯 | 不通过一句话提升工具权限 |
| 普通员工 | 与获准 Bot 协作、纠正个人偏好 | 不自动获得组织共享记忆管理权 |
| Bot 执行者 | 检索自身记忆、提出经验/设定候选、报告进度 | 只能基于明确身份和真实来源 |
| 审核者 | 批准/拒绝知识与人物设定变更 | 留审核记录和版本 |

本地现有 owner 登录态只代表单机所有者，不等于企业 RBAC 已实现。云端接入前使用显式 local-owner 数据域，禁止伪造 tenantId。

## 3. 生命周期与状态

### EMP-001 P0 稳定身份（本地＋服务端）
- UUID 与姓名、会话标题分离；一个 Bot 关联多个任务 Session。
- 人物设定、记忆、任务和交付引用稳定 Bot ID；改名不迁移身份。
- 验收：改名/新任务/重启后 ID 不变，历史任务仍可定位。

### EMP-002 P0 在职管理（服务端权威，本地副本）
- 人员状态：draft、active、paused、archived；初始化状态另列 uninitialized、initializing、ready、failed。
- 暂停接新任务不删除会话；归档不自动终止旧任务；终止执行必须明确调用任务取消。
- 第一阶段兼容现有 active/archived，不为 UI 好看强行做数据迁移。
- 验收：暂停/归档对象不接新派单，数据保留，恢复可审计。

### EMP-003 P1 调岗与离职交接
- 职责变更产生岗位版本；未完成任务逐项交接，保留原责任人和新责任人。
- 撤销工具凭证与停用身份分开记录；交付物归组织，不随 Bot 删除。

## 4. 员工档案、性格、人物设定

### PRO-001 P0 基础档案（本地可运行）
- 保存沟通风格 communicationStyle、做事方式 workStyle、性格 personality、人物设定 persona。
- 身份/岗位仍引用 Bot 目录；不重复维护两套名字与职责。
- 首次访问惰性创建空档案，不编造岗位经历、固定性格或人格量表分数。
- 验收：未配置字段为空，不以人设填充暗示不存在的能力。

### PRO-002 P0 显式修改与 CAS
- owner 可逐字段修改；请求携带 expectedRevision，冲突返回 409。
- 每次记录前值/后值、来源、操作者、时间、revision；相同值不重复写入。
- 不接受 model、apikey、approvalPolicy、permission 等越界字段。
- 验收：两次同 revision 写入仅一次成功，工具权限和模型配置不变。

### PRO-003 P0 锁定、自动学习开关
- owner 可锁定具体字段；关闭 autoLearning 后自动规则和模型学习提议停止，手工管理仍可用。
- 锁定字段不被会话自动更新；显式修改也需先解除锁定，不隐式绕过。
- 验收：锁定与关闭学习后输入同样指令，档案不漂移。

### PRO-004 P0 会话驱动成长
- 第一阶段识别单独的明确指令，例如“记住我的偏好：…”“以后回复先给结论”“以后回复简洁直接”。
- 只处理 source.kind=user 的真实文本消息；Agent relay、工具结果、网页、引用资料不作为人物设定指令。
- 以 messageId 去重；长期偏好写入 active memory；明确的回复风格可更新未锁定 communicationStyle。
- 推断性格/其他人设由模型提出 candidate，owner 审核后生效；不实现“模型认为自己变了就直接覆盖”。
- “这一次/本次/暂时”等临时限定不自动固化；复杂混合句第一阶段保持不自动更新。
- 验收：跨会话可见已确认偏好；临时要求、重复消息、relay 和任意工具文本不会污染档案。

### PRO-005 P0 版本恢复
- 恢复历史版本只恢复可配置字段，生成新 revision 与审计事件，不倒退事件序号。
- 需要当前 expectedRevision；与当前锁定字段冲突时拒绝，先解除锁定。
- 验收：恢复后新旧版本均可追溯，人物设定恢复不改变岗位/权限。

## 5. 记忆系统

### MEM-001 P0 分层记忆
- 类别：fact（已知事实）、preference（偏好）、experience（经历）、procedure（方法经验）、relationship（协作关系）。
- 状态：candidate、active、rejected、deleted；过期单独由 expiresAt 判断。
- 工作状态以任务账本为准，不用一条自然语言记忆替代权威执行状态。

### MEM-002 P0 来源与可信边界
- 每条包含 id、botId、kind、text、status、revision、createdAt、updatedAt、source、expiresAt、pinned。
- source 保存 sessionId/messageId/quote 或 owner 显式修改说明；不让 Agent 任意填写可信 user/owner 身份。
- Agent 提案必须引用其当前 Bot 根会话里真实用户消息的原文片段；不存在、越 Bot、非用户来源均拒绝。
- 模型提案默认 candidate，事实不因重复生成变成已确认事实。
- 验收：伪造 messageId、引用其他 Bot、用 relay 冒充用户均失败。

### MEM-003 P0 管理
- 创建、确认/拒绝、修正、固定、设置有效期、逻辑删除、导出均有审计和 CAS。
- 删除后检索和上下文不再包含内容；原始会话与审计保留遵循单独的数据保留策略，不声称物理抹除。
- 不提供“一键从旧版本复活删除内容”；恢复需 owner 明确重新创建。
- 验收：删除后新会话不注入该记忆；过期记录不注入。

### MEM-004 P0 本地检索
- 无网可用；第一版用 SQLite 持久化与本地关键词排序，不把云 embedding 作为启动依赖。
- 限定当前 Bot；先过滤 active/未过期，再按固定项、相关度、新近排序。
- 提供搜索工具和有界上下文注入，查询/长度/条数有上限；无匹配返回空结果，不编造回忆。
- 中文短语可搜索；不执行用户输入的 SQL/FTS 语法。
- 验收：跨 Bot 零泄漏，查询带 SQL 元字符仍为普通检索文本。

### MEM-005 P0 上下文使用
- 当前任务指令高于历史风格；记忆与人设以“历史数据/建议”传入，不作为更高优先级授权。
- 默认注入少量固定和近期 active 记忆；模型按需查询其他记忆，不全量塞历史。
- 密码、令牌、共享主 Key 不写入记忆/人设；明确敏感凭证模式拒绝录入，不能声称自动识别全部秘密。

### MEM-006 P1 企业共享与关系
- 记忆 scope=bot/private、project、organization，由组织 ACL 控制。
- 私人记忆晋升共享需审批；事实冲突保留来源与候选，不按最后写入覆盖。
- 关系描述基于协作事件与验收，不凭空生成“熟悉某员工”或影响权限。

### MEM-007 P1 整理与遗忘
- 任务完成/反馈事件触发候选提取；重复合并、冲突提示、过期清理分阶段执行。
- 摘要与索引可重建；原始事实记录和删除标记有独立保留策略。
- 批量导入先预览数量与来源，不自动扫描全部员工私人文件。

## 6. 心跳、主动性与任务节律

### HBT-001 P0 运行心跳
- 本地一个调度器，默认 30 秒更新运行快照；不为每个 Bot 启一个永久模型会话。
- 快照包含 sampledAt、runtimeState、activeBotCount、runningSessionCount、runningBotCount、staleAfterMs。
- 运行=执行器状态；心跳正常不证明任务有进展，心跳缺失不证明执行已停。
- 由程序完成，0 次 LLM 调用，卸载时清理 timer。

### HBT-002 P0 工作巡检基础
- 默认 5 分钟检查本地执行状态与档案/记忆统计；第一阶段只读观察，不自动重新派单、发布、取消或调用模型。
- 本机事件到达立即更新；timer 防重入、异常后可恢复，错误不伪装成健康快照。
- 每次结果有时间戳；读取 API 不伪造“刚刚心跳”。
- 验收：重复 tick 不产生任务、模型调用或人设变化；模块卸载后无新 tick。

### HBT-003 P1 主动工作
- 基于 owner 批准的 rule：触发事件/时间、Bot、适用范围、行动、预算、工作时间、冷却与幂等键。
- 无事项即静默；模型只参与需要判断的步骤。
- 静默时段不发普通提醒，紧急升级按明确规则。

### HBT-004 P1 长时间无进展
- 最后进展时间与心跳分开；等待用户、等待依赖、模型故障不计成同一种卡死。
- 先检测、再核验、再按策略提示；不因超时直接重复执行未知副作用。

## 7. 协作、工作与验收

### COL-001 P0 已有能力保留
- bot_directory → bot_dispatch → bot_task_wait；复用稳定身份，持久化收据去重。
- 本期增加记忆/人设后，每个目标任务仍只能加载目标 Bot 的数据。
- 验收：原 90 项核心回归继续通过，已有模型/权限不变。

### WRK-001 P1 长期目标与工作队列
- objective、milestone、priority、dueAt、dependencies、assigneeBotId、scope、status。
- 变更有 revision，依赖图拒绝循环；跨设备执行归属见 LOC-005。

### DEL-001 P1 交付与验收分离
- executionStatus 与 businessStatus 分开。
- businessStatus=draft/submitted/in_review/changes_requested/accepted/cancelled。
- 交付包含 artifact ID、版本、路径/对象存储引用、校验值、来源任务和验收条件。
- 审核者有身份与权限；退回保留理由；修改创建新交付版本。
- 验收：completed 仅执行结束，不自动变为 accepted；业务验收需明确操作。

### DEL-002 P1 复盘学习
- 由已确认验收反馈生成 procedure/experience candidate。
- 批准后新任务可检索，退回意见和工作事实不混为“性格差”。

## 8. 能力、组织与成本

### CAP-001 P1 能力清单
- installed、connected、authorized、healthy、lastChecked 分列；安装钉钉 CLI 不等于账号或操作权限已就绪。
- 缺项时返回具体缺资料/缺连接/缺授权，禁止先搜索源码“现场开发”替代已产品化能力。

### ORG-001 P1 企业 RBAC
- tenantId、owner、manager、requester、approver、deviceId 分开，Team lead 不是业务组织管理员。
- 所有共享数据读写检查 tenant/项目/资源权限；客户端不能提交任意 tenantId 提权。

### BUD-001 P1 成本与路由
- 按 Bot/任务/组织记录用量与费用；客户端统计不是权威计费。
- 预算、并发、重试次数与模型路由策略由服务端/网关约束；不静默切更贵模型。

## 9. 本地/服务端边界与故障

### LOC-001 P0 本地完整运行时
- 本机保存档案、记忆、会话与任务副本，先落盘、再同步。
- 新增员工结构化数据采用 SQLite WAL；不在本期粗暴迁移已有 bots.json/任务账本。
- 数据路径 `${DSH_HOME}/naumi/employees.sqlite`；不把工作树里的测试数据当员工运行数据。

### LOC-002 P1 同步与事件
- 事件字段：eventId、tenantId/domain、deviceId、aggregateId、baseRevision、kind、source、payload、occurredAt。
- 第一阶段本地仅有审计/outbox 待接入记录，syncState 明确为 local_only，不宣称已与服务端同步。
- 同步按 eventId 去重，删除使用 tombstone；冲突字段保留差异。
- 恢复先拉授权/撤权，再传事件和核对归属，不用旧缓存覆盖权威权限。

### LOC-003 P1 离线授权
- 首次企业登记联机；服务端签发包含组织/设备/范围/能力/期限的授权包。
- 设备密钥与凭证使用 OS 密钥存储；不打包企业主密钥。
- 过期后界面/历史保留与可执行操作分开；离线窗口明确反映撤权传播取舍。
- 时间回拨、撤权、设备复制均有专项测试。

### LOC-004 P1 独立模型通道
- 控制中心与模型网关独立故障域；已有有效凭证不逐句重新登录。
- 网关故障按预授权路由切换；本地模型须显式安装与能力验收。
- 控制中心故障而模型可达：已授权本地 AI 工作继续。
- 所有模型不可达：界面/队列/记录继续，推理步骤等待，不报虚假完成。

### LOC-005 P1 归属与防双执行
- local-bound、cloud-bound、portable-exclusive；记录 ownerDeviceId、attemptId、fencingToken。
- 失联不等于停止，服务端不因丢心跳直接重复分配本机副作用任务。
- 租约到期阻止需权威许可的提交；幂等业务键与 UNKNOWN 状态处理。

### LOC-006 P1 故障注入验收
- 关闭控制中心后本地启动、读取档案、修改偏好、人设版本与记忆检索继续。
- 模型不可达、断网、休眠、强杀重启、离线授权过期、消息 ACK 丢失、同步冲突分别测试。
- 服务恢复后不重复派单/提交；异常业务结果先核验原回执。

## 10. 管理界面与交互

### UX-001 P1 员工档案
- 员工详情提供“档案 / 记忆 / 工作 / 成长记录”；不改原模型选择位置。
- 人设字段支持编辑、锁定、候选确认、版本差异与恢复。
- 记忆支持搜索、类别/状态筛选、来源查看、修改、固定、过期、删除与导出。
- 展示“本地已保存 / 待同步 / 冲突 / 已同步”的真实状态，不用统一绿色遮掩。
- 空状态只给必要操作；浅色布局，不加无用标语。

### UX-002 P0 第一阶段可操作入口
- owner HTTP 管理 API 与 Agent 工具先落地；不把只有数据库表或静态原型称为可用。
- Agent 对明确偏好通过会话事件更新；其他候选由 owner API 管理。
- UI 完整管理页属下一阶段，状态在交付矩阵明确标注。

## 11. API 与工具契约（首阶段）

Base `/naumi/employees`，owner-only，GET/POST；写入需 `x-naumi-employees: 1` 与同源检查，body<=32KiB，严格 schema。

GET query：botId 必填；view=profile/memories/history/export/heartbeat；query、status、limit 有边界。

POST action：profile_update、profile_restore、memory_create、memory_update；botId、expectedRevision、operationId 与动作载荷。

工具：employee_profile、employee_memory_search、employee_memory_propose、employee_profile_propose。

- 工具根据真实 caller 的 root Session 定位 Bot，不收任意 botId。
- teammate 只读本 Bot；写候选仅 Lead；owner 管理不改变现有工具权限。
- 错误码 EMP_*，CAS/幂等冲突=409，身份/来源错误=403，验证错误=400，存储故障=503。
- 新建档案 revision=0；保存后递增。重复 operationId 同载荷返回首次结果，不同载荷拒绝。

## 12. 非功能要求

- 首阶段本地 profile/memory 查询与写入无网络依赖；heartbeat 0 LLM。
- 注入正文上限约 8Ki 字符；记录正文和数量有明确上限，不无界增长上下文。
- 数据写入、审计与待同步事件同 SQLite 事务；失败不返回成功。
- WAL + busy_timeout；事务只包含同步 DB 操作，不跨模型/网络 await。
- 未识别 schemaVersion 或损坏 DB fail closed，不自动重建为空库。
- 本机 SQLite 文件不等于加密存储；组织敏感数据加密、密钥轮转和导出策略列后续安全模块。
- 不输出 API Key、cookie、完整环境变量；证据不复制员工私人聊天全文。
- Git 保留原件 hash、修改副本、差异、验证、可执行回滚；回滚在副本测试，不删运行数据。

## 13. 首阶段验收矩阵

| Case | 需求 | 验收 |
| --- | --- | --- |
| AC-01 | PRO-001/LOC-001 | 空档案可读；跨进程 reopen 字段和 revision 保留 |
| AC-02 | PRO-002 | 并发同版本写一个成功；operationId 幂等，异载荷冲突 |
| AC-03 | PRO-003 | 锁定字段/关闭学习阻止自动漂移 |
| AC-04 | PRO-004 | 明确独立偏好自动记录；临时句/relay/引用不自动学习 |
| AC-05 | PRO-005 | 恢复历史生成新版本，权限和模型未变 |
| AC-06 | MEM-002 | 真实 user 来源通过，伪造/其他 Bot/relay 拒绝 |
| AC-07 | MEM-003 | 候选确认/拒绝/修正/删除/过期/固定均持久化 |
| AC-08 | MEM-004 | 中文搜索、字符边界、Bot 隔离、无匹配空结果 |
| AC-09 | MEM-005 | candidate/过期/删除不注入，注入有界，不含凭证样本 |
| AC-10 | HBT-001/002 | 真实快照、失效时间、防重入、0 模型/0 派单、卸载清理 |
| AC-11 | UX-002 | owner HTTP 真读写；guest/跨域/多余字段/超大请求拒绝 |
| AC-12 | COL-001 | 现有 Bot/Team/enterprise/跨 Bot 核心回归通过 |
| AC-13 | LOC-001 | 无服务端连接仍完成创建/检索/更新/重启与巡检 |
| AC-14 | 非功能 | 故障写入不发布成功；未知 DB 版本不清空；备份与回滚通过 |

## 14. 实施阶段与退出条件

### M1 本地连续性基础（现在开始）
PRO-001~005、MEM-001~005、HBT-001/002、LOC-001、UX-002。本阶段完整退出：核心 API/工具/会话事件/SQLite/注入/巡检接入 + AC-01~14 有证据。

### M2 管理界面与交付验收
UX-001、WRK-001、DEL-001/002，补齐可视化管理、候选审核、业务验收和复盘候选。

### M3 企业组织与同步
ORG-001、MEM-006/007、LOC-002/003：组织数据模型、RBAC、设备登记、签名离线授权、同步/冲突/删除、故障测试。

### M4 主动工作与分布式执行
HBT-003/004、CAP-001、BUD-001、LOC-004/005/006、EMP-002/003 扩展；独立模型通道、租约/fencing、预算、能力清单、主动规则。

### M5 员工安装包与发布
带 logo、内置经过打包验证的插件与浏览器、首次登记、升级迁移/回滚、安装包版本和 hash。密钥不进入包。以新设备安装验收，不以开发机运行代替。

阶段交付不得隐去未完成需求；服务端相关功能在服务器有实际实现、部署和故障证据前保持未完成。

## M4 本次验收增量（2026-11-16）

| 需求 | 本次状态 | 验收证据 / 后续门槛 |
| --- | --- | --- |
| HBT-003 | 本地确定性主动规则已接入 | owner审批/CAS/工作窗口/冷却/累计上限、原子通知/队列、真实timer与硬杀重启；受控模型主动执行在预算和全局运行门接通后继续 |
| HBT-004 | 基础观察已接入 | 真实artifact/review进展与Agent自报分列，等待/依赖/模型不可达/故障分开；不因超时重派 |
| CAP-001 | 能力清单与探针基础已接入 | 安装/连接/授权/健康/时间/过期独立；未核验项明确unknown；CLI真实bundle与各账号授权验收继续M5 |
| BUD-001/LOC-004 | 继续实施 | 权威预算、独立模型通道与AI主动执行未借本次0LLM规则冒充完成 |
| LOC-005/006 | 已有租约模块保留，本次补充进程恢复 | 实际租约/设备归属证据仍见EXECUTION_LEASES；本次197回归/12 UI/硬杀/副本回滚与实际3080只读验证见employee-activity证据目录 |

实现记录：`docs/implementation/EMPLOYEE_ACTIVITY_M4.md`；证据：`evidence/proactive-runtime/VERIFICATION.txt`。总目标active，M4/M5未整体退出。

## M4 受管执行准入验收增量（2026-11-16）

- LOC-005/006：从企业交稿端fencing继续接入真实步骤、模型流入口与工具最终guard；在途许可丢失先发取消再保存UNKNOWN，存储异常也不重新开放外部准入。已记录的running工具在真实进程重启后原子改为UNKNOWN，不重放。
- LOC-001/003：有效签名local.read/draft/infer与明确owner开关支持local_only；离线推理仍取决于可达模型通道。授权过期/绑定改变拒绝新推理，owner历史保留。
- COL-001：普通跨Bot能力保留；受管任务内独立派单/调度须使用显式的新任务/执行绑定，不能用于逃逸。真实团队/fork继承根准入。
- 212回归、8界面、真实AgentLoop/工具管线/签名HTTP故障、SIGKILL恢复、20项副本基线测试和实际3080只读接入通过。实现：EMPLOYEE_RUNTIME_GATE_M4.md；证据：evidence/runtime-gate/VERIFICATION.txt。
- BUD-001/LOC-004、受控主动AI编排及M5仍未退出；本地fixture模型不是独立网关/收费模型/生产企业或新员工安装验收。

## M4 企业模型与预算验收增量（2026-11-16）

- BUD-001：四级权威费用/Token/请求/并发预算已接入独立网关；派发前原子预留、usage结算、UNKNOWN不退款/不重放、明确停止后上界记账。旧月份UNKNOWN仍占全局并发。
- LOC-004：独立Node进程和独立账本、有效签名凭证直接调用、不逐句登录；复用原PiAiAdapter，保留模型选择位置。真实AgentLoop控制中心故障实验通过。
- 230 Harness/桌面、233企业端、10 UI、真实网关SIGKILL恢复、35+223项副本基线回归通过。7插件+5网关/启动+5企业/迁移文件实际接入，原业务数据及其他插件hash保持。
- 3183实际网关初始0供应商路由；实际3112签发与预算链使用明确test租户并清理，未发真实供应商请求。合同定价/真实路由/负责人启用、受控主动AI编排、M5仍继续，不以health或fixture代替员工安装与业务验收。
- 详见 EMPLOYEE_MODEL_GATEWAY_M4.md 和 evidence/model-gateway/VERIFICATION.txt；总目标active。

## HBT-003 受控主动AI验收增量（2026-11-17）

- 原子规则触发/入队/累计计数、批准nonce和配置快照、每规则一个未结束条目、24小时队列有效期、无事项0模型、原目标依赖/工作窗口/冷却保留。
- 既有AgentLoop/Native工具实际执行，既有Bot根会话按原preset/权限恢复；不新建替代员工，不重选模型；外部工具继续通过精确设备/任务/代次准入。
- 真实模型UUID和网关费用回执、实际不可变artifact/交付引用与回合结束分列；awaiting_review不是业务接受。原目标不自动完成。
- 人工消息优先、单次模型请求/执行时长上限、停止与撤销后的最终guard、原子记录失败、进程强杀UNKNOWN、负责人核对已验收。
- 251 Harness/桌面、233企业端、11 UI、SIGKILL和53项副本原行为通过，7插件实际3080增量接入。证据 evidence/proactive-ai/VERIFICATION.txt。
- 真实企业模型路由仍0、员工未自动登记或运行；M5安装包及真实员工/供应商验收继续，总目标active。

## M5.1 打包闭包与钉钉预装增量（2026-11-17）

- CAP-001：正式npm插件包补全M4运行文件和直接依赖声明；固定官方dingtalk-workspace-cli 1.0.68三层完整性、目标平台exe与LICENSE/NOTICE，不跑postinstall、不安装全局skills。既有工具审批/运行门保留，没有新增业务旁路。
- EMP/LOC安装基础：独立员工DWS配置与版本化原生组件缓存、内置Node/CLI launcher、禁继承开发者凭证、禁后台升级/使用追踪；readonly状态只证明本地账号存在，不推断远端在线权限。
- 268项Harness/桌面回归、251项副本恢复原行为和persona/memory/schema保留通过。正式运行树已生成70359文件hash清单；正式npm包、unpacked构建/启动结果以evidence/employee-package/VERIFICATION.txt最终记录为准。
- M5尚未退出：远程企业登录session桥、实例/端口隔离、升级/迁移/版本回退与NSIS真实安装链继续。实际3080数据未动，没有自动员工登记/上传/主动AI启用；真实网关路由与员工业务验收仍独立。

## M5.2 桌面生命周期验收增量（2026-11-17）

- 新员工默认standalone，不以相同Logo作为服务归属。独立profile身份/HMAC、精确PID/bundle、持久starting/ready与受控端口处理已实现；UNKNOWN不启动副本，旧bundle存活时不切其依赖。
- profileVersion1/identityProtocol1、私有工作区first-use事务、受管依赖journal/4阶段硬退出恢复、既有配置/真实SQLite/浏览器数据保留、实际bootstrap回执再导航、Windows worker独立生命周期、认证停机与退出重入门已验收。
- 293模块、268副本基线、正式npm72文件/ASAR3模块/resource6份源码一致性、真实双桌面profile/原生浏览器/正常重启/主进程硬杀原PID接回/实际退出通过；UNKNOWN数据为明确样例，真实模型与执行账本的强杀证据仍见M4，不混淆层级。
- 证据evidence/desktop-lifecycle/VERIFICATION.txt，细粒度INS-01~16见DESKTOP_LIFECYCLE_M5_2.md。未退出项：远程企业首次连接/归属边界、业务schema与安装版本迁移/回退、NSIS真实安装链、签名与依赖、真实员工/模型使用。总目标active。

## M5.3 首次企业连接与桌面会话桥增量（2026-11-17）

- 桌面实例协议2把HMAC绑定实际listener port、规范homeHash和企业origin；身份metadata保留v1 UUID/key，旧活worker拒绝自动降级附着，复制/搬迁home不隐式换身份或删除数据。
- 员工首次连接页配置HTTPS企业origin（本机loopback可HTTP），同profile禁止隐式跨企业切换。企业登录使用独立持久session；有限Bearer loopback桥只允许workspace GET、digital-employees GET/POST，不导出Cookie/Set-Cookie，不代理设备签名API。
- 组织/设备登记的proof、签名离线授权、企业RBAC和原设备通道继续权威；首次连接不会自动登记或上传私人记忆。企业会话过期、权限拒绝、未知网络结果不由应用自动回放mutation；POST携带原始operationId，原企业事务回执去重覆盖Chromium可能的网络重传，并以同一UUID核对未知结果。
- CAP-001：GUI桥出现/重启触发能力刷新；干净系统PATH下DPAPI改用固定绝对系统PowerShell。Windows回执rename短暂占用有界重试并保留原权威文件。
- 315项集中模块回归通过。独立双profile Electron、候选正式包/hash、原生浏览器/主进程硬杀接回及副本回滚最终结果按evidence/desktop-enterprise/VERIFICATION.txt记录。真实远程HTTPS员工授权、模型/供应商业务、NSIS安装/升级/卸载、业务schema/已安装版本回退及签名审查仍分别验收，不以本地fixture替代。

## M5.4 连接恢复与真实安装链增量（2026-11-17）

- LOC/EMP：首次URL错误、不可达或取消不再写入连接配置。已有配置不以企业健康作为本地启动前置条件；错误页/系统连接有修复入口。
- 企业切换采用独立userData子home和浏览器account，不覆盖旧origin/签名设备/私人记忆/缓存。版本1工作区active指针原子提交；旧单企业home原地兼容，无复制身份或自动登记。
- 活动任务/未知状态/在途桥操作拒绝切换；正常HMAC停止旧worker并观察退出后再选择新home。旧企业session/browser与人格记忆在返回时继续使用。
- 333项集中回归通过。实际unpacked A/B/A、离线重启与真实NSIS 0.2.0安装/0.2.1升级/0.2.0旧单企业profile降级/卸载证据以evidence/desktop-installation/VERIFICATION.txt及JSON结果为准；具体边界见DESKTOP_INSTALLATION_M5_4.md。
- 故障中安装quiesce、跨工作区旧版回退、业务schema迁移降级、发布签名/依赖、干净员工机与真实企业/供应商业务继续保留为明确门槛，完整目标active。

## 2026-11-17 已确认的默认交互

UX-EMP-001：普通用户不展示员工中心控制台、心跳参数、内部版本/ID、模型预算与同步配置。用户通过Bot菜单调整工作方式、查看记忆、忘记内容和恢复设置；高级管理按管理员身份按需加载。

UX-EMP-002：后台员工能力不随UI隐藏而停用。明确偏好可自动沉淀；推断人设/共享知识仍保留来源与确认，组织权限、预算、设备授权和业务验收仍由原权威方掌握。遗忘和档案恢复保持事务、字段锁、幂等、冲突保护和审计，不通过隐藏界面授予新权限。

实现与验收见 `../implementation/EMPLOYEE_INVISIBLE_EXPERIENCE.md`，不替代完整产品出口。

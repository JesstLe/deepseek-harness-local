import {createBotAvatar} from './bot-avatar.js';
import {EXPERIENCE_EVENT,EXPERIENCE_ACTIONS,advancedEmployeeAccess} from './employee-experience-model.js';
import {taskActivity,employeeTaskState,employeeTasks,receptionTarget} from './bot-task-model.js';
import {MODE_KEY,navigationMode,botActivity,botSessions,botSummary,botTone,newBotTaskRequest,botCatalog,currentSessionId,botSelected} from './bot-sidebar-model.js';
import {CHAT_PANEL,CHAT_EVENT,PIN_KEY,groupCatalog,conversationRows,roomPreview,roomWorking} from './bot-chat-model.js';

export function installBotSidebar(ctx,React,Icon,createPortal){
  return ctx.inject(['remote.session'],scope=>installNavigation(scope,React,Icon,createPortal));
}
function installNavigation(ctx,React,Icon,createPortal){
  const h=React.createElement,{useState,useEffect,useLayoutEffect,useRef,useSyncExternalStore}=React,source=botCatalog(),activity=taskActivity(),groups=groupCatalog(),Avatar=createBotAvatar(React);
  function BotRow({bot,props,pinned,onPin}){
    const {useSessions,useSessionStatus,usePanelInfo,useWorkspaces}=props;
    const sessions=useSessions(s=>s),status=useSessionStatus(s=>s),workspaces=useWorkspaces(s=>s),panelId=usePanelInfo(s=>s.activePanelId),currentId=currentSessionId(sessions,panelId);
    const [history,setHistory]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(null),[unbound,setUnbound]=useState(null),[menu,setMenu]=useState(null),[advanced,setAdvanced]=useState(false),menuButton=useRef(null),menuRef=useRef(null),alive=useRef(true),flight=useRef(false);
    useEffect(()=>{alive.current=true;return()=>{alive.current=false;};},[]);
    useEffect(()=>{if(!menu)return;const abort=new AbortController();setAdvanced(false);void advancedEmployeeAccess(globalThis.fetch,abort.signal).then(value=>{if(!abort.signal.aborted)setAdvanced(value);});menuRef.current?.querySelector('button')?.focus({preventScroll:true});const close=()=>setMenu(null),pointer=e=>{if(!menuRef.current?.contains(e.target)&&!menuButton.current?.contains(e.target))close();},key=e=>{if(e.key==='Escape'){e.preventDefault();close();menuButton.current?.focus({preventScroll:true});}else if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){const buttons=[...menuRef.current.querySelectorAll('button')],index=buttons.indexOf(document.activeElement),next=e.key==='Home'?0:e.key==='End'?buttons.length-1:(index+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;e.preventDefault();buttons[next]?.focus({preventScroll:true});}else if(e.key==='Tab')close();};document.addEventListener('pointerdown',pointer);document.addEventListener('keydown',key);window.addEventListener('resize',close);window.addEventListener('wheel',close,{passive:true});return()=>{abort.abort();document.removeEventListener('pointerdown',pointer);document.removeEventListener('keydown',key);window.removeEventListener('resize',close);window.removeEventListener('wheel',close);};},[menu]);
    const openSettings=mode=>{setMenu(null);window.dispatchEvent(new CustomEvent(EXPERIENCE_EVENT,{detail:{bot,mode}}));};
    const jobs=useSyncExternalStore(activity.subscribe,activity.getSnapshot,activity.getSnapshot);
    const target=receptionTarget(bot,jobs.tasks,sessions,workspaces),state=jobs.status==='ready'?employeeTaskState(bot,jobs.tasks,botActivity(bot,sessions,status)):botActivity(bot,sessions,status),rows=botSessions(bot,sessions,workspaces);
    const active=employeeTasks(bot,jobs.tasks).active.filter(t=>t.targetBotId===bot.id);
    const stateName={running:'工作中',starting:'准备中',waiting:'待你确认',queued:'排队中',idle:'待命',unknown:'待同步'}[state];
    const open=id=>{setError(null);try{ctx.layout.beginNavigation?.();ctx.uiWorkspace.openSession(id);}catch{setError('任务暂未就绪');}};
    const newTask=async()=>{
      if(flight.current)return;flight.current=true;setBusy(true);setError(null);let id=unbound;
      try{
        if(!id){const response=await ctx.remote.session.create(newBotTaskRequest(bot,workspaces));if(!response.ok)throw Error('BOT_CREATE_SESSION_FAILED');id=response.value.sessionId;if(alive.current)setUnbound(id);}
        await source.bind(bot,id);if(alive.current){setUnbound(null);open(id);setHistory(true);}
      }catch(error){if(alive.current)setError(error.message==='BOT_CONFLICT'?'Bot 已更新，请重试关联':error.message==='BOT_ARCHIVED'?'Bot 已归档':'任务关联失败，可重试或在线程模式查看');}
      finally{flight.current=false;if(alive.current)setBusy(false);}
    };
    return h('div',{className:'naumi-bot-entry','data-bot-id':bot.id,'data-pinned':!!pinned,'data-selected':botSelected(bot,currentId,sessions),'data-bot-state':state},
      h('div',{className:'naumi-bot-row'},h('button',{type:'button',className:'naumi-bot-open',onClick:()=>{if(target)open(target);else{setHistory(true);setError('日常会话已归档，可新建聊天');}},'aria-label':bot.name+'，'+stateName,title:bot.name},h(Avatar,{bot,state}),h('span',{className:'naumi-bot-caption'},h('strong',null,bot.name),h('span',null,state!=='idle'&&state!=='unknown'?stateName:botSummary(bot,sessions))),state!=='idle'&&state!=='unknown'&&h('span',{className:'naumi-bot-state',title:stateName,'aria-label':stateName})),
        active.length>0&&h('button',{type:'button',className:'naumi-bot-current','aria-label':'查看'+bot.name+'的当前任务（'+active.length+'）',title:'查看当前任务',onClick:()=>{const task=active[0];if(sessions.byId[task.targetSessionId])open(task.targetSessionId);else{setHistory(true);if(target)open(target);}}},active.length),
        h('button',{ref:menuButton,type:'button',className:'naumi-bot-menu-toggle','aria-label':bot.name+'的设置','aria-haspopup':'menu','aria-expanded':!!menu,onClick:e=>{const r=e.currentTarget.getBoundingClientRect();setMenu(v=>v?null:{left:Math.max(8,Math.min(window.innerWidth-205,r.left)),top:Math.max(8,Math.min(window.innerHeight-240,r.bottom+5))});}},'⋯'),h('button',{type:'button',className:'naumi-bot-history-toggle','aria-label':bot.name+'的任务记录','aria-expanded':history,onClick:()=>setHistory(v=>!v)},'⌄')),
      menu&&createPortal(h('div',{ref:menuRef,className:'nx-bot-menu',role:'menu','aria-label':bot.name+'的设置',style:menu},h('button',{type:'button',role:'menuitem',onClick:()=>{onPin(pinned?null:bot.id);setMenu(null);}},pinned?'取消置顶':'置顶'),[...EXPERIENCE_ACTIONS,...(advanced?[['advanced','高级管理']]:[])].map(([mode,label])=>h('button',{type:'button',key:mode,role:'menuitem','data-advanced':mode==='advanced'||undefined,onClick:()=>openSettings(mode)},label))),document.body),
      h('div',{className:'naumi-bot-history',hidden:!history},h('div',{className:'naumi-bot-history-head'},h('span',null,'任务记录'),h('button',{type:'button',className:'naumi-bot-link',disabled:busy,onClick:newTask},busy?'创建中…':unbound?'重试关联':'+ 新任务')),rows.length?rows.slice().reverse().map(row=>h('button',{type:'button',key:row.sessionId,className:'naumi-bot-task-link','aria-current':row.sessionId===currentId?'page':undefined,onClick:()=>open(row.sessionId)},h(Icon,{name:'chat',size:13}),h('span',null,sessions.projectionsBySession[row.sessionId]?.values.title??row.projections?.values?.title??'新任务'))):h('p',{className:'naumi-bot-empty'},'暂无可打开的任务')),
      error&&h('div',{className:'naumi-bot-error',role:'alert'},error,unbound&&h('button',{type:'button',className:'naumi-bot-link',disabled:busy,onClick:newTask},'重试关联')));
  }
  function Navigation(props){
      const [mode,setMode]=useState(()=>{try{return navigationMode(localStorage.getItem(MODE_KEY));}catch{return 'threads';}}),[search,setSearch]=useState(''),[error,setError]=useState(null);
      const [pinned,setPinned]=useState(()=>{try{return localStorage.getItem(PIN_KEY);}catch{return null;}}),[adding,setAdding]=useState(false),addRef=useRef(null),lastNative=useRef(null);
      const roomState=useSyncExternalStore(mode==='bot'?groups.subscribe:()=>()=>{},groups.getSnapshot,groups.getSnapshot),panel=props.usePanelInfo(s=>s.activePanelId),sessions=props.useSessions(s=>s);
      const sessionId=currentSessionId(sessions,panel);if(sessionId)lastNative.current=sessionId;
      const [surface,setSurface]=useState(null),[wide,setWide]=useState(true);
      const catalog=useSyncExternalStore(source.subscribe,source.getSnapshot,source.getSnapshot);
      useLayoutEffect(()=>{
        let target=null,resize=null,children=null,disposed=false;
        const detach=()=>{resize?.disconnect();children?.disconnect();if(target){target.classList.remove('naumi-navigation');delete target.dataset.naumiNavSurface;delete target.dataset.navigationMode;delete target.dataset.wide;for(const child of target.children)delete child.dataset.naumiThreadContent;}};
        const find=()=>{
          if(disposed||target?.isConnected)return;
          const next=document.querySelector('[data-slot="sidebar.workspaces"]');if(next===target)return;
          detach();target=next;setSurface(next);if(!target)return;
          target.classList.add('naumi-navigation');target.dataset.naumiNavSurface='true';
          const mark=()=>{for(const child of target.children)if(!child.hasAttribute('data-naumi-navigation-owned'))child.dataset.naumiThreadContent='true';};
          mark();children=new MutationObserver(mark);children.observe(target,{childList:true});
          const measure=()=>setWide(target.getBoundingClientRect().width>=100);resize=new ResizeObserver(measure);resize.observe(target);measure();
        };
        find();const observer=new MutationObserver(find);observer.observe(document.getElementById('root')??document.body,{childList:true,subtree:true});
        return()=>{disposed=true;observer.disconnect();detach();};
      },[]);
      useLayoutEffect(()=>{if(surface){surface.dataset.navigationMode=mode;surface.dataset.wide=String(wide);}},[surface,mode,wide]);
      useEffect(()=>{const change=e=>{if(e.key===MODE_KEY)setMode(navigationMode(e.newValue));};window.addEventListener('storage',change);return()=>window.removeEventListener('storage',change);},[]);
      const choose=value=>{setMode(value);setAdding(false);try{localStorage.setItem(MODE_KEY,value);}catch{}if(value==='threads'&&panel===CHAT_PANEL){if(lastNative.current)ctx.uiWorkspace.openSession(lastNative.current);else ctx.layout.selectPanel('naumi-workbench');}};
      useEffect(()=>{const change=()=>choose('bot');window.addEventListener(CHAT_EVENT,change);return()=>window.removeEventListener(CHAT_EVENT,change);},[panel]);
      useEffect(()=>{if(!adding)return;const close=e=>{if(e.type==='keydown'&&e.key!=='Escape')return;if(e.type!=='keydown'&&addRef.current?.contains(e.target))return;setAdding(false);};document.addEventListener('pointerdown',close);document.addEventListener('keydown',close);return()=>{document.removeEventListener('pointerdown',close);document.removeEventListener('keydown',close);};},[adding]);
      const pin=id=>{setPinned(id);try{if(id)localStorage.setItem(PIN_KEY,id);else localStorage.removeItem(PIN_KEY);}catch{}};
      const bots=catalog.bots.filter(bot=>bot.status==='active'&&(!search||bot.name.toLocaleLowerCase().includes(search.toLocaleLowerCase())));
      const create=()=>{setError(null);try{ctx.uiWorkspace.startSession(undefined,{prompt:'请根据我的需求创建一个可长期复用的 Bot（独立智能体或团队），由你自主确定名称与职责，并使用 bot_create 保存身份。不要预置固定岗位，也不要执行尚未确认的业务操作。\n\n我的需求：',whenDraftExists:'append'});}catch{setError('请先选择一个工作区');}};
      if(!surface)return null;
      return createPortal(h(React.Fragment,null,
        h('div',{className:'naumi-navigation-switch','data-naumi-navigation-owned':true,role:'group','aria-label':'导航模式'},h('button',{type:'button','aria-pressed':mode==='threads',onClick:()=>choose('threads'),title:'线程模式'},wide?'线程':h(Icon,{name:'chat',size:16})),h('button',{type:'button','aria-pressed':mode==='bot',onClick:()=>choose('bot'),title:'Bot 模式'},wide?'Bot':h(Icon,{name:'spark',size:16}))),
        h('div',{className:'naumi-bot-navigation','data-naumi-navigation-owned':true,hidden:mode!=='bot'},h('div',{className:'naumi-bot-toolbar',ref:addRef},wide&&h('label',{className:'naumi-bot-search'},h(Icon,{name:'search',size:14}),h('input',{'aria-label':'搜索对话',placeholder:'搜索',value:search,onChange:e=>setSearch(e.target.value)})),h('button',{type:'button',className:'naumi-bot-add','aria-label':'新建对话','aria-haspopup':'menu','aria-expanded':adding,onClick:()=>setAdding(v=>!v)},'+'),adding&&h('div',{className:'naumi-chat-add-menu',role:'menu'},h('button',{type:'button',role:'menuitem',onClick:()=>{setAdding(false);create();}},'新增员工'),h('button',{type:'button',role:'menuitem',onClick:()=>{setAdding(false);groups.select(ctx,roomState.selected,{create:true});}},'新建群聊'))),
          catalog.status==='loading'&&catalog.bots.length===0&&h('p',{className:'naumi-bot-empty',role:'status'},wide?'读取中…':'…'),
          ['error','forbidden'].includes(catalog.status)&&h('div',{className:'naumi-bot-error',role:'alert'},wide?(catalog.status==='forbidden'?'请重新连接工作空间':'Bot 目录读取失败'):'!',h('button',{type:'button',className:'naumi-bot-link',onClick:()=>source.refresh()},'重试')),
          catalog.status==='ready'&&bots.length===0&&h('div',{className:'naumi-bot-empty',role:'status'},wide&&h('span',null,search?'没有匹配的 Bot':'暂无 Bot'),!search&&wide&&h('button',{type:'button',className:'naumi-bot-create',onClick:create},'创建 Bot')),
          roomState.status==='error'&&h('button',{type:'button',className:'naumi-bot-link',onClick:()=>groups.refresh()},'群列表重试'),
          conversationRows(catalog.bots,roomState.rooms,search,pinned).map(row=>row.kind==='bot'?h(BotRow,{key:row.id,bot:row.bot,props,pinned:row.pinned,onPin:pin}):h('div',{key:row.id,className:'naumi-bot-entry naumi-group-entry','data-group-id':row.id,'data-selected':panel===CHAT_PANEL&&roomState.selected===row.id,'data-bot-state':roomWorking(roomState.details[row.id])?'running':'idle'},h('button',{type:'button',className:'naumi-bot-open',onClick:()=>groups.select(ctx,row.id),'aria-label':row.name,title:row.name},h('span',{className:'naumi-group-avatar','aria-hidden':true},row.room.members.slice(0,4).map(m=>{const bot=catalog.bots.find(b=>b.id===m.botId);return bot?h(Avatar,{key:m.botId,bot,staticPreview:true}):null;})),h('span',{className:'naumi-bot-caption'},h('strong',null,row.name),h('span',null,roomPreview(row.room,catalog.bots,roomState.details[row.id]))),roomWorking(roomState.details[row.id])&&h('span',{className:'naumi-bot-state','aria-label':'正在协作'})))),error&&h('p',{className:'naumi-bot-error',role:'alert'},error))),surface);
  }
  // Additive overlay registration: the native workspace parent keeps sole ownership of all child slots.
  return ctx.slots.inject('shell.overlay',()=>ctx.slots.register({name:'shell.overlay',id:'naumi-navigation-modes',order:90},Navigation));
}

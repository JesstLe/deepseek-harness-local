# 总目标：Naumi 数字员工完整交付

建立日期：2026-11-16。状态：active。实施模型：GPT-6.1 Sol。

本文件对应用户明确提出的“制定目标完整推进”，不把单个阶段交付当成总目标完成。

## 阶段与退出门槛

- M1 本地员工连续性：已实现并本地接入，156 项回归、真实跨会话记忆与回滚已验证。
- M2 员工中心、目标、交付验收：本地模块已实现，166 项回归和 20 项界面操作通过；实际页面/接口已接入。文本版本与 local-owner 验收已验证，企业资产/组织审批权威将在 M3 接入。
- M3 企业组织、共享记忆、同步、离线授权：核心已实现并接入本地实际服务；206 项企业端/166 项 Harness 回归与双设备故障链通过。MEM-007 已补齐确定性预览/精确合并/过期整理/候选导入；企业任务/私有资产/原生审核验收桥已接入，214 企业端与178 Harness 回归通过；local-owner 与企业验收保持分离。
- M4 主动规则、能力、预算、模型通道与分布式归属：执行归属/设备绑定/租约/fencing 模块已接入；223 企业端/183 Harness/18 UI、真实双设备过期/旧代次验证通过。能力清单/进展观察/确定性主动规则已接入实际3080，197项回归/12 UI/真实硬杀恢复/副本回滚通过；受管会话全局步骤/模型/工具门已接入实际3080，212项回归/8 UI/硬杀UNKNOWN/20项副本回滚通过；权威预算、独立模型通道与受控AI主动执行继续。
- M5 桌面安装包：待最终集成；logo、预装插件、首次登录、升级/迁移/回滚与安装验收。

## 执行规则

1. 保护其他工作树及运行版未提交改动；只同步已核验的增量文件。
2. 每个完整模块后集中测试；进度写回实现记录与验收矩阵。
3. 总目标维持 active，直至所有必要阶段验收完成；需要外部配置的项按真实证据记录。
4. 本机验收、服务端部署与员工使用验收分别记录；不以代码已提交代替上线。

## 当前接续

M3 核心已接入实际 naumi-design-ops（3112），不是旧 naumi-co；详见 docs/implementation/EMPLOYEE_SYNC_M3.md。当前真实设备未登记、上传关闭。MEM-007 与原生企业工作桥已接入，详见 ENTERPRISE_WORK_BRIDGE.md。M4 执行归属模块已接入，详见 EXECUTION_LEASES_M4.md。能力/运行观察/本地主动规则详见 EMPLOYEE_ACTIVITY_M4.md；受管运行门详见 EMPLOYEE_RUNTIME_GATE_M4.md；下一权威预算/独立模型通道/受控AI主动执行，再 M5 安装包；总目标 active。

## M4 企业模型与预算增量

独立模型网关、签名短期设备凭证、企业/员工/Bot/任务权威预留与真实usage结算、UNKNOWN上界核对、受管会话模型准入和模型管理UI已实现。230 Harness/桌面、233企业端、10 UI与独立进程强杀/重放0已通过。接入及副本回滚证据见 evidence/model-gateway；详见 EMPLOYEE_MODEL_GATEWAY_M4.md。真实供应商路由与负责人预算启用不以空路由health代替，受控主动AI与M5继续，总目标active。

## M4 受控主动 AI 增量

owner确认的run_agent规则、原子持久队列、原AgentLoop/Native工具消费、精确turn/网关UUID/不可变产物、人工输入抢占、请求/时长/工作窗口上限与UNKNOWN恢复/核对已实现并接入实际3080。251 Harness/桌面、233企业端、11 UI、真实SIGKILL及53项副本基线回归通过；7插件增量、其他hash不变。真实AI规则启用0、设备未登记、网关真实路由0。详见 EMPLOYEE_PROACTIVE_AI_M4.md 与 evidence/proactive-ai/VERIFICATION.txt；下一M5安装包完整集成及真实模型/员工使用验收，总目标active。

## M5.1 正式包完整性与钉钉预装增量

修复正式npm包漏M4运行模块与直接peer声明，增加AST/实物pack/import闭包；内置官方dingtalk-workspace-cli 1.0.68固定完整性/许可证、员工独立配置与可写原生缓存、无开发PATH launcher、真实readonly能力观察和Naumi技能。staging逐文件hash/私有状态路径扫描，默认build重stage，beforePack拒绝陈旧/追加/损坏资源。268项本地回归及251项副本回滚通过，实际3080仍62sessions/0running/3bots/revision10，没有接入或改员工数据。本模块的正式包与unpacked桌面构建/启动证据在evidence/employee-package持续记录，详见EMPLOYEE_PACKAGING_M5.md。

下一M5.2：profile实例与端口隔离、受管依赖junction升级、可配置远程企业首次登录/session桥、数据迁移/版本回退；随后NSIS干净安装/升级/卸载、员工授权与真实业务验收。总目标active，不以unpacked启动代替安装验收，不以本地CLI已内置代替企业授权或真实模型路由。

## M5.2 实例与依赖生命周期验收增量

独立实例HMAC/持久回执/端口竞争处理、真实引导URL就绪、私有默认工作区注册、受管junction事务/4阶段硬退出恢复、Windows独立worker及认证退出/重入门已实现。293项回归、268项副本恢复、正式npm包72文件、打包ASAR/resource源码一致性通过；真实双profile/native浏览器、正常重启、Electron主进程SIGKILL后原worker PID接回、正常退出及persona/memory/schema1保留通过。详见DESKTOP_LIFECYCLE_M5_2.md及evidence/desktop-lifecycle/VERIFICATION.txt。

下一M5.3：远程企业首次连接/session桥、endpoint/home归属边界与首次能力刷新；再业务数据/安装版本迁移回退、NSIS实际安装升级卸载、签名/依赖审查和真实员工/供应商使用。当前实际3080仍原服务，本增量不自动注册或启用员工。总目标active。
